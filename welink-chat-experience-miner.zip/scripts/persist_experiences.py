#!/usr/bin/env python3
"""Validate Skill JSONL and save locally or upsert to the experience engine."""
import argparse
import json
import os
from pathlib import Path
from urllib.parse import quote
import urllib.request


def load_records(path):
    records = []
    for number, line in enumerate(Path(path).read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        value = json.loads(line)
        if not isinstance(value, dict):
            raise ValueError(f"第 {number} 行不是 JSON 对象")
        operation = value.get("operation")
        if operation not in ("create", "update"):
            raise ValueError(f"第 {number} 行 operation 必须是 create 或 update")
        required = ("title", "summary", "experience")
        if any(not isinstance(value.get(k), str) or not value[k].strip() for k in required):
            raise ValueError(f"第 {number} 行缺少 title/summary/experience")
        if operation == "update" and not str(value.get("doc_id") or "").strip():
            raise ValueError(f"第 {number} 行 update 缺少 doc_id")
        records.append(value)
    return records


def request(method, url, payload):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=body, method=method,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as response:
        return json.loads(response.read().decode("utf-8"))


def main():
    p = argparse.ArgumentParser(description="保存或写入经验 JSONL")
    p.add_argument("--input", required=True)
    p.add_argument("--mode", choices=("local", "cloud"), default="local")
    p.add_argument("--output-dir", default="D:/CoreInsight/skill-output")
    p.add_argument("--endpoint", default=os.environ.get("EXPERIENCE_ENDPOINT", "https://fuyao.rnd.huawei.com"))
    p.add_argument("--user-id", default=os.environ.get("COREINSIGHT_UPLOAD_BY", os.environ.get("USERNAME", "unknown")))
    p.add_argument("--scene-id", default="251")
    p.add_argument("--scene", default="问题定位数据飞轮")
    args = p.parse_args()
    records = load_records(args.input)
    if args.mode == "local":
        target = Path(args.output_dir); target.mkdir(parents=True, exist_ok=True)
        destination = target / "experiences.jsonl"
        destination.write_text("\n".join(json.dumps(x, ensure_ascii=False) for x in records) + ("\n" if records else ""), encoding="utf-8")
        print(json.dumps({"ok": True, "mode": "local", "count": len(records), "output": str(destination)}, ensure_ascii=False))
        return
    results = []
    base = args.endpoint.rstrip("/") + "/memory/experience/doc"
    for record in records:
        payload = {"user_id": args.user_id, "title": record["title"], "summary": record["summary"], "experience": record["experience"], "scene_id": str(record.get("scene_id") or args.scene_id), "scene": record.get("scene") or args.scene}
        if record.get("rag_search_text"):
            payload["rag_search_text"] = record["rag_search_text"]
        if record.get("metadata") is not None:
            payload["metadata"] = record["metadata"]
        if record["operation"] == "update":
            url, method = f"{base}/{quote(str(record['doc_id']), safe='')}", "PUT"
        else:
            url, method = base, "POST"
        response = request(method, url, payload)
        if response.get("code") not in (None, 200):
            raise RuntimeError(response.get("msg") or str(response))
        data = response.get("data") or {}
        results.append({"operation": record["operation"], "doc_id": data.get("doc_id") or data.get("id") or record.get("doc_id"), "title": record["title"]})
    print(json.dumps({"ok": True, "mode": "cloud", "items": results}, ensure_ascii=False))


if __name__ == "__main__":
    main()
