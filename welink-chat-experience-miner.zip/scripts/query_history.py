#!/usr/bin/env python3
"""Export WeLink history to Markdown without downloading or processing images."""
import argparse
import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path


def run_cli(args, timeout):
    try:
        result = subprocess.run(["welink-cli", *args], capture_output=True,
                                text=True, encoding="utf-8", errors="replace",
                                timeout=timeout)
    except FileNotFoundError as exc:
        raise RuntimeError("未找到 welink-cli，请先安装并登录 WeLink CLI") from exc
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError("welink-cli 查询超时") from exc
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or f"welink-cli 退出码 {result.returncode}")
    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"welink-cli 返回内容不是合法 JSON：{exc}") from exc
    if str(data.get("resultCode", "0")) != "0":
        raise RuntimeError(data.get("resultContext") or "WeLink 查询失败")
    return data.get("respData") or {}


def parse_time(value):
    if not value:
        return 0
    return int(datetime.strptime(value, "%Y-%m-%d %H:%M:%S").timestamp() * 1000)


def fetch(selector, source_id, start_ms, end_ms, count, timeout):
    cursor = ""
    seen = set()
    messages = {}
    while True:
        args = ["im", "query-history-message", selector, source_id,
                "--query-count", str(count)]
        if cursor:
            # WeLink CLI: direction=0 means messages earlier than message-id.
            args += ["--message-id", cursor, "--query-direction", "0"]
        body = run_cli(args, timeout)
        rows = body.get("chatInfo") or []
        if not rows:
            break
        times = []
        for row in rows:
            msg_id = str(row.get("msgId") or "")
            timestamp = int(row.get("serverSendTime") or 0)
            if timestamp:
                times.append(timestamp)
            if not msg_id or (start_ms and timestamp < start_ms) or (end_ms and timestamp > end_ms):
                continue
            messages[msg_id] = row
        if start_ms and times and min(times) < start_ms:
            break
        next_cursor = str(body.get("minMsgId") or "")
        if not next_cursor:
            next_cursor = min((str(x.get("msgId")) for x in rows if x.get("msgId") is not None),
                              default="", key=lambda x: int(x))
        if not next_cursor or next_cursor in seen or len(rows) < count:
            break
        seen.add(next_cursor)
        cursor = next_cursor
    return sorted(messages.values(), key=lambda x: (int(x.get("serverSendTime") or 0), str(x.get("msgId") or "")))


def render(rows, source_label):
    lines = [f"# WeLink 聊天记录：{source_label}", ""]
    for row in rows:
        timestamp = int(row.get("serverSendTime") or 0)
        when = datetime.fromtimestamp(timestamp / 1000).strftime("%Y-%m-%d %H:%M:%S") if timestamp else ""
        sender = str(row.get("sender") or "")
        receiver = str(row.get("receiver") or "")
        msg_id = str(row.get("msgId") or "")
        content = str(row.get("content") or "")
        lines += [f"### {sender}（{when}）", f"消息 ID：{msg_id}", f"接收方：{receiver}", "", content, ""]
    return "\n".join(lines).rstrip() + "\n"


def main():
    parser = argparse.ArgumentParser(description="导出 WeLink 历史聊天记录 Markdown")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--group-id")
    group.add_argument("--user-account")
    parser.add_argument("--start", help="起始时间：YYYY-MM-DD HH:MM:SS")
    parser.add_argument("--end", help="结束时间：YYYY-MM-DD HH:MM:SS")
    parser.add_argument("--output", required=True, help="Markdown 输出路径")
    parser.add_argument("--query-count", type=int, default=100)
    parser.add_argument("--timeout", type=int, default=60)
    args = parser.parse_args()
    start_ms, end_ms = parse_time(args.start), parse_time(args.end)
    if start_ms and end_ms and start_ms > end_ms:
        parser.error("--start 不能晚于 --end")
    selector, source_id = (("--group-id", args.group_id) if args.group_id else ("--user-account", args.user_account))
    rows = fetch(selector, source_id, start_ms, end_ms, max(1, min(100, args.query_count)), args.timeout)
    target = Path(args.output)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(render(rows, source_id), encoding="utf-8")
    print(json.dumps({"ok": True, "count": len(rows), "output": str(target)}, ensure_ascii=False))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(1)
