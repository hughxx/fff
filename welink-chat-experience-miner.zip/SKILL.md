---
name: welink-chat-experience-miner
description: 获取 WeLink 群聊或用户历史消息，导出 UTF-8 Markdown，并按用户指定 Prompt 提取结构化工程经验；支持将结果保存到本地 JSONL 或写入 CoreInsight 经验引擎。适用于不需要前端页面、OCR、图片处理或 file-server 的聊天记录经验提取任务。
---

# WeLink 聊天经验提取

## 工作边界

- 只处理 `welink-cli` 返回的文本聊天记录；不要下载、OCR、上传或解析图片、文件和卡片附件。
- 所有时间使用 `YYYY-MM-DD HH:MM:SS`；未指定起点时从最新消息向历史方向分页，直到没有更早消息。
- 不要把完整聊天正文直接拼进远程请求；先落盘 Markdown，再由 Skill/模型读取文件。

## 三阶段流程

### 1. 获取 WeLink 消息

确认 `welink-cli` 已安装并登录。按来源二选一：

- 群聊：`--group-id <group_id>`
- 单聊/用户：`--user-account <account>`

执行 `scripts/query_history.py` 导出 Markdown。例如：

```bash
python scripts/query_history.py --group-id 986359484802794599 \
  --start "2026-08-01 00:00:00" --end "2026-08-31 23:59:59" \
  --output "D:/CoreInsight/skill-output/welink.md"
```

脚本使用 `query-count=100` 分页；第一页不传游标，后续使用上一页 `minMsgId` 和 `--query-direction 0` 获取更早消息。按 `msgId` 去重，按发送时间升序输出，并保留 sender、receiver、时间、消息 ID、contentType 和原始文本。

### 2. 提取经验

读取导出的 Markdown。默认提取要求：忽略寒暄和无事实内容，识别背景、问题、现象、分析过程、根因、解决方案、验证结果和注意事项；只依据聊天事实，不得编造。

用户提供 Prompt 时，将其作为提取规则补充或替代默认规则。对超长 Markdown 按完整消息边界分块读取，禁止拆开单条消息；跨块内容需要合并后再判断经验边界。

输出必须是 UTF-8 JSONL，每行一个对象，不要 Markdown 代码围栏：

```json
{"operation":"create","title":"简洁标题","summary":"完整经验正文","experience":"结构化 Markdown 剧本","rag_search_text":"关键词","scene_id":"251","scene":"问题定位数据飞轮"}
```

已有经验时输出 `operation=update` 并携带真实 `doc_id`，同时输出合并后的完整 `summary` 和 `experience`；不得重复创建同一经验。没有可沉淀内容时输出空 JSONL，不生成占位经验。

### 3. 保存或写入

先用 Python JSON 解析逐行校验输出，再根据用户选择执行：

- 本地：使用 `scripts/persist_experiences.py --mode local`，保存到指定目录的 `experiences.jsonl`。
- 云端：使用 `--mode cloud`，默认调用 `https://fuyao.rnd.huawei.com/memory/experience/doc`；`create` 使用 POST，`update` 使用 `PUT /memory/experience/doc/{doc_id}`。

云端写入所需用户账号通过 `--user-id` 或环境变量 `COREINSIGHT_UPLOAD_BY` 提供，不要硬编码密码或 API Key。`rag_search_text` 为空时省略；场景默认 `scene_id=251`、`scene=问题定位数据飞轮`。

示例：

```bash
python scripts/persist_experiences.py --input output/experiences.jsonl \
  --mode local --output-dir "D:/CoreInsight/skill-output"
python scripts/persist_experiences.py --input output/experiences.jsonl \
  --mode cloud --user-id w00899061
```

## 失败处理

- 找不到 `welink-cli`：停止流程并提示安装、登录，不伪造数据。
- CLI 非零退出、超时或返回非法 JSON：保留错误信息并停止当前获取阶段。
- 时间范围非法：提示起始时间不能晚于结束时间。
- 云端单条写入失败：报告失败的行号和接口响应，不把失败记录标记为成功。
- 本地保存始终不依赖 OCR、file-server、Hermes、前端页面或数据库连接。

## 资源

- `scripts/query_history.py`：WeLink CLI 分页和 Markdown 导出。
- `scripts/persist_experiences.py`：JSONL 校验及本地/云端保存。
