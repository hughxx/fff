﻿@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"

set "PORT=8080"

where py >nul 2>nul
if %errorlevel%==0 (
    start "Knowledge UI Server" /min py -m http.server %PORT% --bind 127.0.0.1
    goto open_browser
)

where python >nul 2>nul
if %errorlevel%==0 (
    start "Knowledge UI Server" /min python -m http.server %PORT% --bind 127.0.0.1
    goto open_browser
)

echo.
echo 未检测到 Python，无法启动本地服务。
echo 请先安装 Python 3，并勾选 Add Python to PATH。
echo.
pause
exit /b 1

:open_browser
timeout /t 1 /nobreak >nul
start "" "http://127.0.0.1:%PORT%/"
exit /b 0