# 知识资产驾驶舱

根据目录中的页面草图与 UI 风格参考实现。

直接打开 `index.html`，或运行：

```powershell
python -m http.server 8080
```

访问 `http://localhost:8080`。