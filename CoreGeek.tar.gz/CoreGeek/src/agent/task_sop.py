"""Task discovery and evidence-based guidance; generated code runs in the sandbox."""

from __future__ import annotations

import json
import re
import shlex


CONTEXT_PREFIX = "__CG_TASK_CONTEXT__"


def discovery_command(text: str, *, search_root: str = "/tmp") -> str | None:
    # The platform supplies a basename, not a stable task number/workspace path.
    names = set(re.findall(r"(?<![A-Za-z0-9_./-])(task_[A-Za-z0-9_-]+\.md)(?![A-Za-z0-9_.-])", text))
    if len(names) != 1:
        return None
    filename = names.pop()
    program = '''import json, os, pathlib, time
filename = FILENAME
root = pathlib.Path(SEARCH_ROOT).resolve()
started = time.monotonic()
matches = set()
complete = True
for index, (directory, dirs, files) in enumerate(os.walk(root, followlinks=False)):
    if index >= 2500 or time.monotonic() - started > 5:
        complete = False
        break
    dirs.sort()
    if filename in files:
        candidate = (pathlib.Path(directory) / filename).resolve()
        if candidate.is_relative_to(root):
            matches.add(candidate)
    if len(matches) > 1:
        break
result = {'status': 'missing', 'searchComplete': complete}
if len(matches) > 1:
    result['status'] = 'ambiguous'
elif not complete:
    result['status'] = 'search-limit'
elif len(matches) == 1:
    task = matches.pop()
    remaining = 30000
    def read_document(path):
        global remaining
        limit = min(12000, remaining)
        with path.open('rb') as stream:
            data = stream.read(limit + 1)
        remaining -= min(limit, len(data))
        return {'path': str(path), 'text': data[:limit].decode('utf-8-sig', errors='replace'),
                'truncated': len(data) > limit}
    result = {'status': 'ready', 'task': read_document(task), 'documents': []}
    directories = [task.parent]
    # Immediate workspace children only; never infer a workspace from its number.
    directories += sorted(p for p in task.parent.iterdir() if p.is_dir() and not p.is_symlink())[:24]
    for directory in directories:
        for name in ('spec.md', 'API_DOCS.md'):
            path = (directory / name).resolve()
            if path.is_relative_to(task.parent) and path.is_file() and remaining > 0:
                result['documents'].append(read_document(path))
    result['entries'] = sorted(p.name for p in task.parent.iterdir())[:40]
print(PREFIX + json.dumps(result, ensure_ascii=False))
'''.replace("FILENAME", repr(filename)).replace("SEARCH_ROOT", repr(search_root)).replace("PREFIX", repr(CONTEXT_PREFIX))
    return "python3 -c " + shlex.quote(program)


def read_context(result: str) -> str:
    for line in result.splitlines():
        if line.startswith(CONTEXT_PREFIX):
            try:
                value = json.loads(line[len(CONTEXT_PREFIX):])
            except (ValueError, RecursionError):
                return ""
            if isinstance(value, dict) and value.get("status") == "ready" and len(line) <= 40000:
                return json.dumps(value, ensure_ascii=False)
    return ""


TASK_GUIDANCE = (
    "先阅读题目正文再判断题型，不根据 task_1/task_2 或文件名猜题型。以下是流程参考，具体路径、字段、城市、"
    "正确配置和提交结构必须来自本题。taskContext 是本任务首次读取的题目和文档，跨轮保留；truncated=true 时需定向补读。"
    "每次 executeCmd 都是独立 shell，文件修改在本任务内保留，但工作目录和 shell 变量不保留，必须显式 cd 到已确认的绝对路径。"
    "只能使用 execute 命令或 answer JSON，不能输出 python_runner/read_file 等 XML 伪工具。不要同时猜测尚未返回的命令结果。\n"
    "修复部署题：读取题目指定工作区的 spec.md，合并修复缺失目录、配置内容、脚本和权限；只改题目要求的文件。"
    "然后在该工作区运行 ./check，根据实际错误定向修复，未观察到错误不要盲目重写检查器。若确认 CRLF/shebang 问题，"
    "修复相应行尾或用已确认的解释器运行。只有检查实际成功且输出 TOKEN: 值时，提交 {\"token\":\"实际值\"}，"
    "不要把示例 xxx、占位符或打印过的命令当作 TOKEN。拿到有效 TOKEN 后直接返回答案，无需再次列目录或重复修复。\n"
    "API 查询题：读取 API_DOCS.md，允许请求题目指定的 localhost/127.0.0.1 沙盒服务；不需要外网或安装依赖。"
    "用 Python 标准库 urllib.request/json，设置超时，按实际响应修正文档中过时的参数、字段或认证方式。"
    "查询全部分页，核对城市过滤、总数和唯一记录，防止忽略分页或重复计数。统计字段严格按题目定义，"
    "例如 oldest_era 若要求遗产名称就提交名称，不提交年代；数字保留 JSON 数字类型，列表保留数组类型。"
    "不套用固定城市、端口、答案或猜测数据。\n"
    "其他题型：按正文完成并验证，不强行使用 ./check 或 API 流程。输出聚焦必要证据；命令失败后先修正失败原因。"
)
