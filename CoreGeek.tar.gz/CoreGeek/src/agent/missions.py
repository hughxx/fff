from __future__ import annotations
import json,re
from .protocol import distance

class MissionDesk:
    def __init__(self): self.active=""; self.prompted=-1
    def advance(self,w,plan):
        actor=w.pioneer; task=str(w.raw.get("phaseTask") or ""); model=str(w.raw.get("llmResp") or ""); result=str(w.raw.get("lastCmdResult") or "")
        if task and actor:
            if task!=self.active:
                self.active=task
                script="import pathlib,json;fs=sorted(pathlib.Path('.').rglob('*.md'));print(json.dumps([{'file':str(p),'text':p.read_text(encoding='utf-8',errors='replace')} for p in fs],ensure_ascii=False))"
                return "","python3 -c "+json.dumps(script)
            answer=self.decode(model)
            if "taskAnswer" in answer:
                value=answer["taskAnswer"]; value=value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,separators=(",",":"))
                plan.add(actor,"submitAnswer",taskAnswer=value); return "",""
            if answer.get("executeCmd"): return "",str(answer["executeCmd"])
            if w.round!=self.prompted:
                self.prompted=w.round
                return self.prompt(task,result,model),""
            return "",""
        self.active=""
        if not actor or not w.daylight:return "",""
        candidates=[x for x in w.tasks if x.valid and x.cooldown<=0]
        if candidates:
            target=min(candidates,key=lambda x:distance(actor.pos,x.pos)).pos
            if 0<distance(actor.pos,target)<=1: plan.add(actor,"acceptTask")
            else: plan.walk(actor,target)
        return "",""
    @staticmethod
    def decode(text):
        options=[text]; match=re.search(r"\{.*\}",text,re.S)
        if match:options.append(match.group(0))
        for item in options:
            try:
                value=json.loads(item)
                if isinstance(value,dict):return value
            except Exception:pass
        return {}
    @staticmethod
    def prompt(task,result,previous):
        return f'''Solve only the current official task from its text and real command output. The topic, filenames, API contract, variables, answer schema and checker can change; derive all of them from evidence.
Reply with exactly one JSON object. Use {{"executeCmd":"one complete shell command"}} while work remains, or {{"taskAnswer":<exact submitAnswer value>}} once verified. Use Python standard library only. For HTTP tasks derive auth and parameters, handle 401/400, fetch every page and deduplicate IDs. For repair tasks edit a copy and run the named checker. Do not use prose or markdown fences.
TASK:\n{task[-12000:]}\nLAST OUTPUT:\n{result[-12000:]}\nPREVIOUS OUTPUT:\n{previous[-2500:]}'''
