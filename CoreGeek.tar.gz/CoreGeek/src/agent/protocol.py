from __future__ import annotations
from collections import Counter
from dataclasses import dataclass
from typing import Any

ACTORS={"worker","pioneer"}; GUNS={"rocket","gatling","railgun"}; ORES={"stone","iron","copper"}
RANGES={"rocket":(10,15,999),"gatling":(3,5,7),"railgun":(6,8,10)}

@dataclass(frozen=True,order=True,slots=True)
class Pos:
    x:int; y:int
    @classmethod
    def load(cls,v:Any): return cls(int(v["x"]),int(v["y"]))
    def wire(self): return {"x":self.x,"y":self.y}

def distance(a:Pos,b:Pos): return max(abs(a.x-b.x),abs(a.y-b.y))
def around(p:Pos): return tuple(Pos(p.x+dx,p.y+dy) for dx in (-1,0,1) for dy in (-1,0,1) if dx or dy)
def points(xs): return [p.wire() for p in xs]

@dataclass(slots=True)
class Unit:
    id:int; kind:str; pos:Pos; hp:int; level:int; cooldown:int; reach:int; bag:Counter; capacity:int; target:str=""
    @classmethod
    def load(cls,r):
        kind=str(r.get("roleType") or ""); level=max(1,int(r.get("level") or 1)); reach=int(r.get("attackRange") or 0)
        if not reach and kind in RANGES: reach=RANGES[kind][min(level,3)-1]
        default=100 if kind=="worker" else 40 if kind=="pioneer" else 0
        cap=r.get("backPackCapability")
        return cls(int(r.get("id") or 0),kind,Pos.load(r["pos"]),int(r.get("health") or 0),level,int(r.get("cooldown") or 0),reach,Counter(map(str,r.get("backpack") or ())),int(cap if cap is not None else default),str(r.get("targetTeam") or ""))
    @property
    def free(self): return max(0,self.capacity-self.bag.total())
    @property
    def max_hp(self):
        if self.kind=="station": return 1500*self.level
        if self.kind in GUNS or self.kind=="wall": return 500+500*self.level
        return 220 if self.kind=="worker" else 200

@dataclass(slots=True)
class Task:
    pos:Pos; valid:bool; cooldown:int

class Turn:
    def __init__(self,payload):
        self.raw=payload; self.round=int(payload.get("roundNo") or 1); self.tick=(self.round-1)%130; self.day=(self.round-1)//130+1; self.daylight=self.tick<70
        info,own=payload["mapInfo"],payload["teamOur"]
        self.width,self.height=int(info["width"]),int(info["height"]); self.side=str(own.get("type") or ""); self.gold=int(own.get("goldNum") or 0)
        self.zones={Pos.load(z["pos"]):str(z["neutralType"]) for z in info.get("zones") or ()}
        self.ours=[Unit.load(x) for x in own.get("roles") or () if int(x.get("health") or 0)>0]
        self.enemies=[Unit.load(x) for x in (payload.get("teamEnemy") or {}).get("roles") or () if int(x.get("health") or 0)>0]
        self.robots=[Unit.load(x) for x in (payload.get("robot") or {}).get("roles") or () if int(x.get("health") or 0)>0]
        self.tasks=[Task(Pos.load(x["taskPosition"]),bool(x.get("isValid")),int(x.get("coldDownRounds") or 0)) for x in own.get("playerTasks") or ()]
        self.shop={str(x["name"]):int(x["price"]) for x in payload.get("weaponShopList") or ()}; self.vendor={str(x["name"]):int(x["price"]) for x in payload.get("vendorShopList") or ()}
        self.actors=sorted((u for u in self.ours if u.kind in ACTORS),key=lambda u:u.id); self.workers=[u for u in self.actors if u.kind=="worker"]
        self.pioneer=next((u for u in self.actors if u.kind=="pioneer"),None); self.station=next((u for u in self.ours if u.kind=="station"),None)
        self.towers=sorted((u for u in self.ours if u.kind in GUNS),key=lambda u:u.id); self.walls=[u for u in self.ours if u.kind=="wall"]
    def zone(self,name): return [p for p,v in self.zones.items() if v==name]
    def inside(self,p): return 0<=p.x<self.width and 0<=p.y<self.height
    def land(self,p): return self.inside(p) and self.zones.get(p,"land")=="land"
    def base_cells(self):
        if not self.station:return ()
        p=self.station.pos; return (p,Pos(p.x+1,p.y),Pos(p.x,p.y-1),Pos(p.x+1,p.y-1))
    def base_distance(self,p): return min((distance(p,q) for q in self.base_cells()),default=999)
    def blocked(self,actor):
        cells={p for p,z in self.zones.items() if z!="land"}; cells.update(u.pos for u in self.ours+self.enemies if u.id!=actor.id); cells.update(u.pos for u in self.robots); cells.update(self.base_cells()); cells.discard(actor.pos); return cells
