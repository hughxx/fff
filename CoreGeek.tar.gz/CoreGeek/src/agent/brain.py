from typing import Any
from .grid import next_step
from .missions import MissionDesk
from .protocol import GUNS,ORES,Pos,Turn,around,distance,points

MISSIONS=MissionDesk()
class Plan:
    def __init__(self,w):self.w=w;self.actions={};self.claimed=set();self.money=w.gold
    def add(self,u,action,**kw):
        if str(u.id) in self.actions:return False
        self.actions[str(u.id)]={"action":action,**kw};return True
    def adjacent(self,a,p):return a.pos!=p and distance(a.pos,p)<=1
    def walk(self,a,target):
        goals=sorted((p for p in around(target) if self.w.inside(p) and p not in self.w.blocked(a)),key=lambda p:(distance(a.pos,p),p))
        for goal in goals:
            if goal==a.pos:return True
            step=next_step(self.w,a,goal)
            if step and step not in self.claimed:self.claimed.add(step);return self.add(a,"move",targetPos=points([step]))
        return False
    def use(self,a,name,target):
        p=target.pos if hasattr(target,"pos") else target
        return self.add(a,"use",name=name,targetPos=points([p]))

def decide(payload:dict[str,Any]):
    w=Turn(payload);p=Plan(w);prompt,shell=MISSIONS.advance(w,p)
    daylight(w,p) if w.daylight else night(w,p)
    return {"roleCommandMap":p.actions,"prompt":prompt,"executeCmd":shell}

def daylight(w,p):
    existing={u.pos for u in w.towers}; occupied={u.pos for u in w.ours+w.enemies}
    for actor in [u for u in w.workers if str(u.id) not in p.actions]:
        missing=next((x for x in tower_sites(w) if x not in existing and x not in occupied),None)
        if missing is not None and p.money>=25:
            occupied.add(missing)
            if p.adjacent(actor,missing) and p.add(actor,"build",name="rocket",targetPos=points([missing])):p.money-=25;existing.add(missing);occupied.add(missing)
            else:p.walk(actor,missing)
            continue
        if maintain(w,p,actor) or shopping(w,p,actor) or walling(w,p,actor):continue
        earning(w,p,actor)

def maintain(w,p,a):
    hurt=sorted((x for x in w.walls if x.hp<x.max_hp*.55),key=lambda x:x.hp/x.max_hp)
    if a.bag["WallFixer"] and hurt:return p.use(a,"WallFixer",hurt[0]) if p.adjacent(a,hurt[0].pos) else p.walk(a,hurt[0].pos)
    for t in sorted(w.towers,key=lambda x:x.level):
        voucher=f"WeaponUpgradeVoucher{t.level}"
        if t.level<3 and a.bag[voucher]:return p.use(a,voucher,t) if p.adjacent(a,t.pos) else p.walk(a,t.pos)
    return False

def shopping(w,p,a):
    shops=w.zone("weaponShop")
    if not shops:return False
    item="";ready=len(w.towers)==3 and min((x.level for x in w.towers),default=0)>=2
    if ready and not a.bag["Bomb"] and p.money>=w.shop.get("Bomb",10**9)+20:item="Bomb"
    else:
        tower=next((x for x in sorted(w.towers,key=lambda q:q.level) if x.level<3),None)
        if tower:
            name=f"WeaponUpgradeVoucher{tower.level}"
            if not a.bag[name] and p.money>=w.shop.get(name,10**9)+100:item=name
        if not item and sum(x.bag["WallFixer"] for x in w.workers)<2 and p.money>=w.shop.get("WallFixer",10**9)+100:item="WallFixer"
    if not item:return False
    shop=min(shops,key=lambda x:distance(a.pos,x))
    if p.adjacent(a,shop) and p.add(a,"buy",name=item,num=1):p.money-=w.shop[item];return True
    return p.walk(a,shop)

def walling(w,p,a):
    if not a.bag["stone"]:return False
    occupied={x.pos for x in w.ours};target=next((x for x in wall_sites(w) if x not in occupied and x not in p.claimed),None)
    if target is None:return False
    p.claimed.add(target)
    return p.add(a,"build",name="wall",targetPos=points([target])) if p.adjacent(a,target) else p.walk(a,target)

def earning(w,p,a):
    carried=[(n,a.bag[n]) for n in ORES if a.bag[n]];vendors=w.zone("vendor")
    if carried and (a.free<10 or a.bag["copper"]>=10) and vendors:
        target=min(vendors,key=lambda x:distance(a.pos,x))
        if p.adjacent(a,target):
            name,amount=max(carried,key=lambda x:w.vendor.get(x[0],0));return p.add(a,"sell",name=name,num=amount)
        return p.walk(a,target)
    wanted="stone" if len(w.walls)<len(wall_sites(w)) else "copper";mines=w.zone(wanted) or [x for n in ORES for x in w.zone(n)]
    if not mines or a.free<=0:return False
    target=min(mines,key=lambda x:distance(a.pos,x))
    return p.add(a,"collect",targetPos=points([target])) if p.adjacent(a,target) else p.walk(a,target)

def night(w,p):
    threats=[r for r in w.robots if not r.target or r.target==w.side];actors=list(w.actors)
    for a in actors:
        if a.bag["Bomb"] and threats:
            center,value=best_center(threats,100)
            if center and value>=12 and p.use(a,"Bomb",center):break
    free=[a for a in actors if str(a.id) not in p.actions]
    for tower in w.towers:
        if not free:break
        actor=min(free,key=lambda a:distance(a.pos,tower.pos))
        if not p.adjacent(actor,tower.pos):p.walk(actor,tower.pos);free.remove(actor);continue
        if tower.cooldown:free.remove(actor);continue
        live=[r for r in threats if distance(tower.pos,r.pos)<=tower.reach]
        if not live:continue
        count=1 if tower.kind=="railgun" else tower.level;targets=[]
        for _ in range(count):
            center,_=best_center(live,20 if tower.kind=="rocket" else 10)
            if center:targets.append(center)
        if targets and p.add(tower,"attack",controllerId=str(actor.id),targetPos=points(targets)):free.remove(actor)

def best_center(robots,damage):
    weights={"smallRobot":1,"middleRobot":2,"largeRobot":4,"bossRobot":10};best=(0,None)
    for center in {x.pos for x in robots}:
        value=sum(weights.get(r.kind,1)*(1+min(1,(damage if distance(center,r.pos)==0 else damage//2 if distance(center,r.pos)<=1 else 0)/max(1,r.hp))) for r in robots if distance(center,r.pos)<=1)
        if value>best[0]:best=(value,center)
    return best[1],best[0]

def tower_sites(w):
    cells={x for base in w.base_cells() for x in around(base) if w.inside(x) and w.zones.get(x,"land")=="land" and w.base_distance(x)==1}
    return sorted(cells)[:3]
def wall_sites(w):
    if not w.station:return []
    s=w.station.pos;ring=sorted(Pos(x,y) for x in range(s.x-2,s.x+4) for y in range(s.y-3,s.y+3) if w.inside(Pos(x,y)) and w.base_distance(Pos(x,y))==2 and w.zones.get(Pos(x,y),"land")=="land")
    return ring[:-1]
