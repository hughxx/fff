import json,logging
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from .brain import decide
LOG=logging.getLogger("field-agent")
class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        try:
            request=json.loads(self.rfile.read(int(self.headers.get("Content-Length","0"))).decode("utf-8"));response=decide(request)
            LOG.info("round=%s actions=%s prompt=%s cmd=%s",request.get("roundNo"),len(response["roleCommandMap"]),bool(response["prompt"]),bool(response["executeCmd"]))
        except Exception:
            LOG.exception("turn failed");response={"roleCommandMap":{},"prompt":"","executeCmd":""}
        body=json.dumps(response,ensure_ascii=False).encode();self.send_response(200);self.send_header("Content-Type","application/json; charset=utf-8");self.send_header("Content-Length",str(len(body)));self.end_headers();self.wfile.write(body)
    def log_message(self,*_):pass
def serve(port):ThreadingHTTPServer(("0.0.0.0",port),Handler).serve_forever()
