"""Production adapter for the imported 0.2.27 strategy and task runtime.

Keep its coordinated decisions intact, using our transactional request receipts
and bounded public telemetry around the complete engine.
"""

from __future__ import annotations

import copy
import time

from hugh.engine import Engine
from hugh.world import World

from .memory import TurnMemory
from .protocol import Observation, encode_response, idle_response
from .world import World as ValidatedWorld

VERSION = "0.4.0"
UPSTREAM_VERSION = "0.2.27"


class BattleApplication:
    def __init__(self):
        self.engine = Engine()
        self.memory = TurnMemory()
        self.last_status = "not-started"
        self.last_elapsed_seconds = 0.0
        self.last_world = None
        self.last_response = idle_response()

    def handle_turn(self, payload):
        started = time.monotonic()
        self.last_status = "error"
        try:
            observation = Observation.from_payload(payload)
            if "mapInfo" not in payload or "teamOur" not in payload:
                self.last_status = "probe"
                return idle_response()
            status, cached = self.memory.lookup(observation)
            self.last_status = status
            if cached is not None:
                return cached
            if status in {"stale_session", "conflicting_or_stale"}:
                return idle_response()
            # Validate authoritative data without imposing legacy strategy
            # restrictions on splash centers, siege or joint tower operation.
            ValidatedWorld.from_observation(observation)
            candidate = Engine() if status == "new_session" else copy.deepcopy(self.engine)
            frozen = copy.deepcopy(payload)
            response = candidate.decide(frozen)
            encode_response(response)
            world = candidate.previous if candidate.previous is not None and candidate.previous.round == observation.round_no else World(frozen)
            self.memory.commit(observation, response)
            self.engine, self.last_world, self.last_response = candidate, world, copy.deepcopy(response)
            return copy.deepcopy(response)
        except Exception:
            self.last_status = "error"
            raise
        finally:
            self.last_elapsed_seconds = time.monotonic() - started

    def startup_config(self):
        return {"engine": "battle", "version": VERSION, "upstreamVersion": UPSTREAM_VERSION,
                "taskRuntime": "runtime_evidence_v2", "fullTrace": False}

    def decision_outline(self):
        result = {"status": self.last_status, "revision": self.memory.revision,
                  "engine": "battle", "version": VERSION}
        if self.last_status not in {"new", "new_session"} or self.last_world is None:
            return result
        w, task = self.last_world, self.engine.tasks
        commands = self.last_response["roleCommandMap"]
        defense = self.engine.defense_status
        phase = ("inactive" if not task.active else "waiting-command" if task.inflight else
                 "waiting-llm" if task.pending else "submitted" if task.submitted else "need-llm")
        result.update(day=w.day, daytime=w.daylight, decisionMs=round(self.last_elapsed_seconds * 1000, 3),
                      taskPhase=phase,
                      reason=self.engine.decision_reason,
                      strategy=self.engine.strategy.summary(),
                      combatIntents=list(self.engine.defense.intents) if self.engine.defense else [],
                      staffing={"shotsIssued": sum(c.get("action") == "attack" for c in commands.values()),
                                "operator": defense.get("operator"), "repairer": defense.get("repairer")},
                      repair={"stock": defense.get("repair_stock", 0), "target": defense.get("repair_target", 0),
                              "minimum": defense.get("repair_minimum", 0),
                              "alarms": len(self.engine.defense.wall_alarm) if self.engine.defense else 0},
                      task={"phase": phase, "started": task.start, "deadline": task.deadline,
                            "requestsIssued": task.sequence, "hasContext": bool(task.context.get("task_text")),
                            "collectionStatus": task.collection_status if task.collection_status in
                            {"", "context", "observation", "answer", "progress", "resuming", "error"} else "unknown"},
                      treasure={"planned": task.treasure is not None, "travelling": task.treasure_trip is not None,
                                "done": task.treasure_done},
                      failedPreviousActions=[str(row["id"]) for row in self.engine.failed_actions],
                      errorCodes=[e["errorCode"] for e in w.raw.get("errors", [])
                                  if isinstance(e, dict) and type(e.get("errorCode")) is int])
        return result

    def replay_report(self):
        result = {"schema": "coregeek-battle-v1", **self.decision_outline(),
                  "elapsedMs": round(self.last_elapsed_seconds * 1000, 3)}
        if self.last_status in {"new", "new_session"} and self.last_world:
            result["round"] = self.last_world.round
            result["actionCount"] = len(self.last_response["roleCommandMap"])
            result["actionKinds"] = [c["action"] for c in self.last_response["roleCommandMap"].values()]
            result["diagnostics"] = []
        return result
