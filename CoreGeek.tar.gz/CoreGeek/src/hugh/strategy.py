"""Observed counterplay, bounded daytime pressure, and confirmed item accounting.

Enemy walls/base and both robot waves are public. Missing enemy actors or guns
are never evidence that the enemy cannot defend. Summons are an investment in
tonight's wave, not immediate damage or guaranteed kills.
"""
from .world import SUMMONS, TOWERS


class Strategy:
    def __init__(self):
        self.day = 0
        self.used = 0
        self.confirmed = 0
        self.committed_gold = 0
        self.flank_damage_day = 0
        self.enemy_guns = {}
        self.enemy = "unknown"
        self.mode = "grow"
        self.reason = "opening"
        self.summon_name = ""
        self.summon_budget = 0
        self.emergency = False

    def observe(self, w, previous, commands):
        if self.day != w.day:
            self.day, self.used, self.confirmed, self.committed_gold = w.day, 0, 0, 0
        if previous and previous.day == w.day and previous.round + 1 == w.round:
            feedback = w.raw.get("lastRoundRoleActionResults") or {}
            for uid, cmd in commands.items():
                name = cmd.get("name")
                if name not in SUMMONS:
                    continue
                old, now = previous.by_id.get(int(uid)), w.by_id.get(int(uid))
                failed = feedback.get(uid) is False
                if cmd.get("action") == "use":
                    if failed:
                        self.used = max(0, self.used - 1)
                    elif old and now and old.bag[name] > now.bag[name]:
                        self.confirmed += 1
                elif cmd.get("action") == "buy" and failed:
                    self.committed_gold = max(0, self.committed_gold - cmd.get("num", 0) * previous.shop_prices[name])
        # Observed firepower can disprove a weak-opening hypothesis. Expiry
        # makes it unknown again, not absent. A hidden tower is not a dead tower.
        self.enemy_guns = {uid: row for uid, row in self.enemy_guns.items() if w.round - row[1] <= 130}
        for u in w.enemies:
            if u.kind in TOWERS:
                self.enemy_guns[u.id] = (u.level, w.round)

    def update(self, w, combat, losses):
        from .layout import Layout
        layout = Layout(w)
        if any(losses.get(wall.id, 0) >= 10 and wall.pos not in layout.front_core for wall in w.walls):
            self.flank_damage_day = w.day
        w.expand_flanks = (self.flank_damage_day > 0 and w.day <= self.flank_damage_day + 1
                           and len(w.towers) == 3 and all(t.level >= 2 for t in w.towers))
        self.emergency = bool(combat.wall_alarm) or any(u >= 6 for u in combat.urgency.values())
        if w.base.hp < w.base.max_hp * 0.55:
            self.emergency = True
        enemy_base = next((u for u in w.enemies if u.kind == "station"), None)
        walls = [u for u in w.enemies if u.kind == "wall"]
        strong_guns = sum(level >= 2 for level, _ in self.enemy_guns.values()) >= 3
        fractured = any(u.hp < u.max_hp * 0.35 for u in walls)
        wounded = enemy_base is not None and enemy_base.hp < enemy_base.max_hp * 0.65
        self.enemy = ("wounded" if wounded else "fortified" if len(walls) >= 10 and not fractured else
                      "exposed" if enemy_base and (len(walls) < 6 or fractured) else "unknown")
        self.summon_name, self.summon_budget = "", 0
        ready = (w.daylight and w.tick >= 18 and len(w.towers) == 3 and len(w.walls) >= 6
                 and w.base.hp >= w.base.max_hp * 0.75 and not self.emergency)
        if ready:
            # Medium units survive one level-two center hit volley. Stop cheap
            # feeding against a developed battery/fortress. Large units absorb
            # much more fire, but justify their price only with observed damage.
            if w.day <= 2 and not strong_guns and self.enemy != "fortified":
                self.summon_name = "MiddleRobotSummonOrder"
                self.summon_budget = 120 if self.enemy == "exposed" else 60
            elif self.enemy in {"exposed", "wounded"} and all(t.level >= 2 for t in w.towers):
                self.summon_name = "LargeRobotSummonOrder"
                self.summon_budget = 200
        self.mode, self.reason = (
            ("defend", "base_or_wall_at_risk") if self.emergency else
            ("harass", "weak_or_unknown_opening" if w.day <= 2 else "enemy_defense_damaged") if self.summon_name else
            ("fortify", "observed_flank_damage") if w.expand_flanks else
            ("grow", "fund_weapons_and_repairs") if w.daylight else
            ("score", "safe_kills_or_pressured_walls"))

    def use_summon(self, w, actor, commands):
        if not w.daylight or self.used >= 10 or actor.id in commands.busy:
            return False
        # Already paid for: any free daytime action can deploy it. Emergency
        # repairs, task actions and completing the initial guns run before this.
        name = next((name for name in reversed(SUMMONS) if actor.bag[name]), None)
        if name and commands.use(actor, name):
            self.used += 1
            return True
        return False

    def buy_summon(self, w, actor, commands, reserve, allow_trip=False):
        name = self.summon_name
        if not name or actor.id in commands.busy or not actor.free or w.tick >= 68:
            return False
        stock = sum(u.bag[item] for u in w.actors for item in SUMMONS)
        pending = sum(cmd.get("num", 0) for cmd in commands.commands.values()
                      if cmd.get("action") == "buy" and cmd.get("name") in SUMMONS)
        price = w.shop_prices[name]
        limit = min(10 - self.used - stock - pending, 69 - w.tick - stock - pending,
                    max(0, self.summon_budget - self.committed_gold) // price,
                    max(0, commands.gold - reserve) // price, actor.free)
        if limit <= 0:
            return False
        goals = {p for shop in w.near("weaponShop") for p in w.stand_cells(shop)}
        if actor.pos in goals:
            if commands.buy(actor, name, limit):
                self.committed_gold += limit * price
                return True
        # An unknown opponent warrants only an opportunistic purchase, never a
        # dedicated expedition. A known opening can justify a short round trip.
        if allow_trip and self.enemy in {"exposed", "wounded"} and w.tick < 52:
            route = commands.route(actor)
            stand = route.best(goals)
            if stand is not None and route.steps[stand] <= 6 and 2 * route.steps[stand] + limit + 5 < 70 - w.tick:
                return commands.walk(actor, {stand})
        return False

    def summary(self):
        return {"mode": self.mode, "reason": self.reason, "enemy": self.enemy,
                "summonsIssued": self.used, "summonsConfirmed": self.confirmed,
                "summonGoldCommitted": self.committed_gold}
