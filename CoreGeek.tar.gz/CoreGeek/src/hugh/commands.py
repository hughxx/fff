"""Reserve actors, destinations, inventory and team money before emitting actions."""
from .world import ACTORS, TOWERS, ORES, SUMMONS, Route, distance, point


class Commands:
    def __init__(self, world, failed_moves=None):
        self.w = world
        self.gold = world.gold
        self.commands = {}
        self.busy = set()
        self.destinations = {}
        self.builds = set()
        self.tower_count = len(world.towers)
        self.routes = {}
        self.version = 0
        self.failed_moves = failed_moves or {}

    def blocked(self, actor):
        cells = set(self.w.static) | self.builds
        cells.update(r.pos for r in self.w.robots)
        cells.update(u.pos for u in self.w.enemies if u.kind in ACTORS)
        for u in self.w.actors:
            if u.id != actor.id:
                cells.add(self.destinations.get(u.id, u.pos))
        cells.discard(actor.pos)
        return cells

    def route(self, actor):
        key = actor.id, self.version
        if key not in self.routes:
            failed = self.failed_moves.get(actor.id)
            penalty = {failed[1]: 6} if failed and failed[0] == actor.pos and failed[2] >= self.w.round else None
            self.routes[key] = Route(self.w, actor, self.blocked(actor), penalty)
        return self.routes[key]

    def add(self, actor, action, **fields):
        if actor.id in self.busy:
            return False
        self.commands[str(actor.id)] = {"action": action, **fields}
        self.busy.add(actor.id)
        return True

    def walk(self, actor, goals):
        if actor.id in self.busy:
            return False
        route = self.route(actor)
        goal = route.best(goals)
        if goal is None:
            return False
        step = route.first[goal]
        if step is None:
            self.busy.add(actor.id)  # Deliberate hold, not an unsupported "nothing" action.
            return True
        for other in self.w.actors:
            if other.id != actor.id and other.pos == step and self.destinations.get(other.id) == actor.pos:
                return False
        if not self.add(actor, "move", targetPos=[point(step)]):
            return False
        self.destinations[actor.id] = step
        self.version += 1
        return True

    def approach(self, actor, target):
        return self.walk(actor, self.w.stand_cells(target))

    def adjacent(self, actor, target):
        cells = target.cells if hasattr(target, "cells") else {target}
        return actor.pos not in cells and min(distance(actor.pos, p) for p in cells) <= 1

    def build(self, actor, p, kind):
        w = self.w
        if (actor.kind != "worker" or not w.daylight or not self.adjacent(actor, p)
                or p in self.builds or p in w.by_pos or any(r.pos == p for r in w.robots) or w.zones.get(p, "land") != "land"
                or p in self.destinations.values() or not w.inside(p)):
            return False
        if kind in TOWERS:
            if self.gold < 25 or self.tower_count >= 3 or w.base_distance(p) != 1:
                return False
        elif kind != "wall" or not actor.bag["stone"] or w.base_distance(p) != 2:
            return False
        if self.add(actor, "build", name=kind, targetPos=[point(p)]):
            self.builds.add(p)
            self.version += 1
            if kind in TOWERS:
                self.gold -= 25
                self.tower_count += 1
            return True
        return False

    def buy(self, actor, name, number=1):
        price = self.w.shop_prices.get(name)
        if price is None or price <= 0 or not any(self.adjacent(actor, p) for p in self.w.near("weaponShop")):
            return False
        number = min(int(number), actor.free, self.gold // price)
        if number <= 0:
            return False
        if self.add(actor, "buy", name=name, num=number):
            self.gold -= price * number
            return True
        return False

    def sell(self, actor, name, number):
        if name not in ORES or not any(self.adjacent(actor, p) for p in self.w.near("vendor")):
            return False
        number = min(int(number), actor.bag[name])
        # Same-turn proceeds are not spent before the authoritative next request.
        return number > 0 and self.add(actor, "sell", name=name, num=number)

    def collect(self, actor, p):
        return (actor.kind == "worker" and actor.free > 0 and self.w.zones.get(p) in ORES
                and self.adjacent(actor, p) and self.add(actor, "collect", targetPos=[point(p)]))

    def use(self, actor, name, target=None):
        if not actor.bag[name]:
            return False
        if name in SUMMONS and (not self.w.daylight or target is not None):
            return False
        if name in ("Bomb", "DizzyWeapon") and target is None:
            return False
        fields = {"name": name}
        if target is not None:
            p = target.pos if hasattr(target, "pos") else target
            if name in ("Bomb", "DizzyWeapon") and not self.w.inside(p):
                return False
            fields["targetPos"] = [point(p)]
            if name not in ("Bomb", "DizzyWeapon") and not self.adjacent(actor, target):
                return False
        if "UpgradeVoucher" in name:
            kind = name.split("UpgradeVoucher")[0]
            valid = {"Weapon": TOWERS, "Wall": {"wall"}, "Station": {"station"}}
            if target is None or target.kind not in valid[kind] or target.level != int(name[-1]):
                return False
        if name == "WallFixer" and (target is None or target.kind != "wall"):
            return False
        return self.add(actor, "use", **fields)

    def attack(self, actor, tower, targets):
        if (self.w.daylight or tower.cooldown > 0 or str(tower.id) in self.commands
                or not self.adjacent(actor, tower) or actor.id in self.busy
                or len(targets) != (1 if tower.kind == "railgun" else tower.level)
                or any(not self.w.inside(p) or distance(tower.pos, p) > tower.reach for p in targets)):
            return False
        self.commands[str(tower.id)] = {"action": "attack", "controllerId": str(actor.id),
                                         "targetPos": [point(p) for p in targets]}
        self.busy.add(actor.id)
        return True

    def response(self, prompt="", command=""):
        return {"roleCommandMap": self.commands, "prompt": prompt, "executeCmd": command}
