"""Standard-library HTTP server with serialized, idempotent per-team state."""
from collections import OrderedDict
import argparse
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import logging
import os
import sys
import threading
import traceback
from time import perf_counter
from .diagnostics import TraceWriter, VERSION, session_state
from .engine import Engine

LOGGER = logging.getLogger("hugh")
EMPTY = {"roleCommandMap": {}, "prompt": "", "executeCmd": ""}


class Session:
    def __init__(self):
        self.lock = threading.Lock()
        self.engine = Engine()
        self.cache = OrderedDict()
        self.last_round = 0
        self.last_received = None

    def decide(self, payload):
        return self.evaluate(payload)[0]

    def evaluate(self, payload):
        number = int(payload["roundNo"])
        digest = hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        key = number, digest
        with self.lock:
            now = perf_counter()
            gap_ms = round((now - self.last_received) * 1000, 1) if self.last_received is not None else None
            self.last_received = now
            if key in self.cache:
                response, state = self.cache[key]
                return response, dict(state, mode="cached_response", request_gap_ms=gap_ms)
            if number == 1 and self.last_round > 1:
                self.engine, self.cache, self.last_round = Engine(), OrderedDict(), 0
            if number < self.last_round:
                state = session_state(self.engine, "older_round", gap_ms)
                state["reason"] = "older_round_ignored"
                return dict(EMPTY), state
            response = self.engine.decide(payload)
            state = session_state(self.engine, "fresh_decision", gap_ms)
            self.last_round = number
            self.cache[key] = response, state
            while len(self.cache) > 8:
                self.cache.popitem(last=False)
            return response, state


class AgentServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address, trace=None):
        super().__init__(address, Handler)
        self.sessions = {}
        self.session_lock = threading.Lock()
        self.trace = trace if trace is not None else TraceWriter()

    def decision(self, payload, with_diagnostics=False):
        team = payload["teamOur"]
        key = str(team.get("teamId", "")), team.get("type", "")
        with self.session_lock:
            if key not in self.sessions:
                self.sessions[key] = Session()
            session = self.sessions[key]
        result = session.evaluate(payload)
        return result if with_diagnostics else result[0]

    def server_close(self):
        super().server_close()
        trace = getattr(self, "trace", None)
        if trace is not None:
            trace.close()


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_json({"status": "ok", "agent": "Hugh"})

    def do_POST(self):
        start = perf_counter()
        number = "?"
        trace_id = self.server.trace.next_id()
        payload, raw, error = None, b"", None
        state = {"reason": "request_parse_error"}
        try:
            self.connection.settimeout(4)
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 8 * 1024 * 1024:
                raise ValueError("invalid request length")
            raw = self.rfile.read(length)
            payload = json.loads(raw.decode("utf-8-sig"))
            if not isinstance(payload, dict):
                raise ValueError("request must be an object")
            number = payload.get("roundNo", "?")
            state = {"reason": "decision_exception"}
            response, state = self.server.decision(payload, with_diagnostics=True)
        except Exception as exc:
            error = {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
            response = dict(EMPTY)
        sent = self.send_json(response)
        elapsed = (perf_counter() - start) * 1000
        record = {"id": trace_id, "roundNo": number, "request": payload if isinstance(payload, dict) else None,
                  "response": response, "diagnostics": state, "error": error, "elapsedMs": round(elapsed, 2),
                  "http": {"path": self.path, "request_bytes": len(raw), "response_sent": sent}}
        if error and state["reason"] == "request_parse_error":
            record["raw_request"] = raw.decode("utf-8", errors="replace")
        self.server.trace.emit(record)

    def send_json(self, value):
        body = json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        try:
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return True
        except (OSError, TimeoutError):
            return False

    def log_message(self, format, *args):
        pass


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("port", type=int)
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("port must be between 1 and 65535")
    logging.basicConfig(stream=sys.stdout, level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")
    try:
        server = AgentServer(("0.0.0.0", args.port))
    except Exception:
        LOGGER.exception("Hugh startup failed port=%s", args.port)
        raise SystemExit(1)
    LOGGER.info("Hugh listening on 0.0.0.0:%s pid=%s", args.port, os.getpid())
    LOGGER.info("Hugh version=%s diagnostics=plaintext_turns+task_text+json_trace stdout=true", VERSION)
    try:
        server.serve_forever()
    finally:
        server.server_close()
