"""Three rockets, early task income, continuous mining, and sustained wall repairs."""
from collections import Counter
from dataclasses import replace
from .world import World, Route, ORES, TOWERS, distance, neighbors, point
from .commands import Commands
from .layout import Layout
from .combat import Combat
from .tasks import Tasks


class Engine:
    def __init__(self):
        self.tasks = Tasks()
        self.selling = set()
        self.constructing = set()
        self.previous = None
        self.previous_commands = {}
        self.mine_avoid = {}
        self.loss = {}
        self.rebuilding = {}
        self.repair_usage = Counter()
        self.defense_status = {}
        self.decision_reason = "not_started"

    def observe(self, w):
        self.tasks.update(w)
        if self.previous:
            previous_by_id = self.previous.by_id
            feedback = w.raw.get("lastRoundRoleActionResults") or {}
            for u in w.ours:
                old = previous_by_id.get(u.id)
                if old and u.kind == "wall":
                    self.loss[u.id] = max(0, old.hp - u.hp, self.loss.get(u.id, 0) * 0.65)
                command = self.previous_commands.get(str(u.id), {})
                if (old and w.round == self.previous.round + 1 and not self.previous.daylight
                        and command.get("action") == "use" and command.get("name") == "WallFixer"
                        and feedback.get(str(u.id)) is not False and old.bag["WallFixer"] > u.bag["WallFixer"]):
                    self.repair_usage[self.previous.day] += 1
                if command.get("action") == "collect" and old:
                    p = command["targetPos"][0]
                    cell = (p["x"], p["y"])
                    kind = self.previous.zones.get(cell)
                    if feedback.get(str(u.id)) is False or (kind and u.bag[kind] <= old.bag[kind]):
                        self.mine_avoid[cell] = w.round + 6
            self.mine_avoid = {p: expiry for p, expiry in self.mine_avoid.items() if expiry >= w.round}
        self.repair_usage = Counter({day: count for day, count in self.repair_usage.items() if day >= w.day - 3})

    def decide(self, payload):
        w = World(payload)
        self.observe(w)
        c = Commands(w)
        self.defense_status = {}
        if not w.base or not w.actors:
            self.decision_reason = "no_alive_base" if not w.base else "no_alive_actors"
            return c.response()
        layout, combat = Layout(w), Combat(w)
        repairer = w.workers[0] if w.workers and self.repair_target(w) else None
        self.defense_status = {"repairer": repairer.id if repairer else None,
                               "repair_stock": repairer.bag["WallFixer"] if repairer else 0,
                               "repair_minimum": self.repair_minimum(w), "repair_target": self.repair_target(w),
                               "recent_night_repairs": dict(self.repair_usage), "operator": None}
        prompt, command = "", ""
        pioneer = w.pioneer

        # Tasks reserve their actor before any night-time controller allocation.
        if pioneer:
            if self.tasks.active:
                prompt, command = self.tasks.run(w, pioneer, c)
            elif self.tasks.treasure_action(w, pioneer, c, allow_travel=(
                    w.base.hp >= w.base.max_hp * 0.4 and
                    (not w.towers or (w.daylight and w.tick < 55) or
                     any(c.adjacent(worker, tower) for worker in w.workers for tower in w.towers)))):
                pass
            elif self.tasks.available(w):
                self.tasks.accept(w, pioneer, c)
            elif w.daylight:
                self.apply_items(w, pioneer, c, travel=True)
                if pioneer.id not in c.busy:
                    self.supply(w, pioneer, c, "pioneer")

        # A single operator suffices for the observed rocket cluster. Workers
        # temporarily take this role while the pioneer is solving a task.
        operator = None
        choices = []
        if w.towers:
            goals = layout.operator_goals()
            # Make an explicit handover; otherwise the temporary worker blocks
            # the only common stand and the pioneer can never take over.
            if pioneer and pioneer.id not in c.busy and pioneer.pos not in goals:
                occupied = []
                for worker in w.workers:
                    if worker.pos in goals:
                        occupied.append(worker)
                    if (worker.id not in c.busy and worker.pos in goals
                            and distance(pioneer.pos, worker.pos) <= 2):
                        relief = {p for p in neighbors(worker.pos) if p not in goals
                                  and p not in layout.sites and p != pioneer.pos and w.danger[p] == 0}
                        c.walk(worker, relief)
                if occupied and all(worker.id not in c.destinations for worker in occupied):
                    # Approach a free staging cell before asking the operator to
                    # vacate. An occupied final destination is not a route.
                    staging = {p for goal in goals for p in neighbors(goal)
                               if p not in goals and p not in w.static and w.inside(p)}
                    c.walk(pioneer, staging)
            for actor in w.actors:
                if actor.id in c.busy:
                    continue
                route = c.route(actor)
                reachable_goals = layout.operator_goals(route)
                stand = route.best(reachable_goals)
                if stand is not None:
                    bias = 0 if actor.kind == "pioneer" else (6 if actor == w.workers[0] else 3)
                    coverage = sum(distance(stand, t.pos) <= 1 for t in w.towers)
                    choices.append((route.cost[stand] + bias + 4 * (len(w.towers) - coverage), actor.id, actor, stand, route.steps[stand]))
            if choices:
                if repairer:
                    alternatives = [row for row in choices if row[2].id != repairer.id]
                    # Recall the other worker by their own travel deadline.
                    # Distance must not turn the stocked repairer into a miner's
                    # substitute. With no reachable backup, retain best effort.
                    if any(row[2].kind == "worker" or row[4] <= 3 for row in alternatives):
                        choices = alternatives
                choice = min(choices, key=lambda x: x[:2])
                _, _, actor, stand, steps = choice
                if not w.daylight or 70 - w.tick <= steps + 3:
                    operator = actor
                    self.defense_status["operator"] = actor.id
                    self.apply_items(w, actor, c, travel=False, urgent_only=True)
                    if actor.id not in c.busy and not combat.fire(actor, c):
                        if not self.apply_items(w, actor, c, travel=False):
                            c.walk(actor, {stand})

        # Wall builder first, construction/economic worker second. The first
        # worker's departure can be followed safely by another actor this turn.
        for index, actor in enumerate(w.workers):
            if actor.id in c.busy:
                continue
            if self.finish_rebuild(w, actor, c, layout):
                continue
            # A wall about to fall or a dying worker takes precedence over a bomb.
            if self.apply_items(w, actor, c, travel=False, urgent_only=True):
                continue
            if combat.bomb(actor, c):
                continue
            if actor.bag["Medicine"] and actor.hp < actor.max_hp * 0.55 and c.use(actor, "Medicine"):
                continue
            if index == 1 and layout.build_towers(actor, c):
                continue
            if index == 0:
                if self.builder(w, actor, c, layout):
                    continue
            elif self.apply_items(w, actor, c, travel=True):
                continue
            if self.supply(w, actor, c, "builder" if index == 0 else "miner"):
                continue
            if self.economy(w, actor, c, stone_keep=4 if index == 0 else 0):
                continue
            # Reposition idle workers away from a construction/operating cell.
            if actor.pos in layout.sites or actor.pos == layout.hub:
                c.walk(actor, {p for p in w.ring(1) if p not in layout.sites and p != layout.hub})

        if pioneer and pioneer.id not in c.busy:
            if not self.apply_items(w, pioneer, c, travel=True):
                if not self.supply(w, pioneer, c, "pioneer"):
                    route = c.route(pioneer)
                    c.walk(pioneer, layout.operator_goals(route))

        if not prompt and not command:
            prompt = self.tasks.news_prompt(w)
        response = c.response(prompt, command)
        self.decision_reason = "actions_issued" if c.commands else "active_task_no_role_action" if self.tasks.active else "no_action_selected"
        self.previous, self.previous_commands = w, c.commands
        return response

    def apply_items(self, w, actor, c, travel=False, urgent_only=False):
        if actor.id in c.busy:
            return False
        if actor.bag["Medicine"] and actor.hp < actor.max_hp * (0.35 if urgent_only else 0.6):
            return c.use(actor, "Medicine")
        layout = Layout(w)
        maintained = {tuple(p[k] for k in ("x", "y")) for command in c.commands.values()
                      if command.get("action") == "use" and
                      ("UpgradeVoucher" in command.get("name", "") or command.get("name") == "WallFixer")
                      for p in command.get("targetPos", [])}
        options = []
        for target in [w.base] + w.towers + w.walls:
            if not target or target.pos in maintained:
                continue
            if urgent_only:
                if target.kind == "station":
                    if target.hp >= target.max_hp * 0.35:
                        continue
                elif target.kind == "wall":
                    if target.hp > max(150, self.loss.get(target.id, 0) * 2):
                        continue
                    # Leave an available adjacent repairer to handle this wall.
                    if actor.kind == "pioneer" and any(u.id != actor.id and u.id not in c.busy and c.adjacent(u, target)
                           and (u.bag["WallFixer"] or
                                (target.level < 3 and u.bag["WallUpgradeVoucher" + str(target.level)]))
                           for u in w.workers):
                        continue
                else:
                    continue
            prefix = "Station" if target.kind == "station" else "Weapon" if target.kind in TOWERS else "Wall"
            voucher = prefix + "UpgradeVoucher" + str(target.level)
            goal = layout.wall_upgrade_goal(target, self.loss) if target.kind == "wall" else 3
            if target.level < goal and actor.bag[voucher]:
                priority = 100 if prefix == "Weapon" else 40
                if prefix == "Wall":
                    priority = 75 + layout.wall_priority(target, self.loss) * 0.25
                if prefix == "Station":
                    # Keep the base voucher until it also restores useful health.
                    if target.hp > target.max_hp * 0.8:
                        continue
                    priority = 120
                priority += (1 - target.hp / target.max_hp) * 60
                options.append((priority, target, voucher))
            if target.kind == "wall" and actor.bag["WallFixer"]:
                if layout.rebuildable(target, self.loss) and any(
                        u.bag["stone"] and c.adjacent(u, target) for u in w.workers):
                    continue
                threshold = min(target.max_hp - 100, max(target.max_hp * 0.5, self.loss.get(target.id, 0) * 4 + 150))
                if target.hp < threshold:
                    priority = 70 + (1 - target.hp / target.max_hp) * 70
                    priority += layout.wall_priority(target, self.loss) * 0.25
                    options.append((priority, target, "WallFixer"))
        if not options:
            return False
        route = c.route(actor)
        choices = []
        for priority, target, name in options:
            if c.adjacent(actor, target):
                choices.append((priority, -target.id, target, name, None))
            elif travel:
                goal = route.best(w.stand_cells(target))
                if goal is not None:
                    choices.append((priority - route.cost[goal] * 2, -target.id, target, name, goal))
        if not choices:
            return False
        _, _, target, name, goal = max(choices, key=lambda x: x[:2])
        return c.use(actor, name, target) if goal is None else c.walk(actor, {goal})

    def builder(self, w, actor, c, layout):
        if w.daylight and self.repair_target(w):
            route = c.route(actor)
            guard = self.repair_guard(w, actor, c, layout)
            if guard is not None and 70 - w.tick <= route.steps[guard] + 4:
                if actor.pos == guard and self.apply_items(w, actor, c, travel=False):
                    return True
                return c.walk(actor, {guard})
            # Replenish before spending the day delivering upgrades or mining.
            if actor.bag["WallFixer"] < self.repair_target(w) and self.supply(w, actor, c, "builder"):
                return True
        if self.start_rebuild(w, actor, c, layout):
            return True
        if self.apply_items(w, actor, c, travel=True):
            return True
        if w.daylight:
            missing = layout.missing_walls()
            if missing:
                if not actor.bag["stone"]:
                    self.constructing.discard(actor.id)
                target_stones = min(18, len(missing) + 2)
                if actor.bag["stone"] >= target_stones or (w.tick >= 38 and actor.bag["stone"]):
                    self.constructing.add(actor.id)
                if actor.id in self.constructing and layout.build_wall(actor, c):
                    return True
                if actor.id not in self.constructing and self.mine(w, actor, c, {"stone"}):
                    return True
        # The late-game repair worker waits inside the exposed front wall.
        if not w.daylight and actor.bag["WallFixer"] and w.walls:
            guard = self.repair_guard(w, actor, c, layout)
            if guard is not None:
                return c.walk(actor, {guard})
        return False

    def repair_minimum(self, w):
        if not w.walls or not w.workers or w.day < 2:
            return 0
        recent = max((n for day, n in self.repair_usage.items() if w.day - 3 <= day <= w.day), default=0)
        # Actual consumed packs plus 25% and two spare packs. A failed use or
        # a skipped input never counts as consumption. Initial floor is eight.
        return min(40, max(8, (recent * 5 + 3) // 4 + 2))

    def repair_target(self, w):
        minimum = self.repair_minimum(w)
        if not minimum:
            return 0
        level = min((t.level for t in w.towers), default=1) if len(w.towers) == 3 else 1
        # One wall upgrade no longer causes a 160-gold stock jump. Develop
        # firepower while building extra reserves, using our observed demand.
        return max(minimum, {1: 8, 2: 16, 3: 24}[level])

    def repair_guard(self, w, actor, c, layout):
        route = c.route(actor)
        if layout.repair_stand in route.cost:
            return layout.repair_stand
        # An occupied preferred stand must not cancel the return deadline.
        return route.best({p for p in w.ring(1) if p not in layout.sites and p != layout.hub})

    def shop_trip_goals(self, w, actor, c, goals):
        layout = Layout(w)
        guard = self.repair_guard(w, actor, c, layout)
        if guard is None:
            return set()
        outward = c.route(actor)
        homeward = Route(w, replace(actor, pos=guard), c.blocked(actor) - {guard})
        return {p for p in goals if p in outward.steps and p in homeward.steps
                and outward.steps[p] + homeward.steps[p] + 1 + 4 <= 70 - w.tick}

    def finish_rebuild(self, w, actor, c, layout):
        p = self.rebuilding.get(actor.id)
        if p is None:
            return False
        occupant = w.by_pos.get(p)
        if occupant and occupant.kind == "wall":
            # Includes a failed remove: no gap was made, so plan again normally.
            self.rebuilding.pop(actor.id, None)
            return False
        if not w.daylight:
            return False
        if not actor.bag["stone"]:
            return self.mine(w, actor, c, {"stone"})
        if layout.keeps_access(p, c) and c.build(actor, p, "wall"):
            # Clear only after the following authoritative state confirms it.
            return True
        if c.adjacent(actor, p):
            return c.walk(actor, {actor.pos})
        return c.approach(actor, p)

    def start_rebuild(self, w, actor, c, layout):
        if not actor.bag["stone"] or actor.id in self.rebuilding:
            return False
        candidates = [wall for wall in w.walls if layout.rebuildable(wall, self.loss)]
        if not candidates:
            return False
        route = c.route(actor)
        choices = []
        for wall in candidates:
            stand = route.best(w.stand_cells(wall))
            if stand is not None and w.tick + route.steps[stand] + 2 < 55:
                choices.append((route.cost[stand], wall.hp, wall.id, wall, stand))
        for _, _, _, wall, stand in sorted(choices):
            if not c.adjacent(actor, wall):
                return c.walk(actor, {stand})
            if c.add(actor, "remove", targetPos=[point(wall.pos)]):
                self.rebuilding[actor.id] = wall.pos
                return True
        return False

    def shopping_list(self, w, actor, role, gold):
        all_bags = sum((u.bag for u in w.actors), Counter())
        picks = []
        if actor.hp < actor.max_hp * 0.75 and not actor.bag["Medicine"]:
            picks.append(("Medicine", 1))
        if w.base.hp < w.base.max_hp * 0.55 and w.base.level < 3:
            name = "StationUpgradeVoucher" + str(w.base.level)
            if not all_bags[name]:
                picks.append((name, 1))
        target = self.repair_target(w)
        repair_stock = w.workers[0].bag["WallFixer"] if w.workers else 0
        weapon_cost = next((w.shop_prices["WeaponUpgradeVoucher" + str(level)] for level in (1, 2)
                            if sum(t.level == level for t in w.towers) > all_bags["WeaponUpgradeVoucher" + str(level)]), 0)
        minimum = self.repair_minimum(w) if weapon_cost else target
        repair_reserve = max(0, minimum - repair_stock) * w.shop_prices["WallFixer"]
        full_repair_reserve = max(0, target - repair_stock) * w.shop_prices["WallFixer"]
        construction_reserve = max(0, 3 - len(w.towers)) * 25
        if role == "builder" and actor.bag["WallFixer"] < target:
            picks.append(("WallFixer", target - actor.bag["WallFixer"]))
        if role in ("pioneer", "miner"):
            for level in (1, 2):
                name = "WeaponUpgradeVoucher" + str(level)
                missing = sum(t.level == level for t in w.towers) - all_bags[name]
                if missing > 0:
                    picks.append((name, missing))
        layout = Layout(w)
        urgent_walls = any(self.loss.get(t.id, 0) >= 10 or t.hp < t.max_hp * 0.6 for t in w.walls)
        if role in ("builder", "pioneer") and (urgent_walls or
                (len(w.towers) == 3 and all(t.level >= 2 for t in w.towers))):
            frontline = sorted((t for t in w.walls if t.level < layout.wall_upgrade_goal(t, self.loss)),
                               key=lambda t: (-layout.wall_priority(t, self.loss), t.hp / t.max_hp, t.pos))
            for level in (1, 2):
                name = "WallUpgradeVoucher" + str(level)
                missing = sum(t.level == level for t in frontline) - all_bags[name]
                if missing > 0:
                    picks.append((name, min(missing, 3)))
        if (w.day >= 5 and role in ("builder", "miner") and len(w.towers) == 3
                and all(t.level == 3 for t in w.towers) and w.base.hp >= w.base.max_hp * 0.4
                and target and repair_stock >= target):
            reserve = 150
            affordable = max(0, gold - reserve) // w.shop_prices["Bomb"]
            picks.append(("Bomb", min(2 - all_bags["Bomb"], affordable)))
        result = []
        for name, number in picks:
            emergency = name == "Medicine" or name.startswith("StationUpgradeVoucher")
            budget = gold if emergency else gold - construction_reserve
            if name == "WallFixer" and weapon_cost:
                # Fund minimum repairs first; extras leave enough for one gun
                # upgrade. This applies even if the repairer shops first.
                budget = min(budget, max(repair_reserve, budget - weapon_cost))
            elif name.startswith("WeaponUpgradeVoucher"):
                budget -= repair_reserve
            elif not emergency and name != "WallFixer":
                budget -= full_repair_reserve + weapon_cost
            number = min(number, max(0, budget) // w.shop_prices[name], actor.free)
            if number > 0:
                result.append((name, number))
        return result

    def supply(self, w, actor, c, role):
        # Deliver purchases before generating another shopping trip.
        layout = Layout(w)
        needs_repairs = role == "builder" and actor.bag["WallFixer"] < self.repair_target(w)
        if not needs_repairs and any(actor.bag[("Weapon" if target.kind in TOWERS else "Wall") + "UpgradeVoucher" + str(target.level)]
               for target in w.towers + w.walls
               if target.level < (layout.wall_upgrade_goal(target, self.loss) if target.kind == "wall" else 3)):
            return False
        items = self.shopping_list(w, actor, role, c.gold)
        bought_bombs = sum(cmd.get("num", 0) for cmd in c.commands.values()
                           if cmd.get("action") == "buy" and cmd.get("name") == "Bomb")
        bomb_room = max(0, 2 - sum(u.bag["Bomb"] for u in w.actors) - bought_bombs)
        items = [(name, min(n, bomb_room) if name == "Bomb" else n) for name, n in items
                 if name != "Bomb" or bomb_room > 0]
        if not items:
            return False
        # Avoid abandoning a night defense to shop unless the worker is already
        # outside, or repairs actually need replenishing.
        if not w.daylight and role == "pioneer":
            return False
        goals = {p for shop in w.near("weaponShop") for p in w.stand_cells(shop)}
        if role == "builder" and w.daylight and self.repair_target(w):
            # Check an actual walk to the shop, a purchase turn, and the return.
            # Recheck every turn so moving blockers cannot silently delay dusk.
            goals = self.shop_trip_goals(w, actor, c, goals)
            if not goals:
                return False
        if actor.pos in goals:
            name, number = items[0]
            return c.buy(actor, name, number)
        return c.walk(actor, goals)

    def economy(self, w, actor, c, stone_keep=0):
        amounts = {name: max(0, actor.bag[name] - (stone_keep if name == "stone" else 0)) for name in ORES}
        value = sum(n * w.vendor_prices.get(name, 1) for name, n in amounts.items())
        threshold = 25 if w.round < 65 else 100 if any(t.level < 3 for t in w.towers) else 150
        vendor_goals = {p for v in w.near("vendor") for p in w.stand_cells(v)}
        if value >= threshold or (actor.free < 8 and value) or (actor.pos in vendor_goals and value):
            self.selling.add(actor.id)
        if actor.id in self.selling:
            if not value:
                self.selling.discard(actor.id)
            else:
                if actor.pos in vendor_goals:
                    name = max(amounts, key=lambda name: amounts[name] * w.vendor_prices.get(name, 1))
                    return c.sell(actor, name, amounts[name])
                if c.walk(actor, vendor_goals):
                    return True
        ores = {"copper", "iron"}
        if self.tasks.iron_block_from <= w.day <= self.tasks.iron_block_until:
            ores.discard("iron")
        return self.mine(w, actor, c, ores)

    def mine(self, w, actor, c, ores):
        if actor.free <= 0:
            return False
        route = c.route(actor)
        vendors = w.near("vendor")
        choices = []
        for p, kind in w.zones.items():
            if kind not in ores or p in self.mine_avoid:
                continue
            stand = route.best(w.stand_cells(p))
            if stand is None:
                continue
            price = 1 if ores == {"stone"} else w.vendor_prices.get(kind, {"copper": 5, "iron": 3}.get(kind, 1))
            haul = min((distance(p, v) for v in vendors), default=0)
            score = price / (1 + route.cost[stand] * 0.3 + (haul * 0.045 if ores != {"stone"} else 0))
            # Do not commit to standing exposed to a nearby robot for one ore.
            score /= 1 + w.danger[stand]
            choices.append((score, -route.cost[stand], p, stand))
        if not choices:
            return False
        _, _, p, stand = max(choices)
        if actor.pos == stand:
            return c.collect(actor, p)
        return c.walk(actor, {stand})
