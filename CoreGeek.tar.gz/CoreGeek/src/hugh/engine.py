"""Three rockets, early task income, continuous mining, and sustained wall repairs."""
from collections import Counter
from .world import World, ORES, TOWERS, distance, neighbors
from .commands import Commands
from .layout import Layout
from .combat import Combat
from .tasks import Tasks


class Engine:
    def __init__(self):
        self.tasks = Tasks()
        self.selling = set()
        self.constructing = set()
        self.previous = None
        self.previous_commands = {}
        self.mine_avoid = {}
        self.loss = {}
        self.decision_reason = "not_started"

    def observe(self, w):
        self.tasks.update(w)
        if self.previous:
            previous_by_id = self.previous.by_id
            feedback = w.raw.get("lastRoundRoleActionResults") or {}
            for u in w.ours:
                old = previous_by_id.get(u.id)
                if old and u.kind == "wall":
                    self.loss[u.id] = max(0, old.hp - u.hp, self.loss.get(u.id, 0) * 0.65)
                command = self.previous_commands.get(str(u.id), {})
                if command.get("action") == "collect" and old:
                    p = command["targetPos"][0]
                    cell = (p["x"], p["y"])
                    kind = self.previous.zones.get(cell)
                    if feedback.get(str(u.id)) is False or (kind and u.bag[kind] <= old.bag[kind]):
                        self.mine_avoid[cell] = w.round + 6
            self.mine_avoid = {p: expiry for p, expiry in self.mine_avoid.items() if expiry >= w.round}

    def decide(self, payload):
        w = World(payload)
        self.observe(w)
        c = Commands(w)
        if not w.base or not w.actors:
            self.decision_reason = "no_alive_base" if not w.base else "no_alive_actors"
            return c.response()
        layout, combat = Layout(w), Combat(w)
        prompt, command = "", ""
        pioneer = w.pioneer

        # Tasks reserve their actor before any night-time controller allocation.
        if pioneer:
            if self.tasks.active:
                prompt, command = self.tasks.run(w, pioneer, c)
            elif self.tasks.treasure_action(w, pioneer, c):
                pass
            elif self.tasks.available(w):
                self.tasks.accept(w, pioneer, c)
            elif w.daylight:
                self.apply_items(w, pioneer, c, travel=True)
                if pioneer.id not in c.busy:
                    self.supply(w, pioneer, c, "pioneer")

        # A single operator suffices for the observed rocket cluster. Workers
        # temporarily take this role while the pioneer is solving a task.
        operator = None
        choices = []
        if w.towers:
            goals = layout.operator_goals()
            # Make an explicit handover; otherwise the temporary worker blocks
            # the only common stand and the pioneer can never take over.
            if pioneer and pioneer.id not in c.busy and pioneer.pos not in goals:
                for worker in w.workers:
                    if (worker.id not in c.busy and worker.pos in goals
                            and distance(pioneer.pos, worker.pos) <= 2):
                        relief = {p for p in neighbors(worker.pos) if p not in goals
                                  and p not in layout.sites and p != pioneer.pos and w.danger[p] == 0}
                        c.walk(worker, relief)
            for actor in w.actors:
                if actor.id in c.busy:
                    continue
                route = c.route(actor)
                stand = route.best(goals)
                if stand is not None:
                    bias = 0 if actor.kind == "pioneer" else (6 if actor == w.workers[0] else 3)
                    choices.append((route.cost[stand] + bias, actor.id, actor, stand, route.steps[stand]))
            if choices:
                choice = min(choices, key=lambda x: x[:2])
                _, _, actor, _, steps = choice
                if not w.daylight or 70 - w.tick <= steps + 3:
                    operator = actor
                    self.apply_items(w, actor, c, travel=False)
                    if actor.id not in c.busy and not combat.fire(actor, c):
                        c.walk(actor, goals)

        # Wall builder first, construction/economic worker second. The first
        # worker's departure can be followed safely by another actor this turn.
        for index, actor in enumerate(w.workers):
            if actor.id in c.busy:
                continue
            if combat.bomb(actor, c):
                continue
            if actor.bag["Medicine"] and actor.hp < actor.max_hp * 0.55 and c.use(actor, "Medicine"):
                continue
            if index == 1 and layout.build_towers(actor, c):
                continue
            if index == 0:
                if self.builder(w, actor, c, layout):
                    continue
            elif self.apply_items(w, actor, c, travel=True):
                continue
            if self.supply(w, actor, c, "builder" if index == 0 else "miner"):
                continue
            if self.economy(w, actor, c, stone_keep=4 if index == 0 else 0):
                continue
            # Reposition idle workers away from a construction/operating cell.
            if actor.pos in layout.sites or actor.pos == layout.hub:
                c.walk(actor, {p for p in w.ring(1) if p not in layout.sites and p != layout.hub})

        if pioneer and pioneer.id not in c.busy:
            if not self.apply_items(w, pioneer, c, travel=True):
                if not self.supply(w, pioneer, c, "pioneer"):
                    c.walk(pioneer, layout.operator_goals())

        if not prompt and not command:
            prompt = self.tasks.news_prompt(w)
        response = c.response(prompt, command)
        self.decision_reason = "actions_issued" if c.commands else "active_task_no_role_action" if self.tasks.active else "no_action_selected"
        self.previous, self.previous_commands = w, c.commands
        return response

    def apply_items(self, w, actor, c, travel=False):
        if actor.id in c.busy:
            return False
        if actor.bag["Medicine"] and actor.hp < actor.max_hp * 0.6:
            return c.use(actor, "Medicine")
        options = []
        for target in [w.base] + w.towers + w.walls:
            if not target:
                continue
            prefix = "Station" if target.kind == "station" else "Weapon" if target.kind in TOWERS else "Wall"
            voucher = prefix + "UpgradeVoucher" + str(target.level)
            if target.level < 3 and actor.bag[voucher]:
                priority = 100 if prefix == "Weapon" else 40
                if prefix == "Station":
                    # Keep the base voucher until it also restores useful health.
                    if target.hp > target.max_hp * 0.8:
                        continue
                    priority = 120
                priority += (1 - target.hp / target.max_hp) * 60
                options.append((priority, target, voucher))
            if target.kind == "wall" and actor.bag["WallFixer"]:
                threshold = min(target.max_hp - 100, max(target.max_hp * 0.5, self.loss.get(target.id, 0) * 4 + 150))
                if target.hp < threshold:
                    priority = 70 + (1 - target.hp / target.max_hp) * 70
                    options.append((priority, target, "WallFixer"))
        if not options:
            return False
        route = c.route(actor)
        choices = []
        for priority, target, name in options:
            if c.adjacent(actor, target):
                choices.append((priority, -target.id, target, name, None))
            elif travel:
                goal = route.best(w.stand_cells(target))
                if goal is not None:
                    choices.append((priority - route.cost[goal] * 2, -target.id, target, name, goal))
        if not choices:
            return False
        _, _, target, name, goal = max(choices, key=lambda x: x[:2])
        return c.use(actor, name, target) if goal is None else c.walk(actor, {goal})

    def builder(self, w, actor, c, layout):
        if self.apply_items(w, actor, c, travel=True):
            return True
        if w.daylight:
            # Access maintenance is deliberate and limited to the chosen gate.
            if layout.open_gate(actor, c):
                return True
            missing = [p for p in layout.missing_walls() if p != layout.gate or w.tick >= 58]
            if missing:
                if not actor.bag["stone"]:
                    self.constructing.discard(actor.id)
                target_stones = min(18, len(missing) + 2)
                if actor.bag["stone"] >= target_stones or (w.tick >= 38 and actor.bag["stone"]):
                    self.constructing.add(actor.id)
                if actor.id in self.constructing and layout.build_wall(actor, c):
                    return True
                if actor.id not in self.constructing and self.mine(w, actor, c, {"stone"}):
                    return True
        # The late-game repair worker waits inside the exposed front wall.
        if not w.daylight and w.day >= 3 and actor.bag["WallFixer"]:
            return c.walk(actor, {layout.repair_stand})
        return False

    def shopping_list(self, w, actor, role, gold):
        all_bags = sum((u.bag for u in w.actors), Counter())
        picks = []
        if actor.hp < actor.max_hp * 0.75 and not actor.bag["Medicine"]:
            picks.append(("Medicine", 1))
        if w.base.hp < w.base.max_hp * 0.55 and w.base.level < 3:
            name = "StationUpgradeVoucher" + str(w.base.level)
            if not all_bags[name]:
                picks.append((name, 1))
        if role == "builder" and w.day >= 2 and w.walls:
            target = 4 if w.day == 2 else 8 if w.day < 5 else 12
            if actor.bag["WallFixer"] < max(2, target // 3):
                picks.append(("WallFixer", target - actor.bag["WallFixer"]))
        if role in ("pioneer", "miner"):
            for level in (1, 2):
                name = "WeaponUpgradeVoucher" + str(level)
                missing = sum(t.level == level for t in w.towers) - all_bags[name]
                if missing > 0:
                    picks.append((name, missing))
        if w.towers and all(t.level == 3 for t in w.towers) and role in ("builder", "pioneer"):
            frontline = sorted(w.walls, key=lambda wall: (wall.hp / wall.max_hp, wall.pos))[:10]
            for level in (1, 2):
                name = "WallUpgradeVoucher" + str(level)
                missing = sum(t.level == level for t in frontline) - all_bags[name]
                if missing > 0:
                    picks.append((name, min(missing, 3)))
        if w.day >= 5 and role in ("builder", "miner") and gold >= 350 and actor.bag["Bomb"] < 2:
            picks.append(("Bomb", 2 - actor.bag["Bomb"]))
        return [(name, min(n, gold // w.shop_prices[name], actor.free)) for name, n in picks
                if n > 0 and gold >= w.shop_prices[name] and actor.free > 0]

    def supply(self, w, actor, c, role):
        # Deliver purchases before generating another shopping trip.
        if any(actor.bag[("Weapon" if target.kind in TOWERS else "Wall") + "UpgradeVoucher" + str(target.level)]
               for target in w.towers + w.walls if target.level < 3):
            return False
        items = self.shopping_list(w, actor, role, c.gold)
        if not items:
            return False
        # Avoid abandoning a night defense to shop unless the worker is already
        # outside, or repairs actually need replenishing.
        if not w.daylight and role == "pioneer":
            return False
        if role == "builder" and w.daylight and w.tick >= 48 and actor.bag["WallFixer"]:
            return False
        goals = {p for shop in w.near("weaponShop") for p in w.stand_cells(shop)}
        if actor.pos in goals:
            name, number = items[0]
            return c.buy(actor, name, number)
        return c.walk(actor, goals)

    def economy(self, w, actor, c, stone_keep=0):
        amounts = {name: max(0, actor.bag[name] - (stone_keep if name == "stone" else 0)) for name in ORES}
        value = sum(n * w.vendor_prices.get(name, 1) for name, n in amounts.items())
        threshold = 25 if w.round < 65 else 100 if any(t.level < 3 for t in w.towers) else 150
        vendor_goals = {p for v in w.near("vendor") for p in w.stand_cells(v)}
        if value >= threshold or (actor.free < 8 and value) or (actor.pos in vendor_goals and value):
            self.selling.add(actor.id)
        if actor.id in self.selling:
            if not value:
                self.selling.discard(actor.id)
            else:
                if actor.pos in vendor_goals:
                    name = max(amounts, key=lambda name: amounts[name] * w.vendor_prices.get(name, 1))
                    return c.sell(actor, name, amounts[name])
                if c.walk(actor, vendor_goals):
                    return True
        ores = {"copper", "iron"}
        if self.tasks.iron_block_from <= w.day <= self.tasks.iron_block_until:
            ores.discard("iron")
        return self.mine(w, actor, c, ores)

    def mine(self, w, actor, c, ores):
        if actor.free <= 0:
            return False
        route = c.route(actor)
        vendors = w.near("vendor")
        choices = []
        for p, kind in w.zones.items():
            if kind not in ores or p in self.mine_avoid:
                continue
            stand = route.best(w.stand_cells(p))
            if stand is None:
                continue
            price = 1 if ores == {"stone"} else w.vendor_prices.get(kind, {"copper": 5, "iron": 3}.get(kind, 1))
            haul = min((distance(p, v) for v in vendors), default=0)
            score = price / (1 + route.cost[stand] * 0.3 + (haul * 0.045 if ores != {"stone"} else 0))
            # Do not commit to standing exposed to a nearby robot for one ore.
            score /= 1 + w.danger[stand]
            choices.append((score, -route.cost[stand], p, stand))
        if not choices:
            return False
        _, _, p, stand = max(choices)
        if actor.pos == stand:
            return c.collect(actor, p)
        return c.walk(actor, {stand})
