"""The observed three-rocket cluster, rotated with the player's base."""
from .world import neighbors


class Layout:
    def __init__(self, world):
        self.w = world
        self.base = world.base
        self.mirror = self.base.pos[0] < world.width / 2
        self.hub = self.cell(2, 0)
        self.sites = [self.cell(2, -1), self.cell(1, 1), self.cell(2, 1)]
        self.gate = self.cell(-2, 2)
        self.repair_stand = self.cell(-1, 0)
        order = [(-2, y) for y in range(-3, 3)]
        order += [(-1, 2), (0, 2), (1, 2), (1, -3), (0, -3), (-1, -3),
                  (2, -3), (3, -3), (3, -2)]
        self.wall_sites = [self.cell(*p) for p in order if world.inside(self.cell(*p))]
        # Two rear exits near the operator remain open, like the recorded expert.
        # This rear connector links the repair courtyard to the rocket stand.
        self.exits = {self.cell(3, -1), self.cell(3, 0), self.cell(3, 1), self.cell(3, 2), self.cell(2, 2)}

    def cell(self, x, y):
        bx, by = self.base.pos
        return (bx + 1 - x, by - 1 - y) if self.mirror else (bx + x, by + y)

    def missing_walls(self):
        occupied = {u.pos for u in self.w.walls}
        return [p for p in self.wall_sites if p not in occupied]

    def build_towers(self, actor, commands):
        w = self.w
        if not w.daylight or commands.tower_count >= 3 or commands.gold < 25:
            return False
        route = commands.route(actor)
        choices = []
        for i, p in enumerate(self.sites):
            if (p in w.by_pos and w.by_pos[p].id != actor.id) or p in commands.builds or not w.inside(p):
                continue
            stand = route.best(w.stand_cells(p))
            if stand is not None:
                choices.append((route.cost[stand] + i * 0.1, p))
        for _, p in sorted(choices):
            if commands.build(actor, p, "rocket") or commands.approach(actor, p):
                return True
        return False

    def build_wall(self, actor, commands):
        w = self.w
        if not w.daylight or not actor.bag["stone"]:
            return False
        route = commands.route(actor)
        choices = []
        for i, p in enumerate(self.missing_walls()):
            if p in commands.builds or (p in w.by_pos and w.by_pos[p].id != actor.id):
                continue
            if p == self.gate:
                if w.tick < 58:
                    continue
                goals = {q for q in w.stand_cells(p) if w.base_distance(q) == 1}
            else:
                goals = w.stand_cells(p)
            stand = route.best(goals)
            if stand is not None:
                choices.append((i * 0.8 + route.cost[stand], p, goals))
        for _, p, goals in sorted(choices):
            if actor.pos in goals:
                if not self.keeps_access(p, commands):
                    continue
                if commands.build(actor, p, "wall"):
                    return True
            if commands.walk(actor, goals):
                return True
        return False

    def open_gate(self, actor, commands):
        wall = next((u for u in self.w.walls if u.pos == self.gate), None)
        if not self.w.daylight or self.w.tick >= 55 or wall is None:
            return False
        if commands.adjacent(actor, wall):
            from .world import point
            return commands.add(actor, "remove", targetPos=[point(wall.pos)])
        return commands.approach(actor, wall)

    def operator_goals(self, route=None):
        towers = self.w.towers
        if not towers:
            return {self.hub}
        candidates = {p for t in towers for p in self.w.stand_cells(t)}
        if route is not None:
            candidates &= route.cost.keys()
        from .world import distance
        count = {p: sum(distance(p, t.pos) <= 1 for t in towers) for p in candidates}
        best = max(count.values(), default=0)
        return {p for p, n in count.items() if n == best}

    def keeps_access(self, site, commands):
        """Do not seal an existing path between workers and the shared stand."""
        if not self.w.towers:
            return True
        blocked = self.w.static | commands.builds
        goals = self.operator_goals()

        def connected(obstacles):
            seen = set(goals) - obstacles
            todo = list(seen)
            while todo:
                for p in neighbors(todo.pop()):
                    if p not in seen and p not in obstacles and self.w.inside(p):
                        seen.add(p)
                        todo.append(p)
            return seen

        before, after = connected(blocked), connected(blocked | {site})
        required = {u.pos for u in self.w.actors} | {self.repair_stand}
        return not ((required & before) - after)
