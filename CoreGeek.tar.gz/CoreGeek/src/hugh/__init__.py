"""Independent Future War competition agent."""
