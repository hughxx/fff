"""Standalone program sent to the task sandbox; never run on the agent host.

Only the observed declarative spec grammar has an automatic repair path.
Unrecognized requirements return full context for the platform LLM.
"""
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
import urllib.parse


MARKER = "HUGH_TASK:"


def read_text(path, limit=8000):
    with path.open(encoding="utf-8-sig", errors="replace") as stream:
        value = stream.read(limit + 1)
    return value[:limit] + ("\n[FILE_TRUNCATED]" if len(value) > limit else "")


def find_tasks(description):
    # A literal path may contain Unicode or spaces; do not reduce it to an
    # ASCII suffix before checking the actual file.
    try:
        literal = Path(description.strip().strip('"'))
        if literal.is_file():
            return [literal.resolve()]
    except OSError:
        pass
    # Chinese instructions often have no space before the ASCII file name.
    names = re.findall(r"[A-Za-z0-9_./\\:~-]+\.(?:md|txt|json)", description)
    names += re.findall(r'"([^"\r\n]+\.(?:md|txt|json))"', description)
    direct = [Path(n).resolve() for n in names if Path(n).is_file()]
    if direct:
        return sorted(set(direct))
    wanted = {Path(n).name for n in names}
    started, visited = time.monotonic(), set()
    for root in ("/tmp/selfEvolutionTask", os.getcwd(), "/tmp", "/workspace", "/sandbox", "/app", "/home", "/opt"):
        if not os.path.isdir(root):
            continue
        found = []
        for base, dirs, files in os.walk(root):
            dirs[:] = [d for d in dirs if d not in (".git", "node_modules", "__pycache__", "site-packages", ".cache")]
            if len(Path(base).parts) - len(Path(root).parts) >= 7:
                dirs[:] = []
            if base in visited:
                dirs[:] = []
                continue
            visited.add(base)
            for name in files:
                if name in wanted or (not wanted and name.startswith("task_") and name.endswith(".md")):
                    found.append((Path(base) / name).resolve())
            if time.monotonic() - started > 2 or len(visited) > 6000:
                return sorted(set(found))
        if found:
            return sorted(set(found))
    return []


def materials(task):
    """Read nearby documents and explicitly referenced files in one command."""
    root, queue, found = task.parent.resolve(), [task.resolve()], {}
    listing, used = [], 0
    for base, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if not d.startswith(".") and d not in ("node_modules", "__pycache__", "site-packages"))
        if len(Path(base).parts) - len(root.parts) >= 3:
            dirs[:] = []
        for name in sorted(files):
            path = Path(base) / name
            if name.startswith(".hugh_"):
                continue
            listing.append(str(path.relative_to(root)))
            if path.suffix.lower() in (".md", ".txt") and path != task:
                queue.append(path)
        if len(listing) >= 150:
            break
    # No special file names, topic keywords or built-in repair grammar.
    for path in queue:
        path = path.resolve()
        if path in found or not path.is_relative_to(root) or not path.is_file() or used >= 36000:
            continue
        try:
            content = read_text(path, min(9000, (36000 - used) // 4))
        except OSError:
            continue
        used += len(content.encode("utf-8"))
        found[path] = content
        # References may be relative to the document or the task directory.
        references = re.findall(r"[A-Za-z0-9_./-]+\.[A-Za-z0-9_]{1,10}", content)
        references += re.findall(r"(?:\./|[A-Za-z0-9_-]+/)[A-Za-z0-9_./-]+", content)
        for name in references:
            for base in (path.parent, root):
                target = (base / name).resolve()
                if target.is_relative_to(root) and target.is_file() and target not in found:
                    queue.append(target)
    return {str(p): text for p, text in found.items()}, listing[:150]


def inside(root, name):
    path = (root / name).resolve()
    if path == root or not path.is_relative_to(root):
        raise ValueError("Spec path escapes workspace: " + name)
    # The checker and specification are inputs, never repair targets.
    if path.name in ("check", "spec.md"):
        raise ValueError("Reserved spec target: " + name)
    return path


def repair_plan(workspace, spec):
    """Parse *all* requirements before changing any files; fail closed to LLM."""
    plan, section, config = [], "", None
    for raw in spec.splitlines():
        line = raw.strip()
        if not line or line.startswith("# "):
            continue
        if line.startswith("## "):
            title = line[3:].strip()
            if title in ("目录要求", "脚本要求"):
                section, config = title, None
            elif title.startswith("配置文件 "):
                section = "配置文件"
                config = inside(workspace, title[len("配置文件 "):].strip(" `"))
            else:
                raise ValueError("Unknown spec heading: " + title)
            continue
        if not line.startswith("- "):
            raise ValueError("Unknown spec requirement: " + line)
        line = line[2:].strip()
        if section == "目录要求":
            match = re.fullmatch(r"`?([^`\s]+)`?\s+必须存在[，,]\s*权限(?:为)?\s*`?([0-7]{3})`?[。.]?", line)
            if match:
                plan.append(("directory", inside(workspace, match[1]), int(match[2], 8)))
                continue
        elif section == "配置文件":
            match = re.fullmatch(r"第\s*(\d+)\s*行[：:]\s*`([^`\r\n]*)`[。.]?", line)
            if match and 1 <= int(match[1]) <= 10000:
                plan.append(("line", config, int(match[1]), match[2]))
                continue
        elif section == "脚本要求":
            match = re.fullmatch(r"`?([^`\s]+)`?\s+必须存在且可执行[（(]权限\s*`?([0-7]{3})`?[）)][。.]?", line)
            if match:
                plan.append(("script", inside(workspace, match[1]), int(match[2], 8)))
                continue
        raise ValueError("Unknown spec requirement: " + line)
    if not plan:
        raise ValueError("No supported requirements found")
    for op in plan:
        path = op[1]
        if path.exists() and ((op[0] == "directory") != path.is_dir()):
            raise ValueError("Conflicting file type: " + str(path))
        if op[0] == "line" and path.exists() and path.stat().st_size > 128000:
            raise ValueError("Config too large for automatic repair")
    return plan


def apply_plan(plan):
    configs = {}
    for op in plan:
        kind, path = op[:2]
        if kind == "directory":
            path.mkdir(parents=True, exist_ok=True)
            path.chmod(op[2])
        elif kind == "script":
            path.parent.mkdir(parents=True, exist_ok=True)
            if not path.exists():
                path.write_bytes(b"#!/bin/sh\n")
            path.chmod(op[2])
        else:
            if path not in configs:
                configs[path] = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
            lines = configs[path]
            while len(lines) < op[2]:
                lines.append("")
            lines[op[2] - 1] = op[3]
    for path, lines in configs.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        # Preserve physical line numbers when padding an initially short file.
        path.write_bytes(("\n".join(lines) + "\n").encode("utf-8"))


def run_checker(workspace):
    checker = workspace / "check"
    if checker.is_symlink() or not checker.is_file() or checker.stat().st_size > 128000:
        raise ValueError("Missing or unsupported workspace checker")
    data = checker.read_bytes()
    # Fix only launch formatting; preserve the actual verification logic.
    if data.startswith(b"#!") and b"\r\n" in data:
        checker.write_bytes(data.replace(b"\r\n", b"\n"))
    checker.chmod((checker.stat().st_mode & 0o777) | 0o111)
    with tempfile.TemporaryFile() as output:
        result = subprocess.run([str(checker)], cwd=workspace, stdout=output,
                                stderr=subprocess.STDOUT, timeout=8, check=False)
        output.seek(0)
        raw = output.read(12001)
    text = raw[:12000].decode("utf-8", errors="replace")
    truncated = len(raw) > 12000
    tokens = re.findall(r"(?m)^\s*TOKEN:\s*(\S+)\s*$", text)
    token = tokens[-1] if result.returncode == 0 and not truncated and tokens else None
    return result.returncode, text, token



def heritage_contract(body):
    """Only apply the old algorithm when the CURRENT requested computation matches."""
    section = re.search(r"(?ms)^##\s*任务要求\s*\n(.*?)(?=^##\s|\Z)", body)
    if not section:
        return None
    goal = section[1]
    block = re.search(r"```json\s*(.*?)\s*```", goal, re.S)
    if not block:
        return None
    city = re.search(r'"city"\s*:\s*"([^"<>]+)"', block[1])
    if not city:
        return None
    expected = ('{"city":' + json.dumps(city[1], ensure_ascii=False) +
                ',"total_count":<总记录条数>,"world_heritage_count":<保护级别为"世界遗产"的数量>,'
                '"types":["<所有不重复的遗产类型，顺序不限>"],"oldest_era":"<年代最早的遗产名称>"}')
    compact = lambda value: re.sub(r"\s+", "", value)
    if compact(block[1]) != compact(expected):
        return None
    prose = compact((goal[:block.start()] + goal[block.end():]).replace("*", "").replace("`", ""))
    if not re.fullmatch("从API查询" + re.escape(city[1]) + r"市?的全部文化遗产记录，然后(?:通过submitAnswer接口)?提交以下统计信息[：:]", prose):
        return None
    headings = re.findall(r"(?m)^##\s+(.+?)\s*$", body)
    if any(h not in ("任务背景", "任务要求", "提交形式", "提示") for h in headings):
        return None
    return city[1]


def bootstrap(description, runtime_source="", profiles=None):
    context = {"cwd": os.getcwd(), "kind": "generic"}
    files = find_tasks(description)
    if len(files) != 1:
        context["discovery_error"] = "Expected one task file; found " + str([str(p) for p in files[:8]])
        return {"status": "context", "context": context}
    task = files[0]
    docs, listing = materials(task)
    body = docs.get(str(task), read_text(task))
    context.update(task_file=str(task), task_text=body, materials={p: v for p, v in docs.items() if p != str(task)}, files=listing)
    namespace = {"__name__": "hugh_task_runtime"}
    if runtime_source:
        exec(compile(runtime_source, "<hugh runtime>", "exec"), namespace)
    origins = []
    for text in (body, *docs.values()):
        for url in re.findall(r'https?://[^\s<>"\x60]+', text):
            parsed = urllib.parse.urlsplit(url.rstrip(").,;，。；）"))
            origin = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, "", "", ""))
            if parsed.hostname and origin not in origins:
                origins.append(origin)
    config = {"kind": "generic", "base_url": origins[0] if origins else "", "services": origins,
              "path": "/", "params": {}, "headers": {}}
    city = heritage_contract(body)
    api_candidates = list(dict.fromkeys(v for p, v in docs.items() if p != str(task) and "curl" in v and "http" in v))
    api_docs = api_candidates[0] if len(api_candidates) == 1 else ""
    if len(api_candidates) > 1:
        context["api_selection_note"] = "Multiple request guides; choose the current task's API from materials"
    if api_docs:
        context["api_docs"] = api_docs
    if city and runtime_source and api_docs:
        documented = namespace["documented_request"](body, api_docs, city)
        if documented:
            config.update(documented, kind="heritage", city=city, documented_path=documented["path"])
            config["documented_key"] = next((v.removeprefix("Bearer ") for k, v in config["headers"].items()
                                             if k.lower() in ("x-api-key", "authorization")), "")
            context.update(kind="heritage", city=city, solver="baseline_heritage")
            profile = None
            if re.search(r"(?:API|接口)[^\n]*(?:相同|同一|沿用)", body, re.I):
                profile = next((p for p in reversed(profiles or []) if p.get("base_url") == config["base_url"]
                                and p.get("documented_path") == config["documented_path"]
                                and p.get("documented_key", config["documented_key"]) == config["documented_key"]), None)
            if profile:
                config["path"], config["headers"] = profile["path"], dict(profile["headers"])
                config["params"] = {k: city if v == profile["city"] else v for k, v in profile["params"].items()}
            context["profile_reused"] = bool(profile)
    else:
        profile = None
    if config["kind"] != "heritage" and "spec.md" in body and "./check" in body and re.search(r'"token"\s*:', body):
        candidates = set(re.findall(r"\bws_[A-Za-z0-9_-]+\b", body))
        candidates.update(re.findall(r"`([^`\s]+/)`", body))
        workspaces = {(task.parent / name).resolve() for name in candidates}
        workspaces = [p for p in workspaces if p.is_relative_to(task.parent) and (p / "spec.md").is_file()]
        if len(workspaces) == 1:
            workspace = workspaces[0]
            spec = read_text(workspace / "spec.md")
            context.update(kind="engineering", workspace=str(workspace), spec=spec, solver="baseline_spec")
            config.update(kind="engineering", checker=str(workspace / "check"), checker_cwd=str(workspace))
        else:
            context["repair_error"] = "Cannot identify a unique referenced workspace"
    runtime = None
    if runtime_source:
        runner = task.parent / ".hugh_runtime.py"
        runner.write_bytes(runtime_source.encode("utf-8"))
        runtime = namespace["Runtime"](task.parent / ".hugh_api_state.json", config)
        runtime.save()  # A new task never inherits records or an old answer.
        context.update(api_runner=str(runner), api_config=config)
    if config["kind"] == "heritage" and runtime:
        if profile:
            runtime.state.update(schema=profile["schema"], paging=profile["paging"])
        result = runtime.collect()
        return {**result, "context": context}
    if config["kind"] == "engineering":
        try:
            plan = repair_plan(workspace, spec)
            apply_plan(plan)
            code, output, token = run_checker(workspace)
            context.update(checker_exit=code, checker_output=output)
            if token:
                return {"status": "answer", "context": context, "answer": {"token": token}}
        except (OSError, ValueError, subprocess.TimeoutExpired) as error:
            context["repair_error"] = str(error)
    if context.get("solver"):
        context["attempted_solver"] = context["solver"]
    context["solver"] = "model_script"
    return {"status": "context", "context": context}


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    request = json.loads(sys.argv[1])
    try:
        result = bootstrap(request["description"], request.get("runtime_source", ""), request.get("profiles"))
    except Exception as exc:
        result = {"status": "context", "context": {"bootstrap_error": str(exc)}}
    result["id"] = request["id"]
    payload = json.dumps(result, ensure_ascii=False, separators=(",", ":"))
    for key in ("materials", "files", "api_docs", "task_text", "checker_output"):
        if len(payload.encode("utf-8")) <= 48000:
            break
        context = result.get("context", {})
        if key in context:
            context[key] = "[CONTEXT_TRUNCATED; reread the referenced file]"
        payload = json.dumps(result, ensure_ascii=False, separators=(",", ":"))
    if len(payload.encode("utf-8")) > 48000:
        payload = json.dumps({"id": request["id"], "status": "context", "context": {"bootstrap_error": "Output budget exceeded"}})
    print(MARKER + payload)


if __name__ == "__main__":
    main()
