"""Read current task materials and install a task-independent executor."""
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time
import urllib.parse


def read_text(path, limit=9000):
    with path.open(encoding="utf-8-sig", errors="replace") as stream:
        value = stream.read(limit + 1)
    return value[:limit] + ("\n[FILE_TRUNCATED; read this file explicitly]" if len(value) > limit else "")


def find_tasks(description):
    names = re.findall(r"[A-Za-z0-9_./\\:~-]+\.[A-Za-z0-9_]{1,12}", description)
    names += re.findall(r'"([^"\r\n]+)"', description)
    direct = [Path(n).resolve() for n in names if Path(n).is_file()]
    if direct:
        return sorted(set(direct))
    wanted = {Path(n).name for n in names}
    started, visited = time.monotonic(), set()
    for root in ("/tmp/selfEvolutionTask", os.getcwd(), "/tmp", "/workspace", "/sandbox", "/app", "/home", "/opt"):
        if not os.path.isdir(root):
            continue
        found = []
        for base, dirs, files in os.walk(root):
            dirs[:] = [d for d in dirs if d not in (".git", "node_modules", "__pycache__", "site-packages", ".cache")]
            if len(Path(base).parts) - len(Path(root).parts) >= 7:
                dirs[:] = []
            if base in visited:
                dirs[:] = []
                continue
            visited.add(base)
            for name in files:
                if name in wanted:
                    found.append((Path(base) / name).resolve())
            if time.monotonic() - started > 2 or len(visited) > 6000:
                return sorted(set(found))
        if found:
            return sorted(set(found))
    return []


def materials(task):
    """Read nearby documents and explicitly referenced files in one command."""
    root, queue, found = task.parent.resolve(), [task.resolve()], {}
    listing, used = [], 0
    for base, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if not d.startswith(".") and d not in ("node_modules", "__pycache__", "site-packages"))
        if len(Path(base).parts) - len(root.parts) >= 3:
            dirs[:] = []
        for name in sorted(files):
            path = Path(base) / name
            if name.startswith(".hugh_"):
                continue
            listing.append(str(path.relative_to(root)))
            if path.suffix.lower() in (".md", ".txt") and path != task:
                queue.append(path)
        if len(listing) >= 150:
            break
    # No special file names, topic keywords or built-in repair grammar.
    for path in queue:
        path = path.resolve()
        if path in found or not path.is_relative_to(root) or not path.is_file() or used >= 36000:
            continue
        try:
            content = read_text(path, min(9000, (36000 - used) // 4))
        except OSError:
            continue
        used += len(content.encode("utf-8"))
        found[path] = content
        # References may be relative to the document or the task directory.
        references = re.findall(r"[A-Za-z0-9_./-]+\.[A-Za-z0-9_]{1,10}", content)
        for name in references:
            for base in (path.parent, root):
                target = (base / name).resolve()
                if target.is_relative_to(root) and target.is_file() and target not in found:
                    queue.append(target)
    return {str(p): text for p, text in found.items()}, listing[:150]


def bootstrap(description, runtime_source="", profiles=None):
    context = {"cwd": os.getcwd(), "kind": "generic"}
    files = find_tasks(description)
    if len(files) != 1:
        context["discovery_error"] = "Expected one task file; found " + str([str(p) for p in files[:8]])
        return {"status": "context", "context": context}
    task = files[0]
    docs, listing = materials(task)
    body = docs.get(str(task), read_text(task))
    context.update(task_file=str(task), task_text=body,
                   materials={p: value for p, value in docs.items() if p != str(task)}, files=listing)
    urls = []
    for text in (description, *docs.values()):
        for match in re.findall(r"https?://[^\s<>\"'\x60]+", text):
            url = match.rstrip(").,;，。；）")
            target = urllib.parse.urlsplit(url)
            if target.hostname:
                origin = urllib.parse.urlunsplit((target.scheme, target.netloc, "", "", ""))
                if origin not in urls:
                    urls.append(origin)
    config = {"services": urls, "base_url": urls[0] if urls else "", "request": {}}
    hints = []
    for profile in profiles or []:
        if not isinstance(profile, dict):
            continue
        requests = [r for r in profile.get("successful_requests", [])
                    if any(r.get("url", "") == url or r.get("url", "").startswith(url + "/") for url in urls)]
        if requests:
            hints.append({"successful_requests": requests[-2:], "dataset_plans": profile.get("dataset_plans", [])[-2:]})
    # Previous-task evidence is shown to the model, never automatically applied.
    context["previous_task_evidence"] = hints[-2:]
    if runtime_source:
        namespace = {"__name__": "hugh_task_runtime"}
        exec(compile(runtime_source, "<hugh runtime>", "exec"), namespace)
        runner = task.parent / ".hugh_runtime.py"
        runner.write_bytes(runtime_source.encode("utf-8"))
        runtime = namespace["Runtime"](task.parent / ".hugh_task_state.json", config)
        runtime.save()  # Reset ALL source data for every new task.
        context.update(runner=str(runner), config=config, material_sha256=hashlib.sha256(
                       json.dumps(docs, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest())
    return {"status": "context", "context": context}


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    request = json.loads(sys.argv[1])
    try:
        result = bootstrap(request["description"], request.get("runtime_source", ""), request.get("profiles"))
    except Exception as error:
        result = {"status": "context", "context": {"kind": "generic", "bootstrap_error": str(error)}}
    result["id"] = request["id"]
    context = result.get("context", {})
    for key in ("previous_task_evidence", "materials", "files"):
        if len(json.dumps(result, ensure_ascii=False).encode("utf-8")) > 54000:
            context[key] = {"truncated": True, "note": "Read referenced files explicitly"}
    print("HUGH_TASK:" + json.dumps(result, ensure_ascii=False, separators=(",", ":")))


if __name__ == "__main__":
    main()
