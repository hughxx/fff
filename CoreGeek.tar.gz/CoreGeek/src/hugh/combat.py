"""Coordinate rocket splash and global bombs against current robot positions."""
from .world import distance, neighbors, ray

SCORES = {"smallRobot": 1, "middleRobot": 2, "largeRobot": 4, "bossRobot": 10}


class Combat:
    def __init__(self, world):
        self.w = world
        self.health = {r.id: r.hp for r in world.robots}
        self.robots = {r.id: r for r in world.robots}
        self.centers = {}
        for robot in world.robots:
            for p in [robot.pos] + neighbors(robot.pos):
                if world.inside(p):
                    self.centers.setdefault(p, []).append((robot.id, p == robot.pos))

    def weight(self, robot):
        own = not robot.target or robot.target == self.w.side
        close = max(0, 10 - self.w.base_distance(robot.pos)) / 10
        return (1.0 + 1.8 * close) if own else 0.85

    def value(self, hits, health):
        score, kills = 0.0, 0
        for rid, damage in hits:
            hp = health.get(rid, 0)
            if hp <= 0:
                continue
            robot = self.robots[rid]
            score += min(hp, damage) * self.weight(robot)
            if damage >= hp:
                kills += 1
                score += 12 * SCORES.get(robot.kind, 1) * self.weight(robot)
        return score, kills

    def splash(self, p, bomb=False):
        return [(rid, 100 if bomb else (20 if center else 10)) for rid, center in self.centers[p]]

    def apply(self, hits, health=None):
        health = self.health if health is None else health
        for rid, damage in hits:
            health[rid] = max(0, health.get(rid, 0) - damage)

    def rocket(self, tower):
        health = dict(self.health)
        candidates = [p for p in self.centers if distance(p, tower.pos) <= tower.reach]
        targets, damage, total = [], [], 0.0
        for _ in range(tower.level):
            best = max(candidates, key=lambda p: (self.value(self.splash(p), health)[0], p), default=None)
            if best is None:
                return [], [], 0
            hits = self.splash(best)
            value = self.value(hits, health)[0]
            targets.append(best)
            damage.extend(hits)
            total += value
            self.apply(hits, health)
        return targets, damage, total

    def gun(self, tower):
        # Compatibility with existing mixed-tower states; our construction uses rockets.
        candidates = [r for r in self.w.robots if distance(r.pos, tower.pos) <= tower.reach]
        best = ([], [], 0)
        robot_at = {r.pos: r for r in self.w.robots}
        for target in candidates:
            energy = 10 * tower.level
            hits = []
            for p in ray(tower.pos, target.pos)[1:]:
                r = robot_at.get(p)
                if r is None or self.health[r.id] <= 0:
                    continue
                if tower.kind == "gatling":
                    hits = [(r.id, 10 * tower.level)]
                    break
                hit = min(energy, self.health[r.id])
                hits.append((r.id, hit))
                energy -= hit
                if energy <= 0:
                    break
            value = self.value(hits, self.health)[0]
            if value > best[2]:
                best = ([target.pos] * (tower.level if tower.kind == "gatling" else 1), hits, value)
        return best

    def fire(self, actor, commands):
        if self.w.daylight:
            return False
        choices = []
        for tower in self.w.towers:
            if tower.cooldown == 0 and commands.adjacent(actor, tower) and str(tower.id) not in commands.commands:
                targets, hits, value = self.rocket(tower) if tower.kind == "rocket" else self.gun(tower)
                if targets and value > 0:
                    choices.append((value, tower.id, tower, targets, hits))
        if choices:
            _, _, tower, targets, hits = max(choices, key=lambda item: item[:2])
            if commands.attack(actor, tower, targets):
                self.apply(hits)
                return True
        return False

    def bomb(self, actor, commands):
        if self.w.daylight or not actor.bag["Bomb"]:
            return False
        p = max(self.centers, key=lambda p: self.value(self.splash(p, True), self.health)[0], default=None)
        if p is None:
            return False
        hits = self.splash(p, True)
        value, kills = self.value(hits, self.health)
        emergency = self.w.base.hp < 500 and self.w.base_distance(p) < 4
        if (kills >= 4 or value >= 400 or emergency) and commands.use(actor, "Bomb", p):
            self.apply(hits)
            return True
        return False
