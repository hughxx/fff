"""Coordinate rocket splash and global bombs against current robot positions."""
from .world import distance, neighbors, ray

SCORES = {"smallRobot": 1, "middleRobot": 2, "largeRobot": 4, "bossRobot": 10}
POWER = {"smallRobot": 5, "middleRobot": 10, "largeRobot": 20, "bossRobot": 40}


class Combat:
    def __init__(self, world):
        self.w = world
        self.health = {r.id: r.hp for r in world.robots}
        self.robots = {r.id: r for r in world.robots}
        self.enemy_walls = {r.id: r for r in world.enemies if r.kind == "wall"}
        self.wall_health = {rid: r.hp for rid, r in self.enemy_walls.items()}
        self.centers = {}
        for robot in world.robots:
            for p in [robot.pos] + neighbors(robot.pos):
                if world.inside(p):
                    self.centers.setdefault(p, []).append((robot.id, p == robot.pos))
        self.urgency = {r.id: self.defense_urgency(r) for r in world.robots}

    def own_threat(self, robot):
        # Unknown affiliation is treated conservatively for defense only.
        return not robot.target or robot.target == self.w.side

    def defense_urgency(self, robot):
        if not self.own_threat(robot) or robot.abnormal == "dizzy" or not self.w.base:
            return 0.0
        close = self.w.base_distance(robot.pos)
        if close > 6:
            return 0.0
        power = POWER.get(robot.kind, 5)
        base_cell = min(self.w.base.cells, key=lambda p: (distance(robot.pos, p), p))
        line = set(ray(robot.pos, base_cell)[1:-1])
        shielded = any(wall.pos in line for wall in self.w.walls)
        weak_wall = any(distance(robot.pos, wall.pos) <= 3 and wall.hp <= max(150, power * 6)
                        for wall in self.w.walls)
        # This is a conservative danger estimate, not the game's path/attack AI.
        emergency = ((close <= 4 and not shielded) or weak_wall or
                     self.w.base.hp < self.w.base.max_hp * 0.35)
        return 6.0 if emergency else 0.25 * (6 - close) / 6

    def value(self, hits, health):
        score, kills = 0.0, 0
        for rid, damage in hits:
            hp = health.get(rid, 0)
            if hp <= 0:
                continue
            robot = self.robots[rid]
            if not self.own_threat(robot):
                continue
            points = SCORES.get(robot.kind, 1)
            progress = min(1, damage / hp)
            # Defense-only release: opposing kills never improve target choice.
            # Mixed splash still updates actual predicted health for both waves.
            score += 12 * points * progress + 0.2 * min(hp, damage)
            window = min(4, 130 - self.w.tick)
            score += progress * POWER.get(robot.kind, 5) * self.urgency[rid] * window
            if damage >= hp:
                kills += 1
                score += 40 * points
        return score, kills

    def splash(self, p, bomb=False):
        return [(rid, 100 if bomb else (20 if center else 10)) for rid, center in self.centers[p]]

    def urgent_hits(self, hits, health):
        return any(health.get(rid, 0) > 0 and damage > 0 and self.urgency[rid] >= 6
                   for rid, damage in hits)

    def apply(self, hits, health=None):
        health = self.health if health is None else health
        for rid, damage in hits:
            health[rid] = max(0, health.get(rid, 0) - damage)

    def rocket(self, tower):
        health = dict(self.health)
        candidates = [p for p in self.centers if distance(p, tower.pos) <= tower.reach]
        targets, damage, total = [], [], 0.0
        for _ in range(tower.level):
            # A distant easy kill must not outweigh a live breach. Release this
            # restriction as soon as our allocated shots finish the threat.
            live = [p for p in candidates if any(health[rid] > 0 and self.own_threat(self.robots[rid])
                                                 for rid, _ in self.centers[p])]
            urgent = [p for p in live if self.urgent_hits(self.splash(p), health)]
            best = max(urgent or live, key=lambda p: (self.value(self.splash(p), health)[0], p), default=None)
            if best is None:
                if not targets:
                    return [], [], 0
                # The protocol requires level-many targets. Repeat our last
                # defensive aim rather than redirect spare missiles to rivals.
                best = targets[-1]
            hits = self.splash(best)
            value = self.value(hits, health)[0]
            targets.append(best)
            damage.extend(hits)
            total += value
            self.apply(hits, health)
        return targets, damage, total

    def siege(self, tower):
        # Only direct wall impacts are valued; robot targets are evaluated first.
        candidates = [wall for wall in self.enemy_walls.values()
                      if self.wall_health[wall.id] > 0 and distance(wall.pos, tower.pos) <= tower.reach
                      and not any(self.health[r.id] > 0 and not self.own_threat(r)
                                  and distance(wall.pos, r.pos) <= 1 for r in self.w.robots)]
        if not candidates:
            return [], []
        enemy_base = next((u for u in self.w.enemies if u.kind == "station"), None)
        def rank(wall):
            pressure = sum(POWER.get(r.kind, 5) for r in self.w.robots
                           if not self.own_threat(r) and self.health[r.id] > 0 and distance(wall.pos, r.pos) <= 3)
            front = 0
            if enemy_base:
                cx, cy = (self.w.width - 1) / 2, (self.w.height - 1) / 2
                bx, by = enemy_base.pos[0] + 0.5, enemy_base.pos[1] - 0.5
                front = (wall.pos[0] - bx) * (cx - bx) + (wall.pos[1] - by) * (cy - by)
            return (pressure, front, -self.wall_health[wall.id], -wall.id)
        targets, hits = [], []
        health = dict(self.wall_health)
        for _ in range(tower.level):
            live = [wall for wall in candidates if health[wall.id] > 0]
            wall = max(live or candidates, key=rank)
            targets.append(wall.pos)
            hits.append((wall.id, 20))
            health[wall.id] = max(0, health[wall.id] - 20)
        return targets, hits

    def gun(self, tower):
        # Compatibility with existing mixed-tower states; our construction uses rockets.
        candidates = [r for r in self.w.robots if self.health[r.id] > 0 and self.own_threat(r)
                      and distance(r.pos, tower.pos) <= tower.reach]
        best = ([], [], 0)
        best_rank = (False, 0)
        robot_at = {r.pos: r for r in self.w.robots}
        for target in candidates:
            energy = 10 * tower.level
            hits = []
            for p in ray(tower.pos, target.pos)[1:]:
                r = robot_at.get(p)
                if r is None or self.health[r.id] <= 0:
                    continue
                if tower.kind == "gatling":
                    hits = [(r.id, 10 * tower.level)]
                    break
                hit = min(energy, self.health[r.id])
                hits.append((r.id, hit))
                energy -= hit
                if energy <= 0:
                    break
            value = self.value(hits, self.health)[0]
            rank = (self.urgent_hits(hits, self.health), value)
            if rank > best_rank:
                best = ([target.pos] * (tower.level if tower.kind == "gatling" else 1), hits, value)
                best_rank = rank
        return best

    def fire(self, actor, commands):
        if self.w.daylight:
            return False
        choices = []
        for tower in self.w.towers:
            if tower.cooldown == 0 and commands.adjacent(actor, tower) and str(tower.id) not in commands.commands:
                targets, hits, value = self.rocket(tower) if tower.kind == "rocket" else self.gun(tower)
                if targets and value > 0:
                    choices.append((self.urgent_hits(hits, self.health), value, tower.id, tower, targets, hits))
        if choices:
            _, _, _, tower, targets, hits = max(choices, key=lambda item: item[:3])
            if commands.attack(actor, tower, targets):
                self.apply(hits)
                return True
        # Safe spare fire is useful after reachable defense targets are gone.
        for tower in sorted(self.w.towers, key=lambda t: t.id):
            if (tower.kind == "rocket" and tower.cooldown == 0 and commands.adjacent(actor, tower)
                    and str(tower.id) not in commands.commands
                    and not any(self.health[r.id] > 0 and self.own_threat(r)
                                and distance(r.pos, tower.pos) <= tower.reach + 1 for r in self.w.robots)):
                targets, hits = self.siege(tower)
                if targets and commands.attack(actor, tower, targets):
                    self.apply(hits, self.wall_health)
                    return True
        return False

    def bomb(self, actor, commands):
        if self.w.daylight or not actor.bag["Bomb"]:
            return False
        p = max(self.centers, key=lambda p: (self.value(self.splash(p, True), self.health)[0], p), default=None)
        if p is None:
            return False
        hits = self.splash(p, True)
        value, _ = self.value(hits, self.health)
        points = sum(SCORES.get(self.robots[rid].kind, 1) for rid, damage in hits
                     if self.own_threat(self.robots[rid]) and 0 < self.health[rid] <= damage)
        emergency_damage = sum(min(self.health[rid], damage) for rid, damage in hits if self.urgency[rid] >= 6)
        if value > 0 and (points >= 6 or emergency_damage >= 100) and commands.use(actor, "Bomb", p):
            self.apply(hits)
            return True
        return False
