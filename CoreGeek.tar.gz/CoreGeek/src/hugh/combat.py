"""Coordinate rocket splash and global bombs against current robot positions."""
from collections import Counter
from .world import distance, neighbors, ray

SCORES = {"smallRobot": 1, "middleRobot": 2, "largeRobot": 4, "bossRobot": 10}
POWER = {"smallRobot": 5, "middleRobot": 10, "largeRobot": 20, "bossRobot": 40}


class Combat:
    def __init__(self, world, losses=None, commands=None):
        self.w = world
        self.losses = losses or {}
        self.stunned = set()
        self.intents = []
        self.health = {r.id: r.hp for r in world.robots}
        self.robots = {r.id: r for r in world.robots}
        self.enemy_walls = {r.id: r for r in world.enemies if r.kind == "wall"}
        self.wall_health = {rid: r.hp for rid, r in self.enemy_walls.items()}
        self.centers = {}
        for robot in world.robots:
            for p in [robot.pos] + neighbors(robot.pos):
                if world.inside(p):
                    self.centers.setdefault(p, []).append((robot.id, p == robot.pos))
        self.splashes = {p: [(rid, 20 if center else 10) for rid, center in rows] for p, rows in self.centers.items()}
        self.blasts = {p: [(rid, 100) for rid, _ in rows] for p, rows in self.centers.items()}
        self.refresh(commands)

    def power(self, robot):
        return robot.power or POWER.get(robot.kind, 5)

    def active_threat(self, robot):
        return (self.own_threat(robot) and self.health[robot.id] > 0
                and robot.abnormal != "dizzy" and robot.id not in self.stunned)

    def refresh(self, commands=None):
        self.shot_cache = {}
        from .commands import Commands
        commands = commands or Commands(self.w)
        w = self.w
        active = [r for r in w.robots if self.active_threat(r)]
        self.wall_load, self.wall_potential, self.repair_eta, self.wall_alarm = {}, {}, {}, set()
        # Expected load shares tied nearest structures; potential load is an
        # upper bound used to protect against a cluster focusing one weak wall.
        assigned = {wall.id: 0.0 for wall in w.walls}
        self.base_load = 0.0
        for r in active:
            targets = [(min(distance(r.pos, p) for p in u.cells), u) for u in w.walls + w.towers + ([w.base] if w.base else [])]
            nearest = min((d for d, _ in targets), default=999)
            if nearest > (r.reach or 3):
                continue
            tied = [u for d, u in targets if d == nearest]
            for target in tied:
                if target.kind == "wall":
                    assigned[target.id] += self.power(r) / len(tied)
                elif target.kind == "station":
                    self.base_load += self.power(r) / len(tied)
        pending = {tuple(p[k] for k in ("x", "y")): cmd.get("name", "")
                   for cmd in commands.commands.values() if cmd.get("action") == "use"
                   for p in cmd.get("targetPos", [])}
        for wall in w.walls:
            load = max(self.losses.get(wall.id, 0), assigned[wall.id])
            possible = max(load, sum(self.power(r) for r in active if distance(r.pos, wall.pos) <= (r.reach or 3)))
            eta = 999
            for actor in w.actors:
                if actor.id in commands.busy or not (actor.bag["WallFixer"] or
                        (wall.level < 3 and actor.bag["WallUpgradeVoucher" + str(wall.level)])):
                    continue
                route = commands.route(actor)
                stand = route.best(w.stand_cells(wall))
                if stand is not None:
                    eta = min(eta, route.steps[stand] + 1)
            hp = wall.hp
            name = pending.get(wall.pos, "")
            if name == "WallFixer" or name.startswith("WallUpgradeVoucher"):
                eta = 0
                hp = wall.max_hp + (500 if name.startswith("WallUpgradeVoucher") else 0)
            self.wall_load[wall.id], self.wall_potential[wall.id], self.repair_eta[wall.id] = load, possible, eta
            horizon = max(3, min(8, eta + 1))
            if not w.daylight and possible > 0 and hp <= possible * horizon + 100:
                self.wall_alarm.add(wall.id)
        self.urgency = {r.id: self.defense_urgency(r) for r in w.robots}

    def own_threat(self, robot):
        # Unknown affiliation is treated conservatively for defense only.
        return not robot.target or robot.target == self.w.side

    def defense_urgency(self, robot):
        if not self.active_threat(robot) or not self.w.base:
            return 0.0
        close = self.w.base_distance(robot.pos)
        base_cell = min(self.w.base.cells, key=lambda p: (distance(robot.pos, p), p))
        line = set(ray(robot.pos, base_cell)[1:-1])
        shielded = any(wall.pos in line for wall in self.w.walls)
        weak_wall = any(distance(robot.pos, wall.pos) <= (robot.reach or 3) and wall.id in self.wall_alarm
                        for wall in self.w.walls)
        # This is a conservative danger estimate, not the game's path/attack AI.
        emergency = ((close <= 4 and not shielded) or weak_wall or
                     (close <= 6 and self.w.base.hp < self.w.base.max_hp * 0.35))
        return 6.0 if emergency else 0.25 * max(0, 6 - close) / 6

    def value(self, hits, health):
        score, kills = 0.0, 0
        for rid, damage in hits:
            hp = health.get(rid, 0)
            if hp <= 0:
                continue
            robot = self.robots[rid]
            points = SCORES.get(robot.kind, 1)
            if not self.own_threat(robot):
                # A finishing hit earns points and denies the rival those
                # points. Nonlethal damage only subsidizes their defense.
                if damage >= hp:
                    score += 84 * points + 0.1 * hp
                    kills += 1
                else:
                    score -= 0.5 * damage
                continue
            progress = min(1, damage / hp)
            score += 12 * points * progress + 0.2 * min(hp, damage)
            window = min(4, 130 - self.w.tick)
            score += progress * self.power(robot) * self.urgency[rid] * window
            if damage >= hp:
                kills += 1
                score += 40 * points
        return score, kills

    def splash(self, p, bomb=False):
        return self.blasts[p] if bomb else self.splashes[p]

    def urgent_hits(self, hits, health):
        return any(health.get(rid, 0) > 0 and damage > 0 and self.urgency[rid] >= 6
                   for rid, damage in hits)

    def apply(self, hits, health=None):
        health = self.health if health is None else health
        if health is self.health:
            self.shot_cache = {}
        for rid, damage in hits:
            health[rid] = max(0, health.get(rid, 0) - damage)

    def volley_value(self, hits):
        damage = Counter()
        for rid, amount in hits:
            damage[rid] += amount
        return self.value(damage.items(), self.health)[0]

    def finish_value(self, hits, health, remaining):
        """Keep a two/three-missile enemy finish in the search, without valuing
        damage which cannot be completed by this tower's current volley."""
        value = self.value(hits, health)[0]
        for rid, damage in hits:
            hp = health.get(rid, 0)
            r = self.robots[rid]
            if not self.own_threat(r) and damage < hp <= damage * remaining:
                value += (84 * SCORES.get(r.kind, 1) + 0.1 * hp) * damage / hp
        return value

    def rocket(self, tower):
        # Level-three rockets see the same board from every turret. Cache the
        # plan until damage/repair changes it, including consumable comparisons.
        origin = None if tower.reach >= max(self.w.width, self.w.height) else tower.pos
        key = (tower.level, tower.reach, origin)
        if key not in self.shot_cache:
            self.shot_cache[key] = self.plan_rocket(tower)
        return self.shot_cache[key]

    def plan_rocket(self, tower):
        health = dict(self.health)
        candidates = [p for p in self.centers if distance(p, tower.pos) <= tower.reach]
        targets, damage, total = [], [], 0.0
        for shot_index in range(tower.level):
            # A distant easy kill must not outweigh a live breach. Release this
            # restriction as soon as our allocated shots finish the threat.
            remaining = tower.level - shot_index
            live = [p for p in candidates if any(health[rid] > 0 and
                    (self.own_threat(self.robots[rid]) or health[rid] <= amount * remaining)
                    for rid, amount in self.splash(p))]
            urgent = [p for p in live if self.urgent_hits(self.splash(p), health)]
            best = max(urgent or live, key=lambda p: (self.finish_value(self.splash(p), health, remaining), p), default=None)
            if best is None:
                if not targets:
                    return [], [], 0
                # The protocol requires level-many targets; repeat a used aim.
                best = targets[-1]
            hits = self.splash(best)
            value = self.value(hits, health)[0]
            targets.append(best)
            damage.extend(hits)
            total += value
            self.apply(hits, health)
        # Compare complete volleys, not only the next missile's immediate kill.
        # Three 20-damage hits can finish a valuable 60-HP target even when each
        # individual hit loses to a distant one-point kill in the greedy plan.
        total = self.volley_value(damage)
        live = [p for p in candidates if any(self.health[rid] > 0 and
                (self.own_threat(self.robots[rid]) or self.health[rid] <= amount * tower.level)
                for rid, amount in self.splash(p))]
        urgent = [p for p in live if self.urgent_hits(self.splash(p), self.health)]
        for p in urgent or live:
            hits = self.splash(p) * tower.level
            value = self.volley_value(hits)
            if value > total:
                targets, damage, total = [p] * tower.level, hits, value
        return targets, damage, total

    def siege(self, tower):
        # Only direct wall impacts are valued; robot targets are evaluated first.
        candidates = [wall for wall in self.enemy_walls.values()
                      if self.wall_health[wall.id] > 0 and distance(wall.pos, tower.pos) <= tower.reach
                      and not any(self.health[r.id] > 0 and not self.own_threat(r)
                                  and distance(wall.pos, r.pos) <= 1 for r in self.w.robots)]
        if not candidates:
            return [], []
        enemy_base = next((u for u in self.w.enemies if u.kind == "station"), None)
        def rank(wall):
            pressure = sum(self.power(r) for r in self.w.robots
                           if not self.own_threat(r) and self.health[r.id] > 0 and distance(wall.pos, r.pos) <= 3)
            front = 0
            if enemy_base:
                cx, cy = (self.w.width - 1) / 2, (self.w.height - 1) / 2
                bx, by = enemy_base.pos[0] + 0.5, enemy_base.pos[1] - 0.5
                front = (wall.pos[0] - bx) * (cx - bx) + (wall.pos[1] - by) * (cy - by)
            return (pressure, front, -self.wall_health[wall.id], -wall.id)
        targets, hits = [], []
        health = dict(self.wall_health)
        for _ in range(tower.level):
            live = [wall for wall in candidates if health[wall.id] > 0]
            wall = max(live or candidates, key=rank)
            targets.append(wall.pos)
            hits.append((wall.id, 20))
            health[wall.id] = max(0, health[wall.id] - 20)
        return targets, hits

    def gun(self, tower):
        # Compatibility with existing mixed-tower states; our construction uses rockets.
        candidates = [r for r in self.w.robots if self.health[r.id] > 0
                      and distance(r.pos, tower.pos) <= tower.reach]
        best = ([], [], 0)
        best_rank = (False, 0)
        robot_at = {r.pos: r for r in self.w.robots}
        for target in candidates:
            energy = 10 * tower.level
            hits = []
            for p in ray(tower.pos, target.pos)[1:]:
                r = robot_at.get(p)
                if r is None or self.health[r.id] <= 0:
                    continue
                if tower.kind == "gatling":
                    hits = [(r.id, 10 * tower.level)]
                    break
                hit = min(energy, self.health[r.id])
                hits.append((r.id, hit))
                energy -= hit
                if energy <= 0:
                    break
            value = self.value(hits, self.health)[0]
            rank = (self.urgent_hits(hits, self.health), value)
            if rank > best_rank:
                best = ([target.pos] * (tower.level if tower.kind == "gatling" else 1), hits, value)
                best_rank = rank
        return best

    def fire(self, actor, commands):
        if self.w.daylight:
            return False
        choices = []
        for tower in self.w.towers:
            if tower.cooldown == 0 and commands.adjacent(actor, tower) and str(tower.id) not in commands.commands:
                targets, hits, value = self.rocket(tower) if tower.kind == "rocket" else self.gun(tower)
                if targets and value > 0:
                    choices.append((self.urgent_hits(hits, self.health), value, tower.id, tower, targets, hits))
        if choices:
            _, _, _, tower, targets, hits = max(choices, key=lambda item: item[:3])
            remaining = dict(self.health)
            self.apply(hits, remaining)
            kills = any(self.health[r.id] > 0 and remaining[r.id] == 0 for r in self.w.robots)
            # Break a pressured enemy wall in one volley only when all our
            # active robots are far away and the alternative makes no kill.
            if (tower.kind == "rocket" and not self.wall_alarm and self.w.base
                    and self.w.base.hp >= self.w.base.max_hp * 0.8
                    and not any(self.active_threat(r) and self.w.base_distance(r.pos) <= 8 for r in self.w.robots)
                    and not kills):
                aims, wall_hits = self.siege(tower)
                damage = {}
                for rid, amount in wall_hits:
                    damage[rid] = damage.get(rid, 0) + amount
                exposed = any(amount >= self.wall_health[rid] and any(
                    not self.own_threat(r) and self.health[r.id] > 0 and r.abnormal != "dizzy"
                    and distance(r.pos, self.enemy_walls[rid].pos) <= (r.reach or 3)
                    for r in self.w.robots) for rid, amount in damage.items())
                if exposed and commands.attack(actor, tower, aims):
                    self.apply(wall_hits, self.wall_health)
                    self.intents.append("siege")
                    return True
            if commands.attack(actor, tower, targets):
                self.intents.append("steal" if any(self.health[r.id] > 0 and remaining[r.id] == 0
                                    and not self.own_threat(r) for r in self.w.robots) else "defend")
                self.apply(hits)
                self.refresh(commands)
                return True
        # Safe spare fire is useful after reachable defense targets are gone.
        for tower in sorted(self.w.towers, key=lambda t: t.id):
            if (tower.kind == "rocket" and tower.cooldown == 0 and commands.adjacent(actor, tower)
                    and str(tower.id) not in commands.commands
                    and not any(self.health[r.id] > 0 and self.own_threat(r)
                                and distance(r.pos, tower.pos) <= tower.reach + 1 for r in self.w.robots)):
                targets, hits = self.siege(tower)
                if targets and commands.attack(actor, tower, targets):
                    self.apply(hits, self.wall_health)
                    self.intents.append("siege")
                    return True
        return False

    def stun(self, actor, commands):
        if self.w.daylight or actor.id in commands.busy or not actor.bag["DizzyWeapon"]:
            return False
        self.refresh(commands)
        turns = min(5, 130 - self.w.tick)
        def prevented(p):
            return sum(self.power(self.robots[rid]) * turns for rid, _ in self.centers[p]
                       if self.active_threat(self.robots[rid]) and self.urgency[rid] >= 6)
        p = max(self.centers, key=lambda p: (prevented(p), p), default=None)
        if p is None or prevented(p) < 80:
            return False
        if commands.use(actor, "DizzyWeapon", p):
            self.stunned.update(rid for rid, _ in self.centers[p])
            self.refresh(commands)
            self.intents.append("stun")
            return True
        return False

    def bomb_plan(self):
        if self.w.daylight:
            return None
        minimum = (1 if self.w.tick >= 124 else 2) if self.w.day == 10 and self.w.tick >= 100 else 6
        choices = []
        for p in self.centers:
            hits = self.splash(p, True)
            value, _ = self.value(hits, self.health)
            points = sum(SCORES.get(self.robots[rid].kind, 1) * (1 if self.own_threat(self.robots[rid]) else 2)
                         for rid, damage in hits if 0 < self.health[rid] <= damage)
            emergency_damage = sum(min(self.health[rid], damage) for rid, damage in hits if self.urgency[rid] >= 6)
            if value > 0 and (points >= minimum or emergency_damage >= 100):
                choices.append((self.urgent_hits(hits, self.health), value, points, p, hits))
        # Do not spend a remote bomb on points while an unresolved breach
        # cannot be helped by it. Keep the actor/item available to defense.
        if any(self.active_threat(r) and self.urgency[r.id] >= 6 for r in self.w.robots):
            choices = [row for row in choices if row[0]]
        return max(choices, key=lambda row: row[:4], default=None)

    def bomb(self, actor, commands):
        if self.w.daylight or actor.id in commands.busy or not actor.bag["Bomb"]:
            return False
        self.refresh(commands)
        plan = self.bomb_plan()
        if plan is None:
            return False
        urgent, value, _, p, hits = plan
        # A ready gun is free. Reserve bombs for a bigger burst or a finish the
        # gun cannot provide. Compare only operable guns, never assume operators.
        free_value = 0
        for tower in self.w.towers:
            if tower.cooldown or str(tower.id) in commands.commands or not any(
                    u.id not in commands.busy and commands.adjacent(u, tower) for u in self.w.actors):
                continue
            _, gun_hits, gun_value = self.rocket(tower) if tower.kind == "rocket" else self.gun(tower)
            if not urgent or self.urgent_hits(gun_hits, self.health):
                free_value = max(free_value, gun_value)
        if free_value >= value * 0.85:
            return False
        if commands.use(actor, "Bomb", p):
            enemy_kill = any(not self.own_threat(self.robots[rid]) and 0 < self.health[rid] <= amount for rid, amount in hits)
            self.apply(hits)
            self.intents.append("bomb_steal" if enemy_kill else "bomb_defend")
            self.refresh(commands)
            return True
        return False
