"""Extract explicit coordinates/date from this match's public clues."""
import re


def number(text):
    if text.isdecimal():
        return int(text)
    digits = {c: n for n, c in enumerate("零一二三四五六七八九")}
    if "十" in text:
        a, b = text.split("十", 1)
        return (digits.get(a, 1) if a else 1) * 10 + digits.get(b, 0)
    return digits.get(text)


def grounded_treasure(news, world):
    texts = [entry["text"] for entry in news if entry["kind"] == "folkLegends"]
    joined = "\n".join(texts)
    items = ["AcientTablet", "StarSand", "FlameBreath"]
    if not ("石板" in joined and "粉末" in joined and ("焚天" in joined or "橙红色的雾" in joined)):
        return None
    if not all(item in world.shop_prices for item in items):
        return None
    numeric = r"([零一二三四五六七八九十\d]+)"
    for text in reversed(texts):
        if "原点" not in text or "石门" not in text:
            continue
        near_origin = text.split("原点", 1)[1][:100]
        axes = re.findall(r"([东西南北])" + numeric + r"(?:公里|千米|格)", near_origin)
        values = {direction: number(value) for direction, value in axes}
        date = re.search(r"第" + numeric + r"(?:日|天)(白昼|白天|夜晚|夜间|晚上)", text)
        if "东" not in values or "北" not in values or not date:
            continue
        day = number(date[1])
        cell = (values["东"], values["北"])
        if None in cell or day is None or not world.inside(cell) or not world.day <= day <= 10:
            continue
        return {"pos": cell, "day": day, "phase": "day" if date[2] in ("白昼", "白天") else "night",
                "items": items, "evidence": text}
    return None
