"""Multi-turn task/sandbox protocol. Commands are returned to the platform only."""
import ast
import hashlib
import json
from pathlib import Path
import re
import shlex
from .world import pos, point, distance
from .treasure import grounded_treasure

SANDBOX_SOURCE = Path(__file__).with_name("task_sandbox.py").read_text(encoding="utf-8")
RUNTIME_SOURCE = Path(__file__).with_name("task_runtime.py").read_text(encoding="utf-8")
MARKER = "HUGH_TASK:"


def json_object(text):
    decoder = json.JSONDecoder()
    found = []
    for match in re.finditer(r"\{", text or ""):
        try:
            value, _ = decoder.raw_decode(text[match.start():])
            if isinstance(value, dict):
                found.append(value)
        except (ValueError, TypeError):
            pass
    return next((v for v in found if any(k in v for k in ("executeCmd", "taskAnswer", "treasure", "http", "python"))), None)


def discover_command(description, request_id="bootstrap"):
    request = json.dumps({"description": description, "id": request_id, "runtime_source": RUNTIME_SOURCE}, ensure_ascii=False)
    return "python3 -c " + shlex.quote(SANDBOX_SOURCE) + " " + shlex.quote(request)


def fingerprint(command):
    value = re.sub(r"t\d+-r\d+-q\d+", "REQUEST_ID", command.strip())
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def api_command(runner, decision):
    if "python" in decision:
        source = decision["python"]
        if not isinstance(source, str) or not 0 < len(source) <= 18000:
            raise ValueError("python 必须为 1–18000 字符源码")
        tree = ast.parse(source)
        for node in ast.walk(tree):
            imports = [a.name for a in node.names] if isinstance(node, ast.Import) else [node.module or ""] if isinstance(node, ast.ImportFrom) else []
            if any(name.split(".")[0] in {"urllib", "http", "requests", "socket", "subprocess", "os"} for name in imports):
                raise ValueError("API 访问必须使用 fetch_json；不导入网络库或运行 shell")
        payload = {"python": source}
    elif isinstance(decision.get("http"), dict):
        http = decision["http"]
        if set(http) - {"path", "params", "headers"}:
            raise ValueError("http 只支持 path、params、headers；查询参数放在 params 对象")
        if "path" in http and not isinstance(http["path"], str):
            raise ValueError("path 必须是字符串")
        if any(name in http and not isinstance(http[name], dict) for name in ("params", "headers")):
            raise ValueError("params 和 headers 必须是 JSON 对象")
        payload = {"http": http}
    else:
        raise ValueError("API 任务返回 http 或 python，执行器负责 shell 引用和答案标记")
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True)
    payload["id"] = decision["requestId"]
    encoded = json.dumps(payload, ensure_ascii=False)
    command = "python3 -X utf8 " + shlex.quote(runner) + " " + shlex.quote(encoded)
    if len(command) > 30000:
        raise ValueError("代码过长，请只处理当前一步并缩短源码")
    return command, fingerprint(canonical)


def validate_answer(answer, kind, context, verified_tokens):
    if isinstance(answer, str):
        try:
            answer = json.loads(answer)
        except ValueError:
            return None, "taskAnswer 必须是 JSON 对象"
    if not isinstance(answer, dict) or not answer:
        return None, "taskAnswer 必须是非空 JSON 对象"
    if kind == "engineering":
        if set(answer) != {"token"} or not isinstance(answer["token"], str) or answer["token"] not in verified_tokens:
            return None, "必须实际运行当前工作区的 check 并获得成功 TOKEN，不能从示例猜 token"
    if kind == "heritage":
        if set(answer) != {"city", "total_count", "world_heritage_count", "types", "oldest_era"}:
            return None, "文化遗产答案必须包含任务要求的五个字段"
        if not isinstance(answer["city"], str) or not answer["city"] or (context.get("city") and answer["city"] != context["city"]):
            return None, "city 与当前任务不匹配"
        total, world = answer["total_count"], answer["world_heritage_count"]
        if type(total) is not int or type(world) is not int or not 0 <= world <= total:
            return None, "统计数量必须是非负整数，世界遗产数量不能超过总数"
        types = answer["types"]
        if not isinstance(types, list) or not all(isinstance(t, str) and t for t in types):
            return None, "types 必须是类型名称列表"
        if len(set(types)) != len(types) or len(types) > total:
            return None, "types 必须去重且不能多于遗产总数"
        if not isinstance(answer["oldest_era"], str) or not answer["oldest_era"]:
            return None, "oldest_era 填年代最早的遗产名称"
    return answer, ""


class Tasks:
    def __init__(self):
        self.active = ""
        self.start = 0
        self.deadline = 0
        self.booted = False
        self.history = []
        self.pending = ""
        self.pending_round = 0
        self.pending_id = ""
        self.last_command = ""
        self.last_fingerprint = ""
        self.inflight = None
        self.sequence = 0
        self.context = {}
        self.kind = "unknown"
        self.verified_tokens = set()
        self.submitted = set()
        self.news = []
        self.news_seen = set()
        self.news_version = 0
        self.news_requested = 0
        self.daily_calls = 0
        self.call_day = 0
        self.treasure = None
        self.treasure_done = False
        self.treasure_attempt = -1
        self.treasure_attempts = set()
        self.iron_block_until = 0
        self.iron_block_from = 0
        self.ready = None
        self.accept_flight = None
        self.early_read_enabled = True
        self.early_read_status = "not_attempted"

    def update(self, w):
        if self.call_day != w.day:
            self.call_day, self.daily_calls = w.day, 0
        for key, text in (w.raw.get("worldNews") or {}).items():
            if not text or (key, text) in self.news_seen:
                continue
            self.news_seen.add((key, text))
            self.news.append({"day": w.day, "kind": key, "text": text})
            if key == "folkLegends":
                self.news_version += 1
            if key == "officialNews" and "铁" in text:
                if "恢复开采" in text and "完成" in text:
                    self.iron_block_until = 0
                elif "无法采集" in text or "停工" in text:
                    future = "明日" in text or "明天" in text
                    self.iron_block_from = w.day + int(future)
                    self.iron_block_until = w.day + (2 if future else 0)
        active = w.raw.get("phaseTask") or ""
        early, self.accept_flight = self.accept_flight, None
        if active != self.active:
            # Reset BEFORE reading outputs, which may still belong to the old task.
            self.active, self.start = active, w.round
            self.booted, self.ready, self.history = False, None, []
            self.last_command, self.inflight, self.context = "", None, {}
            self.last_fingerprint = ""
            self.kind, self.verified_tokens, self.submitted = "unknown", set(), set()
            if self.pending == "task":
                self.pending, self.pending_id = "", ""
            task = min(w.tasks, key=lambda t: distance(w.pioneer.pos, pos(t["taskPosition"])) if w.pioneer else 0, default={})
            self.deadline = w.round + int(task.get("timeoutRounds") or 15) - 1
        if early:
            result = w.raw.get("lastCmdResult") or ""
            packet = None
            if active and w.round == early["round"] + 1 and result.startswith("[exitCode:0]\n") and "[TRUNCATED]" not in result:
                for line in result.splitlines():
                    if line.startswith(MARKER):
                        try:
                            value = json.loads(line[len(MARKER):])
                            if value.get("id") == early["id"]:
                                packet = value
                        except (ValueError, AttributeError):
                            pass
            context = (packet or {}).get("context") or {}
            task_file = Path(context.get("task_file") or "").name
            expected = re.findall(r"task_[A-Za-z0-9_.-]+\.md", active)
            if task_file and task_file in expected:
                self.booted = True
                self.early_read_status = "used_accept_round_result"
                self.consume_result(early, result)
            else:
                self.early_read_status = "fallback_to_active_task_read"
                # No result means the platform did not make the sandbox available
                # in the accept round. Probe that ordering only once per match.
                if not packet:
                    self.early_read_enabled = False
                self.history.append({"early_read": self.early_read_status,
                                     "reason": "No matching current task file/result; read exact phaseTask now"})
        response = w.raw.get("llmResp") or ""
        if self.pending == "news" and not response and w.round > self.pending_round + 1:
            self.pending = ""
            self.news_requested = max(0, self.news_version - 1)
        if any(e.get("errorCode") == 5 for e in w.raw.get("errors") or []):
            self.daily_calls = 3
        if self.pending == "task" and w.round > self.pending_round:
            obj = json_object(response)
            if obj and obj.get("requestId") == self.pending_id:
                self.ready = obj
            else:
                self.history.append({"model_error": "Missing or mismatched requestId; output consumed once",
                                     "received_requestId": obj.get("requestId") if obj else None})
            self.pending = ""
        elif self.pending == "news" and response:
            # Old model replies cannot override explicit public evidence.
            self.pending = ""
        if self.inflight and w.round > self.inflight["round"]:
            flight, self.inflight = self.inflight, None
            result = (w.raw.get("lastCmdResult") or "") if w.round == flight["round"] + 1 else ""
            self.consume_result(flight, result)
        self.history = self.history[-5:]
        treasure_result = int(w.raw.get("lastSummonTreasureResult") or 0)
        if treasure_result in (1, 4):
            self.treasure_done = True
        elif treasure_result in (2, 3):
            self.treasure = None  # Legal failed attempts consume items; do not retry blindly.
        candidate = grounded_treasure(self.news, w)
        if candidate and self.treasure_key(candidate) not in self.treasure_attempts and not self.treasure_done:
            self.treasure = candidate
        elif self.treasure and (self.treasure["day"] < w.day or self.treasure_key(self.treasure) in self.treasure_attempts):
            self.treasure = None

    def next_id(self, w):
        self.sequence += 1
        return f"t{self.start}-r{w.round}-q{self.sequence}"

    def send_command(self, w, command, request_id, bootstrap=False, digest=None):
        self.last_command = command
        self.last_fingerprint = digest or fingerprint(command)
        self.inflight = {"round": w.round, "command": command,
                         "id": request_id, "bootstrap": bootstrap}
        return "", command

    def consume_result(self, flight, result):
        success = result.startswith("[exitCode:0]\n") and "[TRUNCATED]" not in result
        packet = None
        if success:
            for line in result.splitlines():
                if line.startswith(MARKER):
                    try:
                        value = json.loads(line[len(MARKER):])
                        if isinstance(value, dict) and value.get("id") == flight["id"]:
                            packet = value
                    except ValueError:
                        pass
        if packet and flight["bootstrap"] and isinstance(packet.get("context"), dict):
            self.context = packet["context"]
            self.kind = self.context.get("kind", "unknown")
        if packet and "observation" in packet:
            self.context["api_probe"] = packet["observation"]
        if packet and "config" in packet:
            self.context["api_config"] = packet["config"]
        # Raw checker output is also accepted, but only as the result of a
        # command containing a check invocation, never from reading the task.
        check_invoked = bool(re.search(r"(?:\./|/)check\b", flight["command"]))
        if success and self.kind == "engineering":
            checker_output = self.context.get("checker_output", "") if flight["bootstrap"] else result
            checked = self.context.get("checker_exit") == 0 if flight["bootstrap"] else check_invoked
            tokens = re.findall(r"(?m)^\s*TOKEN:\s*(\S+)\s*$", checker_output) if checked else []
            if tokens:
                self.verified_tokens.add(tokens[-1])
                self.ready = {"taskAnswer": {"token": tokens[-1]}}
        if packet and packet.get("status") == "answer":
            self.ready = {"taskAnswer": packet.get("answer"), "verified_api": bool(self.context.get("api_runner"))}
        self.history.append({"executeCmd": "bootstrap: read official materials and run supported checks/probe" if flight["bootstrap"] else
                             "managed API request/Python execution" if self.context.get("api_runner") else flight["command"][:1800],
                             "result": "See task_context" if packet and flight["bootstrap"] else result[:1800] + ("\n[history excerpt]\n" + result[-1200:] if len(result) > 3000 else result[1800:]) or "No next-round command result received"})

    def run(self, w, actor, commands):
        if not self.active or actor.id in commands.busy:
            return "", ""
        if not self.booted:
            self.booted = True
            commands.busy.add(actor.id)
            request_id = self.next_id(w)
            return self.send_command(w, discover_command(self.active, request_id), request_id, bootstrap=True)
        if self.inflight or self.pending == "task":
            commands.busy.add(actor.id)
            return "", ""
        if self.ready:
            decision, self.ready = self.ready, None
            answer = decision.get("taskAnswer")
            command = decision.get("executeCmd")
            if answer is not None:
                answer, error = validate_answer(answer, self.kind, self.context, self.verified_tokens)
                if self.context.get("api_runner") and not decision.get("verified_api"):
                    error = "API 答案须由执行器实际计算，通过 python 设置 ANSWER 和 COMPLETE"
                encoded = json.dumps(answer, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
                if error or len(encoded) > 24000 or encoded in self.submitted:
                    self.history.append({"answer_error": error or "答案已提交或过长；先核实平台反馈和数据，不能原样重交"})
                elif commands.add(actor, "submitAnswer", taskAnswer=encoded):
                    self.submitted.add(encoded)
                    self.history.append({"submitted_answer": answer})
                    return "", ""
            digest = None
            if self.context.get("api_runner") and answer is None:
                try:
                    command, digest = api_command(self.context["api_runner"], decision)
                except (ValueError, SyntaxError, TypeError, KeyError) as error:
                    self.history.append({"command_error": str(error)})
                    command = None
            if isinstance(command, str) and 0 < len(command) <= 30000:
                digest = digest or fingerprint(command)
                if digest == self.last_fingerprint:
                    self.history.append({"command_error": "上一条命令已有结果，禁止无变化地重复执行；根据结果推进下一步"})
                else:
                    commands.busy.add(actor.id)
                    return self.send_command(w, command, decision["requestId"], digest=digest)
        commands.busy.add(actor.id)
        if w.round >= self.deadline:
            return "", ""  # A new LLM reply could only arrive after expiry.
        request_id = self.next_id(w)
        context = {"task": self.active, "round": w.round,
                   "remaining_rounds": max(0, self.deadline - w.round),
                   "history": self.history[-3:], "feedback": w.raw.get("errors") or [],
                   "task_context": self.context, "requestId": request_id}
        if self.kind == "engineering":
            guide = (
                "【修复任务】依据当前spec列出需要达到的文件状态，结合实际文件和check错误完成修复。"
                "材料齐全时用一个脚本修复全部已确认问题（配置按物理行号补齐空行），随后同一命令运行./check。"
                "只有检测到CRLF shebang或执行权限错误时才修复启动问题，保持验证逻辑。"
                "保留check真实退出码和输出，不能用echo TOKEN或忽略失败伪造成功。"
                "成功check的TOKEN:行原样输出即可；程序收到后直接提交，不需模型复述。"
            )
        elif self.kind in ("heritage", "api"):
            guide = (
                "【API任务】依据本次任务指定的服务地址和API_DOCS构造请求，使用Python标准库urllib/json。"
                "先检查HTTP状态和真实JSON结构，确认记录位置、筛选字段、年代表示及是否分页；文档过时处以实际响应为准。"
                "服务是否已启动、是否需要认证都以任务正文和文档为依据，不猜路由、参数、字段名或凭据。"
                "若分页，按已确认的分页机制取全；若返回全部记录则直接统计。只有确认稳定唯一标识后才按它去重，"
                "不能按名称或类型擅自合并记录；若响应提供总数则核对，否则按实际终止条件验证取全。"
                "已确认的步骤合并执行；遇到未识别结构或错误，打印HTTP状态、响应键及少量原始记录，留待下一轮修正，不能提交半份数据。"
                "请求设超时并用time.monotonic检查整体预算，建议单次2秒、整体12秒以内；接近预算时保存已取数据和续取位置。"
            )
            if self.kind == "heritage":
                guide += (
                    "按当前正文要求用程序计算城市全部记录数、保护级别为世界遗产的数量和不重复类型，数量用JSON整数。"
                    "确认年代字段的真实含义后比较先后；若存在公元前或区间，先核实表示规则，无法判断时输出原始样本。"
                    "样例要求oldest_era填年代最早的遗产名称，具体提交含义始终以本次任务正文为准；不得拿文档示例值充当真实结果。"
                )
        else:
            guide = "任务类型尚未确认。先补齐任务文件和相关依赖，一条命令合并读取，按真实要求决定后续操作。"
        if self.context.get("api_runner"):
            return self.api_prompt(w, request_id, context), ""
        prompt = (
            "【目标】完成当前官方任务，优先减少等待回合，同时保证答案来自实际执行和验证。\n"
            "【事实依据】task是官方任务通知；task_context中的任务正文、spec和API文档来自本次沙盒读取；"
            "history.result及feedback是实际执行或平台反馈。kind只是程序的分类提示，任务要求以当前正文为准。"
            "history.executeCmd是已发出的命令，submitted_answer是尝试提交的内容，均不能单独证明执行成功；"
            "必须核对对应返回。以前模型的计划、猜测和示例答案不构成事实。\n"
            "【执行】直接给出下一条可运行的shell命令，使用现有shell或Python标准库。已读材料直接利用，缺失材料合并读取。"
            "材料足够时合并计算或修复与验证；信息不足时做能确认关键字段的一次探查，失败后根据真实错误修正。"
            "命令使用当前任务的绝对路径或显式cd，不能依赖上一条命令的工作目录。"
            "只有本次任务内文件保留；新题重新确认路径、城市、端口和数据。"
            "平台每条命令限15秒、输出限64KB；合理设超时和输出上限，为返回结果留出余量。\n"
            + guide
            + "\n【结果交付】查询程序完成计算和完整性检查后，最后print('HUGH_TASK:'+json.dumps({'id':本次requestId,'status':'answer','answer':答案对象},ensure_ascii=False))；"
            "程序下一回合会直接提交。失败只打印诊断，不打印答案标记。"
            "回复仅含一个JSON对象，回显本次requestId；命令格式 {\"requestId\":\"...\",\"executeCmd\":\"...\"}。"
            "仅当实际返回已包含完整答案时才可用 {\"requestId\":\"...\",\"taskAnswer\":{...}}；二选一，不输出XML、Markdown或解释。\n"
            + json.dumps(context, ensure_ascii=False)
        )
        self.pending = "task"
        self.pending_round = w.round
        self.pending_id = request_id
        return prompt, ""

    def api_prompt(self, w, request_id, context):
        self.pending, self.pending_round, self.pending_id = "task", w.round, request_id
        return (
            "完成当前官方 API 任务。task_context 的正文、文档、api_probe 均是本次实际读取/请求结果；以实际响应为准。\n"
            "目标是在一条 Python 脚本内完成探查、修正认证/参数、获取全部分页、统计和交卷，尽量不等待下一轮模型。"
            "先读当前错误正文和响应头，脚本用条件分支处理可能的返回结构；预计会失败的候选使用 probe/probe_many，成功后在同一脚本继续。"
            "不能把文档示例数量或记忆中的遗产答案当真实数据。\n"
            "只返回一个 JSON，回显 requestId，二选一：\n"
            '{"requestId":"本次ID","python":"Python 源码"}\n'
            '{"requestId":"本次ID","http":{"path":"文档或反馈确认的路径","params":{"city":"本次城市"},"headers":{"已确认的头":"值"}}}\n'
            "http 字段可省略以沿用默认值；headers/params 中 null 删除旧字段。成功请求的路径、参数和认证头自动成为后续请求默认值。URL 编码、HTTP 状态/错误正文由执行器处理。"
            "python 直接传源码，不加 shell、引号或 heredoc；不用 executeCmd，不输出 HUGH_TASK 标记。\n"
            "优先返回 python 完整脚本；仅当实际信息不足以编写自适应脚本时返回 http 探查。\n"
            "Python 预置：DATA=本次任务最近成功响应的完整 JSON，LAST_HTTP=最近响应，CONFIG=当前请求默认值，WORKDIR=本题目录绝对路径；"
            "probe(path=None,params=None,headers=None) 返回 {status,headers,json/body,error}，失败会记录但不会终止探查；"
            "probe_many([{path?,params?,headers?},...]) 顺序尝试最多12个不同候选，遇到有效2xx JSON就停止，返回实际观测列表。"
            "fetch_json(path=None,params=None,headers=None) 用于已确认的请求/分页，返回 JSON；失败即使被捕获也禁止交卷。所有网络访问用这些函数。"
            "json/re/time/collections 等标准库可自行 import。必须把中文城市放入 params 字典，由固定客户端 urlencode 为百分号编码；"
            "不得把裸中文拼进 URL，不用 encode('ascii')，也不能用 Unicode 转义代替 URL 编码。命令和响应按 UTF-8，源码通过明文 JSON 传输，勿自行拼 shell 引号。"
            "单请求最多2秒、整条命令HTTP预算11秒、最多24次请求；循环前用 remaining_seconds() 检查预算，不能无界试所有组合。\n"
            "候选探查：首先依据错误正文给出的字段、认证头、key、参数修改；文档可能过时，可有限尝试已有key的常见认证载体"
            "（例如 X-API-Key、Authorization Bearer），以及文档已有版本字段的少量相邻候选。不要在日志里自称候选已被确认，必须由实际返回验证。"
            "参数缺失/分页不明时，可在同一脚本比较少量 page/offset/limit/size 候选，验证返回记录或游标确实变化，不能假设参数被服务接受。"
            "只探查本题提供的本地服务；不伪造成功状态，不修改服务器数据或验收器。\n"
            "根据真实 JSON 确认记录位置、字段意义、城市筛选和分页机制；统计代码可以兼容实际发现的候选字段，无法消除歧义时打印少量原始样本。"
            "用实际响应的总数/游标/终止条件确认取全；出现重复页、取数错误或预算不足时保存进度，不生成答案。"
            "确认全部记录后用程序计算数字计数和去重类型，年代按实际表示比较，oldest_era 填最早遗产的名称。"
            "成功时设置 ANSWER=答案字典、COMPLETE=True；执行器下一回合交卷。失败分支不能设置这些变量，不吞异常。"
            "程序必须有清晰的成功条件：真实取数、分页完整、字段确认后才设置 ANSWER/COMPLETE。只有探查失败或预算耗尽才留到下一轮；"
            "打印已尝试候选及错误，保留进度，不能原样重复失败程序。\n"
            + json.dumps(context, ensure_ascii=False)
        )

    def news_prompt(self, w):
        return ""  # Explicit clues are parsed locally; missing clues stay unknown.

    def available(self, w):
        return [t for t in w.tasks if t.get("isValid") is True and int(t.get("coldDownRounds") or 0) == 0]

    def task_goals(self, w, task):
        target = pos(task["taskPosition"])
        name = w.zones.get(target)
        cells = {p for p, kind in w.zones.items() if name and kind == name} or {target}
        return {p for cell in cells for p in w.stand_cells(cell)}

    def accept(self, w, actor, commands):
        route = commands.route(actor)
        choices = []
        for task in self.available(w):
            goals = self.task_goals(w, task)
            stand = route.best(goals)
            if stand is not None:
                choices.append((route.cost[stand], pos(task["taskPosition"]), goals))
        if not choices:
            return False
        _, _, goals = min(choices)
        if actor.pos in goals:
            accepted = commands.add(actor, "acceptTask")
            if accepted and self.early_read_enabled:
                self.sequence += 1
                request_id = f"t{w.round}-r{w.round}-q{self.sequence}"
                command = discover_command("", request_id)
                self.accept_flight = {"round": w.round, "command": command,
                                      "id": request_id, "bootstrap": True}
                self.early_read_status = "sent_with_acceptTask"
            return accepted
        return commands.walk(actor, goals)

    @staticmethod
    def treasure_key(t):
        return (tuple(t["pos"]), t["day"], t["phase"], tuple(sorted(t["items"])))

    def treasure_action(self, w, actor, commands, allow_travel=True):
        t = self.treasure
        if not t or self.treasure_done or self.treasure_key(t) in self.treasure_attempts:
            return False
        if w.day > t["day"] or (w.day == t["day"] and t["phase"] == "day" and not w.daylight):
            self.treasure = None
            return False
        if not allow_travel:
            return False
        missing = [name for name in t["items"] if not actor.bag[name]]
        if missing:
            if w.day < max(1, t["day"] - 2):
                return False
            if commands.gold < w.shop_prices[missing[0]]:
                return False
            return commands.buy(actor, missing[0]) or commands.walk(actor, {p for s in w.near("weaponShop") for p in w.stand_cells(s)})
        travel = distance(actor.pos, t["pos"])
        start = (t["day"] - 1) * 130 + (71 if t["phase"] == "night" else 1)
        if w.round + travel + 5 < start:
            return False
        if commands.adjacent(actor, t["pos"]):
            if w.round < start:
                commands.busy.add(actor.id)
                return True
            if t["phase"] == "day" and not w.daylight:
                return False
            self.treasure_attempt = self.news_version
            self.treasure_attempts.add(self.treasure_key(t))
            return commands.add(actor, "summonTreasure", targetPos=[point(t["pos"])], item=t["items"])
        return commands.approach(actor, t["pos"])
