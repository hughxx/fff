"""Multi-turn task/sandbox protocol. Commands are returned to the platform only."""
import ast
import hashlib
import json
from pathlib import Path
import re
import shlex
from .world import pos, point, distance
from .treasure import grounded_treasure

SANDBOX_SOURCE = Path(__file__).with_name("task_sandbox.py").read_text(encoding="utf-8")
RUNTIME_SOURCE = Path(__file__).with_name("task_runtime.py").read_text(encoding="utf-8")
MARKER = "HUGH_TASK:"


def json_object(text):
    decoder = json.JSONDecoder()
    found = []
    for match in re.finditer(r"\{", text or ""):
        try:
            value, _ = decoder.raw_decode(text[match.start():])
            if isinstance(value, dict):
                found.append(value)
        except (ValueError, TypeError):
            pass
    return next((v for v in found if any(k in v for k in ("executeCmd", "taskAnswer", "treasure", "python", "discover", "resume"))), None)


def discover_command(description, request_id="bootstrap", profiles=None):
    request = json.dumps({"description": description, "id": request_id, "runtime_source": RUNTIME_SOURCE,
                          "profiles": profiles or []}, ensure_ascii=False)
    return "python3 -c " + shlex.quote(SANDBOX_SOURCE) + " " + shlex.quote(request)


def fingerprint(command):
    value = re.sub(r"t\d+-r\d+-q\d+", "REQUEST_ID", command.strip())
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def api_command(runner, decision):
    if decision.get("resume"):
        payload = {"resume": True}
    elif isinstance(decision.get("python"), str):
        code = decision["python"]
        if not 0 < len(code) <= 22000:
            raise ValueError("python 必须为 1–22000 字符源码")
        tree = ast.parse(code)
        for node in ast.walk(tree):
            imports = [a.name for a in node.names] if isinstance(node, ast.Import) else [node.module or ""] if isinstance(node, ast.ImportFrom) else []
            if any(name.split(".")[0] in {"urllib", "http", "requests", "socket"} for name in imports):
                raise ValueError("HTTP 访问使用 probe/collect/read_source，以保留真实响应与数据来源")
        payload = {"python": code, "resumable": decision.get("resumable") is True}
    else:
        raise ValueError("返回 python 源码；执行器处理命令引用、真实结果和提交证据")
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True)
    payload["id"] = decision["requestId"]
    command = "python3 -X utf8 " + shlex.quote(runner) + " " + shlex.quote(json.dumps(payload, ensure_ascii=False))
    if len(command.encode("utf-8")) > 60000:
        raise ValueError("命令过长，请缩短源码")
    return command, fingerprint(canonical)


def validate_answer(answer, *unused):
    try:
        value = answer if isinstance(answer, str) else json.dumps(answer, ensure_ascii=False, allow_nan=False)
        if answer is None or not value or len(value.encode("utf-8")) > 24000:
            raise ValueError("答案为空或超过提交长度")
    except (ValueError, TypeError) as error:
        return None, str(error)
    return answer, ""


def verified_result(answer, proof):
    from .task_runtime import digest
    if not isinstance(proof, dict) or proof.get("method") != "runtime_evidence_v2":
        return False
    try:
        if proof.get("answer_sha256") != digest(answer):
            return False
        sources, checks = proof.get("sources"), proof.get("checks")
        if not isinstance(sources, list) or not isinstance(checks, list) or not (sources or checks):
            return False
        for receipt in sources:
            if (not isinstance(receipt, dict) or receipt.get("complete") is not True
                    or receipt.get("kind") not in ("dataset", "file", "http_single")
                    or not re.fullmatch(r"[0-9a-f]{64}", str(receipt.get("data_sha256", "")))):
                return False
            if receipt["kind"] == "dataset":
                count, total = receipt.get("count"), receipt.get("total")
                if (type(count) is not int or count < 0 or type(receipt.get("pages")) is not int
                        or receipt["pages"] < 1 or (total is not None and (type(total) is not int or total != count))):
                    return False
        return all(isinstance(c, dict) and type(c.get("exit_code")) is int and c["exit_code"] == 0
                   and c.get("truncated") is False for c in checks)
    except (ValueError, TypeError):
        return False


class Tasks:
    def __init__(self):
        self.active = ""
        self.start = 0
        self.deadline = 0
        self.booted = False
        self.history = []
        self.pending = ""
        self.pending_round = 0
        self.pending_id = ""
        self.last_command = ""
        self.last_fingerprint = ""
        self.inflight = None
        self.sequence = 0
        self.context = {}
        self.kind = "unknown"
        self.submitted = set()
        self.news = []
        self.news_seen = set()
        self.news_version = 0
        self.news_requested = 0
        self.daily_calls = 0
        self.call_day = 0
        self.treasure = None
        self.treasure_done = False
        self.treasure_attempt = -1
        self.treasure_attempts = set()
        self.iron_block_until = 0
        self.iron_block_from = 0
        self.ready = None
        self.ready_from_runtime = False
        self.api_profiles = {}
        self.collection_status = ""

    def update(self, w):
        if self.call_day != w.day:
            self.call_day, self.daily_calls = w.day, 0
        for key, text in (w.raw.get("worldNews") or {}).items():
            if not text or (key, text) in self.news_seen:
                continue
            self.news_seen.add((key, text))
            self.news.append({"day": w.day, "kind": key, "text": text})
            if key == "folkLegends":
                self.news_version += 1
            if key == "officialNews" and "铁" in text:
                if "恢复开采" in text and "完成" in text:
                    self.iron_block_until = 0
                elif "无法采集" in text or "停工" in text:
                    future = "明日" in text or "明天" in text
                    self.iron_block_from = w.day + int(future)
                    self.iron_block_until = w.day + (2 if future else 0)
        active = w.raw.get("phaseTask") or ""
        if active != self.active:
            # Reset BEFORE reading outputs, which may still belong to the old task.
            self.active, self.start = active, w.round
            self.booted, self.ready, self.history = False, None, []
            self.ready_from_runtime = False
            self.last_command, self.inflight, self.context = "", None, {}
            self.last_fingerprint = ""
            self.collection_status = ""
            self.kind, self.submitted = "generic", set()
            if self.pending == "task":
                self.pending, self.pending_id = "", ""
            task = min(w.tasks, key=lambda t: distance(w.pioneer.pos, pos(t["taskPosition"])) if w.pioneer else 0, default={})
            self.deadline = w.round + int(task.get("timeoutRounds") or 15) - 1
        response = w.raw.get("llmResp") or ""
        if self.pending == "news" and not response and w.round > self.pending_round + 1:
            self.pending = ""
            self.news_requested = max(0, self.news_version - 1)
        if any(e.get("errorCode") == 5 for e in w.raw.get("errors") or []):
            self.daily_calls = 3
        if self.pending == "task" and w.round > self.pending_round:
            obj = json_object(response)
            if obj and obj.get("requestId") == self.pending_id:
                self.ready = obj
                self.ready_from_runtime = False
            else:
                self.history.append({"model_error": "Missing or mismatched requestId; output consumed once",
                                     "received_requestId": obj.get("requestId") if obj else None})
            self.pending = ""
        elif self.pending == "news" and response:
            # Old model replies cannot override explicit public evidence.
            self.pending = ""
        if self.inflight and w.round > self.inflight["round"]:
            flight, self.inflight = self.inflight, None
            result = (w.raw.get("lastCmdResult") or "") if w.round == flight["round"] + 1 else ""
            self.consume_result(flight, result)
        self.history = self.history[-5:]
        treasure_result = int(w.raw.get("lastSummonTreasureResult") or 0)
        if treasure_result in (1, 4):
            self.treasure_done = True
        elif treasure_result in (2, 3):
            self.treasure = None  # Legal failed attempts consume items; do not retry blindly.
        candidate = grounded_treasure(self.news, w)
        if candidate and self.treasure_key(candidate) not in self.treasure_attempts and not self.treasure_done:
            self.treasure = candidate
        elif self.treasure and (self.treasure["day"] < w.day or self.treasure_key(self.treasure) in self.treasure_attempts):
            self.treasure = None

    def next_id(self, w):
        self.sequence += 1
        return f"t{self.start}-r{w.round}-q{self.sequence}"

    def send_command(self, w, command, request_id, bootstrap=False, digest=None, managed=False):
        self.last_command = command
        self.last_fingerprint = digest or fingerprint(command)
        self.inflight = {"round": w.round, "command": command,
                         "id": request_id, "bootstrap": bootstrap, "managed": managed}
        return "", command

    def consume_result(self, flight, result):
        success = result.startswith("[exitCode:0]\n") and "[TRUNCATED]" not in result
        packet = None
        if success:
            for line in result.splitlines():
                if line.startswith(MARKER):
                    try:
                        value = json.loads(line[len(MARKER):])
                        if isinstance(value, dict) and value.get("id") == flight["id"]:
                            packet = value
                    except ValueError:
                        pass
        if packet and flight["bootstrap"] and isinstance(packet.get("context"), dict):
            self.context = packet["context"]
            self.kind = "generic"
        if packet and flight.get("managed"):
            for key in ("observation", "config", "collections", "http_history", "output", "error", "note"):
                if key in packet:
                    self.context[key] = packet[key]
                elif key in ("error", "note"):
                    self.context.pop(key, None)
            self.collection_status = packet.get("status", "")
            profile = packet.get("profile")
            if isinstance(profile, dict) and profile.get("successful_requests"):
                self.api_profiles[fingerprint(json.dumps(profile, sort_keys=True))] = profile
                self.api_profiles = dict(list(self.api_profiles.items())[-3:])
            if packet.get("status") == "answer":
                self.ready = {"taskAnswer": packet.get("answer"), "proof": packet.get("proof")}
                self.ready_from_runtime = True
        self.history.append({"executeCmd": "read current task materials" if flight["bootstrap"] else
                             "managed task Python" if flight.get("managed") else flight["command"][:1800],
                             "result": "See task_context" if packet else result[:3000] or "No command result received"})

    def run(self, w, actor, commands):
        if not self.active or actor.id in commands.busy:
            return "", ""
        if not self.booted:
            self.booted = True
            commands.busy.add(actor.id)
            if w.round >= self.deadline:
                return "", ""
            request_id = self.next_id(w)
            return self.send_command(w, discover_command(self.active, request_id, list(self.api_profiles.values())),
                                     request_id, bootstrap=True)
        if self.inflight or self.pending == "task":
            commands.busy.add(actor.id)
            return "", ""
        if self.ready:
            decision, self.ready = self.ready, None
            from_runtime, self.ready_from_runtime = self.ready_from_runtime, False
            if "taskAnswer" in decision:
                answer, error = validate_answer(decision["taskAnswer"])
                if not from_runtime or not verified_result(answer, decision.get("proof")):
                    error = "答案必须来自当前实际执行，附带已读取数据源或成功验证进程的证据；不能直接声明完成"
                encoded = answer if isinstance(answer, str) else json.dumps(answer, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
                if error or encoded in self.submitted:
                    self.history.append({"answer_error": error or "答案已经提交，请依据官方反馈修正"})
                elif commands.add(actor, "submitAnswer", taskAnswer=encoded):
                    self.submitted.add(encoded)
                    return "", ""
            elif w.round < self.deadline:
                try:
                    request_id = decision["requestId"]
                    if self.context.get("runner"):
                        command, signature = api_command(self.context["runner"], decision)
                        managed, bootstrap = True, False
                    elif isinstance(decision.get("discover"), str):
                        command = discover_command(decision["discover"], request_id, list(self.api_profiles.values()))
                        signature, managed, bootstrap = fingerprint(command), False, True
                    elif isinstance(decision.get("executeCmd"), str):
                        command = decision["executeCmd"]
                        signature, managed, bootstrap = fingerprint(command), False, False
                    else:
                        raise ValueError("尚未找到任务文件，请先定位，再用 discover 指定完整路径")
                    if not command or len(command.encode("utf-8")) > 100000:
                        raise ValueError("命令为空或过长")
                    if signature == self.last_fingerprint and decision.get("retry") is not True:
                        raise ValueError("禁止无变化地重复执行；仅实际临时故障需要重试时可声明 retry=true")
                    commands.busy.add(actor.id)
                    return self.send_command(w, command, request_id, bootstrap=bootstrap, digest=signature, managed=managed)
                except (ValueError, SyntaxError, TypeError, KeyError) as error:
                    self.history.append({"command_error": str(error)})
        commands.busy.add(actor.id)
        if self.collection_status == "progress" and self.context.get("runner") and w.round < self.deadline:
            self.collection_status = "resuming"
            request_id = self.next_id(w)
            command, signature = api_command(self.context["runner"], {"requestId": request_id, "resume": True})
            return self.send_command(w, command, request_id, digest=signature, managed=True)
        if self.deadline - w.round < 2:
            return "", ""
        request_id = self.next_id(w)
        self.pending, self.pending_round, self.pending_id = "task", w.round, request_id
        context = {"task_notice": self.active, "round": w.round, "remaining_rounds": self.deadline - w.round,
                   "requestId": request_id, "task_context": self.context, "history": self.history[-2:],
                   "official_feedback": w.raw.get("errors") or []}
        return self.task_prompt(context), ""

    def task_prompt(self, context):
        return (
            "完成当前官方任务。任务可能改变主题、数据结构、统计目标、文件规范或答案格式，必须逐项以本次正文为准。\n"
            "task_context.task_text/materials 是实际读取的材料；observation/http_history/output 是实际执行结果。"
            "示例答案、旧任务数据和模型自己的计划不能作为结果。材料已合并读取，FILE_TRUNCATED 的文件需补读。\n"
            "正常仅回复 JSON：{\"requestId\":\"本次ID\",\"python\":\"可执行 Python 源码\",\"resumable\":false}。"
            "可以用标准库处理任意文件、计算、修复或验证；不固定业务字段、统计方法、认证形式或答案键。"
            "代码在 WORKDIR 执行，使用绝对路径或 pathlib.Path(WORKDIR)。不要输出 taskAnswer、ANSWER、COMPLETE 或伪造结果标记。\n"
            "【反馈与效率】信息足够就一条脚本完成请求、有限纠错、取全、计算和验证。"
            "依据最新错误改请求，保留已经取得进展的认证和参数；不要把参数错误当认证错误，也不要忽略已有的成功配置。"
            "CONFIG.request 与 HTTP_HISTORY 随请求更新，保留最近实际尝试和响应，包括失败正文；"
            "DATA/LAST_HTTP 是本条脚本开始前的数据/响应快照，新请求使用函数实际返回。"
            "previous_task_evidence 仅为之前实际成功的请求/分页方案提示；先核对本题服务、筛选值和规则，再决定使用，不能直接套旧数据。\n"
            "【HTTP】probe(url或path=...,params={},headers={},method='GET',json_body=...,body=...) 返回实际状态、headers、json/body/error。"
            "query/header 增量更新，null 删除；中文查询统一放 params，由执行器编码。probe_many([请求,...]) 最多12个候选，首个2xx停止。"
            "fetch_json(**请求) 遇错误抛异常。不要导入网络库，访问仅限当前材料提供的服务。"
            "认证、参数和错误字段按实际内容处理，可在同脚本内有限修正；不猜数据、不吞取数错误。"
            "remaining_seconds() 给出剩余预算：整条命令11秒、单请求2秒、最多24次。\n"
            "【数据集】需要取全的列表使用 collect(name,request={...},records_path=[真实JSON路径],"
            "pagination={...},id_path=真实唯一ID路径或None)，返回完整记录列表。"
            "JSON路径是键/数组下标列表，[] 表示根。不得把包裹对象当记录列表。"
            "分页配置 mode='offset'/'page'/'cursor'/'single'；end='total'/'empty'/'short'/'next'/'has_more'/'single'。"
            "param 是实际分页请求参数名，start 是起点（offset默认0，page默认1，cursor默认省略），page 可设 step。"
            "size_param/size 控制请求页大小，position_path 是响应实际页位置，size_path 是响应实际页大小，"
            "total_path 是响应总数，next_path 是下一游标，has_more_path 是是否还有数据的布尔值。"
            "按实际文档/返回提供可用元数据；存在服务端总数必须提供 total_path。"
            "short 终止必须有实际 size_path，不能用请求大小判断取完。cursor 必须有 next_path；single 仅用于确认一次返回全部的列表。"
            "未提供ID时保留重复记录；只有契约保证唯一时才设置 id_path，不能用名称擅自去重。"
            "无响应位置的重复整页默认拒绝；只有文档确认允许且能验证翻页时才设 allow_repeated_pages=true。"
            "执行器独立检查实际页位置、ID重复、总数变化、提前结束和游标循环；不接受你自行声明取全。"
            "同名同请求的已收集页面可复用；修改请求/分页配置会重新取数。"
            "如果脚本可安全重跑，可设 resumable=true：页间耗尽预算会保存进度，下轮从头重跑该脚本并复用已验证页面；"
            "包含非幂等写操作的脚本不要启用。计算逻辑仍由你按本题要求编写，需自行断言数值、单位、筛选和输出类型。\n"
            "【其他资源与验收】read_source(name,file=绝对路径,format='json'/'csv'/'text') 读取完整文件并记录来源。"
            "read_source(name,request={...},format='json'/'text') 只证明取得一个响应；仅用于文档确认的单资源，不能冒充多页取全。"
            "run([程序,参数,...],cwd=绝对路径,timeout=秒,input=可选文本) 返回真实 id/exit_code/output/truncated；"
            "shell 用 ['sh','-lc',命令]。按本题说明运行真正的验证器，保留其逻辑，不伪造成功输出。"
            "修复与运行验证可在同脚本完成，文件行号按物理行计，路径、权限和内容按当前材料确定。\n"
            "【交付】最后 report(答案,sources=['实际读取的源名'],checks=['实际成功的进程id'])，sources/checks 至少一种。"
            "只有当前执行实际读完的数据源、实际退出0且输出未截断的验证进程可作为证据；异常或未取全禁止交卷。"
            "答案可以是JSON对象、数组、数值或原文字符串，具体形式完全按本题要求；字符串原样提交，其他值JSON序列化。"
            "数据完整不代表业务计算必然正确，交付前逐项核对任务要求。只做探查时打印诊断，不调用 report。\n"
            "如果 task_context.runner 缺失，可先返回 executeCmd 定位文件；找到后返回 {requestId,discover:任务文件完整路径} 重新读取。"
            "失败原因和配置未变化时不要重复脚本；实际临时故障才可用 retry=true。"
            "不要等待最后一回合才执行，给命令结果和提交留出时间。\n"
            + json.dumps(context, ensure_ascii=False)
        )

    def news_prompt(self, w):
        return ""  # Explicit clues are parsed locally; missing clues stay unknown.

    def available(self, w):
        return [t for t in w.tasks if t.get("isValid") is True and int(t.get("coldDownRounds") or 0) == 0]

    def task_goals(self, w, task):
        target = pos(task["taskPosition"])
        name = w.zones.get(target)
        cells = {p for p, kind in w.zones.items() if name and kind == name} or {target}
        return {p for cell in cells for p in w.stand_cells(cell)}

    def accept(self, w, actor, commands):
        route = commands.route(actor)
        choices = []
        for task in self.available(w):
            goals = self.task_goals(w, task)
            stand = route.best(goals)
            if stand is not None:
                choices.append((route.cost[stand], pos(task["taskPosition"]), goals))
        if not choices:
            return False
        _, _, goals = min(choices)
        if actor.pos in goals:
            return commands.add(actor, "acceptTask")
        return commands.walk(actor, goals)

    @staticmethod
    def treasure_key(t):
        return (tuple(t["pos"]), t["day"], t["phase"], tuple(sorted(t["items"])))

    def treasure_action(self, w, actor, commands, allow_travel=True):
        t = self.treasure
        if not t or self.treasure_done or self.treasure_key(t) in self.treasure_attempts:
            return False
        if w.day > t["day"] or (w.day == t["day"] and t["phase"] == "day" and not w.daylight):
            self.treasure = None
            return False
        if not allow_travel:
            return False
        missing = [name for name in t["items"] if not actor.bag[name]]
        if missing:
            if w.day < max(1, t["day"] - 2):
                return False
            if commands.gold < w.shop_prices[missing[0]]:
                return False
            return commands.buy(actor, missing[0]) or commands.walk(actor, {p for s in w.near("weaponShop") for p in w.stand_cells(s)})
        travel = distance(actor.pos, t["pos"])
        start = (t["day"] - 1) * 130 + (71 if t["phase"] == "night" else 1)
        if w.round + travel + 5 < start:
            return False
        if commands.adjacent(actor, t["pos"]):
            if w.round < start:
                commands.busy.add(actor.id)
                return True
            if t["phase"] == "day" and not w.daylight:
                return False
            self.treasure_attempt = self.news_version
            self.treasure_attempts.add(self.treasure_key(t))
            return commands.add(actor, "summonTreasure", targetPos=[point(t["pos"])], item=t["items"])
        return commands.approach(actor, t["pos"])
