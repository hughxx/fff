"""Multi-turn task/sandbox protocol. Commands are returned to the platform only."""
import ast
import hashlib
import json
from pathlib import Path
import re
import shlex
from .world import pos, point, distance
from .treasure import grounded_treasure

SANDBOX_SOURCE = Path(__file__).with_name("task_sandbox.py").read_text(encoding="utf-8")
RUNTIME_SOURCE = Path(__file__).with_name("task_runtime.py").read_text(encoding="utf-8")
MARKER = "HUGH_TASK:"


def clip(text, limit):
    return text if len(text) <= limit else text[:limit//2] + "\n[...middle omitted...]\n" + text[-limit//2:]


def json_object(text):
    decoder = json.JSONDecoder()
    found = []
    for match in re.finditer(r"\{", text or ""):
        try:
            value, _ = decoder.raw_decode(text[match.start():])
            if isinstance(value, dict):
                found.append(value)
        except (ValueError, TypeError):
            pass
    return next((v for v in found if any(k in v for k in ("executeCmd", "taskAnswer", "treasure", "http", "python", "collect", "discover"))), None)


def discover_command(description, request_id="bootstrap", profiles=None):
    request = json.dumps({"description": description, "id": request_id, "runtime_source": RUNTIME_SOURCE,
                          "profiles": profiles or []}, ensure_ascii=False)
    return "python3 -c " + shlex.quote(SANDBOX_SOURCE) + " " + shlex.quote(request)


def fingerprint(command):
    value = re.sub(r"t\d+-r\d+-q\d+", "REQUEST_ID", command.strip())
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def api_command(runner, decision):
    if "collect" in decision:
        if not isinstance(decision["collect"], dict):
            raise ValueError("collect 必须为对象")
        payload = {"collect": decision["collect"]}
    elif "python" in decision:
        source = decision["python"]
        if not isinstance(source, str) or not 0 < len(source) <= 18000:
            raise ValueError("python 必须为 1–18000 字符源码")
        ast.parse(source)
        payload = {"python": source}
    elif isinstance(decision.get("http"), dict):
        http = decision["http"]
        if set(http) - {"path", "params", "headers"}:
            raise ValueError("http 只支持 path、params、headers；查询参数放在 params 对象")
        if "path" in http and not isinstance(http["path"], str):
            raise ValueError("path 必须是字符串")
        if any(name in http and not isinstance(http[name], dict) for name in ("params", "headers")):
            raise ValueError("params 和 headers 必须是 JSON 对象")
        payload = {"http": http}
    else:
        raise ValueError("API 任务返回 http 或 python，执行器负责 shell 引用和答案标记")
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True)
    payload["id"] = decision["requestId"]
    encoded = json.dumps(payload, ensure_ascii=False)
    command = "python3 -X utf8 " + shlex.quote(runner) + " " + shlex.quote(encoded)
    if len(command.encode("utf-8")) > 60000:
        raise ValueError("代码过长，请只处理当前一步并缩短源码")
    return command, fingerprint(canonical)


def validate_answer(answer, kind, context, verified_tokens):
    if kind not in ("engineering", "heritage"):
        try:
            text = answer if isinstance(answer, str) else json.dumps(answer, ensure_ascii=False, allow_nan=False)
            if answer is None or not text or len(text.encode("utf-8")) > 24000:
                raise ValueError("答案为空或过长")
        except (ValueError, TypeError) as error:
            return None, str(error)
        return answer, ""
    if isinstance(answer, str):
        try:
            answer = json.loads(answer)
        except ValueError:
            return None, "taskAnswer 必须是 JSON 对象"
    if not isinstance(answer, dict) or not answer:
        return None, "taskAnswer 必须是非空 JSON 对象"
    if kind == "engineering":
        if set(answer) != {"token"} or not isinstance(answer["token"], str) or answer["token"] not in verified_tokens:
            return None, "必须实际运行当前工作区的 check 并获得成功 TOKEN，不能从示例猜 token"
    if kind == "heritage":
        if set(answer) != {"city", "total_count", "world_heritage_count", "types", "oldest_era"}:
            return None, "文化遗产答案必须包含任务要求的五个字段"
        if not isinstance(answer["city"], str) or not answer["city"] or (context.get("city") and answer["city"] != context["city"]):
            return None, "city 与当前任务不匹配"
        total, world = answer["total_count"], answer["world_heritage_count"]
        if type(total) is not int or type(world) is not int or not 0 <= world <= total:
            return None, "统计数量必须是非负整数，世界遗产数量不能超过总数"
        types = answer["types"]
        if not isinstance(types, list) or not all(isinstance(t, str) and t for t in types):
            return None, "types 必须是类型名称列表"
        if len(set(types)) != len(types) or len(types) > total:
            return None, "types 必须去重且不能多于遗产总数"
        if not isinstance(answer["oldest_era"], str) or not answer["oldest_era"]:
            return None, "oldest_era 填年代最早的遗产名称"
    return answer, ""


def verified_collection(answer, proof):
    if not isinstance(proof, dict) or proof.get("method") != "fixed_collector_v1" or proof.get("complete") is not True:
        return False
    if not isinstance(answer, dict) or proof.get("computed_answer") != answer or proof.get("city") != answer.get("city"):
        return False
    total = proof.get("total")
    if type(total) is not int or total <= 0 or total != proof.get("unique_count") or total != answer.get("total_count"):
        return False
    offset = 0
    for page in proof.get("pages", []):
        if (not isinstance(page, dict) or page.get("offset") != offset or type(page.get("count")) is not int
                or type(page.get("limit")) is not int or not 0 < page["count"] <= page["limit"]):
            return False
        offset += page["count"]
    return offset == total and bool(re.fullmatch(r"[0-9a-f]{64}", str(proof.get("ids_sha256", ""))))


class Tasks:
    def __init__(self):
        self.active = ""
        self.start = 0
        self.deadline = 0
        self.booted = False
        self.history = []
        self.pending = ""
        self.pending_round = 0
        self.pending_id = ""
        self.last_command = ""
        self.last_fingerprint = ""
        self.inflight = None
        self.sequence = 0
        self.context = {}
        self.kind = "unknown"
        self.verified_tokens = set()
        self.submitted = set()
        self.news = []
        self.news_seen = set()
        self.news_version = 0
        self.news_requested = 0
        self.daily_calls = 0
        self.call_day = 0
        self.treasure = None
        self.treasure_done = False
        self.treasure_attempt = -1
        self.treasure_attempts = set()
        self.treasure_trip = None
        self.iron_block_until = 0
        self.iron_block_from = 0
        self.ready = None
        self.ready_from_runtime = False
        self.api_profiles = {}
        self.consumed_ids = set()
        self.reply_hashes = set()
        self.collection_status = ""

    def update(self, w):
        if self.call_day != w.day:
            self.call_day, self.daily_calls = w.day, 0
        for key, text in (w.raw.get("worldNews") or {}).items():
            if not text or (key, text) in self.news_seen:
                continue
            self.news_seen.add((key, text))
            self.news.append({"day": w.day, "kind": key, "text": text})
            if key == "folkLegends":
                self.news_version += 1
            if key == "officialNews" and "铁" in text:
                if "恢复开采" in text and "完成" in text:
                    self.iron_block_until = 0
                elif "无法采集" in text or "停工" in text:
                    future = "明日" in text or "明天" in text
                    self.iron_block_from = w.day + int(future)
                    self.iron_block_until = w.day + (2 if future else 0)
        active = w.raw.get("phaseTask") or ""
        if active != self.active:
            # Reset BEFORE reading outputs, which may still belong to the old task.
            self.active, self.start = active, w.round
            self.booted, self.ready, self.history = False, None, []
            self.ready_from_runtime = False
            self.reply_hashes.clear()  # The same script may be valid for a different task.
            self.last_command, self.inflight, self.context = "", None, {}
            self.last_fingerprint = ""
            self.collection_status = ""
            self.kind, self.verified_tokens, self.submitted = "unknown", set(), set()
            if self.pending == "task":
                self.pending, self.pending_id = "", ""
            task = min(w.tasks, key=lambda t: distance(w.pioneer.pos, pos(t["taskPosition"])) if w.pioneer else 0, default={})
            self.deadline = w.round + int(task.get("timeoutRounds") or 15) - 1
        response = w.raw.get("llmResp") or ""
        if self.pending == "news" and not response and w.round > self.pending_round + 1:
            self.pending = ""
            self.news_requested = max(0, self.news_version - 1)
        if any(e.get("errorCode") == 5 for e in w.raw.get("errors") or []):
            self.daily_calls = 3
        if self.pending == "task" and w.round > self.pending_round:
            obj = json_object(response)
            supplied = obj.get("requestId") if obj else None
            task_id = re.match(r"t(\d+)-", str(supplied or ""))
            stale = (str(supplied) in self.consumed_ids or
                     (task_id and int(task_id[1]) != self.start) or
                     hashlib.sha256(response.encode("utf-8")).hexdigest() in self.reply_hashes)
            # The platform returns the one outstanding reply on the next turn.
            # Bind it here; the model need not copy or increment an internal ID.
            if obj and w.round == self.pending_round + 1 and not stale:
                self.ready = {**obj, "requestId": self.pending_id}
                self.ready_from_runtime = False
                self.reply_hashes.add(hashlib.sha256(response.encode("utf-8")).hexdigest())
                if supplied and supplied != self.pending_id:
                    self.history.append({"protocol_note": "Bound fresh reply to current request", "received_id": supplied})
            else:
                self.history.append({"model_error": "Missing, stale or late model reply", "received_requestId": supplied})
            self.consumed_ids.add(self.pending_id)
            self.pending = ""
        elif self.pending == "news" and response:
            # Old model replies cannot override explicit public evidence.
            self.pending = ""
        if self.inflight and w.round > self.inflight["round"]:
            flight, self.inflight = self.inflight, None
            result = (w.raw.get("lastCmdResult") or "") if w.round == flight["round"] + 1 else ""
            self.consume_result(flight, result)
        self.history = self.history[-5:]
        treasure_result = int(w.raw.get("lastSummonTreasureResult") or 0)
        if treasure_result in (1, 4):
            self.treasure_done = True
        elif treasure_result in (2, 3):
            self.treasure = None  # Legal failed attempts consume items; do not retry blindly.
        candidate = grounded_treasure(self.news, w)
        if candidate and self.treasure_key(candidate) not in self.treasure_attempts and not self.treasure_done:
            self.treasure = candidate
        elif self.treasure and (self.treasure["day"] < w.day or self.treasure_key(self.treasure) in self.treasure_attempts):
            self.treasure = None

    def next_id(self, w):
        self.sequence += 1
        return f"t{self.start}-r{w.round}-q{self.sequence}"

    def send_command(self, w, command, request_id, bootstrap=False, digest=None, managed=False):
        self.last_command = command
        self.last_fingerprint = digest or fingerprint(command)
        self.inflight = {"round": w.round, "command": command,
                         "id": request_id, "bootstrap": bootstrap, "managed": managed}
        return "", command

    def consume_result(self, flight, result):
        success = result.startswith("[exitCode:0]\n") and "[TRUNCATED]" not in result
        packet = None
        if success:
            for line in result.splitlines():
                if line.startswith(MARKER):
                    try:
                        value = json.loads(line[len(MARKER):])
                        if isinstance(value, dict) and value.get("id") == flight["id"]:
                            packet = value
                    except ValueError:
                        pass
        if packet and flight["bootstrap"] and isinstance(packet.get("context"), dict):
            self.context = packet["context"]
            self.kind = self.context.get("kind", "unknown")
        if packet and "observation" in packet:
            self.context["api_probe"] = packet["observation"]
        if packet and "config" in packet:
            self.context["api_config"] = packet["config"]
        if packet and "collection" in packet:
            self.context["api_collection"] = packet["collection"]
            self.collection_status = packet.get("status", "")
            self.context["collection_error"] = packet.get("error", "")
        if packet:
            for key in ("output", "stderr", "traceback", "error", "processes"):
                self.context.pop(key, None)
                if key in packet:
                    self.context[key] = packet[key]
            if packet.get("verification"):
                verification = packet["verification"]
                if verification.get("exit_code") == 0 and not verification.get("truncated") and verification.get("token"):
                    self.verified_tokens.add(verification["token"])
        profile = (packet or {}).get("profile")
        if isinstance(profile, dict) and profile.get("base_url"):
            self.api_profiles[profile["base_url"]] = profile
        # Raw checker output is also accepted, but only as the result of a
        # command containing a check invocation, never from reading the task.
        check_invoked = bool(re.search(r"(?:\./|/)check\b", flight["command"]))
        if success and self.kind == "engineering":
            checker_output = self.context.get("checker_output", "") if flight["bootstrap"] else result
            checked = self.context.get("checker_exit") == 0 if flight["bootstrap"] else check_invoked
            tokens = re.findall(r"(?m)^\s*TOKEN:\s*(\S+)\s*$", checker_output) if checked else []
            if tokens:
                self.verified_tokens.add(tokens[-1])
                self.ready = {"taskAnswer": {"token": tokens[-1]}}
        if packet and packet.get("status") == "answer" and (flight["bootstrap"] or flight.get("managed")):
            self.ready = {"taskAnswer": packet.get("answer"), "verified_api": bool(self.context.get("api_runner")),
                          "proof": packet.get("proof"), "script_fallback": packet.get("script_fallback") is True and flight.get("managed")}
            self.ready_from_runtime = True
        outside = "\n".join(line for line in result.splitlines() if not line.startswith(MARKER))
        self.context["command_output"] = clip(outside if packet else result, 6000)
        code = flight["command"]
        if flight.get("managed"):
            try:
                code = json.loads(shlex.split(code)[-1]).get("python", "continue collection")
            except (ValueError, IndexError):
                pass
        self.history.append({"executeCmd": "read materials and try supported solver" if flight["bootstrap"] else clip(code, 3500),
                             "result": {k: packet[k] for k in ("status", "error", "traceback") if k in packet} if packet else clip(result, 4000),
                             "external_output": clip(outside, 2500)})

    def run(self, w, actor, commands):
        if not self.active or actor.id in commands.busy:
            return "", ""
        if not self.booted:
            self.booted = True
            commands.busy.add(actor.id)
            request_id = self.next_id(w)
            if w.round >= self.deadline:
                return "", ""
            return self.send_command(w, discover_command(self.active, request_id, list(self.api_profiles.values())[-3:]), request_id, bootstrap=True)
        if self.inflight or self.pending == "task":
            commands.busy.add(actor.id)
            return "", ""
        if self.ready:
            decision, self.ready = self.ready, None
            from_runtime, self.ready_from_runtime = self.ready_from_runtime, False
            answer = decision.get("taskAnswer")
            command = decision.get("executeCmd")
            if answer is not None:
                answer, error = validate_answer(answer, self.kind, self.context, self.verified_tokens)
                if not from_runtime and not (self.kind == "engineering" and answer and answer.get("token") in self.verified_tokens):
                    error = "答案必须来自当前实际执行，不能直接采用模型声明"
                if self.kind == "heritage" and (not from_runtime or
                        (not decision.get("script_fallback") and not verified_collection(answer, decision.get("proof")))):
                    error = "缺少固定执行器取全证明：唯一 ID 数、服务端总数、分页覆盖和计算结果必须一致"
                encoded = answer if isinstance(answer, str) else json.dumps(answer, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
                if error or len(encoded) > 24000 or encoded in self.submitted:
                    self.history.append({"answer_error": error or "答案已提交或过长；先核实平台反馈和数据，不能原样重交"})
                elif commands.add(actor, "submitAnswer", taskAnswer=encoded):
                    self.submitted.add(encoded)
                    self.history.append({"submitted_answer": answer})
                    return "", ""
            digest = None
            if isinstance(decision.get("discover"), str) and answer is None:
                return self.send_command(w, discover_command(decision["discover"], decision["requestId"],
                                         list(self.api_profiles.values())[-3:]), decision["requestId"], bootstrap=True)
            if self.context.get("api_runner") and answer is None:
                try:
                    if self.kind == "heritage" and not ("collect" in decision or "python" in decision):
                        raise ValueError("映射问题返回collect；接口机制已改变时返回完整python脚本")
                    command, digest = api_command(self.context["api_runner"], decision)
                except (ValueError, SyntaxError, TypeError, KeyError) as error:
                    self.history.append({"command_error": str(error)})
                    command = None
            if isinstance(command, str) and 0 < len(command.encode("utf-8")) <= 60000 and w.round < self.deadline:
                digest = digest or fingerprint(command)
                if digest == self.last_fingerprint:
                    self.history.append({"command_error": "上一条命令已有结果，禁止无变化地重复执行；根据结果推进下一步"})
                else:
                    commands.busy.add(actor.id)
                    return self.send_command(w, command, decision["requestId"], digest=digest, managed=bool(self.context.get("api_runner")))
        commands.busy.add(actor.id)
        if self.collection_status == "progress" and w.round < self.deadline:
            self.collection_status = "resuming"
            request_id = self.next_id(w)
            command, digest = api_command(self.context["api_runner"], {"requestId": request_id, "collect": {}})
            return self.send_command(w, command, request_id, digest=digest, managed=True)
        if self.deadline - w.round < 2:
            return "", ""  # LLM -> command -> result/submission needs two turns.
        request_id = self.next_id(w)
        context = {"task": self.active, "round": w.round,
                   "remaining_rounds": max(0, self.deadline - w.round),
                   "history": self.history[-3:], "feedback": w.raw.get("errors") or [],
                   "task_context": self.context, "requestId": request_id}
        if self.context.get("api_runner"):
            return self.api_prompt(w, request_id, context), ""
        self.pending, self.pending_round, self.pending_id = "task", w.round, request_id
        return self.script_prompt(context), ""

    def api_prompt(self, w, request_id, context):
        self.pending, self.pending_round, self.pending_id = "task", w.round, request_id
        if self.kind == "heritage":
            # Keep the authoritative response and task, not pages of obsolete
            # generated scripts. The model supplies mappings, never answers.
            context = {**context, "history": self.history[-1:]}
            return (
                "修正当前官方文化遗产任务的接口配置。固定程序已经读取任务及 API_DOCS，并按实际错误修正认证、"
                "按 offset/limit 连续取页，独立验证 ID、偏移、总数、字段并计算答案。\n"
                "只输出 JSON：{\"collect\":{需要修改的配置}}。内部ID由程序关联。"
                "映射可以修复时优先这个短配置。不要输出taskAnswer。\n"
                "以 collection_error 和最新 api_probe 为准，保留 api_config 中已确认的认证与参数，"
                "不要因过时文档撤销服务器已经接受的修正。401 要求 Bearer 后，400 缺参数表示应补参数。\n"
                "collect 可省略不需修改的项：path 为已确认路径；headers/params 为增量字典，null 删除字段；"
                "schema 可改 records_path、pagination_path（JSON 键的列表）、id/name/type/era/protected/total/offset/limit（实际字段名）；"
                "paging 只可改 offset 和 limit 对应的请求参数名。必须根据实际响应选映射，不能凭空猜记录。\n"
                "若全部记录已取得但年代无法比较，返回 collect.era_order，将 api_collection.eras 的所有原始年代标签"
                "从最早到最晚排列，每个恰好一次。不得提供遗产名称或统计答案。"
                "若只是暂时网络故障且配置无需改变，collect={} 触发重新验证。\n"
                "若接口已改为游标等旧采集流程无法表达的机制，可返回 {\"python\":\"完整脚本\"}。"
                "脚本使用probe/fetch_json实际取数，按真实元数据取全并断言，计算当前五个字段，最后report(answer)。"
                "探索失败用probe，最终取数用fetch_json；不要只取第一页或采用上次数据。\n"
                + json.dumps(context, ensure_ascii=False)
            )
        return self.script_prompt(context)

    def script_prompt(self, context):
        return (
            "完成当前官方任务。task_context.task_text/materials/spec/api_docs 是实际读取的材料；"
            "command_output/output/stderr/traceback/api_probe/history.result 是真实执行反馈。以本题正文和真实返回为准。\n"
            "已知流程无法直接处理本题时由你编写完整求解程序。正常仅返回 JSON：{\"python\":\"Python源码\"}，无需填写内部ID。"
            "如果 api_runner 缺失，先用 {executeCmd:定位命令} 找到文件，再返回 {discover:任务文件完整路径}。\n"
            "尽量在一条脚本内完成探查、修复、取全、计算和验收。候选失败可以记录后继续；找到成功方案后真正调用后续步骤，"
            "不能只定义函数。不要沿用示例答案或过去任务的数据。\n"
            "【预防错误】中文参数放params交给urlencode，文件/输出使用UTF-8。配置按物理行补空行。"
            "目录用绝对路径或WORKDIR，不依赖上一条命令的cd。文件存在却启动失败时检查首行CRLF、解释器和权限，保留验收逻辑。"
            "先看JSON键和类型，不能把包裹对象当列表。用实际返回的偏移和页大小推进；请求size不等于实际返回limit。"
            "遇到重复页或ID先修翻页方式，不能去重到少量数据就交卷。总数、尾页和本题筛选条件都要核对。\n"
            "【可用函数，直接调用无需import】probe(path=None,params=None,headers=None)返回status/headers/json/body/error，"
            "失败候选不阻止之后成功的方案；probe_many([候选字典,...])遇成功2xx JSON停止。"
            "fetch_json用于最终取数，错误会抛异常。成功请求可继续沿用，保留已修正的认证，不要因缺参数重新撤销认证。"
            "这些请求限当前材料提供的服务，单请求2秒、共享11秒、最多24次；不要穷举无依据的组合。\n"
            "read_file(路径,format='text'/'json'/'csv')读取实际文件。run([程序,参数,...],cwd=目录)返回exit_code/output/truncated；"
            "探查命令可按返回码分支。verify([本题真正验收器,...],cwd=目录)要求退出0和完整输出，失败即使捕获也不能交卷；"
            "再次对同一验收器验证成功可消除前次失败。标准库可用，但最终验收推荐verify。"
            "WORKDIR为本题目录，DATA为最近数据快照，CONFIG为当前请求配置。\n"
            "【交付】同一脚本中计算answer并调用report(answer)，不要提供sources/checks名称，不要直接回复taskAnswer或伪造TOKEN。"
            "已识别的部署任务会在脚本结束后独立重跑官方check，最终只提交真实TOKEN。其他题必须按正文完成断言和验收。"
            "未捕获异常或最终验收失败不提交；允许失败的探索不要使用verify。\n"
            "最小文件计算示例：rows=read_file('input.csv',format='csv'); answer=sum(int(r['amount']) for r in rows); report(answer)。"
            "此处文件名和字段只是用法示例，实际以本题为准。\n"
            + json.dumps(context, ensure_ascii=False)
        )

    def news_prompt(self, w):
        return ""  # Explicit clues are parsed locally; missing clues stay unknown.

    def available(self, w):
        return [t for t in w.tasks if t.get("isValid") is True and int(t.get("coldDownRounds") or 0) == 0]

    def task_goals(self, w, task):
        target = pos(task["taskPosition"])
        name = w.zones.get(target)
        cells = {p for p, kind in w.zones.items() if name and kind == name} or {target}
        return {p for cell in cells for p in w.stand_cells(cell)}

    def accept(self, w, actor, commands):
        route = commands.route(actor)
        choices = []
        for task in self.available(w):
            goals = self.task_goals(w, task)
            stand = route.best(goals)
            if stand is not None:
                choices.append((route.cost[stand], pos(task["taskPosition"]), goals))
        if not choices:
            return False
        _, _, goals = min(choices)
        if actor.pos in goals:
            return commands.add(actor, "acceptTask")
        return commands.walk(actor, goals)

    @staticmethod
    def treasure_key(t):
        return (tuple(t["pos"]), t["day"], t["phase"], tuple(sorted(t["items"])))

    def treasure_action(self, w, actor, commands, allow_travel=True):
        t = self.treasure
        if not t or self.treasure_done or self.treasure_key(t) in self.treasure_attempts:
            return False
        if w.day > t["day"] or (w.day == t["day"] and t["phase"] == "day" and not w.daylight):
            self.treasure = None
            return False
        key = self.treasure_key(t)
        if not allow_travel:
            # Once the expedition has begun, reserve the pioneer while the
            # temporary operator arrives. Do not recall both actors to the gun.
            if self.treasure_trip == key and w.base and w.base.hp >= w.base.max_hp * 0.4:
                commands.busy.add(actor.id)
                return True
            self.treasure_trip = None
            return False
        missing = [name for name in t["items"] if not actor.bag[name]]
        if missing:
            if w.day < max(1, t["day"] - 2):
                return False
            if commands.gold < w.shop_prices[missing[0]]:
                return False
            return commands.buy(actor, missing[0]) or commands.walk(actor, {p for s in w.near("weaponShop") for p in w.stand_cells(s)})
        route = commands.route(actor)
        stand = route.best(w.stand_cells(t["pos"]))
        if stand is None:
            return False
        travel = route.steps[stand]
        start = (t["day"] - 1) * 130 + (71 if t["phase"] == "night" else 1)
        depart = start - travel - 8
        if t["phase"] == "day" and t["day"] > 1:
            # A morning opening competes with the other player. Leave during
            # the preceding daylight, giving the backup time to take over.
            preceding_dusk = (t["day"] - 2) * 130 + 70
            depart = min(depart, preceding_dusk - travel - 8)
        if self.treasure_trip != key and w.round < depart:
            return False
        self.treasure_trip = key
        if commands.adjacent(actor, t["pos"]):
            if w.round < start:
                commands.busy.add(actor.id)
                return True
            if t["phase"] == "day" and not w.daylight:
                return False
            self.treasure_attempt = self.news_version
            self.treasure_attempts.add(self.treasure_key(t))
            self.treasure_trip = None
            return commands.add(actor, "summonTreasure", targetPos=[point(t["pos"])], item=t["items"])
        return commands.approach(actor, t["pos"])
