"""Task sandbox HTTP transport, verified heritage collection and API fallback."""
import json
import hashlib
from pathlib import Path
import re
import sys
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request

SCHEMA = {"records_path": ["data", "records"], "pagination_path": ["data", "pagination"],
          "id": "id", "name": "name", "type": "type", "era": "era", "protected": "protected_level",
          "total": "total_count", "offset": "offset", "limit": "limit"}


def lookup(value, path):
    for key in path:
        if not isinstance(value, dict) or key not in value:
            raise ValueError("Unknown response structure at " + repr(path))
        value = value[key]
    return value


def era_rank(label):
    # Only relative chronology is used, never a remembered heritage answer.
    periods = ["旧石器", "新石器", "夏", "商", "西周", "东周", "春秋", "战国", "秦", "西汉", "东汉",
               "三国", "西晋", "东晋", "南北朝", "隋", "唐", "五代", "辽", "北宋", "西夏", "金",
               "南宋", "元", "明", "清", "民国", "现代"]
    aliases = {"周": "西周", "汉": "西汉", "晋": "西晋", "宋": "北宋"}
    clean = re.sub(r"时代|时期|[\s、，,；;/\-—至到]", "", label)
    pattern = "(" + "|".join(sorted(periods + list(aliases), key=len, reverse=True)) + ")(?:朝|代)?"
    matches = list(re.finditer(pattern, clean))
    tokens = [m[1] for m in matches]
    if not tokens or "".join(m[0] for m in matches) != clean:
        raise ValueError("Unknown era; provide era_order for all observed labels: " + label)
    return min(periods.index(aliases.get(token, token)) for token in tokens)


def documented_request(body, docs, city):
    """Use this task's documented example; never invent auth or pagination."""
    bases = re.findall(r"https?://(?:localhost|127\.0\.0\.1|\[::1\])(?::\d+)?", body)
    examples = re.findall(r'https?://[^\s`"<>]+/[^\s`"<>]*', docs)
    if not bases or not examples:
        return None
    base = urllib.parse.urlsplit(bases[0])
    sample = next((urllib.parse.urlsplit(u) for u in examples
                   if urllib.parse.urlsplit(u).netloc == base.netloc), None)
    if sample is None:
        return None
    params = dict(urllib.parse.parse_qsl(sample.query))
    if city and "city" in params:
        params["city"] = city
    headers = dict(re.findall(r'-H\s+["\']([^:"\']+):\s*([^"\']+)["\']', docs))
    return {"base_url": urllib.parse.urlunsplit((base.scheme, base.netloc, "", "", "")),
            "path": sample.path, "params": params, "headers": headers}


class Runtime:
    def __init__(self, state_path, config=None):
        self.path = Path(state_path)
        self.state = {"config": config, "last": None, "data": None} if config is not None else json.loads(self.path.read_text(encoding="utf-8"))
        self.observations = []
        self.failed = False
        self.started = time.monotonic()
        self.request_count = 0

    def http_summary(self, observation):
        """Keep useful status, paging and IDs visible even for large responses."""
        summary = {k: observation[k] for k in ("url", "request_headers", "status", "error", "truncated") if k in observation}
        body = observation.get("json")
        if isinstance(body, dict):
            schema = self.state.get("schema", SCHEMA)
            try:
                rows = lookup(body, schema["records_path"])
                paging = lookup(body, schema["pagination_path"])
                summary.update(pagination=paging, records_count=len(rows),
                               ids=[r.get(schema["id"]) for r in rows[:25]])
            except (ValueError, TypeError, AttributeError, KeyError):
                summary["json"] = bounded(body, 1200)
        else:
            summary["body"] = str(observation.get("body", ""))[:500]
        return summary

    def remaining_seconds(self):
        return max(0.0, 11 - (time.monotonic() - self.started))

    def save(self):
        self.path.write_text(json.dumps(self.state, ensure_ascii=False), encoding="utf-8")

    def fetch(self, path=None, params=None, headers=None):
        config = self.state["config"]
        base = urllib.parse.urlsplit(config["base_url"])
        target = urllib.parse.urlsplit(urllib.parse.urljoin(config["base_url"], path or config["path"]))
        if (target.scheme, target.netloc) != (base.scheme, base.netloc):
            raise ValueError("API request must use the service specified by this task")
        query = dict(config.get("params", {}))
        if params is not None:
            query.update(params)
        query.update(urllib.parse.parse_qsl(target.query))
        query = {k: v for k, v in query.items() if v is not None}
        url = urllib.parse.urlunsplit((target.scheme, target.netloc,
              urllib.parse.quote(urllib.parse.unquote(target.path), safe="/"),
              urllib.parse.urlencode(query, doseq=True), ""))
        auth = dict(config.get("headers", {}))
        for name, value in (headers or {}).items():
            if value is None:
                auth.pop(name, None)
            else:
                auth[name] = str(value)
        observation = {"url": url, "request_headers": auth}
        try:
            budget = self.remaining_seconds()
            if budget <= 0 or self.request_count >= 24:
                raise TimeoutError("Command HTTP time budget exhausted; save progress and continue next turn")
            self.request_count += 1
            request = urllib.request.Request(url, headers=auth)
            try:
                response = urllib.request.urlopen(request, timeout=min(2.0, budget))
            except urllib.error.HTTPError as error:
                response = error  # Preserve the actual error body and headers.
            with response:
                raw = response.read(131073)
                observation.update(status=response.code, headers=dict(response.headers), truncated=len(raw) > 131072)
            body = raw[:131072].decode("utf-8-sig", errors="replace")
            try:
                observation["json"] = json.loads(body)
            except ValueError:
                observation["body"] = body
            if 200 <= observation["status"] < 300 and not observation["truncated"] and "json" in observation:
                # Only successful requests establish reusable defaults/data.
                self.state["config"]["headers"] = auth
                self.state["config"]["path"] = target.path
                self.state["config"]["params"] = query
                self.state["data"] = observation.get("json")
        except Exception as error:
            observation.update(status=None, error=type(error).__name__ + ": " + str(error))
        self.state["last"] = observation
        self.observations.append(observation)
        self.save()
        print("HUGH_HTTP:" + json.dumps(self.http_summary(observation), ensure_ascii=False, separators=(",", ":")))
        return observation

    def probe_many(self, candidates):
        if not isinstance(candidates, list) or len(candidates) > 12:
            raise ValueError("probe_many expects at most 12 candidate requests")
        results, seen = [], set()
        for candidate in candidates:
            signature = json.dumps(candidate, sort_keys=True, ensure_ascii=False)
            if signature in seen:
                continue
            seen.add(signature)
            if self.remaining_seconds() <= 0 or self.request_count >= 24:
                break
            response = self.fetch(**candidate)
            results.append(response)
            if response.get("status") is not None and 200 <= response["status"] < 300 and "json" in response and not response.get("truncated"):
                break
        return results

    def fetch_json(self, path=None, params=None, headers=None):
        response = self.fetch(path, params, headers)
        if response.get("status") is None or not 200 <= response["status"] < 300 or response.get("truncated") or "json" not in response:
            self.failed = True
            raise RuntimeError("API request failed: " + json.dumps(response, ensure_ascii=False)[:8000])
        return response["json"]

    def profile(self):
        config = self.state["config"]
        if not self.state.get("collection", {}).get("records"):
            return None
        city = config.get("city")
        return {"base_url": config["base_url"], "documented_path": config.get("documented_path", config["path"]),
                "path": config["path"], "headers": config.get("headers", {}), "city": city,
                "params": {k: v for k, v in config.get("params", {}).items() if k not in ("offset", "limit", "page", "size")},
                "schema": self.state.get("schema", SCHEMA), "paging": self.state.get("paging", {"offset": "offset", "limit": "limit"})}

    def repaired_fetch(self, params):
        """Advance only on an explicit error from this service, preserving fixes."""
        seen = set()
        while self.remaining_seconds() > 0 and self.request_count < 24:
            config = self.state["config"]
            signature = json.dumps([config, params], sort_keys=True, ensure_ascii=False)
            if signature in seen:
                break
            seen.add(signature)
            response = self.fetch(params=params)
            body = response.get("json") or {}
            message = body.get("message", "") if isinstance(body, dict) else ""
            if response.get("status") == 401 and "Authorization" in message and "Bearer" in message:
                key = config.get("documented_key")
                if not key:
                    break
                config.setdefault("headers", {})["Authorization"] = "Bearer " + key
            elif response.get("status") == 400:
                missing = re.search(r"Missing required parameter:\s*['\"]?([A-Za-z_][A-Za-z_0-9]*)", message)
                if not missing or missing[1] not in ("city", "location") or not config.get("city"):
                    break
                config.setdefault("params", {})[missing[1]] = config["city"]
                params[missing[1]] = config["city"]
            else:
                return response
            self.save()
        return self.state.get("last") or {"status": None, "error": "HTTP budget exhausted"}

    def collect(self, plan=None):
        """Own the dataset and its completeness proof; no model completion flag."""
        plan = plan or {}
        result = {"status": "needs_plan"}
        try:
            if not isinstance(plan, dict) or set(plan) - {"path", "params", "headers", "schema", "paging", "era_order"}:
                raise ValueError("collect supports path/params/headers/schema/paging/era_order only")
            config = self.state["config"]
            if config.get("kind") != "heritage" or not config.get("city"):
                raise ValueError("Fixed collector requires a current heritage task and city")
            if any(k in plan for k in ("path", "params", "headers", "schema", "paging")):
                # A new query/schema may represent different records. Never mix.
                self.state.pop("collection", None)
                self.state["data"] = None
                for key in ("params", "headers"):
                    if key in plan:
                        if not isinstance(plan[key], dict):
                            raise ValueError(key + " must be an object")
                        config.setdefault(key, {}).update(plan[key])
                        config[key] = {k: v for k, v in config[key].items() if v is not None}
                if "path" in plan:
                    if not isinstance(plan["path"], str):
                        raise ValueError("path must be a string")
                    config["path"] = plan["path"]
            for key, default in (("schema", SCHEMA), ("paging", {"offset": "offset", "limit": "limit"})):
                value = {**self.state.get(key, default), **plan.get(key, {})}
                if set(value) != set(default):
                    raise ValueError("Unknown " + key + " fields")
                for name, item in value.items():
                    if name.endswith("_path"):
                        if not isinstance(item, list) or not all(isinstance(v, str) for v in item):
                            raise ValueError("JSON paths must be lists of keys")
                    elif not isinstance(item, str) or not item:
                        raise ValueError("Field and parameter names must be nonempty strings")
                self.state[key] = value
            schema, paging = self.state["schema"], self.state["paging"]
            for key in ("city", "location"):
                if key in config.get("params", {}) and config["params"][key] != config["city"]:
                    raise ValueError("Query city does not match current official task")
            parsed_path = urllib.parse.urlsplit(config["path"])
            if parsed_path.query:
                raise ValueError("Put query values in params, not path")
            collection = self.state.setdefault("collection", {"records": {}, "total": None, "next_offset": 0,
                                                              "limit": 10, "pages": [], "complete": False})
            while not collection["complete"]:
                if self.remaining_seconds() < 0.2 or self.request_count >= 24:
                    result = {"status": "progress", "note": "HTTP budget reached; resume fixed collector"}
                    break
                requested = collection["next_offset"]
                params = {"page": None, "size": None, paging["offset"]: requested, paging["limit"]: collection["limit"]}
                response = self.repaired_fetch(params)
                if response.get("status") != 200 or response.get("truncated") or "json" not in response:
                    raise ValueError("Cannot collect: " + json.dumps(self.http_summary(response), ensure_ascii=False))
                rows = lookup(response["json"], schema["records_path"])
                page = lookup(response["json"], schema["pagination_path"])
                if not isinstance(rows, list) or not all(isinstance(r, dict) for r in rows) or not isinstance(page, dict):
                    raise ValueError("Expected a list of record objects and pagination object")
                total, offset, limit = [page.get(schema[k]) for k in ("total", "offset", "limit")]
                if any(type(v) is not int for v in (total, offset, limit)) or total < 0 or limit <= 0:
                    raise ValueError("Invalid actual pagination total/offset/limit")
                if offset != requested:
                    raise ValueError(f"Pagination did not advance: requested offset {requested}, returned {offset}")
                if collection["total"] is not None and total != collection["total"]:
                    raise ValueError("Server total changed during collection")
                if len(rows) > limit or offset + len(rows) > total or (not rows and offset < total):
                    raise ValueError("Page size/total inconsistent; do not submit")
                additions = {}
                for row in rows:
                    ident = row.get(schema["id"])
                    if type(ident) not in (str, int) or ident == "":
                        raise ValueError("Missing stable record ID")
                    key = json.dumps(ident, ensure_ascii=False)
                    if key in collection["records"] or key in additions:
                        raise ValueError("Repeated record ID/page: " + key)
                    if any(not isinstance(row.get(schema[k]), str) or not row[schema[k]]
                           for k in ("name", "type", "era", "protected")):
                        raise ValueError("Missing or invalid heritage fields; inspect schema")
                    if row.get("city") is not None and row["city"] != config["city"]:
                        raise ValueError("Record belongs to another city")
                    additions[key] = row
                collection["records"].update(additions)
                collection.update(total=total, next_offset=offset + len(rows), limit=limit)
                collection["pages"].append({"offset": offset, "limit": limit, "count": len(rows)})
                collection["complete"] = len(collection["records"]) == total and collection["next_offset"] == total
                self.save()
            if collection["complete"]:
                rows = list(collection["records"].values())
                if not rows:
                    raise ValueError("No records from which to select oldest heritage")
                labels = sorted({r[schema["era"]] for r in rows})
                supplied = plan.get("era_order")
                if supplied is not None:
                    if not isinstance(supplied, list) or len(supplied) != len(labels) or set(supplied) != set(labels):
                        raise ValueError("era_order must contain every observed era exactly once, oldest first")
                    ranks = {label: i for i, label in enumerate(supplied)}
                else:
                    ranks = {label: era_rank(label) for label in labels}
                oldest = min(rows, key=lambda r: ranks[r[schema["era"]]])
                answer = {"city": config["city"], "total_count": len(rows),
                          "world_heritage_count": sum(r[schema["protected"]] == "世界遗产" for r in rows),
                          "types": sorted({r[schema["type"]] for r in rows}), "oldest_era": oldest[schema["name"]]}
                # Independent fixed-code summary sent to the agent for its second gate.
                proof = {"method": "fixed_collector_v1", "city": config["city"], "total": collection["total"],
                         "unique_count": len(rows), "complete": True, "pages": collection["pages"],
                         "ids_sha256": hashlib.sha256("\n".join(sorted(collection["records"])).encode()).hexdigest(),
                         "computed_answer": answer}
                result = {"status": "answer", "answer": answer, "proof": proof}
        except (ValueError, TypeError, KeyError) as error:
            result = {"status": "needs_plan", "error": str(error)}
        collection = self.state.get("collection", {})
        schema = self.state.get("schema", SCHEMA)
        result["collection"] = {k: v for k, v in collection.items() if k != "records"}
        result["collection"]["unique_count"] = len(collection.get("records", {}))
        result["collection"]["eras"] = sorted({str(r.get(schema["era"], "")) for r in collection.get("records", {}).values()})
        result["profile"] = self.profile()
        result["config"] = self.state["config"]
        result["observation"] = bounded(self.state.get("last"))
        self.save()
        print("HUGH_COLLECTION:" + json.dumps({"status": result["status"], "error": result.get("error"),
              **result["collection"]}, ensure_ascii=False, separators=(",", ":")))
        return result

    def execute(self, packet):
        if self.state["config"].get("kind") == "heritage":
            if "collect" not in packet:
                return {"status": "needs_plan", "error": "Heritage tasks require collect; Python ANSWER/COMPLETE cannot bypass collection"}
            return self.collect(packet["collect"])
        if "http" in packet:
            request = packet["http"]
            self.fetch(request.get("path"), request.get("params"), request.get("headers"))
            return {"status": "observation", "observation": self.state["last"], "config": self.state["config"]}
        # The wrapper owns shell quoting, correlation IDs, and answer delivery.
        scope = {"__name__": "__task__", "fetch_json": self.fetch_json,
                 "probe": self.fetch, "probe_many": self.probe_many, "remaining_seconds": self.remaining_seconds,
                 "DATA": self.state.get("data"), "LAST_HTTP": self.state.get("last"),
                 "WORKDIR": str(self.path.parent),
                 "CONFIG": json.loads(json.dumps(self.state["config"])),
                 "ANSWER": None, "COMPLETE": False}
        try:
            exec(compile(packet["python"], "<task python>", "exec"), scope)
            if scope.get("ANSWER") is not None:
                last = self.state.get("last") or {}
                if (self.failed or self.state.get("data") is None or scope.get("COMPLETE") is not True
                        or last.get("status") is None or not 200 <= last["status"] < 300 or last.get("truncated") or "json" not in last):
                    raise ValueError("Cannot submit: failed HTTP request, no verified API data, or completeness not established")
                if not isinstance(scope["ANSWER"], dict):
                    raise ValueError("ANSWER must be a JSON object")
                return {"status": "answer", "answer": scope["ANSWER"]}
            return {"status": "observation", "observation": self.state.get("last"),
                    "note": "No ANSWER set; inspect output and continue"}
        except Exception as error:
            return {"status": "error", "error": type(error).__name__ + ": " + str(error),
                    "traceback": traceback.format_exc()[-3000:], "observation": self.state.get("last")}


def bounded(value, limit=18000):
    text = json.dumps(value, ensure_ascii=False)
    return value if len(text.encode("utf-8")) <= limit else {"truncated": True, "preview": text[:limit // 4],
             "note": "Full last JSON response is available as DATA inside the next Python execution"}


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    packet = json.loads(sys.argv[1])
    runtime = Runtime(Path(__file__).with_name(".hugh_api_state.json"))
    result = runtime.execute(packet)
    result.setdefault("observation", runtime.state.get("last"))
    result.setdefault("config", runtime.state["config"])
    if "observation" in result:
        result["observation"] = bounded(result["observation"])
    result["id"] = packet["id"]
    print("HUGH_TASK:" + json.dumps(result, ensure_ascii=False, separators=(",", ":")))


if __name__ == "__main__":
    main()
