"""Task-independent execution, source receipts, HTTP and pagination checks."""
from contextlib import redirect_stdout
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value):
    return hashlib.sha256(encoded(value).encode("utf-8")).hexdigest()


def clone(value):
    return json.loads(encoded(value))


def lookup(value, path):
    if not isinstance(path, list):
        raise ValueError("A JSON path must be a list of keys or array indices")
    for key in path:
        if isinstance(value, dict) and isinstance(key, str) and key in value:
            value = value[key]
        elif isinstance(value, list) and type(key) is int and 0 <= key < len(value):
            value = value[key]
        else:
            raise ValueError("JSON path not present: " + repr(path))
    return value


def bounded(value, limit=12000):
    text = encoded(value)
    return value if len(text.encode("utf-8")) <= limit else {
        "truncated": True, "preview": text[:limit // 4],
        "note": "Log preview only; complete responses and datasets remain in task state."}


class ContinueNextTurn(Exception):
    """A verified page checkpoint exists; replay only an explicitly resumable script."""


class LimitedOutput(io.StringIO):
    def write(self, text):
        remaining = max(0, 7000 - self.tell())
        super().write(text[:remaining])
        return len(text)


class Runtime:
    def __init__(self, state_path, config=None):
        self.path = Path(state_path)
        self.state = ({"config": clone(config), "last": None, "data": None, "sources": {},
                       "checks": {}, "successful_requests": [], "http_history": []}
                      if config is not None else json.loads(self.path.read_text(encoding="utf-8")))
        self.started, self.request_count = time.monotonic(), 0
        self.used, self.used_checks = set(), set()
        self.answer = None
        self.reported = False
        self.proof = None
        self.log_bytes = 0

    def remaining_seconds(self):
        return max(0.0, 11 - (time.monotonic() - self.started))

    def save(self):
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(encoded(self.state), encoding="utf-8")
        temporary.replace(self.path)

    def emit(self, label, value):
        line = label + ":" + encoded(bounded(value, 1800))
        size = len(line.encode("utf-8"))
        if self.log_bytes + size < 15000:
            print(line)
            self.log_bytes += size

    def request_config(self, request=None):
        request = request or {}
        if not isinstance(request, dict) or set(request) - {"url", "path", "method", "params", "headers", "json_body", "body"}:
            raise ValueError("request supports url/path/method/params/headers/json_body/body")
        defaults = self.state["config"].get("request", {})
        result = {**defaults, **request}
        if "path" in request and "url" not in request:
            result["url"] = urllib.parse.urljoin(defaults.get("url", self.state["config"].get("base_url", "")), request["path"])
        result.pop("path", None)
        result.setdefault("url", self.state["config"].get("base_url", ""))
        for field in ("params", "headers"):
            if not isinstance(request.get(field, {}), dict):
                raise ValueError(field + " must be an object")
            result[field] = {**defaults.get(field, {}), **request.get(field, {})}
            result[field] = {k: v for k, v in result[field].items() if v is not None}
        target = urllib.parse.urlsplit(result["url"])
        origin = urllib.parse.urlunsplit((target.scheme, target.netloc, "", "", ""))
        if target.scheme not in ("http", "https") or origin not in self.state["config"].get("services", []):
            raise ValueError("Use an HTTP service referenced in the current task materials")
        params = dict(urllib.parse.parse_qsl(target.query))
        params.update(result["params"])
        result["params"] = params
        result["url"] = urllib.parse.urlunsplit((target.scheme, target.netloc,
                          urllib.parse.quote(urllib.parse.unquote(target.path), safe="/"), "", ""))
        result["method"] = str(result.get("method", "GET")).upper()
        return result

    def fetch(self, path=None, params=None, headers=None, _resolved=None, **options):
        request = {**options}
        for key, value in (("path", path), ("params", params), ("headers", headers)):
            if value is not None:
                request[key] = value
        config = clone(_resolved) if _resolved is not None else self.request_config(request)
        # Persist the latest attempted request as well as separate successful
        # evidence. A 400 must not silently restore headers used before a 401.
        self.state["config"]["request"] = clone(config)
        query = urllib.parse.urlencode(config["params"], doseq=True)
        url = config["url"] + ("?" + query if query else "")
        observation = {"url": url, "request": clone(config)}
        try:
            budget = self.remaining_seconds()
            if budget <= 0 or self.request_count >= 24:
                raise TimeoutError("HTTP budget exhausted")
            self.request_count += 1
            auth = {k: str(v) for k, v in config["headers"].items()}
            body = config.get("body")
            if config.get("json_body") is not None:
                if body is not None:
                    raise ValueError("Choose body or json_body")
                body = encoded(config["json_body"])
                auth.setdefault("Content-Type", "application/json; charset=utf-8")
            if isinstance(body, str):
                body = body.encode("utf-8")
            request = urllib.request.Request(url, data=body, headers=auth, method=config["method"])
            try:
                response = urllib.request.urlopen(request, timeout=min(2.0, budget))
            except urllib.error.HTTPError as error:
                response = error
            with response:
                raw = response.read(262145)
                observation.update(status=response.code, headers=dict(response.headers), truncated=len(raw) > 262144)
            text = raw[:262144].decode("utf-8-sig", errors="replace")
            observation["text"] = text
            try:
                observation["json"] = json.loads(text)
            except ValueError:
                observation["body"] = text
            if 200 <= observation["status"] < 300 and not observation["truncated"]:
                self.state["data"] = observation.get("json", observation.get("body"))
                successes = self.state["successful_requests"]
                if not successes or successes[-1] != config:
                    successes.append(clone(config))
                    del successes[:-4]
        except Exception as error:
            observation.update(status=None, error=type(error).__name__ + ": " + str(error))
        self.state["last"] = observation
        self.state["http_history"].append(clone(observation))
        del self.state["http_history"][:-4]
        self.save()
        self.emit("HUGH_HTTP", observation)
        return clone(observation)

    @staticmethod
    def require_success(response, json_only=True):
        if (response.get("status") is None or not 200 <= response["status"] < 300
                or response.get("truncated") or (json_only and "json" not in response)):
            raise ValueError("Request failed or incomplete: " + encoded(bounded(response, 5000)))

    def fetch_json(self, **request):
        response = self.fetch(**request)
        self.require_success(response)
        return response["json"]

    def probe_many(self, candidates):
        if not isinstance(candidates, list) or len(candidates) > 12:
            raise ValueError("probe_many accepts up to 12 candidates")
        results, seen = [], set()
        for candidate in candidates:
            key = digest(candidate)
            if key in seen:
                continue
            seen.add(key)
            if self.remaining_seconds() <= 0 or self.request_count >= 24:
                break
            result = self.fetch(**candidate)
            results.append(result)
            if result.get("status") is not None and 200 <= result["status"] < 300 and not result.get("truncated"):
                break
        return results

    def read_source(self, name, *, request=None, file=None, format="json"):
        """A complete file or ONE response, not a claim that a paged API is complete."""
        self.source_name(name)
        if format not in ("json", "csv", "text"):
            raise ValueError("format must be json/csv/text")
        if (request is None) == (file is None):
            raise ValueError("read_source needs exactly one of request or file")
        if file is not None:
            path = Path(file)
            if not path.is_absolute():
                path = self.path.parent / path
            with path.open("rb") as stream:
                raw = stream.read(1048577)
            if len(raw) > 1048576:
                raise ValueError("Source exceeds 1 MiB; process it explicitly and run a verifier")
            text = raw.decode("utf-8-sig")
            data = json.loads(text) if format == "json" else list(csv.DictReader(io.StringIO(text))) if format == "csv" else text
            evidence = {"kind": "file", "path": str(path.resolve()), "bytes_sha256": hashlib.sha256(raw).hexdigest()}
        else:
            response = self.fetch(**request)
            self.require_success(response, json_only=format == "json")
            data = (response["json"] if format == "json" else list(csv.DictReader(io.StringIO(response["text"])))
                    if format == "csv" else response["text"])
            evidence = {"kind": "http_single", "request": response["request"], "scope": "one_response"}
        self.state["sources"][name] = {"complete": True, "data": data, "evidence": evidence}
        self.used.add(name)
        self.save()
        self.emit("HUGH_SOURCE", {"name": name, **evidence, "data_sha256": digest(data)})
        return clone(data)

    @staticmethod
    def source_name(name):
        if not isinstance(name, str) or not 0 < len(name) <= 100:
            raise ValueError("Source name must be 1-100 characters")

    def collect(self, name, *, request=None, records_path=None, pagination=None, id_path=None):
        """Collect a dataset according to the CURRENT documented/observed contract."""
        self.source_name(name)
        pagination = clone(pagination or {"mode": "single", "end": "single"})
        allowed = {"mode", "end", "param", "start", "step", "size_param", "size", "position_path",
                   "size_path", "total_path", "next_path", "has_more_path", "allow_repeated_pages"}
        if set(pagination) - allowed:
            raise ValueError("Unknown pagination option")
        mode, end = pagination.get("mode"), pagination.get("end")
        if mode not in ("single", "offset", "page", "cursor"):
            raise ValueError("mode must be single/offset/page/cursor")
        if end not in ("single", "total", "empty", "short", "next", "has_more"):
            raise ValueError("Declare end: single/total/empty/short/next/has_more")
        if (mode == "single") != (end == "single"):
            raise ValueError("single mode requires single end")
        if mode != "single" and not isinstance(pagination.get("param"), str):
            raise ValueError("Declare the actual paging request parameter")
        for ending, field in (("total", "total_path"), ("short", "size_path"),
                              ("next", "next_path"), ("has_more", "has_more_path")):
            if end == ending and field not in pagination:
                raise ValueError(ending + " termination requires " + field)
        if mode == "cursor" and "next_path" not in pagination:
            raise ValueError("cursor mode requires next_path")
        start = pagination.get("start", 1 if mode == "page" else 0 if mode == "offset" else None)
        if mode in ("offset", "page") and (type(start) is not int or start < 0):
            raise ValueError("offset/page start must be a nonnegative integer")
        step = pagination.get("step", 1)
        if type(step) is not int or step <= 0:
            raise ValueError("page step must be positive")
        config = self.request_config(request)
        for key in ("param", "size_param"):
            if key in pagination:
                config["params"].pop(pagination[key], None)
        plan = {"request": config, "records_path": records_path if records_path is not None else [],
                "pagination": pagination, "id_path": id_path}
        signature = digest(plan)
        source = self.state["sources"].get(name)
        if not source or source.get("signature") != signature:
            source = {"signature": signature, "plan": plan, "data": [], "complete": False,
                      "next": start, "total": None, "size": pagination.get("size"),
                      "ids": [], "tokens": [], "page_hashes": [], "pages": [],
                      "evidence": {"kind": "dataset"}}
            self.state["sources"][name] = source
        self.used.add(name)
        while not source["complete"]:
            if self.remaining_seconds() < 0.2 or self.request_count >= 24:
                self.save()
                raise ContinueNextTurn("Dataset checkpoint saved: " + name)
            token = source["next"]
            params = dict(config["params"])
            if mode != "single" and token is not None:
                params[pagination["param"]] = token
            if pagination.get("size_param") and source["size"] is not None:
                params[pagination["size_param"]] = source["size"]
            response = self.fetch(_resolved={**config, "params": params})
            self.require_success(response)
            body = response["json"]
            rows = lookup(body, plan["records_path"])
            if not isinstance(rows, list):
                raise ValueError("records_path must point to a list, not its enclosing object")
            if "position_path" in pagination and encoded(lookup(body, pagination["position_path"])) != encoded(token):
                raise ValueError("Server page position did not match the requested position")
            total = lookup(body, pagination["total_path"]) if "total_path" in pagination else None
            if "total_path" in pagination:
                if type(total) is not int or total < 0:
                    raise ValueError("Server total must be a nonnegative integer")
                if source["total"] is not None and total != source["total"]:
                    raise ValueError("Server total changed during collection")
            actual_size = lookup(body, pagination["size_path"]) if "size_path" in pagination else None
            if actual_size is not None and (type(actual_size) is not int or actual_size <= 0 or len(rows) > actual_size):
                raise ValueError("Invalid actual page size")
            new_ids = []
            if id_path is not None:
                for row in rows:
                    identity = lookup(row, id_path)
                    if identity is None:
                        raise ValueError("Unique identifier is missing")
                    key = encoded(identity)
                    if key in source["ids"] or key in new_ids:
                        raise ValueError("Repeated unique ID; dataset is not complete")
                    new_ids.append(key)
            page_hash = digest(rows)
            if (rows and page_hash in source["page_hashes"] and "position_path" not in pagination
                    and not pagination.get("allow_repeated_pages", False)):
                raise ValueError("Repeated page without a verified position; inspect the API contract")
            count = len(source["data"]) + len(rows)
            if total is not None and count > total:
                raise ValueError("Collected count exceeds the server total")
            next_token = lookup(body, pagination["next_path"]) if "next_path" in pagination else None
            more = lookup(body, pagination["has_more_path"]) if "has_more_path" in pagination else None
            if "has_more_path" in pagination and type(more) is not bool:
                raise ValueError("has_more_path must contain an actual boolean")
            ended = (end == "single" or (end == "total" and count == total)
                     or (end == "empty" and not rows) or (end == "short" and len(rows) < actual_size)
                     or (end == "next" and next_token in (None, "")) or (end == "has_more" and more is False))
            if ended and total is not None and count != total:
                raise ValueError("Termination before all records were collected")
            if ended and more is True:
                raise ValueError("Termination contradicts has_more")
            if not ended and not rows and mode in ("offset", "page"):
                raise ValueError("Empty page before declared termination")
            if not ended:
                advance = (token + len(rows) if mode == "offset" else token + step if mode == "page" else next_token)
                if advance in (None, "") or encoded(advance) == encoded(token) or encoded(advance) in source["tokens"]:
                    raise ValueError("Pagination cursor/position did not advance")
            else:
                advance = None
            # Commit a whole validated page atomically; no partial duplicate data.
            source["data"].extend(clone(rows))
            source["ids"].extend(new_ids)
            source["tokens"].append(encoded(token))
            source["page_hashes"].append(page_hash)
            source["pages"].append({"position": token, "count": len(rows), "total": total, "actual_size": actual_size})
            source.update(next=advance, total=total, complete=ended)
            if actual_size is not None:
                source["size"] = actual_size
            self.save()
            self.emit("HUGH_COLLECTION", {"name": name, "page": source["pages"][-1], "count": count,
                                         "complete": ended, "id_path": id_path})
        return clone(source["data"])

    def run(self, argv, *, cwd=None, timeout=8, input=None):
        """Capture the actual process result; checker names/formats are task-defined."""
        if not isinstance(argv, list) or not argv or not all(isinstance(v, str) for v in argv):
            raise ValueError("run requires an argv list; use ['sh','-lc',...] when shell syntax is necessary")
        budget = min(float(timeout), self.remaining_seconds())
        if budget <= 0:
            raise TimeoutError("Command budget exhausted")
        cwd = str(Path(cwd).resolve()) if cwd else str(self.path.parent)
        result = {"argv": argv, "cwd": cwd}
        with tempfile.TemporaryFile() as output:
            try:
                proc = subprocess.run(argv, cwd=cwd, stdout=output, stderr=subprocess.STDOUT,
                                      input=input.encode("utf-8") if isinstance(input, str) else input,
                                      timeout=budget, env={**os.environ, "PYTHONUTF8": "1"})
                result["exit_code"] = proc.returncode
            except subprocess.TimeoutExpired:
                result.update(exit_code=None, error="Process timed out")
            output.seek(0)
            raw = output.read(16001)
        result.update(output=raw[:16000].decode("utf-8", errors="replace"), truncated=len(raw) > 16000)
        ident = "process-" + str(len(self.state["checks"]) + 1)
        result["id"] = ident
        self.state["checks"][ident] = result
        self.used_checks.add(ident)
        self.save()
        self.emit("HUGH_PROCESS", result)
        return clone(result)

    def report(self, answer, *, sources=None, checks=None):
        names, checks = sources or [], checks or []
        if not isinstance(names, list) or not isinstance(checks, list) or not (names or checks):
            raise ValueError("report requires actual source names and/or successful process IDs")
        receipts = []
        for name in self.used:
            if not self.state["sources"][name].get("complete"):
                raise ValueError("An accessed dataset is incomplete: " + name)
        for name in names:
            source = self.state["sources"].get(name)
            if name not in self.used or not source or not source.get("complete"):
                raise ValueError("Source was not completely read by this execution: " + str(name))
            receipt = {"name": name, **source["evidence"], "complete": True, "data_sha256": digest(source["data"])}
            if source["evidence"]["kind"] == "dataset":
                receipt.update(count=len(source["data"]), total=source["total"], pages=len(source["pages"]),
                               contract=source["plan"]["pagination"], id_path=source["plan"]["id_path"])
            receipts.append(receipt)
        executions = []
        for ident in checks:
            result = self.state["checks"].get(ident)
            if ident not in self.used_checks or not result or result.get("exit_code") != 0 or result.get("truncated"):
                raise ValueError("Verifier did not actually succeed in this execution: " + str(ident))
            executions.append(clone(result))
        if answer is None or len(encoded(answer).encode("utf-8")) > 24000:
            raise ValueError("Answer is null or exceeds the submission budget")
        self.answer, self.reported = clone(answer), True
        self.report_inputs = (clone(answer), list(names), list(checks))
        self.proof = {"method": "runtime_evidence_v2", "answer_sha256": digest(answer),
                      "sources": receipts, "checks": executions}

    def execute(self, packet):
        if packet.get("resume"):
            if not self.state.get("resumable"):
                return {"status": "error", "error": "Previous script did not opt into resume"}
            source = self.state["script"]
        else:
            source = packet.get("python")
            if not isinstance(source, str) or not source:
                return {"status": "error", "error": "Return python source for the current task"}
            self.state.update(script=source, resumable=packet.get("resumable") is True)
        self.save()
        scope = {"__name__": "__task__", "probe": self.fetch, "fetch_json": self.fetch_json,
                 "probe_many": self.probe_many, "collect": self.collect, "read_source": self.read_source,
                 "run": self.run, "report": self.report, "lookup": lookup,
                 "remaining_seconds": self.remaining_seconds, "WORKDIR": str(self.path.parent),
                 "CONFIG": self.state["config"], "LAST_HTTP": clone(self.state.get("last")),
                 "HTTP_HISTORY": self.state["http_history"], "DATA": clone(self.state.get("data"))}
        stream = LimitedOutput()
        previous_cwd = os.getcwd()
        try:
            os.chdir(self.path.parent)
            with redirect_stdout(stream):
                exec(compile(source, "<task python>", "exec"), scope)
            if scope.get("ANSWER") is not None or scope.get("COMPLETE") is True:
                raise ValueError("ANSWER/COMPLETE are not evidence; use report with verified sources/checks")
            if self.reported:
                answer, names, checks = self.report_inputs
                self.report(answer, sources=names, checks=checks)
            result = ({"status": "answer", "answer": self.answer, "proof": self.proof} if self.reported
                      else {"status": "observation", "note": "No report; inspect actual results and continue"})
        except ContinueNextTurn as error:
            result = {"status": "progress" if self.state["resumable"] else "observation", "note": str(error),
                      "resume_requires": "An idempotent script with resumable=true"}
        except BaseException as error:
            result = {"status": "error", "error": type(error).__name__ + ": " + str(error),
                      "traceback": traceback.format_exc()[-2500:]}
        finally:
            os.chdir(previous_cwd)
        self.save()
        result.update(output=stream.getvalue(), observation=bounded(self.state.get("last")),
                      config=self.state["config"], http_history=[bounded(o, 3000) for o in self.state["http_history"]],
                      collections={name: {"complete": value["complete"], "count": len(value["data"]),
                                         "pages": value["pages"][-4:], "total": value["total"]}
                                   for name, value in self.state["sources"].items() if "pages" in value},
                      profile={"successful_requests": self.state["successful_requests"],
                               "dataset_plans": [v["plan"] for v in self.state["sources"].values()
                                                 if v.get("complete") and "plan" in v][-3:]})
        return result


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    packet = json.loads(sys.argv[1])
    runtime = Runtime(Path(__file__).with_name(".hugh_task_state.json"))
    result = runtime.execute(packet)
    result["id"] = packet["id"]
    # Never loop indefinitely trying to shrink a nested object.
    for field in ("output", "observation", "http_history", "profile", "traceback"):
        if len(encoded(result).encode("utf-8")) > 55000 and field in result:
            result[field] = bounded(result[field], 1500)
    if len(encoded(result).encode("utf-8")) > 55000:
        result = {"id": packet["id"], "status": "error", "error": "Result too large; reduce output or answer"}
    print("HUGH_TASK:" + encoded(result))


if __name__ == "__main__":
    main()
