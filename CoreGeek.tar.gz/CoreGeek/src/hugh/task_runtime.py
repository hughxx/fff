"""Installed inside each task sandbox: HTTP transport and Python execution."""
import base64
import json
from pathlib import Path
import re
import sys
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request


def documented_request(body, docs, city):
    """Use this task's documented example; never invent auth or pagination."""
    bases = re.findall(r"https?://(?:localhost|127\.0\.0\.1|\[::1\])(?::\d+)?", body)
    examples = re.findall(r'https?://[^\s`"<>]+/[^\s`"<>]*', docs)
    if not bases or not examples:
        return None
    base = urllib.parse.urlsplit(bases[0])
    sample = next((urllib.parse.urlsplit(u) for u in examples
                   if urllib.parse.urlsplit(u).netloc == base.netloc), None)
    if sample is None:
        return None
    params = dict(urllib.parse.parse_qsl(sample.query))
    if city and "city" in params:
        params["city"] = city
    headers = dict(re.findall(r'-H\s+["\']([^:"\']+):\s*([^"\']+)["\']', docs))
    return {"base_url": urllib.parse.urlunsplit((base.scheme, base.netloc, "", "", "")),
            "path": sample.path, "params": params, "headers": headers}


class Runtime:
    def __init__(self, state_path, config=None):
        self.path = Path(state_path)
        self.state = {"config": config, "last": None, "data": None} if config is not None else json.loads(self.path.read_text(encoding="utf-8"))
        self.observations = []
        self.failed = False
        self.started = time.monotonic()

    def save(self):
        self.path.write_text(json.dumps(self.state, ensure_ascii=False), encoding="utf-8")

    def fetch(self, path=None, params=None, headers=None):
        config = self.state["config"]
        base = urllib.parse.urlsplit(config["base_url"])
        target = urllib.parse.urlsplit(urllib.parse.urljoin(config["base_url"], path or config["path"]))
        if (target.scheme, target.netloc) != (base.scheme, base.netloc):
            raise ValueError("API request must use the service specified by this task")
        query = dict(config.get("params", {})) if params is None else dict(params)
        query.update(urllib.parse.parse_qsl(target.query))
        query = {k: v for k, v in query.items() if v is not None}
        url = urllib.parse.urlunsplit((target.scheme, target.netloc,
              urllib.parse.quote(urllib.parse.unquote(target.path), safe="/"),
              urllib.parse.urlencode(query, doseq=True), ""))
        auth = dict(config.get("headers", {}))
        for name, value in (headers or {}).items():
            if value is None:
                auth.pop(name, None)
            else:
                auth[name] = str(value)
        observation = {"url": url, "request_header_names": sorted(auth)}
        try:
            budget = 11 - (time.monotonic() - self.started)
            if budget <= 0:
                raise TimeoutError("Command HTTP time budget exhausted; save progress and continue next turn")
            request = urllib.request.Request(url, headers=auth)
            try:
                response = urllib.request.urlopen(request, timeout=min(2.0, budget))
            except urllib.error.HTTPError as error:
                response = error  # Preserve the actual error body and headers.
            with response:
                raw = response.read(131073)
                observation.update(status=response.code, headers=dict(response.headers), truncated=len(raw) > 131072)
            body = raw[:131072].decode("utf-8-sig", errors="replace")
            try:
                observation["json"] = json.loads(body)
            except ValueError:
                observation["body"] = body
            if not 200 <= observation["status"] < 300 or observation["truncated"]:
                self.failed = True
            else:
                # Only successful requests establish reusable defaults/data.
                self.state["config"]["headers"] = auth
                self.state["data"] = observation.get("json")
        except Exception as error:
            self.failed = True
            observation.update(status=None, error=type(error).__name__ + ": " + str(error))
        self.state["last"] = observation
        self.observations.append(observation)
        self.save()
        return observation

    def fetch_json(self, path=None, params=None, headers=None):
        response = self.fetch(path, params, headers)
        if response.get("status") is None or not 200 <= response["status"] < 300 or response.get("truncated") or "json" not in response:
            self.failed = True
            raise RuntimeError("API request failed: " + json.dumps(response, ensure_ascii=False)[:8000])
        return response["json"]

    def execute(self, packet):
        if "http" in packet:
            request = packet["http"]
            self.fetch(request.get("path"), request.get("params"), request.get("headers"))
            return {"status": "observation", "observation": self.state["last"], "config": self.state["config"]}
        # The wrapper owns shell quoting, correlation IDs, and answer delivery.
        scope = {"__name__": "__task__", "fetch_json": self.fetch_json,
                 "DATA": self.state.get("data"), "LAST_HTTP": self.state.get("last"),
                 "WORKDIR": str(self.path.parent),
                 "CONFIG": json.loads(json.dumps(self.state["config"])),
                 "ANSWER": None, "COMPLETE": False}
        try:
            exec(compile(packet["python"], "<task python>", "exec"), scope)
            if scope.get("ANSWER") is not None:
                if self.failed or self.state.get("data") is None or scope.get("COMPLETE") is not True:
                    raise ValueError("Cannot submit: failed HTTP request, no verified API data, or completeness not established")
                if not isinstance(scope["ANSWER"], dict):
                    raise ValueError("ANSWER must be a JSON object")
                return {"status": "answer", "answer": scope["ANSWER"]}
            return {"status": "observation", "observation": self.state.get("last"),
                    "note": "No ANSWER set; inspect output and continue"}
        except Exception as error:
            return {"status": "error", "error": type(error).__name__ + ": " + str(error),
                    "traceback": traceback.format_exc()[-3000:], "observation": self.state.get("last")}


def bounded(value, limit=18000):
    text = json.dumps(value, ensure_ascii=False)
    return value if len(text.encode("utf-8")) <= limit else {"truncated": True, "preview": text[:limit // 4],
             "note": "Full last JSON response is available as DATA inside the next Python execution"}


def main():
    packet = json.loads(base64.b64decode(sys.argv[1]).decode("utf-8"))
    runtime = Runtime(Path(__file__).with_name(".hugh_api_state.json"))
    result = runtime.execute(packet)
    result.setdefault("observation", runtime.state.get("last"))
    result.setdefault("config", runtime.state["config"])
    if "observation" in result:
        result["observation"] = bounded(result["observation"])
    result["id"] = packet["id"]
    print("HUGH_TASK:" + json.dumps(result, ensure_ascii=False, separators=(",", ":")))


if __name__ == "__main__":
    main()
