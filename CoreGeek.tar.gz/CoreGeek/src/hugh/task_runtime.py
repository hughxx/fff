"""Task sandbox HTTP transport, verified heritage collection and API fallback."""
import json
import hashlib
import builtins
import csv
from contextlib import redirect_stdout, redirect_stderr
import io
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
import traceback
from types import ModuleType
import urllib.error
import urllib.parse
import urllib.request

SCHEMA = {"records_path": ["data", "records"], "pagination_path": ["data", "pagination"],
          "id": "id", "name": "name", "type": "type", "era": "era", "protected": "protected_level",
          "total": "total_count", "offset": "offset", "limit": "limit"}


def lookup(value, path):
    for key in path:
        if not isinstance(value, dict) or key not in value:
            raise ValueError("Unknown response structure at " + repr(path))
        value = value[key]
    return value


def era_rank(label):
    # Only relative chronology is used, never a remembered heritage answer.
    periods = ["旧石器", "新石器", "夏", "商", "西周", "东周", "春秋", "战国", "秦", "西汉", "东汉",
               "三国", "西晋", "东晋", "南北朝", "隋", "唐", "五代", "辽", "北宋", "西夏", "金",
               "南宋", "元", "明", "清", "民国", "现代"]
    aliases = {"周": "西周", "汉": "西汉", "晋": "西晋", "宋": "北宋"}
    clean = re.sub(r"时代|时期|[\s、，,；;/\-—至到]", "", label)
    pattern = "(" + "|".join(sorted(periods + list(aliases), key=len, reverse=True)) + ")(?:朝|代)?"
    matches = list(re.finditer(pattern, clean))
    tokens = [m[1] for m in matches]
    if not tokens or "".join(m[0] for m in matches) != clean:
        raise ValueError("Unknown era; provide era_order for all observed labels: " + label)
    return min(periods.index(aliases.get(token, token)) for token in tokens)


def documented_request(body, docs, city):
    """Use this task's documented example; never invent auth or pagination."""
    bases = re.findall(r"https?://(?:localhost|127\.0\.0\.1|\[::1\])(?::\d+)?", body)
    examples = re.findall(r'https?://[^\s`"<>]+/[^\s`"<>]*', docs)
    if not bases or not examples:
        return None
    base = urllib.parse.urlsplit(bases[0])
    sample = next((urllib.parse.urlsplit(u) for u in examples
                   if urllib.parse.urlsplit(u).netloc == base.netloc), None)
    if sample is None:
        return None
    params = dict(urllib.parse.parse_qsl(sample.query))
    if city and "city" in params:
        params["city"] = city
    headers = dict(re.findall(r'-H\s+["\']([^:"\']+):\s*([^"\']+)["\']', docs))
    return {"base_url": urllib.parse.urlunsplit((base.scheme, base.netloc, "", "", "")),
            "path": sample.path, "params": params, "headers": headers}


class Runtime:
    def __init__(self, state_path, config=None):
        self.path = Path(state_path)
        self.state = {"config": config, "last": None, "data": None} if config is not None else json.loads(self.path.read_text(encoding="utf-8"))
        self.observations = []
        self.failed = False
        self.started = time.monotonic()
        self.request_count = 0
        self.verifications = {}
        self.processes = []
        self.reported = False
        self.answer = None
        self.log_bytes = 0

    def emit(self, label, value):
        line = label + ":" + json.dumps(value, ensure_ascii=False, separators=(",", ":"))
        size = len(line.encode("utf-8"))
        if self.log_bytes + size <= 12000:
            print(line)
            self.log_bytes += size

    def http_summary(self, observation):
        """Keep useful status, paging and IDs visible even for large responses."""
        summary = {k: observation[k] for k in ("url", "request_headers", "status", "error", "truncated") if k in observation}
        body = observation.get("json")
        if isinstance(body, dict):
            schema = self.state.get("schema", SCHEMA)
            try:
                rows = lookup(body, schema["records_path"])
                paging = lookup(body, schema["pagination_path"])
                summary.update(pagination=paging, records_count=len(rows),
                               ids=[r.get(schema["id"]) for r in rows[:25]])
            except (ValueError, TypeError, AttributeError, KeyError):
                summary["json"] = bounded(body, 1200)
        else:
            summary["body"] = str(observation.get("body", ""))[:500]
        return summary

    def remaining_seconds(self):
        return max(0.0, 11 - (time.monotonic() - self.started))

    def save(self):
        self.path.write_text(json.dumps(self.state, ensure_ascii=False), encoding="utf-8")

    def fetch(self, path=None, params=None, headers=None, *, url=None, method="GET", json_body=None, body=None):
        config = self.state["config"]
        base = urllib.parse.urlsplit(config["base_url"])
        target = urllib.parse.urlsplit(urllib.parse.urljoin(config["base_url"], url or path or config["path"]))
        origin = urllib.parse.urlunsplit((target.scheme, target.netloc, "", "", ""))
        if origin not in config.get("services", [config["base_url"]]) or target.scheme not in ("http", "https"):
            raise ValueError("API request must use the service specified by this task")
        query = dict(config.get("params", {}))
        if params is not None:
            query.update(params)
        query.update(urllib.parse.parse_qsl(target.query))
        query = {k: v for k, v in query.items() if v is not None}
        url = urllib.parse.urlunsplit((target.scheme, target.netloc,
              urllib.parse.quote(urllib.parse.unquote(target.path), safe="/"),
              urllib.parse.urlencode(query, doseq=True), ""))
        auth = dict(config.get("headers", {}))
        for name, value in (headers or {}).items():
            if value is None:
                auth.pop(name, None)
            else:
                auth[name] = str(value)
        observation = {"url": url, "request_headers": auth}
        try:
            budget = self.remaining_seconds()
            if budget <= 0 or self.request_count >= 24:
                raise TimeoutError("Command HTTP time budget exhausted; save progress and continue next turn")
            self.request_count += 1
            if json_body is not None:
                body = json.dumps(json_body, ensure_ascii=False)
                auth.setdefault("Content-Type", "application/json; charset=utf-8")
            payload = body.encode("utf-8") if isinstance(body, str) else body
            request = urllib.request.Request(url, data=payload, headers=auth, method=method)
            try:
                response = urllib.request.urlopen(request, timeout=min(2.0, budget))
            except urllib.error.HTTPError as error:
                response = error  # Preserve the actual error body and headers.
            with response:
                raw = response.read(131073)
                observation.update(status=response.code, headers=dict(response.headers), truncated=len(raw) > 131072)
            body = raw[:131072].decode("utf-8-sig", errors="replace")
            observation["text"] = body
            try:
                observation["json"] = json.loads(body)
            except ValueError:
                observation["body"] = body
            if 200 <= observation["status"] < 300 and not observation["truncated"] and "json" in observation:
                self.state["data"] = observation.get("json")
        except Exception as error:
            observation.update(status=None, error=type(error).__name__ + ": " + str(error))
        self.state["last"] = observation
        # Keep local progress after a 401 -> 400, without promoting a failed
        # request into cross-task reuse (profile still requires collected data).
        self.state["config"].update(headers=auth, path=target.path, params=query)
        self.observations.append(observation)
        self.save()
        self.emit("HUGH_HTTP", self.http_summary(observation))
        return observation

    def probe_many(self, candidates):
        if not isinstance(candidates, list) or len(candidates) > 12:
            raise ValueError("probe_many expects at most 12 candidate requests")
        results, seen = [], set()
        for candidate in candidates:
            signature = json.dumps(candidate, sort_keys=True, ensure_ascii=False)
            if signature in seen:
                continue
            seen.add(signature)
            if self.remaining_seconds() <= 0 or self.request_count >= 24:
                break
            response = self.fetch(**candidate)
            results.append(response)
            if response.get("status") is not None and 200 <= response["status"] < 300 and "json" in response and not response.get("truncated"):
                break
        return results

    def fetch_json(self, path=None, params=None, headers=None, **options):
        response = self.fetch(path, params, headers, **options)
        if response.get("status") is None or not 200 <= response["status"] < 300 or response.get("truncated") or "json" not in response:
            self.failed = True
            raise RuntimeError("API request failed: " + json.dumps(response, ensure_ascii=False)[:8000])
        self.failed = False  # An explicit successful retry completes this required read.
        return response["json"]

    def profile(self):
        config = self.state["config"]
        if not self.state.get("collection", {}).get("records"):
            return None
        city = config.get("city")
        return {"base_url": config["base_url"], "documented_path": config.get("documented_path", config["path"]),
                "documented_key": config.get("documented_key", ""),
                "path": config["path"], "headers": config.get("headers", {}), "city": city,
                "params": {k: v for k, v in config.get("params", {}).items() if k not in ("offset", "limit", "page", "size")},
                "schema": self.state.get("schema", SCHEMA), "paging": self.state.get("paging", {"offset": "offset", "limit": "limit"})}

    def repaired_fetch(self, params):
        """Advance only on an explicit error from this service, preserving fixes."""
        seen = set()
        while self.remaining_seconds() > 0 and self.request_count < 24:
            config = self.state["config"]
            signature = json.dumps([config, params], sort_keys=True, ensure_ascii=False)
            if signature in seen:
                break
            seen.add(signature)
            response = self.fetch(params=params)
            body = response.get("json") or {}
            message = body.get("message", "") if isinstance(body, dict) else ""
            if response.get("status") == 401 and "Authorization" in message and "Bearer" in message:
                key = config.get("documented_key")
                if not key:
                    break
                config.setdefault("headers", {})["Authorization"] = "Bearer " + key
            elif response.get("status") == 400:
                missing = re.search(r"Missing required parameter:\s*['\"]?([A-Za-z_][A-Za-z_0-9]*)", message)
                if not missing or missing[1] not in ("city", "location") or not config.get("city"):
                    break
                config.setdefault("params", {})[missing[1]] = config["city"]
                params[missing[1]] = config["city"]
            else:
                return response
            self.save()
        return self.state.get("last") or {"status": None, "error": "HTTP budget exhausted"}

    def collect(self, plan=None):
        """Own the dataset and its completeness proof; no model completion flag."""
        plan = plan or {}
        result = {"status": "needs_plan"}
        try:
            if not isinstance(plan, dict) or set(plan) - {"path", "params", "headers", "schema", "paging", "era_order"}:
                raise ValueError("collect supports path/params/headers/schema/paging/era_order only")
            config = self.state["config"]
            if config.get("kind") != "heritage" or not config.get("city"):
                raise ValueError("Fixed collector requires a current heritage task and city")
            if any(k in plan for k in ("path", "params", "headers", "schema", "paging")):
                # A new query/schema may represent different records. Never mix.
                self.state.pop("collection", None)
                self.state["data"] = None
                for key in ("params", "headers"):
                    if key in plan:
                        if not isinstance(plan[key], dict):
                            raise ValueError(key + " must be an object")
                        config.setdefault(key, {}).update(plan[key])
                        config[key] = {k: v for k, v in config[key].items() if v is not None}
                if "path" in plan:
                    if not isinstance(plan["path"], str):
                        raise ValueError("path must be a string")
                    config["path"] = plan["path"]
            for key, default in (("schema", SCHEMA), ("paging", {"offset": "offset", "limit": "limit"})):
                value = {**self.state.get(key, default), **plan.get(key, {})}
                if set(value) != set(default):
                    raise ValueError("Unknown " + key + " fields")
                for name, item in value.items():
                    if name.endswith("_path"):
                        if not isinstance(item, list) or not all(isinstance(v, str) for v in item):
                            raise ValueError("JSON paths must be lists of keys")
                    elif not isinstance(item, str) or not item:
                        raise ValueError("Field and parameter names must be nonempty strings")
                self.state[key] = value
            schema, paging = self.state["schema"], self.state["paging"]
            for key in ("city", "location"):
                if key in config.get("params", {}) and config["params"][key] != config["city"]:
                    raise ValueError("Query city does not match current official task")
            parsed_path = urllib.parse.urlsplit(config["path"])
            if parsed_path.query:
                raise ValueError("Put query values in params, not path")
            collection = self.state.setdefault("collection", {"records": {}, "total": None, "next_offset": 0,
                                                              "limit": 10, "pages": [], "complete": False})
            while not collection["complete"]:
                if self.remaining_seconds() < 0.2 or self.request_count >= 24:
                    result = {"status": "progress", "note": "HTTP budget reached; resume fixed collector"}
                    break
                requested = collection["next_offset"]
                params = {"page": None, "size": None, paging["offset"]: requested, paging["limit"]: collection["limit"]}
                response = self.repaired_fetch(params)
                if response.get("status") != 200 or response.get("truncated") or "json" not in response:
                    raise ValueError("Cannot collect: " + json.dumps(self.http_summary(response), ensure_ascii=False))
                rows = lookup(response["json"], schema["records_path"])
                page = lookup(response["json"], schema["pagination_path"])
                if not isinstance(rows, list) or not all(isinstance(r, dict) for r in rows) or not isinstance(page, dict):
                    raise ValueError("Expected a list of record objects and pagination object")
                total, offset, limit = [page.get(schema[k]) for k in ("total", "offset", "limit")]
                if any(type(v) is not int for v in (total, offset, limit)) or total < 0 or limit <= 0:
                    raise ValueError("Invalid actual pagination total/offset/limit")
                if offset != requested:
                    raise ValueError(f"Pagination did not advance: requested offset {requested}, returned {offset}")
                if collection["total"] is not None and total != collection["total"]:
                    raise ValueError("Server total changed during collection")
                if len(rows) > limit or offset + len(rows) > total or (not rows and offset < total):
                    raise ValueError("Page size/total inconsistent; do not submit")
                additions = {}
                for row in rows:
                    ident = row.get(schema["id"])
                    if type(ident) not in (str, int) or ident == "":
                        raise ValueError("Missing stable record ID")
                    key = json.dumps(ident, ensure_ascii=False)
                    if key in collection["records"] or key in additions:
                        raise ValueError("Repeated record ID/page: " + key)
                    if any(not isinstance(row.get(schema[k]), str) or not row[schema[k]]
                           for k in ("name", "type", "era", "protected")):
                        raise ValueError("Missing or invalid heritage fields; inspect schema")
                    if row.get("city") is not None and row["city"] != config["city"]:
                        raise ValueError("Record belongs to another city")
                    additions[key] = row
                collection["records"].update(additions)
                collection.update(total=total, next_offset=offset + len(rows), limit=limit)
                collection["pages"].append({"offset": offset, "limit": limit, "count": len(rows)})
                collection["complete"] = len(collection["records"]) == total and collection["next_offset"] == total
                self.save()
            if collection["complete"]:
                rows = list(collection["records"].values())
                if not rows:
                    raise ValueError("No records from which to select oldest heritage")
                labels = sorted({r[schema["era"]] for r in rows})
                supplied = plan.get("era_order")
                if supplied is not None:
                    if not isinstance(supplied, list) or len(supplied) != len(labels) or set(supplied) != set(labels):
                        raise ValueError("era_order must contain every observed era exactly once, oldest first")
                    ranks = {label: i for i, label in enumerate(supplied)}
                else:
                    ranks = {label: era_rank(label) for label in labels}
                oldest = min(rows, key=lambda r: ranks[r[schema["era"]]])
                answer = {"city": config["city"], "total_count": len(rows),
                          "world_heritage_count": sum(r[schema["protected"]] == "世界遗产" for r in rows),
                          "types": sorted({r[schema["type"]] for r in rows}), "oldest_era": oldest[schema["name"]]}
                # Independent fixed-code summary sent to the agent for its second gate.
                proof = {"method": "fixed_collector_v1", "city": config["city"], "total": collection["total"],
                         "unique_count": len(rows), "complete": True, "pages": collection["pages"],
                         "ids_sha256": hashlib.sha256("\n".join(sorted(collection["records"])).encode()).hexdigest(),
                         "computed_answer": answer}
                result = {"status": "answer", "answer": answer, "proof": proof}
        except (ValueError, TypeError, KeyError) as error:
            result = {"status": "needs_plan", "error": str(error)}
        collection = self.state.get("collection", {})
        schema = self.state.get("schema", SCHEMA)
        result["collection"] = {k: v for k, v in collection.items() if k != "records"}
        result["collection"]["unique_count"] = len(collection.get("records", {}))
        result["collection"]["eras"] = sorted({str(r.get(schema["era"], "")) for r in collection.get("records", {}).values()})
        result["profile"] = self.profile()
        result["config"] = self.state["config"]
        result["observation"] = bounded(self.state.get("last"))
        self.save()
        self.emit("HUGH_COLLECTION", {"status": result["status"], "error": result.get("error"), **result["collection"]})
        return result

    def run(self, argv, *, cwd=None, timeout=8):
        """Exploration may return nonzero; only verify declares final acceptance."""
        if not isinstance(argv, list) or not argv:
            raise ValueError("run expects an argv list")
        cwd = str(Path(cwd or self.path.parent).resolve())
        result = {"argv": [str(v) for v in argv], "cwd": cwd}
        program = (Path(cwd) / argv[0]).resolve()
        if program.is_file():
            with program.open("rb") as stream:
                prefix = stream.read(512)
            if prefix.startswith(b"#!"):
                result["first_line"] = prefix.split(b"\n")[0].decode("utf-8", errors="replace")
                if program.is_relative_to(self.path.parent.resolve()) and program.stat().st_size <= 131072:
                    raw = program.read_bytes()
                    if b"\r\n" in raw and b"\0" not in raw:
                        program.write_bytes(raw.replace(b"\r\n", b"\n"))
                        result["launch_repair"] = "CRLF normalized; verification logic preserved"
                    program.chmod((program.stat().st_mode & 0o777) | 0o100)
        budget = min(float(timeout), self.remaining_seconds())
        if budget <= 0:
            raise TimeoutError("Command budget exhausted")
        with tempfile.TemporaryFile() as output:
            try:
                process = subprocess.run(argv, cwd=cwd, stdout=output, stderr=subprocess.STDOUT,
                                         timeout=budget, env={**os.environ, "PYTHONUTF8": "1"})
                result["exit_code"] = process.returncode
            except (OSError, subprocess.TimeoutExpired) as error:
                result.update(exit_code=None, error=type(error).__name__ + ": " + str(error))
            output.seek(0)
            raw = output.read(16001)
        result.update(output=raw[:16000].decode("utf-8", errors="replace"), truncated=len(raw) > 16000)
        self.processes.append(result)
        self.emit("HUGH_PROCESS", result)
        return result

    def verify(self, argv, **options):
        key = json.dumps([argv, str(Path(options.get("cwd") or self.path.parent).resolve())], sort_keys=True)
        self.verifications[key] = False
        result = self.run(argv, **options)
        self.verifications[key] = result["exit_code"] == 0 and not result["truncated"]
        if not self.verifications[key]:
            raise ValueError("Final verifier failed: " + json.dumps(result, ensure_ascii=False))
        return result

    def read_file(self, file, format="text"):
        path = Path(file)
        if not path.is_absolute():
            path = self.path.parent / path
        text = path.read_text(encoding="utf-8-sig")
        if format == "json":
            return json.loads(text)
        if format == "csv":
            return list(csv.DictReader(io.StringIO(text)))
        if format != "text":
            raise ValueError("format must be text/json/csv")
        return text

    def report(self, answer):
        encoded = answer if isinstance(answer, str) else json.dumps(answer, ensure_ascii=False, allow_nan=False)
        if answer is None or not encoded or len(encoded.encode("utf-8")) > 24000:
            raise ValueError("Answer is empty or exceeds submission budget")
        self.reported, self.answer = True, answer

    def validate_api_fallback(self):
        """Retain observed completeness checks when the familiar metadata exists.

        Other API contracts are validated by the model's task-specific script;
        there is no general business-answer proof inferred from a successful echo.
        """
        successes = [o for o in self.observations if o.get("status") == 200 and not o.get("truncated") and "json" in o]
        if not successes or not self.reported or not isinstance(self.answer, dict):
            raise ValueError("API fallback needs fresh successful reads and report(answer), not ANSWER/COMPLETE")
        schema = self.state.get("schema", SCHEMA)
        totals, identities = set(), set()
        for observation in successes:
            try:
                rows = lookup(observation["json"], schema["records_path"])
                meta = lookup(observation["json"], schema["pagination_path"])
            except (ValueError, TypeError):
                continue
            total = meta.get(schema["total"]) if isinstance(meta, dict) else None
            if type(total) is not int or not isinstance(rows, list):
                continue
            totals.add(total)
            for row in rows:
                if not isinstance(row, dict) or row.get(schema["id"]) is None:
                    raise ValueError("Missing ID in observed paginated dataset")
                identities.add(json.dumps(row[schema["id"]], ensure_ascii=False))
        if totals and (len(totals) != 1 or len(identities) != next(iter(totals)) or self.answer.get("total_count") != len(identities)):
            raise ValueError("API fallback has not read all observed records or reported count differs")

    def execute(self, packet):
        if self.state["config"].get("kind") == "heritage" and "collect" in packet:
            return self.collect(packet["collect"])
        if "http" in packet:
            request = packet["http"]
            self.fetch(request.get("path"), request.get("params"), request.get("headers"))
            return {"status": "observation", "observation": self.state["last"], "config": self.state["config"]}
        # Unknown tasks use a plain script. No global library replacements,
        # inferred source registries, or failed-candidate poisoning.
        self.failed, self.reported, self.verifications, self.processes = False, False, {}, []
        self.observations = []
        scope = {"__name__": "__task__", "fetch_json": self.fetch_json,
                 "probe": self.fetch, "probe_many": self.probe_many, "remaining_seconds": self.remaining_seconds,
                 "DATA": self.state.get("data"), "LAST_HTTP": self.state.get("last"),
                 "WORKDIR": str(self.path.parent),
                 "CONFIG": self.state["config"], "run": self.run, "verify": self.verify,
                 "read_file": self.read_file, "report": self.report,
                 "ANSWER": None, "COMPLETE": False}
        modules = {}
        for name in ("probe", "probe_many", "fetch_json", "run", "verify", "read_file", "report"):
            module = ToolModule(name, scope[name])
            modules[name] = module
        def compatible_import(name, globals=None, locals=None, fromlist=(), level=0):
            if not level and name in modules:
                return modules[name]
            return builtins.__import__(name, globals, locals, fromlist, level)
        scope["__builtins__"] = {**vars(builtins), "__import__": compatible_import}
        previous = os.getcwd()
        output, stderr = LimitedOutput(), LimitedOutput()
        try:
            os.chdir(self.path.parent)
            with redirect_stdout(output), redirect_stderr(stderr):
                exec(compile(packet["python"], "<task python>", "exec"), scope)
                if self.state["config"].get("kind") != "heritage" and scope.get("ANSWER") is not None and scope.get("COMPLETE") is True:
                    self.report(scope["ANSWER"])
                if self.failed or any(not ok for ok in self.verifications.values()):
                    raise ValueError("A required read or final verifier has not succeeded")
                config = self.state["config"]
                verification = None
                if config.get("kind") == "engineering":
                    # Independently run the CURRENT official checker, even if
                    # the model reports success or runs an unrelated command.
                    verification = self.verify([config["checker"]], cwd=config["checker_cwd"])
                    tokens = re.findall(r"(?m)^\s*TOKEN:\s*(\S+)\s*$", verification["output"])
                    if not tokens:
                        raise ValueError("Official verifier did not output a TOKEN")
                    verification["token"] = tokens[-1]
                    self.report({"token": tokens[-1]})
                elif config.get("kind") == "heritage" and self.reported:
                    self.validate_api_fallback()
            result = {"status": "answer", "answer": self.answer} if self.reported else {"status": "observation", "note": "No report; inspect results and continue"}
            if verification:
                result["verification"] = verification
            if self.state["config"].get("kind") == "heritage" and result["status"] == "answer":
                result["script_fallback"] = True
        except BaseException as error:
            result = {"status": "error", "error": type(error).__name__ + ": " + str(error),
                      "traceback": traceback.format_exc()[-3000:]}
        finally:
            os.chdir(previous)
        result.update(output=output.getvalue(), stderr=stderr.getvalue(), processes=self.processes[-3:], observation=bounded(self.state.get("last")))
        return result


class ToolModule(ModuleType):
    def __init__(self, name, function):
        super().__init__(name)
        self.function = function
        setattr(self, name, function)

    def __call__(self, *args, **kwargs):
        return self.function(*args, **kwargs)


class LimitedOutput(io.StringIO):
    def write(self, text):
        super().write(text[:max(0, 7000-self.tell())])
        return len(text)


def bounded(value, limit=18000):
    text = json.dumps(value, ensure_ascii=False)
    return value if len(text.encode("utf-8")) <= limit else {"truncated": True, "preview": text[:limit // 4],
             "note": "Full last JSON response is available as DATA inside the next Python execution"}


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    packet = json.loads(sys.argv[1])
    runtime = Runtime(Path(__file__).with_name(".hugh_api_state.json"))
    result = runtime.execute(packet)
    result.setdefault("observation", runtime.state.get("last"))
    result.setdefault("config", runtime.state["config"])
    if "observation" in result:
        result["observation"] = bounded(result["observation"])
    result["id"] = packet["id"]
    for field in ("observation", "processes", "output", "stderr", "config"):
        if len(json.dumps(result, ensure_ascii=False).encode("utf-8")) > 48000 and field in result:
            result[field] = bounded(result[field], 2000)
    if len(json.dumps(result, ensure_ascii=False).encode("utf-8")) > 48000:
        result = {"id": packet["id"], "status": "error", "error": "Output budget exceeded; reduce diagnostic output"}
    print("HUGH_TASK:" + json.dumps(result, ensure_ascii=False, separators=(",", ":")))


if __name__ == "__main__":
    main()
