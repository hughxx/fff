#!/usr/bin/env python3
"""Platform entry point: python3 main3.py PORT."""
from pathlib import Path
import os
import sys


def main():
    # Match the demo's working directory and import setup before loading code.
    root = Path(__file__).resolve().parent
    os.chdir(root)
    sys.path.insert(0, str(root / "src"))
    from hugh.server import main as serve
    serve()

if __name__ == "__main__":
    main()
