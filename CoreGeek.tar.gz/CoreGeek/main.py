#!/usr/bin/env python3
from main3 import main

if __name__ == "__main__":
    main()
