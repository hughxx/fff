# 账号组与模型配置

工作区必须且只能引用一个同节点账号组。账号组是共享配置：修改后，所有引用它的工作区下次执行使用新配置。账号管理页面分为“账号”和“账号组”两个页签；工作区只展示配置、切换账号组，不再单独编辑成员或模型。

## 接口

所有路径均以 `/api` 开头。

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/account-groups` | 返回 `{"items":[账号组对象]}`，不分页 |
| POST | `/account-groups` | 创建，返回 201 和账号组对象 |
| PUT | `/account-groups/{group_id}` | 完整替换组名称及成员配置，返回账号组对象 |
| DELETE | `/account-groups/{group_id}` | 返回 `{"success":true}`；仍被工作区引用时返回 409 |
| PUT | `/workspaces/{workspace_id}/account-group` | 请求 `{"group_id":"group-xxx"}`，返回更新后的工作区 |

创建和更新账号组请求示例：

```json
{
  "name": "开发账号组",
  "node_id": "node-01",
  "members": [
    {"account_id":"account-a","model":"Glm-5.2","available":true,"fallback":true},
    {"account_id":"account-b","model":"Glm-5.2-Auto","available":true,"fallback":false}
  ]
}
```

`name`、`node_id`、`members` 必填；成员数量 1～200，账号不得重复且必须属于同节点。成员 `account_id`、`model` 必填；`available` 和 `fallback` 默认 true。已有组不能改节点。新增成员或更换模型时，服务端实时获取该账号模型列表并校验。

返回对象示例：

```json
{
  "id":"group-xxx",
  "name":"开发账号组",
  "node_id":"node-01",
  "members":[{"group_id":"group-xxx","account_id":"account-a","model":"Glm-5.2","available":true,"fallback":true}],
  "create_time":"2026-11-10T08:00:00+00:00",
  "update_time":"2026-11-10T08:00:00+00:00"
}
```

创建工作区可选传入已有组 ID：

```json
{"name":"demo","group_id":"group-xxx","python_version":"3.10","autoMemoryEnabled":false}
```

工作区在账号组所属节点创建。仅 `name` 必填。`group_id`、`account_id` 及其余字段可选。工作区响应新增 `group_id`；保留的 `accounts` 为账号组生成的只读成员视图，`default_model` 对应组成员的 `model`。旧工作区成员增删、模型设置、available 设置接口返回 409，提示到账号组管理配置。

### 兼容原创建请求

`POST /api/workspaces` 继续接受 `{"name":"demo"}` 和 `{"name":"demo","account_id":"account-a"}`。不传 group_id（或传 null）时，为该工作区新建同名组，使用指定账号；未指定账号时从在线节点的已登录、未过期账号中随机选择。不会因为名称相同而接管已有账号组。

同名组默认启用账号和模型降级，模型取该账号最新列表中第一个具体值；列表没有具体模型时保存为未配置，执行前须有可用模型，不退回 CLI 隐式默认模型。传入已有 group_id 时不创建额外组；同时传 account_id 时要求账号属于该组。创建失败的数据库事务会回滚组记录。

## 执行与切换

- 新建会话省略 `account_id` 时，从组内启用、已登录且未过期的账号中随机选择；显式指定也必须满足这些条件。
- 组或工作区绑定变更不会打断正在运行的任务。已有会话下一次发送时，原账号仍可用则保留；否则从当前组选择可用账号。没有可用账号则拒绝执行。
- 换账号保留平台会话历史，新增切换说明，清空旧 CLI 会话 ID；新账号从新的 CLI 上下文执行，不复制旧账号的本地上下文。
- 模型优先级：本轮请求的 `model` > 当前组成员的 `model`。最终始终传具体的 `--model`，不再提供“CodeAgent 默认模型”选项。
- 删除账号时仍支持手动指定各工作区替代账号；账号必须从每个所属组中移除，不能删除任何组的最后一个成员。先在账号组中补充成员或调整引用关系。

## 模型列表与降级

`GET /api/accounts/{account_id}/models` 每次执行该账号的 `codeagent models -v`，返回 `models` 和原始输出 `raw`。CLI 返回的 `value:null` 仅为原始数据，选择器过滤它。添加成员默认选第一个具体模型。没有具体模型时显示“没有可用模型列表”，通过 `?` 查看命令返回，不猜测模型。

手动打开模型选择器获取最新列表。各节点启动后及每轮检查结束一小时后检查本节点账号；执行会话前也实时检查。

- 开启 `fallback`：配置模型不在最新列表中时，选择第一个可用具体模型并保存到组，首页提示旧模型与替换模型。
- 关闭 `fallback`：保留原配置并提示，执行不可用模型时返回 409。
- 列表为空或获取失败不随意替换。调用 CLI 后如明确报模型不可用、尚无正文或工具执行，会重新获取列表，在允许降级时尝试未试过的模型；不会重跑已经产生工具操作的请求。
- 账号认证失效与模型失效分别处理；模型降级不会登录账号或改变认证状态。

首页告警 `GET /api/accounts/model-alerts` 返回 `{"items":[...]}`；每项包含 `workspace_id`、`workspace_name`、`account_id`、`account_name`、`model`（旧模型）、`new_model`（未替换时 null）、`error`、`detected_at`。点击跳转账号组配置。

## 升级部署

默认开启自动建表时，启动自动创建新增账号组及关联表。每个节点首次遇到尚未绑定组的工作区，为它创建同名账号组，保留原账号、显式模型和 available 设置；之后重启不会重复创建。无需清库，也没有单独执行“默认模型迁移”。模型可用性按上述规则检查。

所有节点均需更新部署包。修改组配置统一通过当前版本服务进行；已有独立运行任务继续使用它启动时的配置。
