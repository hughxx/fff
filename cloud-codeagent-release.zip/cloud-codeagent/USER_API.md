# 用户业务接口文档

这里的“用户接口”指调用方创建工作区、管理文件和 Skill、发起 CodeAgent 会话所需的接口。节点注册、账号登录和账号维护是平台管理能力，不要求业务调用方感知。完整管理接口另见 [API.md](API.md)。

以下路径以 `http://<host>:<port>/api` 为基址。当前后端不要求平台 API Key；JSON 请求使用 `Content-Type: application/json`。一个工作区会由后端绑定所在节点的已登录账号，**创建工作区和会话时都不传 `account_id`**。首次使用的顺序是：创建工作区 → 创建会话 → 发送消息；文件和 Skill 可在会话前后管理。

## 通用字段与错误

列表形式均为 `{"items": [...], "total": 0}`；`total` 是筛选后的总数，不是当前页数量。支持分页的接口使用 `page`（整数，≥1，默认 1）及 `page_size`（整数，1～200，默认 20）。没有请求体的 GET/DELETE 不需发送 JSON。

普通错误返回 `{"detail":"具体错误"}`；FastAPI 参数校验失败（HTTP 422）返回 `{"detail":[{"type":"...","loc":["body","name"],"msg":"...","input":"..."}]}`，数组元素可含其他 Pydantic 字段。典型状态：400 路径或 ZIP 不合法、404 不存在、409 状态冲突/资源仍有关联、413 文件超限、415 类型或编码不支持、422 参数校验、502 本地 CLI/节点通信失败、503 节点/账号/数据库不可用、504 会话执行超时。服务端错误说明以 `detail` 为准。时间字符串为带 `+00:00` 的 UTC ISO 8601 格式。

路径变量 `workspace_id` 是创建工作区时传的 `name`；`session_id` 是平台返回的 `sess_...`，与内部 `codeagent_session_id` 不同。路径和查询参数要 URL 编码，例如文件路径中的空格；不要将整个路径变量 `workspace_id` 当成文件系统路径。

## 工作区对象与接口

工作区对象在创建、列表和详情中使用同一结构：

```json
{
  "id": "demo",
  "name": "demo",
  "node_id": "node-01",
  "status": "ready",
  "create_time": "2026-09-20T08:00:00+00:00",
  "update_time": "2026-09-20T08:00:00+00:00"
}
```

调用接口时使用工作区 `id`。服务端自行定位目录，不在工作区对象中返回服务器路径；文件接口返回的路径均相对于该工作区根目录。`status` 可能为 `creating`、`ready`、`error`、`deleting`。用户只有在 `ready` 时才能操作工作区文件或创建会话。

### `GET /api/workspaces`：列出工作区

查询参数：`node_id`（可选，字符串，按节点过滤）、`page`、`page_size`。不传 `node_id` 查看所有节点的工作区。

成功：HTTP 200，`{"items":[工作区对象...],"total":N}`。例如：

```json
{"items":[{"id":"demo","name":"demo","node_id":"node-01","status":"ready","create_time":"2026-09-20T08:00:00+00:00","update_time":"2026-09-20T08:00:00+00:00"}],"total":1}
```

### `POST /api/workspaces`：创建工作区

JSON 请求体：`name` **必填**，1～128 字符；首字符为英文字母或数字，其余可用英文字母、数字、`_`、`-`。`node_id` **可选**，1～64 字符；省略时使用当前接入节点。请求体不接受其他字段。

```json
{"name":"demo"}
```

成功：HTTP 201，返回完整工作区对象（见上）。若节点没有已登录且未过期的可用账号，无法创建；同名工作区或同名目录已存在也会失败。调用方不需要选择账号。

### `GET /api/workspaces/{workspace_id}`：查看工作区

路径参数：`workspace_id` **必填**，例如 `demo`。成功：HTTP 200，返回完整工作区对象；不存在为 404。

### `DELETE /api/workspaces/{workspace_id}`：删除工作区

路径参数：`workspace_id` **必填**。成功：HTTP 200，返回 `{"success":true}`。工作区仍有会话时返回 409，须先删除会话；删除会移除该工作区的本地文件，属于不可恢复操作。

## 文件接口

所有接口均使用 `/api/workspaces/{workspace_id}/files`。`path` 相对于工作区根目录，例如 `src/main.py`。目录列表允许 `.` 表示根目录；其他操作不能针对根目录。路径不得为绝对路径、包含 `..` 或经过符号链接/Windows junction。上传支持任意文件类型，单文件默认上限 512 MiB；文本读取和编辑仅支持 UTF-8，单文件默认上限 2 MiB。超限返回 413。

目录项结构如下：

```json
{"name":"main.py","path":"src/main.py","type":"file","size":18}
```

`type` 为 `file`、`directory` 或 `symlink`；`size` 单位为字节。符号链接只会在目录列表中显示，不允许通过文件接口继续访问。

### `GET /api/workspaces/{workspace_id}/files`：浏览目录

查询参数 `path` 可选，字符串，最多 1000 字符，默认 `.`。例如 `?path=src`。

成功：HTTP 200，返回 `{"path":"src","items":[目录项...]}`。`items` 按名称排序；目录不存在时返回 404。

```json
{"path":"src","items":[{"name":"main.py","path":"src/main.py","type":"file","size":18}]}
```

### `GET /api/workspaces/{workspace_id}/files/content`：读取文本文件

查询参数 `path` **必填**，1～1000 字符。例如 `?path=src%2Fmain.py`。

成功：HTTP 200，返回 `{"path":"src/main.py","content":"print('hello')\n"}`。文件不存在为 404；非 UTF-8 文件为 415。

### `GET /api/workspaces/{workspace_id}/files/download`：下载原始文件

查询参数 `path` **必填**，1～1000 字符。成功：HTTP 200，返回原始文件字节及下载文件名；二进制文件也可下载。

### `POST /api/workspaces/{workspace_id}/files/directories`：创建空目录

JSON 请求体为 `{"path":"src"}`，父目录须存在。成功：HTTP 201，返回 `{"path":"src","type":"directory"}`；已存在返回 409。

### `POST /api/workspaces/{workspace_id}/files/upload`：上传任意文件

查询参数 `path` **必填**，1～1000 字符，例如 `?path=src%2Fimage.png`。请求头为 `Content-Type: application/octet-stream`，请求体是原始文件字节，不使用 JSON 或 multipart。成功：HTTP 201，返回 `{"path":"src/image.png","type":"file","size":N}`。服务器会为嵌套路径创建父目录，已存在的文件不会被覆盖。上传文件夹时逐个上传文件并在 `path` 中保留文件夹层级；空文件夹可调用创建目录接口。

### `PUT /api/workspaces/{workspace_id}/files`：覆盖文本文件

JSON 请求体：`path` **必填**，1～1000 字符；`content` **必填**，字符串。父目录须已存在；目标如是目录，返回 409。

```json
{"path":"src/main.py","content":"print('updated')\n"}
```

成功：HTTP 200，返回 `{"success":true,"path":"src/main.py"}`。目标文件不存在返回 404，不会创建新文件。

### `DELETE /api/workspaces/{workspace_id}/files`：删除文件或目录

查询参数 `path` **必填**，1～1000 字符。例如 `?path=src%2Fmain.py`。成功：HTTP 200，返回 `{"success":true}`。删除目录时会递归删除目录内容；目标不存在为 404。

## Skill ZIP 接口

Skill 安装在工作区的 `.cac/skills/<name>/`。一个 ZIP 对应一个 Skill，包内可直接包含 `SKILL.md` 和其他文件，或放在 `my-skill/`、`skills/my-skill/`、`.cac/skills/my-skill/` 目录下；文件夹名称应与 `SKILL.md` 的 front matter `name` 一致。`SKILL.md` 必须为 UTF-8，并包含非空 `description`：

```markdown
---
name: my-skill
description: 帮助分析项目的 Skill
---

# 使用说明
```

名称最多 64 字符，只允许小写字母、数字和中划线。ZIP 请求体是**原始二进制**，HTTP 头必须是 `Content-Type: application/zip`，不能改为 JSON 或 `multipart/form-data`。包大小上限 16 MiB，最多 512 个条目；单个解压文件上限 16 MiB，解压后总量上限 64 MiB。非法路径、重复路径和符号链接会被拒绝。

Skill 信息有三种返回形态：

```json
{"name":"my-skill","description":"帮助分析项目的 Skill","files":["SKILL.md","references/guide.md"]}
```

- **列表项**：上面三个字段。若磁盘上的某个 Skill 已损坏，则该项可能只有 `name` 和 `error`，没有 `description`、`files`。
- **创建/替换返回值**：上面三个字段；`files` 是包内安装的全部文件相对路径。
- **详情返回值**：在三个字段外增加 `content`，即完整 `SKILL.md` 文本。

### `GET /api/workspaces/{workspace_id}/skills`：列出 Skill

只有路径参数 `workspace_id`；不支持 `page`/`page_size`。成功：HTTP 200，返回 `{"items":[Skill 列表项...],"total":N}`。

### `POST /api/workspaces/{workspace_id}/skills`：上传新 Skill

只有路径参数 `workspace_id`；请求头和请求体如上。成功：HTTP 201，返回 `name`、`description`、`files`。同名 Skill 已存在返回 409，不会覆盖。

```bash
curl -X POST 'http://<host>:<port>/api/workspaces/demo/skills' \
  -H 'Content-Type: application/zip' --data-binary '@my-skill.zip'
```

### `GET /api/workspaces/{workspace_id}/skills/{name}`：查看 Skill

路径参数 `workspace_id`、`name` **必填**。成功：HTTP 200，返回 `name`、`description`、`files`、`content`。缺少 Skill 或 `SKILL.md` 返回 404。

### `PUT /api/workspaces/{workspace_id}/skills/{name}`：更新 Skill

路径参数 `workspace_id`、`name` **必填**；请求体为完整 ZIP，格式与 POST 相同。ZIP 内的 `name` 必须与路径中的 `name` 相同。成功：HTTP 200，返回 `name`、`description`、`files`。这是**整目录替换**：旧目录中未在新 ZIP 出现的文件会被删除。目标 Skill 不存在返回 404。

### `DELETE /api/workspaces/{workspace_id}/skills/{name}`：删除 Skill

路径参数 `workspace_id`、`name` **必填**。成功：HTTP 200，返回 `{"success":true}`；会删除完整 Skill 目录。

## 会话对象与接口

创建、列表和详情都使用以下会话字段；`codeagent_session_id` 由后端维护，通常首次成功发消息后才有值，调用方始终使用 `session_id`。

```json
{
  "session_id": "sess_0123456789abcdef",
  "workspace_id": "demo",
  "node_id": "node-01",
  "codeagent_session_id": null,
  "title": "项目分析",
  "status": "ready",
  "created_by": null,
  "created_at": "2026-09-20T08:10:00+00:00",
  "updated_at": "2026-09-20T08:10:00+00:00"
}
```

状态包括 `ready`（新建）、`running`（执行中）、`idle`（执行完成）、`error`、`cancelled`，删除过程中可能为 `deleting`。未提供标题时，首次消息会将输入前 100 个字符作为标题。

### `GET /api/sessions`：列出会话

查询参数：`workspace_id`（可选，按工作区过滤）、`keyword`（可选，最多 500 字符，匹配标题）、`created_by`（可选，精确匹配）、`page`、`page_size`。例如 `?workspace_id=demo&page=1&page_size=20`。

成功：HTTP 200，返回 `{"items":[会话对象...],"total":N}`，列表项不含 `messages`。

### `POST /api/sessions`：创建会话

JSON 请求体：`workspace_id` **必填**，1～128 字符；`title` 可选，字符串或 `null`，最多 500 字符；`created_by` 可选，字符串或 `null`，最多 128 字符。`created_by` 只是列表过滤标签，不是身份认证字段。

```json
{"workspace_id":"demo","title":"项目分析"}
```

成功：HTTP 201，返回完整会话对象。工作区不存在为 404；工作区尚未就绪或不在目标节点上会返回 409。

### `GET /api/sessions/{session_id}`：查看会话和历史消息

路径参数 `session_id` **必填**。成功：HTTP 200，返回会话对象，并增加 `messages` 数组。消息按创建时间、ID 排序，每项字段如下：

```json
{
  "id": "msg_0123456789abcdef",
  "session_id": "sess_0123456789abcdef",
  "role": "user",
  "content": "请分析当前项目",
  "raw_result": null,
  "created_at": "2026-09-20T08:11:00+00:00"
}
```

`role` 通常为 `user`、`assistant`，平台执行错误可为 `system`。用户消息的 `raw_result` 为 `null`；助手/系统消息的 `raw_result` 是最终结果对象的 **JSON 字符串**，不是嵌套对象；`content` 可以为 `null`。不存在返回 404。

### `POST /api/sessions/{session_id}/messages`：发送消息

路径参数 `session_id` **必填**。查询参数 `stream` 为布尔值，默认 `false`。JSON 请求体仅有 `input`：必填字符串，1～100000 字符，不得全为空白或包含 NUL 字符。

```json
{"input":"请分析当前项目结构"}
```

`stream=false` 时成功返回 HTTP 200、`application/json`，正文是 CodeAgent 的最终 `result` 对象。平台要求该对象含 `type: "result"`；常见字段如下，CLI 版本可能附加其他字段：

```json
{
  "type": "result",
  "is_error": false,
  "result": "项目包含 backend 和 frontend 两部分。",
  "session_id": "cli-session-123"
}
```

这里的 `session_id` 是 **CLI 会话 ID**，不是平台的 `sess_...`。CLI 返回 `is_error: true` 时也可能以 HTTP 200 返回结果对象；调用方应检查该字段。若平台本身执行失败且 `stream=false`，返回正常的 HTTP 错误及 `detail`。

`stream=true` 时成功返回 HTTP 200、`Content-Type: application/x-ndjson`。每一行是一个完整 JSON 对象，按 CodeAgent CLI 的原始顺序输出，最后一行一定是 `type=result`；中间事件的具体字段取决于 CLI 版本，平台不改写它们。例如：

```ndjson
{"type":"system","subtype":"init","session_id":"cli-session-123"}
{"type":"assistant","message":{"content":[{"type":"text","text":"正在查看目录"}]}}
{"type":"result","is_error":false,"result":"分析完成","session_id":"cli-session-123"}
```

如果开始流式响应后平台执行失败，HTTP 状态已经是 200，最终行会改为平台错误结果，例如：

```json
{"type":"result","subtype":"error_platform","is_error":true,"result":"会话执行超时（包含排队等待）","session_id":null,"platform_session_id":"sess_0123456789abcdef"}
```

因此流式调用方必须读取并检查最后一行的 `is_error`。客户端断开流连接会取消本轮执行。一个会话同一时间只能运行一轮消息，重复发送通常返回 409；发送前须有可用且已登录的节点账号。

```bash
curl -N -X POST 'http://<host>:<port>/api/sessions/sess_0123456789abcdef/messages?stream=true' \
  -H 'Content-Type: application/json' -d '{"input":"请分析当前项目结构"}'
```

### `POST /api/sessions/{session_id}/cancel`：取消执行

路径参数 `session_id` **必填**，不需请求体。成功：HTTP 200，返回 `{"success":true,"status":"cancelled"}`；如果当前没有执行，仍可能返回成功，但 `status` 是该会话当前状态（如 `idle`）。该接口取消当前执行，不删除历史会话。

### `DELETE /api/sessions/{session_id}`：删除会话

路径参数 `session_id` **必填**。成功：HTTP 200，返回 `{"success":true}`。会删除平台会话和历史消息，并尝试清理对应的 CodeAgent CLI 会话；执行中的会话不能直接删除，先调用 `cancel`。

## 最小调用示例

账号由平台管理员预先在节点上登录后，调用方只需使用下列三个请求：

```bash
curl -X POST 'http://<host>:<port>/api/workspaces' \
  -H 'Content-Type: application/json' -d '{"name":"demo"}'

curl -X POST 'http://<host>:<port>/api/sessions' \
  -H 'Content-Type: application/json' -d '{"workspace_id":"demo"}'

curl -N -X POST 'http://<host>:<port>/api/sessions/<上一步返回的session_id>/messages?stream=true' \
  -H 'Content-Type: application/json' -d '{"input":"你好，请介绍这个项目"}'
```
