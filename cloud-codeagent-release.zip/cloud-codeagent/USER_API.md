# 用户业务接口文档

这里的“用户接口”指调用方创建工作区、管理文件和 Skill、发起 CodeAgent 会话所需的接口。创建工作区可指定已登录账号 ID，也可由平台随机选择；节点注册与账号登录见 [API.md](API.md)。

以下路径以 `http://<host>:<port>/api` 为基址。当前后端不要求平台 API Key；JSON 请求使用 `Content-Type: application/json`。可直接创建工作区，让平台随机选择可用账号；如需固定账号，可先从 `GET /api/accounts` 获取账号 ID。创建会话时同样可以省略账号。

## 通用字段与错误

列表形式均为 `{"items": [...], "total": 0}`；`total` 是筛选后的总数，不是当前页数量。支持分页的接口使用 `page`（整数，≥1，默认 1）及 `page_size`（整数，1～200，默认 20）。没有请求体的 GET/DELETE 不需发送 JSON。

普通错误返回 `{"detail":"具体错误"}`；FastAPI 参数校验失败（HTTP 422）返回 `{"detail":[{"type":"...","loc":["body","name"],"msg":"...","input":"..."}]}`，数组元素可含其他 Pydantic 字段。典型状态：400 路径或 ZIP 不合法、404 不存在、409 状态冲突/资源仍有关联、413 文件超限、415 类型或编码不支持、422 参数校验、502 本地 CLI/节点通信失败、503 节点/账号/数据库不可用、504 会话执行超时。服务端错误说明以 `detail` 为准。时间字符串为带 `+00:00` 的 UTC ISO 8601 格式。

路径变量 `workspace_id` 是创建工作区时传的 `name`；`session_id` 是平台返回的 `sess_...`，与内部 `codeagent_session_id` 不同。路径和查询参数要 URL 编码，例如文件路径中的空格；不要将整个路径变量 `workspace_id` 当成文件系统路径。

## 工作区对象与接口

工作区对象在创建、列表和详情中使用同一结构：

```json
{
  "id": "demo",
  "name": "demo",
  "node_id": "node-01",
  "account_id": "account-xxx",
  "python_version": "3.10",
  "status": "ready",
  "create_time": "2026-09-20T08:00:00+00:00",
  "update_time": "2026-09-20T08:00:00+00:00"
}
```

调用接口时使用工作区 `id`。服务端自行定位目录，不在工作区对象中返回服务器路径；文件接口返回的路径均相对于该工作区根目录。`status` 可能为 `creating`、`ready`、`error`、`deleting`。用户只有在 `ready` 时才能操作工作区文件或创建会话。

### `GET /api/workspaces`：列出工作区

查询参数：`node_id`（可选，字符串，按节点过滤）、`page`、`page_size`。不传 `node_id` 查看所有节点的工作区。

成功：HTTP 200，`{"items":[工作区对象...],"total":N}`。例如：

```json
{"items":[{"id":"demo","name":"demo","node_id":"node-01","account_id":"account-xxx","python_version":"3.10","status":"ready","create_time":"2026-09-20T08:00:00+00:00","update_time":"2026-09-20T08:00:00+00:00"}],"total":1}
```

### `POST /api/workspaces`：创建工作区

JSON 请求体：`name` **必填**，1～128 字符；首字符为英文字母或数字，其余可用英文字母、数字、`_`、`-`。`account_id` 可选；不传时从集群中已登录、未过期且节点在线的账号中随机选择，工作区自动落在实际选中账号所属节点。`python_version` 可选，支持 `3.10`（默认）和 `3.12`。响应中的 `account_id` 是最终选中的账号。

```json
{"name":"demo"}
```

成功：HTTP 201，返回完整工作区对象（见上）。账号未登录、过期、节点离线或 Python 未安装时无法创建；同名工作区或同名目录已存在也会失败。

### `GET /api/workspaces/{workspace_id}`：查看工作区

路径参数：`workspace_id` **必填**，例如 `demo`。成功：HTTP 200，返回完整工作区对象；不存在为 404。

### `DELETE /api/workspaces/{workspace_id}`：删除工作区

路径参数：`workspace_id` **必填**。成功：HTTP 200，返回 `{"success":true}`。工作区仍有会话时返回 409，须先删除会话；删除会移除该工作区的本地文件，属于不可恢复操作。

## 执行工作区命令

`POST /api/workspaces/{workspace_id}/commands` 在工作区所属节点上执行系统 shell 命令，工作目录是该工作区根目录。请求体：

```json
{"command":"ls -la","timeout_seconds":60}
```

`command` **必填**，非空字符串，最多 10000 字符；`timeout_seconds` 可选，大于 0、最多 1800，默认 60。执行使用后端进程的系统用户权限，不提供交互式输入。成功收到执行结果时返回 HTTP 200，例如 `{"exit_code":0,"stdout":"...","stderr":"","timed_out":false}`；命令返回非零退出码仍为 HTTP 200。超时会停止进程并返回 `timed_out=true`。stdout 和 stderr 合计最多 16 MiB，超限返回 413。访问非归属节点时由后端转发到所属节点。

## 文件接口

所有接口均使用 `/api/workspaces/{workspace_id}/files`。`path` 相对于工作区根目录，例如 `src/main.py`。目录列表允许 `.` 表示根目录；其他操作不能针对根目录。路径不得为绝对路径、包含 `..` 或经过符号链接/Windows junction。上传支持任意文件类型，单文件默认上限 512 MiB；文本读取和编辑仅支持 UTF-8，单文件默认上限 2 MiB。超限返回 413。

目录项结构如下：

```json
{"name":"main.py","path":"src/main.py","type":"file","size":18}
```

`type` 为 `file`、`directory` 或 `symlink`；`size` 单位为字节。符号链接只会在目录列表中显示，不允许通过文件接口继续访问。

### `GET /api/workspaces/{workspace_id}/files`：浏览目录

查询参数 `path` 可选，字符串，最多 1000 字符，默认 `.`。例如 `?path=src`。

成功：HTTP 200，返回 `{"path":"src","items":[目录项...]}`。`items` 按名称排序；目录不存在时返回 404。

```json
{"path":"src","items":[{"name":"main.py","path":"src/main.py","type":"file","size":18}]}
```

### `GET /api/workspaces/{workspace_id}/files/content`：读取文本文件

查询参数 `path` **必填**，1～1000 字符。例如 `?path=src%2Fmain.py`。

成功：HTTP 200，返回 `{"path":"src/main.py","content":"print('hello')\n"}`。文件不存在为 404；非 UTF-8 文件为 415。

### `GET /api/workspaces/{workspace_id}/files/download`：下载原始文件

查询参数 `path` **必填**，1～1000 字符。成功：HTTP 200，返回原始文件字节及下载文件名；二进制文件也可下载。

### `POST /api/workspaces/{workspace_id}/files/directories`：创建空目录

JSON 请求体为 `{"path":"src"}`，父目录须存在。成功：HTTP 201，返回 `{"path":"src","type":"directory"}`；已存在返回 409。

### `POST /api/workspaces/{workspace_id}/files/upload`：上传任意文件

查询参数 `path` **必填**，1～1000 字符，例如 `?path=src%2Fimage.png`。请求头为 `Content-Type: application/octet-stream`，请求体是原始文件字节，不使用 JSON 或 multipart。成功：HTTP 201，返回 `{"path":"src/image.png","type":"file","size":N}`。服务器会为嵌套路径创建父目录，已存在的文件不会被覆盖。上传文件夹时逐个上传文件并在 `path` 中保留文件夹层级；空文件夹可调用创建目录接口。

### `PUT /api/workspaces/{workspace_id}/files`：覆盖文本文件

JSON 请求体：`path` **必填**，1～1000 字符；`content` **必填**，字符串。父目录须已存在；目标如是目录，返回 409。

```json
{"path":"src/main.py","content":"print('updated')\n"}
```

成功：HTTP 200，返回 `{"success":true,"path":"src/main.py"}`。目标文件不存在返回 404，不会创建新文件。

### `DELETE /api/workspaces/{workspace_id}/files`：删除文件或目录

查询参数 `path` **必填**，1～1000 字符。例如 `?path=src%2Fmain.py`。成功：HTTP 200，返回 `{"success":true}`。删除目录时会递归删除目录内容；目标不存在为 404。

## Skill ZIP 接口

Skill 安装在工作区的 `.cac/skills/<name>/`。一个 ZIP 对应一个 Skill，包内可直接包含 `SKILL.md` 和其他文件，或放在 `my-skill/`、`skills/my-skill/`、`.cac/skills/my-skill/` 目录下；文件夹名称应与 `SKILL.md` 的 front matter `name` 一致。`SKILL.md` 必须为 UTF-8，并包含非空 `description`：

```markdown
---
name: my-skill
description: 帮助分析项目的 Skill
---

# 使用说明
```

名称最多 64 字符，只允许小写字母、数字和中划线。ZIP 请求体是**原始二进制**，HTTP 头必须是 `Content-Type: application/zip`，不能改为 JSON 或 `multipart/form-data`。包大小上限 16 MiB，最多 512 个条目；单个解压文件上限 16 MiB，解压后总量上限 64 MiB。非法路径、重复路径和符号链接会被拒绝。

Skill 信息有三种返回形态：

```json
{"name":"my-skill","description":"帮助分析项目的 Skill","files":["SKILL.md","references/guide.md"]}
```

- **列表项**：上面三个字段。若磁盘上的某个 Skill 已损坏，则该项可能只有 `name` 和 `error`，没有 `description`、`files`。
- **创建/替换返回值**：上面三个字段；`files` 是包内安装的全部文件相对路径。
- **详情返回值**：在三个字段外增加 `content`，即完整 `SKILL.md` 文本。

### `GET /api/workspaces/{workspace_id}/skills`：列出 Skill

只有路径参数 `workspace_id`；不支持 `page`/`page_size`。成功：HTTP 200，返回 `{"items":[Skill 列表项...],"total":N}`。

### `POST /api/workspaces/{workspace_id}/skills`：上传新 Skill

只有路径参数 `workspace_id`；请求头和请求体如上。成功：HTTP 201，返回 `name`、`description`、`files`。同名 Skill 已存在返回 409，不会覆盖。

```bash
curl -X POST 'http://<host>:<port>/api/workspaces/demo/skills' \
  -H 'Content-Type: application/zip' --data-binary '@my-skill.zip'
```

### `GET /api/workspaces/{workspace_id}/skills/{name}`：查看 Skill

路径参数 `workspace_id`、`name` **必填**。成功：HTTP 200，返回 `name`、`description`、`files`、`content`。缺少 Skill 或 `SKILL.md` 返回 404。

### `PUT /api/workspaces/{workspace_id}/skills/{name}`：更新 Skill

路径参数 `workspace_id`、`name` **必填**；请求体为完整 ZIP，格式与 POST 相同。ZIP 内的 `name` 必须与路径中的 `name` 相同。成功：HTTP 200，返回 `name`、`description`、`files`。这是**整目录替换**：旧目录中未在新 ZIP 出现的文件会被删除。目标 Skill 不存在返回 404。

### `DELETE /api/workspaces/{workspace_id}/skills/{name}`：删除 Skill

路径参数 `workspace_id`、`name` **必填**。成功：HTTP 200，返回 `{"success":true}`；会删除完整 Skill 目录。

## 会话对象与接口

创建、列表和详情都使用以下会话字段；`codeagent_session_id` 由后端维护，通常首次成功发消息后才有值，调用方始终使用 `session_id`。

```json
{
  "session_id": "sess_0123456789abcdef",
  "workspace_id": "demo",
  "node_id": "node-01",
  "codeagent_session_id": null,
  "title": "项目分析",
  "status": "ready",
  "created_by": null,
  "created_at": "2026-09-20T08:10:00+00:00",
  "updated_at": "2026-09-20T08:10:00+00:00"
}
```

状态包括 `ready`（新建）、`running`（执行中）、`idle`（执行完成）、`error`、`cancelled`，删除过程中可能为 `deleting`。未提供标题时，首次消息会将输入前 100 个字符作为标题。

### `GET /api/sessions`：列出会话

查询参数：`workspace_id`（可选，按工作区过滤）、`keyword`（可选，最多 500 字符，匹配标题）、`created_by`（可选，精确匹配）、`page`、`page_size`。例如 `?workspace_id=demo&page=1&page_size=20`。

成功：HTTP 200，返回 `{"items":[会话对象...],"total":N}`，列表项不含 `messages`。

### `POST /api/sessions`：创建会话

JSON 请求体：`workspace_id` **必填**，1～128 字符；`account_id` 可选，省略时从该工作区可用账号中随机选一个；`title` 可选，字符串或 `null`，最多 500 字符；`created_by` 可选，字符串或 `null`，最多 128 字符。`created_by` 只是列表过滤标签，不是身份认证字段。

```json
{"workspace_id":"demo","title":"项目分析"}
```

成功：HTTP 201，返回完整会话对象。工作区不存在为 404；工作区尚未就绪或不在目标节点上会返回 409。

### `GET /api/sessions/{session_id}`：查看会话和历史消息

路径参数 `session_id` **必填**。成功：HTTP 200，返回会话对象，并增加 `messages` 数组。消息按创建时间、ID 排序，每项字段如下：

```json
{
  "id": "msg_0123456789abcdef",
  "session_id": "sess_0123456789abcdef",
  "role": "user",
  "content": "请分析当前项目",
  "raw_result": null,
  "created_at": "2026-09-20T08:11:00+00:00"
}
```

`role` 通常为 `user`、`assistant`，平台执行错误可为 `system`。用户消息的 `raw_result` 为 `null`；助手/系统消息的 `raw_result` 是最终结果对象的 **JSON 字符串**，不是嵌套对象；`content` 可以为 `null`。不存在返回 404。

### `POST /api/sessions/{session_id}/messages`：发送消息

路径参数 `session_id` **必填**。查询参数 `stream` 为布尔值，默认 `false`。JSON 请求体：`input` 必填字符串，1～100000 字符，不得全为空白或包含 NUL 字符；`model` 可选，例如 `Glm-5.2`。优先使用本轮 `model`，否则使用工作区绑定账号的默认模型；两者都没有时使用 CodeAgent 自身默认模型。

```json
{"input":"请分析当前项目结构"}
```

`stream=false` 时成功返回 HTTP 200、`application/json`，正文是 CodeAgent 的最终 `result` 对象。平台要求该对象含 `type: "result"`；常见字段如下，CLI 版本可能附加其他字段：

```json
{
  "type": "result",
  "is_error": false,
  "result": "项目包含 backend 和 frontend 两部分。",
  "session_id": "cli-session-123"
}
```

这里的 `session_id` 是 **CLI 会话 ID**，不是平台的 `sess_...`。CLI 返回 `is_error: true` 时也可能以 HTTP 200 返回结果对象；调用方应检查该字段。若平台本身执行失败且 `stream=false`，返回正常的 HTTP 错误及 `detail`。

`stream=true` 时成功返回 HTTP 200、`Content-Type: application/x-ndjson`。每一行是一个完整 JSON 对象，按 CodeAgent CLI 的原始顺序输出，最后一行一定是 `type=result`；中间事件的具体字段取决于 CLI 版本，平台不改写它们。例如：

```ndjson
{"type":"system","subtype":"init","session_id":"cli-session-123"}
{"type":"assistant","message":{"content":[{"type":"text","text":"正在查看目录"}]}}
{"type":"result","is_error":false,"result":"分析完成","session_id":"cli-session-123"}
```

如果开始流式响应后平台执行失败，HTTP 状态已经是 200，最终行会改为平台错误结果，例如：

```json
{"type":"result","subtype":"error_platform","is_error":true,"result":"会话执行超时（包含排队等待）","session_id":null,"platform_session_id":"sess_0123456789abcdef"}
```

因此流式调用方必须读取并检查最后一行的 `is_error`。客户端断开流连接会取消本轮执行。一个会话同一时间只能运行一轮消息，重复发送通常返回 409；发送前须有可用且已登录的节点账号。

```bash
curl -N -X POST 'http://<host>:<port>/api/sessions/sess_0123456789abcdef/messages?stream=true' \
  -H 'Content-Type: application/json' -d '{"input":"请分析当前项目结构"}'
```

### `POST /api/sessions/{session_id}/cancel`：取消执行

路径参数 `session_id` **必填**，不需请求体。成功：HTTP 200，返回 `{"success":true,"status":"cancelled"}`；如果当前没有执行，仍可能返回成功，但 `status` 是该会话当前状态（如 `idle`）。该接口取消当前执行，不删除历史会话。

### `DELETE /api/sessions/{session_id}`：删除会话

路径参数 `session_id` **必填**。成功：HTTP 200，返回 `{"success":true,"cli_cleanup":true}`。会删除平台会话和历史消息，并尝试清理对应的 CodeAgent CLI 会话；若 CLI 命令失败，仍删除平台数据并返回 `"cli_cleanup":false`，账号目录中的剩余 CLI 数据会在删除账号时清理。执行中的会话不能直接删除，先调用 `cancel`。

## 最小调用示例

账号由平台管理员预先在节点上登录后，调用方先取得账号资源 ID，再发送：

```bash
curl -X POST 'http://<host>:<port>/api/workspaces' \
  -H 'Content-Type: application/json' -d '{"name":"demo"}'

curl -X POST 'http://<host>:<port>/api/sessions' \
  -H 'Content-Type: application/json' -d '{"workspace_id":"demo","account_id":"account-xxx"}'

curl -N -X POST 'http://<host>:<port>/api/sessions/<上一步返回的session_id>/messages?stream=true' \
  -H 'Content-Type: application/json' -d '{"input":"你好，请介绍这个项目"}'
```
# 上传 ZIP 文件夹

一个工作区可以关联多个同节点账号。创建工作区时可以指定一个 `account_id`，也可以省略并随机选择；之后可调用 `POST /api/workspaces/{workspace_id}/accounts` 并传 `{"account_id":"account-..."}` 继续关联。工作区返回 `accounts` 数组，每项有 `account_id` 和 `default_model`。新建会话只需传 `workspace_id`，后端从该工作区已关联、已登录且未过期的账号中随机选择；如需指定，也可传 `account_id`。会话返回值中的 `account_id` 是实际选中的账号。

创建工作区时可选 `python_version`，值为 `"3.10"`（默认）或 `"3.12"`。已有工作区可用 `PUT /api/workspaces/{workspace_id}/python`，请求体如 `{"python_version":"3.12"}`。版本在工作区所在节点校验；保存后，新启动的工作区命令与 CodeAgent 会话轮次使用所选 Python，已有进程继续使用启动时的版本。后端服务自身的 Python 不变。

## 异步命令任务

`POST /api/workspaces/{workspace_id}/command-tasks` 创建异步 shell 任务，请求体为 `{"command":"python3 script.py","timeout_seconds":1800}`，立即返回 HTTP 202 和 `{"task_id":"task_...","status":"queued"}`。`timeout_seconds` 可省略，默认 1800 秒，最大 1800 秒。

`GET /api/workspaces/{workspace_id}/command-tasks/{task_id}` 查询任务。返回字段包含 `task_id`、`workspace_id`、`command`、`timeout_seconds`、`status`、`exit_code`、`stdout`、`stderr`、`timed_out`、`create_time`、`update_time`。状态可能是 `queued`、`running`、`success`、`failed`、`cancelled`；超时表现为 `status=failed` 且 `timed_out=true`。运行中也可以查询当前已收集的输出，任务结果会持久化。

`POST /api/workspaces/{workspace_id}/command-tasks/{task_id}/cancel` 取消任务并终止其整个进程组，返回 `{"success":true,"status":"cancelled"}`。任务在工作区所属节点执行，工作目录是工作区根目录，并继承该工作区选择的 Python 环境。该能力适用于 Git、npm、Python 脚本、OKF CLI 和其他非交互式 shell 任务。

选择模型时，先通过 `GET /api/accounts/{account_id}/models` 获取该账号的选项。每项的 `value` 才是发送给 CodeAgent 的模型参数；`label` 和 `description` 用于展示。`value: null` 表示默认模型。调用 `PUT /api/workspaces/{workspace_id}/accounts/{account_id}/model` 并传 `{"model":"Glm-5.2-Auto"}` 设置工作区使用此账号的默认模型，传 `{"model":null}` 恢复 CodeAgent 默认模型。消息中的可选 `model` 只覆盖本轮。账号自身不保存模型选择；没有模型值时 CLI 命令不加 `--model`。

`POST /api/workspaces/{workspace_id}/files/upload-zip?path=.` 使用 `Content-Type: application/zip`，请求体直接放 ZIP 文件字节。`path` 默认是工作区根目录，也可传已有目录的相对路径；ZIP 内容直接放入该目录，不额外添加 ZIP 同名文件夹。需要新建外层目录时传 `create_folder=true` 并将 `path` 设为新目录名。成功返回 HTTP 201：`{"path":".","type":"directory","size":12345}`。同名目录会合并；已有同路径文件或文件与目录类型冲突返回 409；无效 ZIP、越界路径或符号链接返回 400；压缩包或解压后的总内容超过 512 MiB 返回 413。前端“上传文件夹”默认直接解压，可勾选“为 ZIP 创建同名文件夹”；ZIP 文件本身不会保留。文件页打开时每 3 秒刷新当前目录列表。
