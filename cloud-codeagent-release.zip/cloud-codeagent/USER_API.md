# 用户业务接口文档

这里的“用户接口”指调用方创建工作区、管理文件和 Skill、发起 CodeAgent 会话所需的接口。创建工作区可指定已登录账号 ID，也可由平台随机选择；节点注册与账号登录见 [API.md](API.md)。

以下路径以 `http://<host>:<port>/api` 为基址。当前后端不要求平台 API Key；JSON 请求使用 `Content-Type: application/json`。可直接创建工作区，让平台随机选择可用账号；如需固定账号，可先从 `GET /api/accounts` 获取账号 ID。创建会话时同样可以省略账号。

## 通用字段与错误

列表形式均为 `{"items": [...], "total": 0}`；`total` 是筛选后的总数，不是当前页数量。支持分页的接口使用 `page`（整数，≥1，默认 1）及 `page_size`（整数，1～200，默认 20）。没有请求体的 GET/DELETE 不需发送 JSON。

普通错误返回 `{"detail":"具体错误"}`；FastAPI 参数校验失败（HTTP 422）返回 `{"detail":[{"type":"...","loc":["body","name"],"msg":"...","input":"..."}]}`，数组元素可含其他 Pydantic 字段。典型状态：400 路径或 ZIP 不合法、404 不存在、409 状态冲突/资源仍有关联、413 文件超限、415 类型或编码不支持、422 参数校验、502 本地 CLI/节点通信失败、503 节点/账号/数据库不可用、504 会话执行超时。服务端错误说明以 `detail` 为准。时间字符串为带 `+00:00` 的 UTC ISO 8601 格式。


路径变量 `workspace_id` 是创建工作区时传的 `name`；`session_id` 是平台返回的 `sess_...`，与内部 `codeagent_session_id` 不同。路径和查询参数要 URL 编码，例如文件路径中的空格；不要将整个路径变量 `workspace_id` 当成文件系统路径。

## 工作区对象与接口

工作区对象在创建、列表和详情中使用同一结构：

```json
{
  "id": "demo",
  "name": "demo",
  "node_id": "node-01",
  "account_id": "account-xxx",
  "python_version": "3.10",
  "status": "ready",
  "create_time": "2026-09-20T08:00:00+00:00",
  "update_time": "2026-09-20T08:00:00+00:00"
}
```

调用接口时使用工作区 `id`。服务端自行定位目录，不在工作区对象中返回服务器路径；文件接口返回的路径均相对于该工作区根目录。`status` 可能为 `creating`、`ready`、`error`、`deleting`。用户只有在 `ready` 时才能操作工作区文件或创建会话。

### `GET /api/workspaces`：列出工作区

查询参数：`node_id`（可选，字符串，按节点过滤）、`page`、`page_size`。不传 `node_id` 查看所有节点的工作区。

成功：HTTP 200，`{"items":[工作区对象...],"total":N}`。例如：

```json
{"items":[{"id":"demo","name":"demo","node_id":"node-01","account_id":"account-xxx","python_version":"3.10","status":"ready","create_time":"2026-09-20T08:00:00+00:00","update_time":"2026-09-20T08:00:00+00:00"}],"total":1}
```

### `POST /api/workspaces`：创建工作区

JSON 请求体：`name` **必填**，1～128 字符；首字符为英文字母或数字，其余可用英文字母、数字、`_`、`-`。`account_id` 可选；不传时从集群中已登录、未过期且节点在线的账号中随机选择，工作区自动落在实际选中账号所属节点。`python_version` 可选，支持 `3.10`（默认）和 `3.12`。响应中的 `account_id` 是最终选中的账号。

```json
{"name":"demo"}
```

成功：HTTP 201，返回完整工作区对象（见上）。账号未登录、过期、节点离线或 Python 未安装时无法创建；同名工作区或同名目录已存在也会失败。

### `GET /api/workspaces/{workspace_id}`：查看工作区

路径参数：`workspace_id` **必填**，例如 `demo`。成功：HTTP 200，返回完整工作区对象；不存在为 404。

### `DELETE /api/workspaces/{workspace_id}`：删除工作区

路径参数：`workspace_id` **必填**。成功：HTTP 200，返回 `{"success":true}`。自动删除关联会话和历史；有正在执行的任务时返回 409，需先停止；删除会移除该工作区的本地文件，属于不可恢复操作。

## 执行工作区命令

`POST /api/workspaces/{workspace_id}/commands` 在工作区所属节点上执行系统 shell 命令，工作目录是该工作区根目录。请求体：

```json
{"command":"ls -la","timeout_seconds":60}
```

`command` **必填**，非空字符串，最多 10000 字符；`timeout_seconds` 可选，大于 0、最多 1800，默认 60。执行使用后端进程的系统用户权限，不提供交互式输入。成功收到执行结果时返回 HTTP 200，例如 `{"exit_code":0,"stdout":"...","stderr":"","timed_out":false}`；命令返回非零退出码仍为 HTTP 200。超时会停止进程并返回 `timed_out=true`。stdout 和 stderr 合计最多 16 MiB，超限返回 413。访问非归属节点时由后端转发到所属节点。

## 文件接口

所有接口均使用 `/api/workspaces/{workspace_id}/files`。`path` 相对于工作区根目录，例如 `src/main.py`。目录列表允许 `.` 表示根目录；其他操作不能针对根目录。路径不得为绝对路径、包含 `..` 或经过符号链接/Windows junction。上传支持任意文件类型，单文件默认上限 512 MiB；文本读取和编辑仅支持 UTF-8，单文件默认上限 2 MiB。超限返回 413。

目录项结构如下：

```json
{"name":"main.py","path":"src/main.py","type":"file","size":18}
```

`type` 为 `file`、`directory` 或 `symlink`；`size` 单位为字节。符号链接只会在目录列表中显示，不允许通过文件接口继续访问。

### `GET /api/workspaces/{workspace_id}/files`：浏览目录

查询参数 `path` 可选，字符串，最多 1000 字符，默认 `.`。例如 `?path=src`。

成功：HTTP 200，返回 `{"path":"src","items":[目录项...]}`。`items` 按名称排序；目录不存在时返回 404。

```json
{"path":"src","items":[{"name":"main.py","path":"src/main.py","type":"file","size":18}]}
```

### `GET /api/workspaces/{workspace_id}/files/content`：读取文本文件

查询参数 `path` **必填**，1～1000 字符。例如 `?path=src%2Fmain.py`。

成功：HTTP 200，返回 `{"path":"src/main.py","content":"print('hello')\n"}`。文件不存在为 404；非 UTF-8 文件为 415。

### `GET /api/workspaces/{workspace_id}/files/download`：下载原始文件

查询参数 `path` **必填**，1～1000 字符。成功：HTTP 200，返回原始文件字节及下载文件名；二进制文件也可下载。

### `POST /api/workspaces/{workspace_id}/files/directories`：创建空目录

JSON 请求体为 `{"path":"src"}`，父目录须存在。成功：HTTP 201，返回 `{"path":"src","type":"directory"}`；已存在返回 409。

### `POST /api/workspaces/{workspace_id}/files/upload`：上传任意文件

查询参数 `path` **必填**，1～1000 字符，例如 `?path=src%2Fimage.png`。请求头为 `Content-Type: application/octet-stream`，请求体是原始文件字节，不使用 JSON 或 multipart。成功：HTTP 201，返回 `{"path":"src/image.png","type":"file","size":N}`。服务器会为嵌套路径创建父目录，已存在的文件不会被覆盖。上传文件夹时逐个上传文件并在 `path` 中保留文件夹层级；空文件夹可调用创建目录接口。

### `PUT /api/workspaces/{workspace_id}/files`：覆盖文本文件

JSON 请求体：`path` **必填**，1～1000 字符；`content` **必填**，字符串。父目录须已存在；目标如是目录，返回 409。

```json
{"path":"src/main.py","content":"print('updated')\n"}
```

成功：HTTP 200，返回 `{"success":true,"path":"src/main.py"}`。目标文件不存在返回 404，不会创建新文件。

### `DELETE /api/workspaces/{workspace_id}/files`：删除文件或目录

查询参数 `path` **必填**，1～1000 字符。例如 `?path=src%2Fmain.py`。成功：HTTP 200，返回 `{"success":true}`。删除目录时会递归删除目录内容；目标不存在为 404。

## Skill ZIP 接口

Skill 安装在工作区的 `.cac/skills/<name>/`。一个 ZIP 对应一个 Skill，包内可直接包含 `SKILL.md` 和其他文件，或放在 `my-skill/`、`skills/my-skill/`、`.cac/skills/my-skill/` 目录下；文件夹名称应与 `SKILL.md` 的 front matter `name` 一致。`SKILL.md` 必须为 UTF-8，并包含非空 `description`：

```markdown
---
name: my-skill
description: 帮助分析项目的 Skill
---

# 使用说明
```

名称最多 64 字符，只允许小写字母、数字和中划线。ZIP 请求体是**原始二进制**，HTTP 头必须是 `Content-Type: application/zip`，不能改为 JSON 或 `multipart/form-data`。包大小上限 16 MiB，最多 512 个条目；单个解压文件上限 16 MiB，解压后总量上限 64 MiB。非法路径、重复路径和符号链接会被拒绝。

Skill 信息有三种返回形态：

```json
{"name":"my-skill","description":"帮助分析项目的 Skill","files":["SKILL.md","references/guide.md"]}
```

- **列表项**：上面三个字段。若磁盘上的某个 Skill 已损坏，则该项可能只有 `name` 和 `error`，没有 `description`、`files`。
- **创建/替换返回值**：上面三个字段；`files` 是包内安装的全部文件相对路径。
- **详情返回值**：在三个字段外增加 `content`，即完整 `SKILL.md` 文本。

### `GET /api/workspaces/{workspace_id}/skills`：列出 Skill

只有路径参数 `workspace_id`；不支持 `page`/`page_size`。成功：HTTP 200，返回 `{"items":[Skill 列表项...],"total":N}`。

### `POST /api/workspaces/{workspace_id}/skills`：上传新 Skill

只有路径参数 `workspace_id`；请求头和请求体如上。成功：HTTP 201，返回 `name`、`description`、`files`。同名 Skill 已存在返回 409，不会覆盖。

```bash
curl -X POST 'http://<host>:<port>/api/workspaces/demo/skills' \
  -H 'Content-Type: application/zip' --data-binary '@my-skill.zip'
```

### `GET /api/workspaces/{workspace_id}/skills/{name}`：查看 Skill

路径参数 `workspace_id`、`name` **必填**。成功：HTTP 200，返回 `name`、`description`、`files`、`content`。缺少 Skill 或 `SKILL.md` 返回 404。

### `PUT /api/workspaces/{workspace_id}/skills/{name}`：更新 Skill

路径参数 `workspace_id`、`name` **必填**；请求体为完整 ZIP，格式与 POST 相同。ZIP 内的 `name` 必须与路径中的 `name` 相同。成功：HTTP 200，返回 `name`、`description`、`files`。这是**整目录替换**：旧目录中未在新 ZIP 出现的文件会被删除。目标 Skill 不存在返回 404。

### `DELETE /api/workspaces/{workspace_id}/skills/{name}`：删除 Skill

路径参数 `workspace_id`、`name` **必填**。成功：HTTP 200，返回 `{"success":true}`；会删除完整 Skill 目录。

## 会话对象与接口

创建、列表和详情都使用以下会话字段；`codeagent_session_id` 由后端维护，通常首次成功发消息后才有值，调用方始终使用 `session_id`。

```json
{
  "session_id": "sess_0123456789abcdef",
  "workspace_id": "demo",
  "node_id": "node-01",
  "codeagent_session_id": null,
  "title": "项目分析",
  "status": "ready",
  "created_by": null,
  "created_at": "2026-09-20T08:10:00+00:00",
  "updated_at": "2026-09-20T08:10:00+00:00"
}
```

状态包括 `ready`（新建）、`running`（执行中）、`idle`（执行完成）、`error`、`cancelled`，删除过程中可能为 `deleting`。未提供标题时，首次消息会将输入前 100 个字符作为标题。

### `GET /api/sessions`：列出会话

查询参数：`workspace_id`（可选，按工作区过滤）、`keyword`（可选，最多 500 字符，匹配标题）、`created_by`（可选，精确匹配）、`page`、`page_size`。例如 `?workspace_id=demo&page=1&page_size=20`。

成功：HTTP 200，返回 `{"items":[会话对象...],"total":N}`，列表项不含 `messages`。

### `POST /api/sessions`：创建会话

JSON 请求体：`workspace_id` **必填**，1～128 字符；`account_id` 可选，省略时从该工作区可用账号中随机选一个；`title` 可选，字符串或 `null`，最多 500 字符；`created_by` 可选，字符串或 `null`，最多 128 字符。`created_by` 只是列表过滤标签，不是身份认证字段。

```json
{"workspace_id":"demo","title":"项目分析"}
```

成功：HTTP 201，返回完整会话对象。工作区不存在为 404；工作区尚未就绪或不在目标节点上会返回 409。

### `GET /api/sessions/{session_id}`：查看会话和历史消息

路径参数 `session_id` **必填**。成功：HTTP 200，返回会话对象，并增加 `messages` 数组。消息按创建时间、ID 排序，每项字段如下：

```json
{
  "id": "msg_0123456789abcdef",
  "session_id": "sess_0123456789abcdef",
  "role": "user",
  "content": "请分析当前项目",
  "raw_result": null,
  "created_at": "2026-09-20T08:11:00+00:00"
}
```

`role` 通常为 `user`、`assistant`，平台执行错误可为 `system`。用户消息的 `raw_result` 为 `null`；助手/系统消息的 `raw_result` 是最终结果对象的 **JSON 字符串**，不是嵌套对象；`content` 可以为 `null`。不存在返回 404。

### `POST /api/sessions/{session_id}/messages`：发送消息

路径参数 `session_id` **必填**。查询参数 `stream` 为布尔值，默认 `false`。JSON 请求体：`input` 必填字符串，1～100000 字符，不得全为空白或包含 NUL 字符；`model` 可选，例如 `Glm-5.2`。优先使用本轮 `model`，否则使用工作区绑定账号的默认模型；两者都没有时使用 CodeAgent 自身默认模型。

```json
{"input":"请分析当前项目结构"}
```

`stream=false` 时成功返回 HTTP 200、`application/json`，正文是 CodeAgent 的最终 `result` 对象。平台要求该对象含 `type: "result"`；常见字段如下，CLI 版本可能附加其他字段：

```json
{
  "type": "result",
  "is_error": false,
  "result": "项目包含 backend 和 frontend 两部分。",
  "session_id": "cli-session-123"
}
```

这里的 `session_id` 是 **CLI 会话 ID**，不是平台的 `sess_...`。CLI 返回 `is_error: true` 时也可能以 HTTP 200 返回结果对象；调用方应检查该字段。若平台本身执行失败且 `stream=false`，返回正常的 HTTP 错误及 `detail`。

`stream=true` 时成功返回 HTTP 200、`Content-Type: application/x-ndjson`。每一行是一个完整 JSON 对象，按 CodeAgent CLI 的原始顺序输出，最后一行一定是 `type=result`；中间事件的具体字段取决于 CLI 版本，平台不改写它们。例如：

```ndjson
{"type":"system","subtype":"init","session_id":"cli-session-123"}
{"type":"assistant","message":{"content":[{"type":"text","text":"正在查看目录"}]}}
{"type":"result","is_error":false,"result":"分析完成","session_id":"cli-session-123"}
```

如果开始流式响应后平台执行失败，HTTP 状态已经是 200，最终行会改为平台错误结果，例如：

```json
{"type":"result","subtype":"error_platform","is_error":true,"result":"CodeAgent 未返回最终 result","session_id":null,"platform_session_id":"sess_0123456789abcdef"}
```

因此流式调用方必须读取并检查最后一行的 `is_error`。客户端断开流连接会取消本轮执行。一个会话同一时间只能运行一轮消息，重复发送通常返回 409；发送前须有可用且已登录的节点账号。

```bash
curl -N -X POST 'http://<host>:<port>/api/sessions/sess_0123456789abcdef/messages?stream=true' \
  -H 'Content-Type: application/json' -d '{"input":"请分析当前项目结构"}'
```

### `POST /api/sessions/{session_id}/cancel`：取消执行

路径参数 `session_id` **必填**，不需请求体。成功：HTTP 200，返回 `{"success":true,"status":"cancelled"}`；如果当前没有执行，仍可能返回成功，但 `status` 是该会话当前状态（如 `idle`）。该接口取消当前执行，不删除历史会话。

### `DELETE /api/sessions/{session_id}`：删除会话

路径参数 `session_id` **必填**。成功：HTTP 200，返回 `{"success":true,"cli_cleanup":true}`。会删除平台会话和历史消息，并尝试清理对应的 CodeAgent CLI 会话；若 CLI 命令失败，仍删除平台数据并返回 `"cli_cleanup":false`，账号目录中的剩余 CLI 数据会在删除账号时清理。执行中的会话不能直接删除，先调用 `cancel`。

## 最小调用示例

账号由平台管理员预先在节点上登录后，调用方先取得账号资源 ID，再发送：

```bash
curl -X POST 'http://<host>:<port>/api/workspaces' \
  -H 'Content-Type: application/json' -d '{"name":"demo"}'

curl -X POST 'http://<host>:<port>/api/sessions' \
  -H 'Content-Type: application/json' -d '{"workspace_id":"demo","account_id":"account-xxx"}'

curl -N -X POST 'http://<host>:<port>/api/sessions/<上一步返回的session_id>/messages?stream=true' \
  -H 'Content-Type: application/json' -d '{"input":"你好，请介绍这个项目"}'
```
# 上传 ZIP 文件夹

一个工作区可以关联多个同节点账号。创建工作区时可以指定一个 `account_id`，也可以省略并随机选择；之后可调用 `POST /api/workspaces/{workspace_id}/accounts` 并传 `{"account_id":"account-..."}` 继续关联。工作区返回 `accounts` 数组，每项有 `account_id` 和 `default_model`。新建会话只需传 `workspace_id`，后端从该工作区已关联、已登录且未过期的账号中随机选择；如需指定，也可传 `account_id`。会话返回值中的 `account_id` 是实际选中的账号。

创建工作区时可选 `python_version`，值为 `"3.10"`（默认）或 `"3.12"`。已有工作区可用 `PUT /api/workspaces/{workspace_id}/python`，请求体如 `{"python_version":"3.12"}`。版本在工作区所在节点校验；保存后，新启动的工作区命令与 CodeAgent 会话轮次使用所选 Python，已有进程继续使用启动时的版本。后端服务自身的 Python 不变。

## 异步命令任务

`POST /api/workspaces/{workspace_id}/command-tasks` 创建异步 shell 任务，请求体为 `{"command":"python3 script.py","timeout_seconds":1800}`，立即返回 HTTP 202 和 `{"task_id":"task_...","status":"queued"}`。`timeout_seconds` 可省略，默认 1800 秒，最大 1800 秒。

`GET /api/workspaces/{workspace_id}/command-tasks/{task_id}` 查询任务。返回字段包含 `task_id`、`workspace_id`、`command`、`timeout_seconds`、`status`、`exit_code`、`stdout`、`stderr`、`timed_out`、`create_time`、`update_time`。状态可能是 `queued`、`running`、`success`、`failed`、`cancelled`；超时表现为 `status=failed` 且 `timed_out=true`。运行中也可以查询当前已收集的输出，任务结果会持久化。

`POST /api/workspaces/{workspace_id}/command-tasks/{task_id}/cancel` 取消任务并终止其整个进程组，返回 `{"success":true,"status":"cancelled"}`。任务在工作区所属节点执行，工作目录是工作区根目录，并继承该工作区选择的 Python 环境。该能力适用于 Git、npm、Python 脚本、OKF CLI 和其他非交互式 shell 任务。

选择模型时，先通过 `GET /api/accounts/{account_id}/models` 获取该账号的选项。每项的 `value` 才是发送给 CodeAgent 的模型参数；`label` 和 `description` 用于展示。`value: null` 表示默认模型。调用 `PUT /api/workspaces/{workspace_id}/accounts/{account_id}/model` 并传 `{"model":"Glm-5.2-Auto"}` 设置工作区使用此账号的默认模型，传 `{"model":null}` 恢复 CodeAgent 默认模型。消息中的可选 `model` 只覆盖本轮。账号自身不保存模型选择；没有模型值时 CLI 命令不加 `--model`。

`POST /api/workspaces/{workspace_id}/files/upload-zip?path=.` 使用 `Content-Type: application/zip`，请求体直接放 ZIP 文件字节。`path` 默认是工作区根目录，也可传已有目录的相对路径；ZIP 内容直接放入该目录，不额外添加 ZIP 同名文件夹。需要新建外层目录时传 `create_folder=true` 并将 `path` 设为新目录名。成功返回 HTTP 201：`{"path":".","type":"directory","size":12345}`。同名目录会合并；已有同路径文件或文件与目录类型冲突返回 409；无效 ZIP、越界路径或符号链接返回 400；压缩包或解压后的总内容超过 512 MiB 返回 413。前端“上传文件夹”默认直接解压，可勾选“为 ZIP 创建同名文件夹”；ZIP 文件本身不会保留。文件页打开时每 3 秒刷新当前目录列表。
# CodeAgent 会话异步任务

## 可恢复的实时事件订阅

`GET /api/sessions/{session_id}/tasks/{task_id}/events?after=0` 返回 `application/x-ndjson`。先回放已保存事件，再持续返回新事件。每条业务事件增加整型 `event_id`，在该任务内单调递增；断线后传入最后处理成功的序号作为 `after`，仅回放更晚的事件。空闲时发送 `{"type":"heartbeat"}`，无序号，可忽略。最终 `type=result` 后连接结束。已结束任务也可回放；任务不存在或不属于会话返回 404，负数游标返回 422。重复读取已结束的终点可能返回终态结果，调用方按任务与序号去重。

关闭订阅不会取消后台任务，多个页面可同时订阅，不会争抢事件。会话详情新增 `active_task_id`（无运行中异步任务时为 null），用于重新打开页面后找到当前任务。订阅事件和会话正文采用各自的展示区域，正文从会话历史读取，避免把回放事件再次追加为重复消息。

前端已改用异步提交及此订阅接口，刷新、离开或关闭页面不会取消任务，断线自动重连。异步任务由独立运行器执行，Web 后端停止/重启不终止该任务，恢复后继续查询、订阅及取消。机器重启、运行器或 CodeAgent 退出不支持自动续跑。原有 POST messages 的同步/流式调用方式未变，旧的直接流式 POST 断开仍会取消；需要断线和 Web 重启恢复的调用方应使用 tasks + events。

事件随任务保存到数据库，删除会话时一起删除；与保留七天的工作区诊断日志不同。

流式与异步执行中的 assistant 文本按消息分组及时保存到会话历史，同一消息的多个文本片段合并，内部 user 工具输入不会作为助手正文保存。最终 result 与最后一条主助手回复相同时只补充 raw_result，不覆盖先前消息；取消或失败时已经保存的中间回复保留，并增加系统错误消息。同步 JSON 调用只提供 CLI 最终结果。工具进度通过流式事件和工作区日志查看，不作为普通聊天正文写入数据库。

已有工作区先通过 `POST /api/sessions` 创建会话（请求示例：`{"workspace_id":"test1"}`），取得 `session_id` 后提交任务。不传账号时创建会话会随机绑定工作区可用账号。

## 提交

`POST /api/sessions/{session_id}/tasks`

```json
{"input":"分析当前项目并生成文档","model":"Glm-5.2"}
```

`input` 必填，1–100000 字符且不能全为空白；`model` 可选，省略时使用工作区为会话账号设置的默认模型，再未设置则不传 CLI 模型参数。提交成功立即返回 HTTP 202：

```json
{"task_id":"task_xxx","session_id":"sess_xxx","status":"running"}
```

无需保持 HTTP 连接，也无需消费流。后台使用 CodeAgent stream-json 持续读取事件并写工作区七天日志，不设置执行时长上限。同一会话正在执行时再次提交（包括同步、流式）返回 409；账号认证无效返回 409。提交响应丢失不等于任务未创建，请勿盲目重试；本接口没有幂等键。

## 查询

`GET /api/sessions/{session_id}/tasks/{task_id}` 返回 HTTP 200：

```json
{
  "task_id":"task_xxx",
  "session_id":"sess_xxx",
  "node_id":"node_xxx",
  "status":"success",
  "input":"分析当前项目并生成文档",
  "model":"Glm-5.2",
  "result":{"type":"result","subtype":"success","is_error":false,"result":"分析结果……","session_id":"cli-session-id"},
  "error":null,
  "create_time":"2026-10-16T01:00:00+00:00",
  "update_time":"2026-10-16T01:05:00+00:00"
}
```

状态为 `running`、`success`、`failed`、`cancelled`；运行中 `result` 和 `error` 为 null。`result` 是 CodeAgent 最终结果对象（额外字段原样保留），平台失败时可能是平台错误结果；重启中断时可能为 null。`error` 为失败/取消原因或 null。建议每 3–5 秒查询，达到终态后停止轮询。结果也会写入会话历史，可通过会话详情接口读取。查询不返回实时增量输出，排查中间事件使用工作区 `.codeagent-logs/`。

## 取消

`POST /api/sessions/{session_id}/tasks/{task_id}/cancel` 无请求体，返回：

```json
{"success":true,"task_id":"task_xxx","status":"cancelled"}
```

任务已结束则返回实际终态，不覆盖结果。不存在或不属于该会话的任务返回 404。普通会话取消接口也可取消当前异步任务。

以上接口均支持跨节点转发。Web 后端启动后识别独立运行器的任务锁，存活任务保持 running；运行器已退出而任务未完成时标记 failed，不自动重新执行。取消请求通过本节点任务目录传给运行器；若十秒内尚未结束，取消接口返回实际状态，继续查询即可。删除会话会删除其数据库任务记录。已有同步/流式接口保留。
# 通用文件浏览、统计与目录树

以下接口均使用工作区相对路径，自动转发至所属节点。`path` 默认 `.`，最长 1000 字符。禁止绝对路径、`..` 和穿过符号链接的路径。隐藏文件计入，符号链接不跟随，普通文件按目录条目计数（硬链接不去重）。结果不是文件系统快照，扫描时并发写入可能影响结果。

## 兼容原有文件列表

`GET /api/workspaces/{workspace_id}/files?path=src`

不传新参数时，原有行为、排序和返回结构保持不变：

```json
{"path":"src","items":[{"name":"main.py","path":"src/main.py","type":"file","size":120}]}
```

新增可选参数：

| 参数 | 默认 | 说明 |
| --- | --- | --- |
| include_counts | false | 为本次列表中的每个目录增加 `counts`；不增加文件条目的字段 |
| count_depth | 1 | 每个子目录内部的统计深度，1～100；1 只统计该子目录直属内容 |
| max_entries | 100000 | 启用 counts 时，整个请求共享的扫描条目上限，1～1000000；包含当前目录及各子目录的扫描条目。旧列表不传 include_counts 时不应用此限制 |

例如只浏览 `src`，但同时显示每个文件夹内直属文件和目录的数量：

```http
GET /api/workspaces/demo/files?path=src&include_counts=true
```

```json
{
  "path":"src",
  "items":[{
    "name":"lib","path":"src/lib","type":"directory","size":4096,
    "counts":{
      "max_depth":1,"file_count":3,"directory_count":2,"total_size_bytes":1200,
      "skipped_symlink_count":0,"other_count":0,"depth_limited":true
    }
  }]
}
```

`size` 保留原来的文件系统元数据含义，目录的 size 不是内容总大小；内容大小使用 counts.total_size_bytes。增加 `count_depth=2` 可多统计一层；默认不递归扫描整个工作区。

## 文件和目录统计

`GET /api/workspaces/{workspace_id}/files/stats`

| 参数 | 默认 | 说明 |
| --- | --- | --- |
| mode | recursive | `recursive` 递归统计；`direct` 只统计直属内容。已删除叶子模式，传入该模式返回 422 |
| max_depth | 不限制深度 | 可选 1～100；目标目录是第 0 层，直属文件/目录是第 1 层。direct 模式固定为 1，即使传入其他合法深度也按 1 执行 |
| max_entries | 100000 | 扫描条目上限，1～1000000 |

统计 `.raw` 全部文件，不需要命令或临时文件：

```http
GET /api/workspaces/demo/files/stats?path=repos/project/.raw
```

最多统计两层：

```http
GET /api/workspaces/demo/files/stats?path=repos/project/.raw&max_depth=2
```

```json
{
  "path":"repos/project/.raw","mode":"recursive","max_depth":2,
  "file_count":125,"directory_count":12,"total_size_bytes":204800,
  "skipped_symlink_count":0,"other_count":0,"depth_limited":true
}
```

字段说明（列表 counts 和树的汇总字段也使用相同口径）：

- file_count：已扫描范围内普通文件数。
- directory_count：已发现的真实子目录数，不包含统计起点本身；包含深度边界上的未展开目录。
- total_size_bytes：已统计普通文件的逻辑字节数之和，不是磁盘占用。
- skipped_symlink_count：已发现但未跟随的符号链接/目录联接数。
- other_count：其他文件系统条目数，例如 FIFO；不作为普通文件读取。
- depth_limited：是否存在因为层数限制未扫描内部内容的目录。true 表示数量仅代表已扫描范围，不能当成完整递归总数；不会为了判断边界目录是否为空再深入扫描。
- max_depth：实际使用的深度，不限深度时为 null。

## 一次查询目录树

`GET /api/workspaces/{workspace_id}/files/tree?path=src&max_depth=2`

| 参数 | 默认 | 说明 |
| --- | --- | --- |
| max_depth | 3 | 1～100；1 仅列直属条目。选择足够大的深度可一次获取完整树；depth_limited=false 表示已全部展开 |
| max_entries | 10000 | 扫描与返回条目上限，1～100000 |

```json
{
  "path":"src","max_depth":2,
  "items":[{
    "name":"lib","path":"src/lib","type":"directory","size":4096,"expanded":true,
    "children":[
      {"name":"main.py","path":"src/lib/main.py","type":"file","size":120},
      {"name":"nested","path":"src/lib/nested","type":"directory","size":4096,"expanded":false}
    ]
  }],
  "file_count":1,"directory_count":2,"total_size_bytes":120,
  "skipped_symlink_count":0,"other_count":0,"depth_limited":true
}
```

条目按名称排序，path 始终相对工作区根目录。目录 `expanded=true` 时包含 children，空目录为 `children:[]`；深度边界上的目录为 `expanded=false` 且没有 children，不能把它视为空目录。文件、链接和其他条目没有 children。树的顶层数量汇总只覆盖返回树的范围。

## 错误与使用边界

新扫描能力：目录不存在或扫描期间消失 404；无读取权限 403；非法路径/目标非目录 400；其他文件系统错误 409；参数不合法 422；超过 max_entries 为 413。错误体 `{"detail":"原因"}`，不会返回部分结果伪装成成功或 0。深度限制则是正常 200，通过 depth_limited 和 expanded 标明边界。

扫描在后台线程执行，但 HTTP 请求仍等待扫描完成。大目录应先用浅层列表或树，再按需展开子目录；深度限制不能限制同一层的文件数量，需同时设置 max_entries。读取、下载、上传、ZIP 上传、修改和删除等原有文件接口不变。
# 账号自动保活

每个节点自动为本节点已有登录身份的账号发送一次独立的 `你好` 请求；正在登录的账号跳过。不需要工作区，也不使用用户会话或覆盖模型设置。

首次无调度记录时立即尝试，此后取“上次成功后 24 小时”和“expires_at 到期前 1 小时”中的较早时间，每 30 秒检查一次。多个账号在节点内依次执行，运行和排队可能延迟实际时间。成功但到期时间仍落在提前量内时，最早 5 分钟后再尝试，避免密集循环。失败后 5 分钟重试；登录凭据失效时仍需重新登录。服务停机或网络失败时无法保证到期前续期。

发送成功后执行 `codeagent auth status --json`，同步账号状态和新到期时间；不会恢复已删除的刷新按钮和设置接口。调度计划保存在节点 state_dir 下 `account-keepalive.json`，重启继续使用。保活工作目录在 state_dir 下 `account-keepalive/<账号ID>`。

后端 `logs/codeagent.log` 中搜索“账号保活”，可看到开始、成功、失败、旧/新到期时间和 next_at/retry_at（UTC 时间）。请求使用现有 command_timeout（默认 60 秒），超时会清理子进程并重试，不改变用户对话的超时规则。
# Shell 异步任务历史与重启恢复

前端“执行命令”现使用 POST `/api/workspaces/{workspace_id}/command-tasks`，提交后可继续提交其他命令。任务历史来自数据库，刷新或重新打开页面后仍可查询状态、输出及取消运行中的任务。

新增 GET `/api/workspaces/{workspace_id}/command-tasks?page=1&page_size=20`。page 从 1 开始，page_size 为 1～200，返回 `{"items":[任务摘要],"total":数量}`，按创建时间倒序。摘要包含 task_id、workspace_id、command、timeout_seconds、status、exit_code、timed_out、create_time、update_time；不含 stdout/stderr，选中任务后通过原 GET `/{task_id}` 获取完整结果。

异步 Shell 使用独立运行器，Web 服务重启不终止命令；输出执行期间持续写库。取消接口通过运行器终止进程组，最多等待约 10 秒，若仍运行则返回实际 queued/running 状态，继续查询确认。原同步 POST `/commands` 保留，超时参数含义不变。机器重启或运行器异常退出后不自动重复执行，未完成任务标记 failed，保留已写入数据库的输出。

账号保活只占用正在保活的账号，不再长时间持有账号管理全局锁；其他账号的添加和删除不受保活请求等待影响。同一账号保活期间登录或删除返回 409，稍后重试。
# 删除或移除账号时选择替代账号

页面删除账号时，为每个关联工作区分别选择替代账号；从工作区移除账号时，只选择当前工作区的替代账号。不会默认替用户提交选择。

可用账号必须属于同节点、已绑定该工作区、已登录且 expires_at 为空或晚于当前时间。**多个账号全部过期，与没有可用替代账号一样**：禁止提交删除，先添加一个可用账号，或者重新登录已有账号。窗口提供工作区添加账号和账号管理入口。正在执行的会话仍需先停止；平台历史保留，后续建立新的 CLI 上下文。

1. 查询候选：GET `/api/accounts/account-old/replacement-options`

```json
{"workspaces":[{"workspace_id":"demo","name":"demo","node_id":"node-1","candidates":[{"id":"account-new","name":"研发账号","expires_at":null}]}]}
```

无关联工作区返回 `{"workspaces":[]}`，可直接删除；有关联但无可用替代账号则对应 `candidates:[]`。

2. 删除账号：DELETE `/api/accounts/account-old`，Content-Type 为 application/json：

```json
{"replacements":{"demo":"account-new"}}
```

映射的 key 是工作区 ID，value 是平台账号资源 ID（不是 CLI 工号）。显式映射必须覆盖全部关联工作区；如果关联变化或候选账号过期，返回 409，需要重新查询选项。多个工作区分别选择，任何一个不满足则全部回滚。不传请求体仍支持自动选择。

3. 仅从工作区移除：DELETE `/api/workspaces/demo/accounts/account-old?replacement_account_id=account-new`，无请求体，成功返回更新后的工作区。省略参数仍支持自动选择。

以上接口沿用原删除响应与状态规则，不删除会话历史；无法选择原账号、未绑定账号、其他节点账号或已失效账号。
# 暂停使用工作区账号

不删除账号时，可调用：

```http
PUT /api/workspaces/my-space/accounts/account-xxx/available
Content-Type: application/json

{"available": false}
```

成功返回 HTTP 200 和完整工作区对象，`accounts` 对应项示例：

```json
{"account_id": "account-xxx", "default_model": null, "available": false}
```

将 `available` 改为 `true` 即可恢复。默认启用，只影响该工作区；保留绑定、模型配置、会话历史，不中断正在运行的任务。停用账号不参加随机选择、手动新建会话和替代账号选择。已有会话再次发送消息会返回 409，先启用账号再发送。若全部停用，随机新建会话返回 503，需要启用或添加已登录且未过期的账号。开关不会刷新认证或改变账号在其他工作区的状态。
# 查询工作区用量

调用 `GET /api/workspaces/{workspace_id}/disk-usage`，返回 `total_size_bytes`（总文件大小）、`codeagent_log_size_bytes`（其中执行日志大小）、`other_size_bytes`（其他文件大小）、`file_count`、`disk_free_bytes`（所在磁盘共享剩余空间）、`skipped_symlink_count` 和 `measured_at`（UTC 统计时间）。所有大小单位为字节，日志已经包含在总量中。默认缓存 5 分钟，加 `?refresh=true` 可重新统计；不跟随符号链接。无需传服务器路径。
# 查看账号保活日志

账号管理每行提供“保活日志”，可查看上次尝试、上次成功、下次计划时间、最近失败原因及各模型尝试记录。每 10 秒更新显示，也可手动刷新记录，不会触发保活。

接口：`GET /api/accounts/{account_id}/keepalive`，时间字段为 Unix 秒，返回 `last_attempt`、`last_success`、`next_at`、`status`、`last_error` 和 `history`。无历史时返回 `history: []`。日志保留近 7 天最多 100 次模型尝试；默认模型失败后会查询当前账号的可用模型并依次尝试明确模型，失败不会清空上次成功时间。旧版本已经丢失的成功时间不能自动恢复。
# 工作区自动记忆开关

新建工作区可传 `autoMemoryEnabled`（布尔值，默认 false）。创建后通过 `GET /api/workspaces/{workspace_id}/memory` 查询，返回 `{"autoMemoryEnabled":false}`；通过 `PUT /api/workspaces/{workspace_id}/memory` 和请求体 `{"autoMemoryEnabled":true}` 开启，传 false 关闭。接口只修改工作区设置文件中的此字段，保留其他键及已有记忆。前端创建页与工作区概览均可设置；下次启动 CodeAgent 执行时读取。
