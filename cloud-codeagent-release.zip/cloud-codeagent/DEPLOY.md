# 部署说明

发布包包含 FastAPI 后端、已构建的前端和 Ubuntu 20.04 x86_64 / Python 3.10 的离线依赖包。服务器无需安装 Node.js 或 npm，也无需创建 venv。Python 解释器、CodeAgent CLI 和数据库不包含在发布包中。

## 安装并启动

用实际运行服务的 Linux 用户登录，确认当前 shell 的 `PATH` 已包含你在 `.bashrc` 中配置的 Python 3.10：

```bash
command -v python3
python3 --version
```

版本应为 3.10。随后解压发布包，离线安装后端依赖并启动：

如果复用此前版本创建的 MySQL 数据库，先执行一次：

```bash
docker exec -it mysql mysql -u root -p codeagent -e 'ALTER TABLE t_ca_node DROP COLUMN max_concurrency;'
```

全新数据库不需要这一步。

```bash
unzip cloud-codeagent-release.zip
cd cloud-codeagent
python3 -m pip install --user --no-index --find-links=wheels -r backend/requirements.txt
bash start.sh --host 10.10.10.23 --port 8800
```

把示例 IP 换成该节点可供其他节点访问的实际地址。`start.sh` 调用 `python3`，使用启动它的 shell 传入的 `PATH`；从交互式终端运行时会继承 `.bashrc` 配好的路径。若以后改用 systemd 等服务管理器，需给服务进程配置相同的 `PATH`，因为它不会自动读取 `.bashrc`。

本节点的对话及执行命令不设置并发上限，节点页面仅显示当前运行任务数。

会话执行不设置总时长上限，跨节点转发也不限制响应等待时间；连接目标节点仍限时 10 秒。异步会话支持断线及 Web 重启后恢复查看，手动取消会终止执行。旧直接流式请求仍与连接绑定。Shell 命令接口的 timeout_seconds 独立生效。

浏览器打开 `http://10.10.10.23:8800/`。前端由后端直接提供，无需单独启动 `frontend/dist`。接口文档在 `/docs`，服务日志在 `backend/logs/codeagent.log`。

## 目录与配置

### Web 后端重启与正在执行的会话

页面及 `/sessions/{id}/tasks` 创建的异步会话使用独立 Python 运行器。每个任务的运行描述、取消标记、运行器锁及 `worker.log` 位于当前服务用户的 `~/.cloud-codeagent/session-runners/task_xxx/`。运行代码副本按内容哈希放在同级 `runtime-*` 目录，发布包替换不影响已启动任务；新任务使用新代码。该目录包含本机数据库连接配置，权限仅授予服务用户，不要作为问题日志分享。工作区 `.codeagent-logs/` 仍保留原始 CLI 输出。

重新部署只停止监听 Web 端口的 `python3 -u run.py` 进程，然后替换发布程序目录并用相同用户、相同数据目录启动。不要终止 `utils.session_worker` 运行器、CodeAgent 进程或清空 `.cloud-codeagent`。Web 暂停期间任务仍读取输出并写数据库；Web 恢复后页面重连。若使用 systemd/容器，需要保证重启 Web 不同时销毁运行器所属进程组/cgroup 或容器；默认杀死整个服务进程组的管理方式不适用。

异步 CodeAgent 会话和异步 Shell 命令均使用独立运行器，前端两者均已改用异步接口。部署时同时保留 utils.session_worker 和 utils.command_worker 进程。旧 POST messages 和 POST commands 同步/直接流式请求仍按原生命周期执行。首次升级前已由旧后端执行的 Shell 任务不能转交运行器，应等其完成再升级。机器重启、数据库不可用导致运行器失败、运行器或 CLI 被杀均不保证续跑；平台不会自动重新执行以避免重复操作。

MySQL 自动建表使用同一数据库连接持有 GET_LOCK 命名锁，最多等待 120 秒；节点依次检查表并只创建缺失表，完成或失败后释放锁。不会自动补齐旧工作区账号关联，也不会自动修改已有表结构。

部署时保留当前使用的 Python 解释器及依赖。运行器状态与代码副本暂不自动清理，避免误删活跃任务；七天清理仅针对工作区诊断日志。无需额外手动启动常驻服务，也无需清空数据库。

每轮会话的 CodeAgent 原始输出保存在所属工作区的 `.codeagent-logs/`，每轮一个 JSONL 文件，文件名包含 UTC 时间、平台会话 ID 和唯一编号。每条记录包含 UTC 时间、累计秒数和事件类型；stdout/stderr、启动参数、输入、最终结果及数据库保存阶段均追加记录并及时 flush。原始内容不截断、不脱敏，分享前请检查敏感信息。每次该工作区开始会话执行时，自动删除最后修改时间超过七天的日志；没有新执行时不会主动清理。删除工作区也会删除这些日志。日志写入失败会记录到服务日志，不中断对话。本日志针对会话调用 CodeAgent，不包含账号登录及独立 Shell 命令接口。

```text
cloud-codeagent/
├── backend/         # FastAPI 后端、配置及 requirements.txt
├── frontend/dist/   # 已构建的前端静态文件
├── wheels/          # Python 3.10 离线依赖
├── start.sh         # 启动脚本
├── API.md           # 管理接口文档
├── USER_API.md      # 用户接口文档
└── DEPLOY.md        # 本说明
```

应用配置在 `backend/config/settings.py`，其中包含数据库连接、运行数据目录和工作区使用的 Python 解释器设置。后端启动会自动创建缺失的业务表，但不会修改已有表结构。多节点须连接同一个 MySQL 数据库，各节点分别保留自己的账号配置和工作区文件。

工作区默认使用 Python 3.10，也可在创建时或工作区详情页选择 Python 3.12。服务器需要在工作区所属节点安装相应解释器：默认配置分别为 `/home/codeagent/python310/bin/python3` 和 `/home/codeagent/python312/bin/python3.12`。后端本身仍由启动脚本调用当前 `PATH` 中的 `python3`。工作区的命令与 CodeAgent 子进程每次启动时根据工作区版本设置 `PYTHON` 与 `PATH`；切换版本不影响已运行的进程，也不创建 venv。Python 3.12 所需第三方包请用 3.12 的 `pip` 单独安装。

此版本新增工作区与账号关联表。部署到已有数据库时，启动会创建该表，并把每个已有工作区原来的账号关联补入；原有会话仍使用其已记录的账号。一个工作区之后可关联同节点的更多账号，并为每个账号设置该工作区的默认模型。账号本身不保存模型设置。
如果旧版本曾设置账号级默认模型，升级后请到工作区中为对应账号重新选择；旧账号级设置不会继续影响对话执行。

更新部署包时保留数据库和各节点的数据目录。若服务启动失败，查看终端的完整报错或 `backend/logs/codeagent.log`；若 `python3 --version` 仍显示 3.8，先检查当前登录用户的 `.bashrc` 与 `PATH`。
# 本次升级：工作区账号 available 开关

旧数据库请在停止所有节点后，对共享 MySQL 数据库执行一次以下 SQL，再部署并启动所有节点。无需删除数据；已有绑定默认启用。新建数据库会自动带此字段，不需执行 ALTER。自动建表不会更新旧表。

```sql
ALTER TABLE t_ca_workspace_account ADD COLUMN available BOOLEAN NOT NULL DEFAULT TRUE;
```
