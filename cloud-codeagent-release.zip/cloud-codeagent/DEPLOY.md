# ZIP 发布包部署说明

这个包已经包含构建好的前端。服务器不需要安装 Node.js、npm 或单独启动前端。

## 包内目录

```text
cloud-codeagent/
├── backend/            # FastAPI 后端、requirements.txt、schema.sql、.env.example
├── frontend/dist/     # 已构建的 HTML、JS、CSS
├── start.sh           # Ubuntu 启动脚本
├── DEPLOY.md          # 本说明
└── cloud-codeagent.service.example
```

请保持 `backend` 与 `frontend` 的相对位置。程序会根据自身代码位置寻找 dist，不依赖启动时的工作目录。

## 1. 解压与安装 Python 依赖

服务器需要 Python **3.11 或更新版本**、Git、已安装的 CodeAgent CLI，以及可连接的 GaussDB。

```bash
unzip cloud-codeagent-release.zip
cd cloud-codeagent
python3.11 -m venv .venv
.venv/bin/python -m pip install -r backend/requirements.txt
```

如果已有满足要求的 Python 环境，可以直接使用该环境。ZIP 中不包含 Python 解释器、Python 离线安装包、CodeAgent CLI 或数据库；上述 pip 安装需要可用的软件源。

## 2. 配置数据库与账号目录

```bash
cp backend/.env.example backend/.env
```

修改 `backend/.env` 中的数据库连接参数，至少填写 `CA_DB_PASSWORD`；确认：

```dotenv
CA_DATA_DIR=/home/codeagent
CA_CODEAGENT_COMMAND=["/home/codeagent/.local/bin/codeagent"]
# 如启用访问认证，所有节点保持一致，进入页面后在“连接设置”填写。
CA_API_KEY=
```

首次部署时，在目标 GaussDB 执行 `backend/schema.sql` 创建表。多个节点共用同一数据库，不要在每个节点重复初始化索引。

## 3. 一次启动前后端

使用普通 `codeagent` 用户执行，把示例 IP 换成服务器实际 IP：

```bash
bash start.sh --host 10.10.10.23 --port 8800 --concurrency 4
```

也可以不用脚本：

```bash
cd backend
../.venv/bin/python run.py --host 10.10.10.23 --port 8800 --concurrency 4
```

`--host` 是本机监听及节点注册地址，不能使用 `0.0.0.0`。使用非默认 Python 时，可运行 `PYTHON_BIN=/path/to/python bash start.sh ...`。

## 4. 打开页面

在自己的浏览器访问：

```text
http://10.10.10.23:8800/
```

确保浏览器所在机器能访问服务器的 8800 端口。

- 页面地址示例：`http://10.10.10.23:8800/#/workspaces`。
- 浏览器接口地址：`/api/nodes`、`/api/sessions` 等，由同一 FastAPI 进程处理。
- 原有 `/nodes`、`/sessions` 等 API 仍可直接调用；`/docs` 仍是接口文档。
- **dist 不用执行任何启动命令，也不要双击其中的 index.html 使用。** 后端启动后，会自动提供它的页面和静态资源。

如果首页返回 404，检查 `frontend/dist/index.html` 是否存在且目录结构正确；自定义位置可设置 `CA_FRONTEND_DIR`。如果页面能打开但提示连接失败，检查数据库和后端日志。配置了 API Key 时，需在页面“连接设置”输入同一个 Key。

需要常驻运行时，可修改并安装包内的 `cloud-codeagent.service.example`。Nginx 是可选组件，直接通过 FastAPI 访问不需要它。

## 仅在本机验证页面（可选）

没有 GaussDB 时，把 `backend/.env` 中以下配置改为：

```dotenv
CA_DATABASE_URL=sqlite:///./codeagent.db
CA_DB_AUTO_CREATE=true
CA_DATA_DIR=./.data
```

然后执行 `bash start.sh --host 127.0.0.1 --port 8800 --concurrency 4`。
这只用于单机开发验证；账号登录与对话仍需真实 CodeAgent CLI，正式集群应使用 GaussDB。
