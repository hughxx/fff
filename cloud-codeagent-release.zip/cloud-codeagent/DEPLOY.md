# ZIP 发布包部署说明

这个包已经包含构建好的前端，直接使用系统 Python 启动。服务器不需要安装 Node.js、npm，不使用虚拟环境，也不需要外置环境变量或 .env 文件。

当前默认使用 **SQLite 单机数据库**。首次启动自动创建 `backend/codeagent.db` 和业务表，不需要连接 GaussDB 或手工执行建表 SQL。

## 包内目录

```text
cloud-codeagent/
├── backend/            # FastAPI 后端、config/settings.py、requirements.txt、schema.sql
├── frontend/dist/     # 已构建的 HTML、JS、CSS
├── start.sh           # Ubuntu 启动脚本
├── DEPLOY.md          # 本说明
└── cloud-codeagent.service.example
```

请保持 `backend` 与 `frontend` 的相对位置。程序会根据自身代码位置寻找 dist，不依赖启动时的工作目录。

## 1. 解压与安装 Python 依赖

服务器需要 Python **3.8**、Git，以及用于账号登录和对话的 CodeAgent CLI。SQLite 由 Python 内置，无需另行安装数据库服务。

```bash
unzip cloud-codeagent-release.zip
cd cloud-codeagent
python3 --version
python3 -m pip install -r backend/requirements.txt
```

代码和依赖按 Python 3.8 适配，Ubuntu 20.04 可使用自带的 Python 3.8。安装依赖和启动服务使用同一个系统 Python，依赖版本以包内 `backend/requirements.txt` 为准。ZIP 中不包含 Python 解释器、Python 离线安装包、CodeAgent CLI 或运行数据；上述 pip 安装需要可用的软件源。

## 2. 应用配置与数据库初始化

应用配置统一写在 `backend/config/settings.py`。SQLite 已配置好，默认直接启动即可。修改这个文件后重启服务生效，程序不会读取 `.env` 或 `CA_*` 环境变量。

- `database_url` 指向 `backend/codeagent.db` 的绝对路径，不受启动时工作目录影响。
- `db_auto_create=True`：首次启动自动建表，后续启动沿用已有数据。

- `data_dir` 默认为运行用户的主目录；使用 `codeagent` 用户时通常为 `/home/codeagent`。
- `codeagent_command` 默认为 `["codeagent"]`，使用已安装的 CLI；也可直接在配置文件中填写可执行文件的绝对路径。
- `api_key` 默认为 `None`；如需要访问认证，在配置文件中设置，所有节点保持一致，进入页面后在“连接设置”填写同一个 Key。

服务运行用户需对 `backend` 目录有写入权限。更新代码时保留已有的 `backend/codeagent.db` 和 `data_dir` 下的节点、账号、工作区数据；发布 ZIP 不包含或覆盖数据库文件。当前按单机运行，多台服务器各自的 SQLite 文件不会共享资源。

## 3. 一次启动前后端

使用普通 `codeagent` 用户执行，把示例 IP 换成服务器实际 IP：

```bash
bash start.sh --host 10.10.10.23 --port 8800 --concurrency 4
```

也可以不用脚本：

```bash
cd backend
python3 -u run.py --host 10.10.10.23 --port 8800 --concurrency 4
```

`--host` 是本机监听及节点注册地址，不能使用 `0.0.0.0`。启动脚本直接调用系统的 `python3`；如需指定 Python 的安装位置，可在上面的命令中将 `python3` 换成绝对路径。

## 4. 打开页面

在自己的浏览器访问：

```text
http://10.10.10.23:8800/
```

确保浏览器所在机器能访问服务器的 8800 端口。

- 页面地址示例：`http://10.10.10.23:8800/#/workspaces`。
- 浏览器接口地址：`/api/nodes`、`/api/sessions` 等，由同一 FastAPI 进程处理。
- 原有 `/nodes`、`/sessions` 等 API 仍可直接调用；`/docs` 仍是接口文档。
- **dist 不用执行任何启动命令，也不要双击其中的 index.html 使用。** 后端启动后，会自动提供它的页面和静态资源。

如果首页返回 404，检查 `frontend/dist/index.html` 是否存在且目录结构正确；自定义位置可修改 `config/settings.py` 的 `frontend_dir`。如果页面能打开但提示连接失败，检查数据库和后端日志。配置了 API Key 时，需在页面“连接设置”输入同一个 Key。

需要常驻运行时，可修改并安装包内的 `cloud-codeagent.service.example`。Nginx 是可选组件，直接通过 FastAPI 访问不需要它。

## 5. 查看日志与认证异常

从本版开始，使用 `start.sh` 或 `python3 run.py` 启动时，日志同时输出到终端和 `backend/logs/codeagent.log`。文件达到 5 MiB 自动轮转，保留 3 个历史文件；目录在首次启动时自动创建。`config/settings.py` 的 `log_dir` 可直接修改日志位置。

日志在导入第三方依赖和读取配置前初始化，缺少 Python 包、启动参数错误、配置校验失败会写入具体原因和退出码；Python 异常带完整堆栈。初始化阶段固定写入 `backend/logs/codeagent.log`，配置读取成功后使用 `log_dir`。端口绑定失败、数据库异常和接口处理异常也会记录原始错误。启动时会显示 Python 路径、监听地址、端口和并发数。

```bash
cd /home/codeagent/cloud-codeagent
tail -n 200 -f backend/logs/codeagent.log
```

如果是此前没有文件日志的版本，只能在启动终端查看；通过 systemd 启动的服务可使用 `journalctl -u cloud-codeagent -n 200 -f` 查看。

如果只有启停信息，先捕获启动命令的完整终端输出。将下面的 IP、端口和并发数换成实际使用的值；这条命令也能捕获写入应用日志之前发生的 shell/Python 错误：

```bash
cd /home/codeagent/cloud-codeagent
set -o pipefail
bash start.sh --host 10.10.10.23 --port 8800 --concurrency 4 2>&1 | tee -a startup-console.log
printf '启动命令退出码: %s\n' "${PIPESTATUS[0]}"
```

收到 Uvicorn 处理的停止信号时，会先记录 `收到退出信号 signal=SIGINT` 或 `signal=SIGTERM` 等信息，再关闭服务。信号记录说明停止方式，不能确定是谁发送的；强制杀死进程（SIGKILL）无法由应用自身记录。旧日志中没有记录的错误或信号无法事后还原，需要重现问题。

账号认证显示“异常”时，更新本版并重启，在页面点击“重新登录”，然后查看同一账号 ID 对应的日志。会记录登录开始/成功、认证状态查询失败、CLI 退出码、超时前的输出及经过脱敏的错误输出；授权链接和常见 token、密码字段会被隐藏，服务监听地址会正常显示。

日志中的 `无法启动本地命令` 通常需要检查 `codeagent` 是否安装、可执行文件路径及目录权限；`operation=auth status` 可定位认证状态查询失败，结合退出码和输出继续检查。页面的“异常”状态本身不能确定具体原因。

更新代码时保留已有的数据库及账号目录。历史失败如果没有留下日志，需要重新触发一次认证才能记录。

## 后续切回 GaussDB（可选）

GaussDB 连接配置仍保留在 `backend/config/settings.py`。网络恢复后，如需切回，在 `Settings` 类中修改：

```python
database_url: Optional[SecretStr] = None
db_auto_create: bool = False
```

首次使用目标 GaussDB 时执行 `backend/schema.sql` 创建表，随后重启服务。SQLite 数据不会自动迁移到 GaussDB；多节点部署需要共用同一个 GaussDB。
