# ZIP 发布包部署说明

这个包已经包含构建好的前端，直接使用系统 Python 启动。服务器不需要安装 Node.js、npm，不使用虚拟环境，也不需要外置环境变量或 .env 文件。

当前默认连接 **MySQL 8.0**：`10.90.113.224:3306/codeagent`。首次启动自动创建业务表，多个节点共用这一数据库。

如果当前 MySQL 已由旧版创建过 `t_ca_workspace.workspace_path` 列，请先停止所有使用这个库的节点，在部署此版后、启动服务前执行一次：

```bash
docker exec -it mysql mysql -u root -p codeagent
```

进入 MySQL 后执行 `ALTER TABLE t_ca_workspace DROP COLUMN workspace_path;`，再执行 `exit`。这只删除不再使用的列，保留工作区、账号和会话记录；`create_all()` 不会修改已有表结构。全新数据库无需执行此步骤。

## 包内目录

```text
cloud-codeagent/
├── backend/            # FastAPI 后端、config/settings.py、requirements.txt、schema.sql
├── frontend/dist/     # 已构建的 HTML、JS、CSS
├── wheels/            # Ubuntu 20.04 x86_64 / Python 3.8 离线依赖包
├── start.sh           # Ubuntu 启动脚本
├── DEPLOY.md          # 本说明
└── cloud-codeagent.service.example
```

请保持 `backend` 与 `frontend` 的相对位置。程序会根据自身代码位置寻找 dist，不依赖启动时的工作目录。

## 1. 解压与安装 Python 依赖

服务器需要 Python **3.8**、CodeAgent CLI，并能够连接 `10.90.113.224:3306` 的 MySQL。

```bash
unzip cloud-codeagent-release.zip
cd cloud-codeagent
python3 --version
python3 -m pip install --user --no-index --find-links=wheels -r backend/requirements.txt
```

代码和依赖按 Ubuntu 20.04 x86_64 / Python 3.8 适配。安装依赖和启动服务使用同一个系统 Python，依赖版本以包内 `backend/requirements.txt` 为准。ZIP 含离线 Python wheels，不含 Python 解释器、CodeAgent CLI 或运行数据。

## 2. 应用配置与数据库初始化

应用配置统一写在 `backend/config/settings.py`。MySQL 地址、库名及账密已写入该文件；修改后重启服务生效，程序不会读取 `.env` 或 `CA_*` 环境变量。

- `database_url=None` 时使用配置中的 MySQL 地址、端口、库名和账密。
- `db_auto_create=True`：首次启动自动建表，后续启动沿用已有数据。

- `data_dir` 默认为运行用户的主目录；使用 `codeagent` 用户时通常为 `/home/codeagent`。
- `codeagent_command` 默认为 `["codeagent"]`，使用已安装的 CLI；也可直接在配置文件中填写可执行文件的绝对路径。

服务运行用户需对日志目录有写入权限。更新代码时保留 MySQL 数据卷以及各节点 `data_dir` 下的账号和工作区数据。所有节点使用同一个 MySQL 库，并用各自可互访的地址启动。

## 3. 一次启动前后端

使用普通 `codeagent` 用户执行，把示例 IP 换成服务器实际 IP：

```bash
bash start.sh --host 10.10.10.23 --port 8800 --concurrency 4
```

也可以不用脚本：

```bash
cd backend
python3 -u run.py --host 10.10.10.23 --port 8800 --concurrency 4
```

`--host` 是本机监听及节点注册地址，不能使用 `0.0.0.0`。启动脚本直接调用系统的 `python3`；如需指定 Python 的安装位置，可在上面的命令中将 `python3` 换成绝对路径。

## 4. 打开页面

在自己的浏览器访问：

```text
http://10.10.10.23:8800/
```

确保浏览器所在机器能访问服务器的 8800 端口。

创建工作区只需填写名称，所属节点可选，不需要选择或传入 CodeAgent 账号。接口最简请求是 `POST /api/workspaces`，请求体 `{"name":"my-project"}`；`node_id` 不传时使用当前接入节点。管理员在“账号管理”中维护节点的登录状态，后端自动选择该节点已登录且未过期的账号，多账号时优先使用关联工作区较少的账号。节点无可用认证时返回 503，需管理员完成节点登录后重试。

工作区是本地目录，创建时仅初始化根目录和 `.cac` 项目配置。文件页面默认打开根目录，可新建目录、上传任意文件或文件夹、下载、编辑 UTF-8 文本，也可以通过会话让 CodeAgent 创建文件。更新程序后已有数据库和工作区文件继续沿用，无需移动原来的文件。

更新后工作区创建接口不再接收 `account_id`，已有调用方应移除此字段；账号绑定仍保存在后端，已有工作区和会话无需迁移。工作区与会话响应不再返回内部账号 ID。

- 页面地址示例：`http://10.10.10.23:8800/#/workspaces`。
- 浏览器接口地址：`/api/nodes`、`/api/sessions` 等，由同一 FastAPI 进程处理。
- 原有 `/nodes`、`/sessions` 等 API 仍可直接调用；`/docs` 仍是接口文档。
- **dist 不用执行任何启动命令，也不要双击其中的 index.html 使用。** 后端启动后，会自动提供它的页面和静态资源。

如果首页返回 404，检查 `frontend/dist/index.html` 是否存在且目录结构正确；自定义位置可修改 `config/settings.py` 的 `frontend_dir`。如果页面能打开但提示连接失败，检查数据库和后端日志。

需要常驻运行时，可修改并安装包内的 `cloud-codeagent.service.example`。Nginx 是可选组件，直接通过 FastAPI 访问不需要它。

## 5. 查看日志与认证异常

从本版开始，使用 `start.sh` 或 `python3 run.py` 启动时，日志同时输出到终端和 `backend/logs/codeagent.log`。文件达到 5 MiB 自动轮转，保留 3 个历史文件；目录在首次启动时自动创建。`config/settings.py` 的 `log_dir` 可直接修改日志位置。

日志在导入第三方依赖和读取配置前初始化，缺少 Python 包、启动参数错误、配置校验失败会写入具体原因和退出码；Python 异常带完整堆栈。初始化阶段固定写入 `backend/logs/codeagent.log`，配置读取成功后使用 `log_dir`。端口绑定失败、数据库异常和接口处理异常也会记录原始错误。启动时会显示 Python 路径、监听地址、端口和并发数。

```bash
cd /home/codeagent/cloud-codeagent
tail -n 200 -f backend/logs/codeagent.log
```

如果是此前没有文件日志的版本，只能在启动终端查看；通过 systemd 启动的服务可使用 `journalctl -u cloud-codeagent -n 200 -f` 查看。

如果只有启停信息，先捕获启动命令的完整终端输出。将下面的 IP、端口和并发数换成实际使用的值；这条命令也能捕获写入应用日志之前发生的 shell/Python 错误：

```bash
cd /home/codeagent/cloud-codeagent
set -o pipefail
bash start.sh --host 10.10.10.23 --port 8800 --concurrency 4 2>&1 | tee -a startup-console.log
printf '启动命令退出码: %s\n' "${PIPESTATUS[0]}"
```

收到 Uvicorn 处理的停止信号时，会先记录 `收到退出信号 signal=SIGINT` 或 `signal=SIGTERM` 等信息，再关闭服务。信号记录说明停止方式，不能确定是谁发送的；强制杀死进程（SIGKILL）无法由应用自身记录。旧日志中没有记录的错误或信号无法事后还原，需要重现问题。

账号认证显示“异常”时，更新本版并重启，在页面点击“重新登录”，然后查看同一账号 ID 对应的日志。会记录登录开始/成功、认证状态查询失败、CLI 退出码、超时前的输出及经过脱敏的错误输出；授权链接和常见 token、密码字段会被隐藏，服务监听地址会正常显示。

本版兼容 `auth status --json` 在尚未登录时返回退出码 1：只有返回有效认证状态 JSON、`loggedIn` 为布尔值 `false` 且无显式错误时，才按未登录处理，登录期间继续显示“等待登录”并保留登录进程。状态输出前如有 CLI 的版本更新提示，也会正常解析。其他非零退出码、无效 JSON 和显式错误仍会报错。登录和状态查询使用 CLI 支持的原生命令，不附加 `--skip-safe-check`；该参数只用于对话命令。此前已因这个问题变成“异常”的账号，更新并重启后点击“重新登录”获取新的授权链接。

日志中的 `无法启动本地命令` 通常需要检查 `codeagent` 是否安装、可执行文件路径及目录权限；`operation=auth status` 可定位认证状态查询失败，结合退出码和输出继续检查。页面的“异常”状态本身不能确定具体原因。

更新代码时保留已有的数据库及账号目录。历史失败如果没有留下日志，需要重新触发一次认证才能记录。

## MySQL 连接排查

在数据库服务器执行 `docker ps --filter name=mysql`、`docker logs mysql --tail 100` 和 `docker exec mysql mysqladmin ping -h 127.0.0.1 -u root -p`。在应用服务器执行 `nc -vz 10.90.113.224 3306`；端口通不代表 MySQL 握手和认证成功，还需检查容器日志和数据库用户的远程连接权限。启动失败的完整堆栈可在 `backend/logs/codeagent.log` 查看。
