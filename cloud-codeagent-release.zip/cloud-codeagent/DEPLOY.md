# ZIP 发布包部署说明

这个包已经包含构建好的前端，直接使用系统 Python 启动。服务器不需要安装 Node.js、npm，不使用虚拟环境，也不需要外置环境变量或 .env 文件。

## 包内目录

```text
cloud-codeagent/
├── backend/            # FastAPI 后端、config/settings.py、requirements.txt、schema.sql
├── frontend/dist/     # 已构建的 HTML、JS、CSS
├── start.sh           # Ubuntu 启动脚本
├── DEPLOY.md          # 本说明
└── cloud-codeagent.service.example
```

请保持 `backend` 与 `frontend` 的相对位置。程序会根据自身代码位置寻找 dist，不依赖启动时的工作目录。

## 1. 解压与安装 Python 依赖

服务器需要 Python **3.11 或更新版本**、Git、已安装的 CodeAgent CLI，以及可连接的 GaussDB。

```bash
unzip cloud-codeagent-release.zip
cd cloud-codeagent
python3 --version
python3 -m pip install -r backend/requirements.txt
```

确认 `python3` 的版本至少为 3.11，安装依赖和启动服务使用同一个系统 Python。ZIP 中不包含 Python 解释器、Python 离线安装包、CodeAgent CLI 或数据库；上述 pip 安装需要可用的软件源。

## 2. 应用配置与数据库初始化

数据库地址、库名、账号、密码和其他应用配置统一写在 `backend/config/settings.py`。修改这个文件后重启服务即可生效，程序不会读取 `.env` 或 `CA_*` 环境变量。

- `data_dir` 默认为运行用户的主目录；使用 `codeagent` 用户时通常为 `/home/codeagent`。
- `codeagent_command` 默认为 `["codeagent"]`，使用已安装的 CLI；也可直接在配置文件中填写可执行文件的绝对路径。
- `api_key` 默认为 `None`；如需要访问认证，在配置文件中设置，所有节点保持一致，进入页面后在“连接设置”填写同一个 Key。

首次部署时，在目标 GaussDB 执行 `backend/schema.sql` 创建表。多个节点共用同一数据库，不要在每个节点重复初始化索引。

## 3. 一次启动前后端

使用普通 `codeagent` 用户执行，把示例 IP 换成服务器实际 IP：

```bash
bash start.sh --host 10.10.10.23 --port 8800 --concurrency 4
```

也可以不用脚本：

```bash
cd backend
python3 -u run.py --host 10.10.10.23 --port 8800 --concurrency 4
```

`--host` 是本机监听及节点注册地址，不能使用 `0.0.0.0`。启动脚本直接调用系统的 `python3`；如需指定 Python 的安装位置，可在上面的命令中将 `python3` 换成绝对路径。

## 4. 打开页面

在自己的浏览器访问：

```text
http://10.10.10.23:8800/
```

确保浏览器所在机器能访问服务器的 8800 端口。

- 页面地址示例：`http://10.10.10.23:8800/#/workspaces`。
- 浏览器接口地址：`/api/nodes`、`/api/sessions` 等，由同一 FastAPI 进程处理。
- 原有 `/nodes`、`/sessions` 等 API 仍可直接调用；`/docs` 仍是接口文档。
- **dist 不用执行任何启动命令，也不要双击其中的 index.html 使用。** 后端启动后，会自动提供它的页面和静态资源。

如果首页返回 404，检查 `frontend/dist/index.html` 是否存在且目录结构正确；自定义位置可修改 `config/settings.py` 的 `frontend_dir`。如果页面能打开但提示连接失败，检查数据库和后端日志。配置了 API Key 时，需在页面“连接设置”输入同一个 Key。

需要常驻运行时，可修改并安装包内的 `cloud-codeagent.service.example`。Nginx 是可选组件，直接通过 FastAPI 访问不需要它。

## 仅在本机验证页面（可选）

没有 GaussDB 时，在 `backend/config/settings.py` 的 `Settings` 类中将以下字段改为：

```python
database_url: SecretStr | None = SecretStr("sqlite:///./codeagent.db")
db_auto_create: bool = True
data_dir: Path = Path("./.data")
```

然后执行 `bash start.sh --host 127.0.0.1 --port 8800 --concurrency 4`。
这只用于单机开发验证；账号登录与对话仍需真实 CodeAgent CLI，正式集群应使用 GaussDB。
