# 部署说明

发布包包含 FastAPI 后端、已构建的前端和 Ubuntu 20.04 x86_64 / Python 3.10 的离线依赖包。服务器无需安装 Node.js 或 npm，也无需创建 venv。Python 解释器、CodeAgent CLI 和数据库不包含在发布包中。

## 安装并启动

用实际运行服务的 Linux 用户登录，确认当前 shell 的 `PATH` 已包含你在 `.bashrc` 中配置的 Python 3.10：

```bash
command -v python3
python3 --version
```

版本应为 3.10。随后解压发布包，离线安装后端依赖并启动：

```bash
unzip cloud-codeagent-release.zip
cd cloud-codeagent
python3 -m pip install --user --no-index --find-links=wheels -r backend/requirements.txt
bash start.sh --host 10.10.10.23 --port 8800
```

把示例 IP 换成该节点可供其他节点访问的实际地址。`start.sh` 调用 `python3`，使用启动它的 shell 传入的 `PATH`；从交互式终端运行时会继承 `.bashrc` 配好的路径。若以后改用 systemd 等服务管理器，需给服务进程配置相同的 `PATH`，因为它不会自动读取 `.bashrc`。

默认不限制本节点的对话及执行命令并发。如果需要限制，启动时增加 `--concurrency 4` 等正整数参数。节点接口中的 `max_concurrency=0` 表示未限制。
节点启动后也可以在“节点管理 → 查看详情”中修改最大并发数，留空表示不限制；修改立即生效并保存在数据库，重启后继续使用。若重启时显式传入 `--concurrency`，该参数会覆盖保存的设置。

浏览器打开 `http://10.10.10.23:8800/`。前端由后端直接提供，无需单独启动 `frontend/dist`。接口文档在 `/docs`，服务日志在 `backend/logs/codeagent.log`。

## 目录与配置

```text
cloud-codeagent/
├── backend/         # FastAPI 后端、配置及 requirements.txt
├── frontend/dist/   # 已构建的前端静态文件
├── wheels/          # Python 3.10 离线依赖
├── start.sh         # 启动脚本
├── API.md           # 管理接口文档
├── USER_API.md      # 用户接口文档
└── DEPLOY.md        # 本说明
```

应用配置在 `backend/config/settings.py`，其中包含数据库连接、运行数据目录和工作区使用的 Python 解释器设置。后端启动会自动创建缺失的业务表，但不会修改已有表结构。多节点须连接同一个 MySQL 数据库，各节点分别保留自己的账号配置和工作区文件。

工作区默认使用 Python 3.10，也可在创建时或工作区详情页选择 Python 3.12。服务器需要在工作区所属节点安装相应解释器：默认配置分别为 `/home/codeagent/python310/bin/python3` 和 `/home/codeagent/python312/bin/python3.12`。后端本身仍由启动脚本调用当前 `PATH` 中的 `python3`。工作区的命令与 CodeAgent 子进程每次启动时根据工作区版本设置 `PYTHON` 与 `PATH`；切换版本不影响已运行的进程，也不创建 venv。Python 3.12 所需第三方包请用 3.12 的 `pip` 单独安装。

此版本新增工作区与账号关联表。部署到已有数据库时，启动会创建该表，并把每个已有工作区原来的账号关联补入；原有会话仍使用其已记录的账号。一个工作区之后可关联同节点的更多账号，并为每个账号设置该工作区的默认模型。账号本身不保存模型设置。
如果旧版本曾设置账号级默认模型，升级后请到工作区中为对应账号重新选择；旧账号级设置不会继续影响对话执行。

更新部署包时保留数据库和各节点的数据目录。若服务启动失败，查看终端的完整报错或 `backend/logs/codeagent.log`；若 `python3 --version` 仍显示 3.8，先检查当前登录用户的 `.bashrc` 与 `PATH`。
