from sqlalchemy import select

from dao.base_dao import BaseDao
from entity.models import CommandTask
from utils.errors import AppError


class CommandTaskDao(BaseDao):
    def __init__(self):
        super().__init__(CommandTask)

    def get_for_workspace(self, db, workspace_id, task_id, lock=False):
        statement = select(CommandTask).where(
            CommandTask.id == task_id, CommandTask.workspace_id == workspace_id
        )
        if lock:
            statement = statement.with_for_update()
        item = db.scalar(statement)
        if item is None:
            raise AppError(404, "命令任务不存在")
        return item
