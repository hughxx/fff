from sqlalchemy import func, select

from utils.errors import AppError


class BaseDao:
    def __init__(self, model):
        self.model = model

    def get(self, db, resource_id, *, lock=False):
        statement = select(self.model).where(self.model.id == resource_id)
        if lock:
            statement = statement.with_for_update()
        resource = db.scalar(statement)
        if resource is None:
            raise AppError(404, "资源不存在")
        return resource

    def page(self, db, *, filters=(), page=1, page_size=20):
        statement = select(self.model).where(*filters)
        total = db.scalar(select(func.count()).select_from(statement.subquery()))
        items = db.scalars(
            statement.order_by(self.model.create_time.desc(), self.model.id)
            .offset((page - 1) * page_size)
            .limit(page_size)
        ).all()
        return items, total

    def add(self, db, **values):
        resource = self.model(**values)
        db.add(resource)
        db.flush()
        return resource

    def delete(self, db, resource):
        db.delete(resource)
        db.flush()
