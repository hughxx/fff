from sqlalchemy import select

from dao.base_dao import BaseDao
from entity.models import Account, Workspace


class AccountDao(BaseDao):
    def __init__(self):
        super().__init__(Account)

    def has_workspaces(self, db, account_id):
        return (
            db.scalar(select(Workspace.id).where(Workspace.account_id == account_id).limit(1))
            is not None
        )
