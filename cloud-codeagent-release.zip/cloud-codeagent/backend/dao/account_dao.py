from sqlalchemy import func, or_, select

from dao.base_dao import BaseDao
from entity.models import Account, Workspace


class AccountDao(BaseDao):
    def __init__(self):
        super().__init__(Account)

    def has_workspaces(self, db, account_id):
        return (
            db.scalar(select(Workspace.id).where(Workspace.account_id == account_id).limit(1))
            is not None
        )

    def available_for_workspace(self, db, node_id, now_ms):
        workspace_count = (
            select(func.count(Workspace.id))
            .where(Workspace.account_id == Account.id)
            .correlate(Account)
            .scalar_subquery()
        )
        return db.scalar(
            select(Account)
            .where(
                Account.node_id == node_id,
                Account.auth_status == "logged_in",
                or_(Account.expires_at.is_(None), Account.expires_at > now_ms),
            )
            .order_by(workspace_count, Account.create_time, Account.id)
            .limit(1)
            .with_for_update()
        )
