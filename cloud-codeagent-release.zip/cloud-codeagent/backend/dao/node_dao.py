from sqlalchemy import func, select, update

from dao.base_dao import BaseDao
from entity.models import Account, Node, Workspace


class NodeDao(BaseDao):
    def __init__(self):
        super().__init__(Node)

    def counts(self, db, node_id):
        return {
            "accounts_count": db.scalar(
                select(func.count()).select_from(Account).where(Account.node_id == node_id)
            ),
            "workspaces_count": db.scalar(
                select(func.count()).select_from(Workspace).where(Workspace.node_id == node_id)
            ),
        }

    def recover_resources(self, db, node_id):
        db.execute(
            update(Account)
            .where(Account.node_id == node_id, Account.auth_status == "waiting_login")
            .values(auth_status="error")
        )
        db.execute(
            update(Workspace)
            .where(Workspace.node_id == node_id, Workspace.status.in_(["creating", "deleting"]))
            .values(status="error")
        )
