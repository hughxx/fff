from sqlalchemy import select

from dao.base_dao import BaseDao
from entity.models import AgentSession, Workspace


class WorkspaceDao(BaseDao):
    def __init__(self):
        super().__init__(Workspace)

    def has_sessions(self, db, workspace_id):
        return (
            db.scalar(
                select(AgentSession.id).where(AgentSession.workspace_id == workspace_id).limit(1)
            )
            is not None
        )
