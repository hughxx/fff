from sqlalchemy import delete, select, update

from dao.base_dao import BaseDao
from entity.models import AgentSession, SessionMessage, utcnow
from utils.errors import AppError


class SessionDao(BaseDao):
    def __init__(self):
        super().__init__(AgentSession)

    def claim(self, db, session_id, status):
        count = db.execute(
            update(AgentSession)
            .where(
                AgentSession.id == session_id,
                AgentSession.status.not_in(["running", "deleting"]),
            )
            .values(status=status, update_time=utcnow())
        ).rowcount
        if count != 1:
            self.get(db, session_id)
            raise AppError(409, "会话已有请求正在执行")
        return self.get(db, session_id)

    def recover(self, db, node_id):
        db.execute(
            update(AgentSession)
            .where(
                AgentSession.node_id == node_id,
                AgentSession.status.in_(["running", "deleting"]),
            )
            .values(status="error", current_pid=None, update_time=utcnow())
        )

    def messages(self, db, session_id):
        return db.scalars(
            select(SessionMessage)
            .where(SessionMessage.session_id == session_id)
            .order_by(SessionMessage.create_time, SessionMessage.id)
        ).all()

    def delete_messages(self, db, session_id):
        db.execute(delete(SessionMessage).where(SessionMessage.session_id == session_id))
