import logging
from contextlib import asynccontextmanager
from types import SimpleNamespace
from typing import Optional

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from sqlalchemy.exc import IntegrityError, OperationalError

from config.database import Database
from config.settings import Settings
from router import (
    account_router,
    command_task_router,
    file_router,
    node_router,
    session_router,
    skill_router,
    workspace_router,
)
from service.account_service import AccountService
from service.command_service import CommandService
from service.file_service import FileService
from service.node_service import NodeService
from service.routing_service import RoutingService
from service.session_service import SessionService
from service.skill_service import SkillService
from service.workspace_service import WorkspaceService
from utils.codeagent import CodeAgentClient
from utils.errors import AppError
from utils.frontend import mount_frontend

logger = logging.getLogger(__name__)


def log_request_error(request, exc, status):
    logger.log(
        logging.ERROR if status >= 500 else logging.WARNING,
        "接口请求失败 method=%s path=%s status=%s error=%s",
        request.method,
        request.url.path,
        status,
        exc,
        exc_info=(type(exc), exc, exc.__traceback__),
    )


def create_app(settings: Optional[Settings] = None, *, http_transport=None) -> FastAPI:
    settings = settings or Settings()

    @asynccontextmanager
    async def lifespan(app):
        db = Database(settings)
        http = httpx.AsyncClient(
            transport=http_transport,
            follow_redirects=False,
            timeout=httpx.Timeout(settings.message_timeout + 30, connect=10),
        )
        cli = CodeAgentClient(settings)
        nodes = NodeService(db, settings)
        accounts = AccountService(db, settings, nodes, cli)
        workspaces = WorkspaceService(db, settings, nodes, accounts)
        commands = CommandService(db, settings, nodes, workspaces)
        files = FileService(settings, workspaces)
        sessions = SessionService(db, settings, nodes, accounts, workspaces, cli)
        nodes.running_count = lambda: sessions.running_count() + commands.running_count()
        app.state.services = SimpleNamespace(
            db=db,
            nodes=nodes,
            accounts=accounts,
            workspaces=workspaces,
            commands=commands,
            files=files,
            skills=SkillService(files),
            sessions=sessions,
            routing=RoutingService(db, nodes, http),
        )
        try:
            await db.initialize()
            await nodes.start()
            await commands.start()
            yield
        finally:
            await commands.close()
            await sessions.close()
            await accounts.close()
            await nodes.close()
            await http.aclose()
            await db.close()

    app = FastAPI(
        title="Cloud CodeAgent",
        version="1.0.0",
        lifespan=lifespan,
        description="同构节点 CodeAgent 平台；会话接口支持 JSON 和 NDJSON。",
    )
    app.state.settings = settings

    @app.exception_handler(AppError)
    async def app_error(request: Request, exc: AppError):
        log_request_error(request, exc, exc.status_code)
        return JSONResponse(
            {"detail": exc.detail},
            status_code=exc.status_code,
        )

    @app.exception_handler(IntegrityError)
    async def integrity_error(request: Request, exc: IntegrityError):
        log_request_error(request, exc, 409)
        return JSONResponse({"detail": "资源已存在或仍有关联资源"}, status_code=409)

    @app.exception_handler(OperationalError)
    async def database_error(request: Request, exc: OperationalError):
        log_request_error(request, exc, 503)
        return JSONResponse({"detail": "数据库暂时不可用"}, status_code=503)

    @app.exception_handler(OSError)
    async def file_error(request: Request, exc: OSError):
        if isinstance(exc, FileNotFoundError):
            status, detail = 404, "文件或父目录不存在"
        elif isinstance(exc, FileExistsError):
            status, detail = 409, "文件或目录已存在"
        elif isinstance(exc, PermissionError):
            status, detail = 403, "没有文件访问权限"
        else:
            status, detail = 400, "文件系统操作失败"
        log_request_error(request, exc, status)
        return JSONResponse({"detail": detail}, status_code=status)

    @app.get("/api/health", include_in_schema=False)
    @app.get("/health", tags=["Health"])
    async def health():
        return {"status": "ok", "node_id": app.state.services.nodes.node_id}

    for module in (
        node_router,
        account_router,
        command_task_router,
        workspace_router,
        file_router,
        skill_router,
        session_router,
    ):
        app.include_router(module.router)
        app.include_router(
            module.router,
            prefix="/api",
            include_in_schema=False,
        )
    mount_frontend(app, settings.frontend_dir)
    return app


app = create_app()
