import os
import sys
from pathlib import Path
from typing import Dict, List, Optional, Union

from pydantic import BaseModel, ConfigDict, Field, SecretStr, field_validator, model_validator
from sqlalchemy import URL


class Settings(BaseModel):
    """应用配置直接维护在这里；不读取 .env 或系统环境变量。"""

    model_config = ConfigDict(validate_default=True)

    host: str = "127.0.0.1"
    port: int = Field(default=8800, ge=1, le=65535)
    concurrency: int = Field(default=4, ge=1, le=128)
    data_dir: Path = Path.home()
    log_dir: Path = Path(__file__).resolve().parents[1] / "logs"
    frontend_dir: Optional[Path] = Path(__file__).resolve().parents[2] / "frontend" / "dist"
    # 测试可覆盖为 SQLite URL；正常启动使用下方 MySQL 配置。
    database_url: Optional[SecretStr] = None
    db_host: str = "10.90.113.224"
    db_port: int = 3306
    db_name: str = "codeagent"
    db_user: str = "root"
    db_password: SecretStr = SecretStr("Root123!")
    db_auto_create: bool = True
    codeagent_command: List[str] = ["codeagent"]
    python_executables: Dict[str, str] = Field(
        default_factory=lambda: {
            "3.10": sys.executable if os.name == "nt" else "/home/codeagent/python310/bin/python3",
        }
    )
    command_timeout: float = Field(default=60, gt=0)
    message_timeout: float = Field(default=1800, gt=0)
    cancel_grace_seconds: float = Field(default=5, gt=0)
    heartbeat_seconds: float = Field(default=10, gt=0)
    node_stale_seconds: float = Field(default=40, gt=0)
    login_timeout: float = Field(default=300, gt=0)
    login_url_timeout: float = Field(default=15, gt=0)
    login_poll_seconds: float = Field(default=3, gt=0)
    max_file_bytes: int = Field(default=2 * 1024 * 1024, ge=1)
    max_upload_bytes: int = Field(default=512 * 1024 * 1024, ge=1)
    max_output_bytes: int = Field(default=16 * 1024 * 1024, ge=1024)
    stream_queue_size: int = Field(default=128, ge=1)

    @field_validator("host")
    @classmethod
    def validate_host(cls, value: str) -> str:
        if not value or any(c in value for c in "/\\@?# \t\n\r"):
            raise ValueError("host 必须是节点间可访问的 IP 或主机名")
        if value in {"0.0.0.0", "::"}:
            raise ValueError("host 是节点注册地址，不能使用通配监听地址")
        return value

    @field_validator("codeagent_command")
    @classmethod
    def validate_command(cls, value: List[str]) -> List[str]:
        if not value or not all(value):
            raise ValueError("codeagent_command 不得为空")
        return value

    @model_validator(mode="after")
    def check_heartbeat(self):
        if self.node_stale_seconds <= self.heartbeat_seconds:
            raise ValueError("node_stale_seconds 必须大于 heartbeat_seconds")
        return self

    @property
    def state_dir(self) -> Path:
        return self.data_dir.expanduser().resolve() / ".cloud-codeagent"

    @property
    def accounts_dir(self) -> Path:
        return self.data_dir.expanduser().resolve() / "accounts"

    @property
    def workspaces_dir(self) -> Path:
        return self.data_dir.expanduser().resolve() / "workspaces"

    def connection_url(self) -> Union[str, URL]:
        if self.database_url:
            return self.database_url.get_secret_value()
        if not self.db_password.get_secret_value():
            raise ValueError(
                "请在 config/settings.py 填写 MySQL db_password"
            )
        return URL.create(
            "mysql+pymysql",
            username=self.db_user,
            password=self.db_password.get_secret_value(),
            host=self.db_host,
            port=self.db_port,
            database=self.db_name,
            query={"charset": "utf8mb4", "connect_timeout": "10"},
        )
