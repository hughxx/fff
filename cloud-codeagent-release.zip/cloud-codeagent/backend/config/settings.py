from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field, SecretStr, field_validator, model_validator
from sqlalchemy import URL


class Settings(BaseModel):
    """应用配置直接维护在这里；不读取 .env 或系统环境变量。"""

    model_config = ConfigDict(validate_default=True)

    host: str = "127.0.0.1"
    port: int = Field(default=8800, ge=1, le=65535)
    concurrency: int = Field(default=4, ge=1, le=128)
    data_dir: Path = Path.home()
    frontend_dir: Path | None = Path(__file__).resolve().parents[2] / "frontend" / "dist"
    database_url: SecretStr | None = None
    db_host: str = "gauss.mlops-test.rnd.huawei.com"
    db_port: int = 8000
    db_name: str = "mlops"
    db_schema: str = "coreinsight"
    db_user: str = "coreinsight"
    db_password: SecretStr = SecretStr("dataengineer_group@2026")
    db_sslmode: str = "prefer"
    db_auto_create: bool = False
    api_key: SecretStr | None = None
    codeagent_command: list[str] = ["codeagent"]
    command_timeout: float = Field(default=60, gt=0)
    message_timeout: float = Field(default=1800, gt=0)
    cancel_grace_seconds: float = Field(default=5, gt=0)
    heartbeat_seconds: float = Field(default=10, gt=0)
    node_stale_seconds: float = Field(default=40, gt=0)
    login_timeout: float = Field(default=300, gt=0)
    login_url_timeout: float = Field(default=15, gt=0)
    login_poll_seconds: float = Field(default=3, gt=0)
    max_file_bytes: int = Field(default=2 * 1024 * 1024, ge=1)
    max_output_bytes: int = Field(default=16 * 1024 * 1024, ge=1024)
    stream_queue_size: int = Field(default=128, ge=1)

    @field_validator("host")
    @classmethod
    def validate_host(cls, value: str) -> str:
        if not value or any(c in value for c in "/\\@?# \t\n\r"):
            raise ValueError("host 必须是节点间可访问的 IP 或主机名")
        if value in {"0.0.0.0", "::"}:
            raise ValueError("host 是节点注册地址，不能使用通配监听地址")
        return value

    @field_validator("db_schema")
    @classmethod
    def validate_schema(cls, value: str) -> str:
        import re

        if not re.fullmatch(r"[a-zA-Z_][a-zA-Z0-9_]*", value):
            raise ValueError("无效的数据库 schema")
        return value

    @field_validator("codeagent_command")
    @classmethod
    def validate_command(cls, value: list[str]) -> list[str]:
        if not value or not all(value):
            raise ValueError("codeagent_command 不得为空")
        return value

    @model_validator(mode="after")
    def check_heartbeat(self):
        if self.node_stale_seconds <= self.heartbeat_seconds:
            raise ValueError("node_stale_seconds 必须大于 heartbeat_seconds")
        return self

    @property
    def state_dir(self) -> Path:
        return self.data_dir.expanduser().resolve() / ".cloud-codeagent"

    @property
    def accounts_dir(self) -> Path:
        return self.data_dir.expanduser().resolve() / "accounts"

    @property
    def workspaces_dir(self) -> Path:
        return self.data_dir.expanduser().resolve() / "workspaces"

    def connection_url(self) -> str | URL:
        if self.database_url:
            return self.database_url.get_secret_value()
        if not self.db_password.get_secret_value():
            raise ValueError(
                "请在 config/settings.py 填写 db_password；本地开发可将 database_url 设为 SQLite URL"
            )
        return URL.create(
            "postgresql+psycopg2",
            username=self.db_user,
            password=self.db_password.get_secret_value(),
            host=self.db_host,
            port=self.db_port,
            database=self.db_name,
            query={"sslmode": self.db_sslmode, "connect_timeout": "10"},
        )
