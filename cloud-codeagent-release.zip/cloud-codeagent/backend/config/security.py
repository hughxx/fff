import secrets
from typing import Optional

from fastapi import Depends, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from utils.errors import AppError

bearer = HTTPBearer(auto_error=False)


async def require_api_key(
    request: Request, credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer)
):
    configured = request.app.state.settings.api_key
    if configured and configured.get_secret_value():
        if credentials is None or not secrets.compare_digest(
            credentials.credentials, configured.get_secret_value()
        ):
            raise AppError(401, "缺少或无效的 Bearer API Key")
