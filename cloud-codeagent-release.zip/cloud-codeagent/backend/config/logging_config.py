import logging
from logging.handlers import RotatingFileHandler

from utils.logging_utils import RedactingFormatter


def configure_logging(settings):
    directory = settings.log_dir.expanduser().resolve()
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / "codeagent.log"
    secrets = [settings.db_password.get_secret_value()]
    if settings.api_key:
        secrets.append(settings.api_key.get_secret_value())
    formatter = RedactingFormatter(secrets)
    handlers = [
        logging.StreamHandler(),
        RotatingFileHandler(path, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"),
    ]
    for handler in handlers:
        handler.setFormatter(formatter)
    logging.basicConfig(level=logging.INFO, handlers=handlers, force=True)
    for name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
        logger = logging.getLogger(name)
        logger.handlers.clear()
        logger.propagate = True
        logger.setLevel(logging.INFO)
    return path
