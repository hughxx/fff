import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

from utils.logging_utils import RedactingFormatter


def configure_logging(settings=None):
    # 启动入口在导入第三方依赖、读取配置之前也能写日志。
    directory = (
        (settings.log_dir if settings else Path(__file__).resolve().parents[1] / "logs")
        .expanduser()
        .resolve()
    )
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / "codeagent.log"
    secrets = [settings.db_password.get_secret_value()] if settings else []
    formatter = RedactingFormatter(secrets)
    handlers = [
        logging.StreamHandler(),
        RotatingFileHandler(path, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"),
    ]
    for handler in handlers:
        handler.setFormatter(formatter)
    logging.basicConfig(level=logging.INFO, handlers=handlers, force=True)
    for name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
        logger = logging.getLogger(name)
        logger.handlers.clear()
        logger.propagate = True
        logger.setLevel(logging.INFO)
    return path
