import asyncio
from typing import Callable, TypeVar

from sqlalchemy import create_engine, event
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool
from sqlalchemy.schema import CreateSchema

from config.settings import Settings
from entity.models import Base
from utils.async_tools import to_thread

T = TypeVar("T")


class Database:
    def __init__(self, settings: Settings):
        url = settings.connection_url()
        sqlite = str(url).startswith("sqlite")
        kwargs = {"connect_args": {"check_same_thread": False, "timeout": 30}} if sqlite else {}
        if sqlite and ":memory:" in str(url):
            kwargs["poolclass"] = StaticPool
        self.engine = create_engine(url, pool_pre_ping=True, **kwargs).execution_options(
            schema_translate_map={"coreinsight": None if sqlite else settings.db_schema}
        )
        self.sessions = sessionmaker(self.engine, expire_on_commit=False)
        self.settings = settings
        self.sqlite = sqlite
        if sqlite:

            @event.listens_for(self.engine, "connect")
            def set_pragmas(connection, _):
                connection.execute("PRAGMA foreign_keys=ON")

    async def initialize(self):
        if self.settings.db_auto_create:

            def create():
                with self.engine.begin() as connection:
                    if not self.sqlite:
                        connection.execute(
                            CreateSchema(self.settings.db_schema, if_not_exists=True)
                        )
                    Base.metadata.create_all(connection)

            await to_thread(create)

    async def run(self, operation: Callable[[Session], T]) -> T:
        # 每次业务事务独占 Session，数据库 I/O 不阻塞 ASGI 事件循环。
        def execute():
            with self.sessions.begin() as session:
                return operation(session)

        operation_task = asyncio.create_task(to_thread(execute))
        try:
            return await asyncio.shield(operation_task)
        except asyncio.CancelledError:
            # 线程中的事务不能被取消，必须等其提交/回滚后再清理资源。
            await operation_task
            raise

    async def close(self):
        await to_thread(self.engine.dispose)
