import asyncio
from typing import Callable, TypeVar

from sqlalchemy import create_engine, event, insert, select
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

from config.settings import Settings
from entity.models import Base, Workspace, WorkspaceAccount
from utils.async_tools import to_thread

T = TypeVar("T")


class Database:
    def __init__(self, settings: Settings):
        url = settings.connection_url()
        sqlite = str(url).startswith("sqlite")
        kwargs = {"connect_args": {"check_same_thread": False, "timeout": 30}} if sqlite else {}
        if sqlite and ":memory:" in str(url):
            kwargs["poolclass"] = StaticPool
        self.engine = create_engine(url, pool_pre_ping=True, **kwargs)
        self.sessions = sessionmaker(self.engine, expire_on_commit=False)
        self.settings = settings
        self.sqlite = sqlite
        if sqlite:

            @event.listens_for(self.engine, "connect")
            def set_pragmas(connection, _):
                connection.execute("PRAGMA foreign_keys=ON")

    async def initialize(self):
        if self.settings.db_auto_create:

            def create():
                with self.engine.begin() as connection:
                    Base.metadata.create_all(connection)
                    missing = (
                        select(Workspace.id, Workspace.account_id)
                        .outerjoin(
                            WorkspaceAccount,
                            (WorkspaceAccount.workspace_id == Workspace.id)
                            & (WorkspaceAccount.account_id == Workspace.account_id),
                        )
                        .where(WorkspaceAccount.workspace_id.is_(None))
                    )
                    backfill = insert(WorkspaceAccount).from_select(
                        ["workspace_id", "account_id"], missing
                    )
                    backfill = backfill.prefix_with("OR IGNORE" if self.sqlite else "IGNORE")
                    connection.execute(backfill)

            await to_thread(create)

    async def run(self, operation: Callable[[Session], T]) -> T:
        # 每次业务事务独占 Session，数据库 I/O 不阻塞 ASGI 事件循环。
        def execute():
            with self.sessions.begin() as session:
                return operation(session)

        operation_task = asyncio.create_task(to_thread(execute))
        try:
            return await asyncio.shield(operation_task)
        except asyncio.CancelledError:
            # 线程中的事务不能被取消，必须等其提交/回滚后再清理资源。
            await operation_task
            raise

    async def close(self):
        await to_thread(self.engine.dispose)
