-- 首次部署在目标 GaussDB 执行；所有节点共享这些表。
-- 如需更换 schema，同时修改本脚本和 config/settings.py 中的 db_schema。
CREATE SCHEMA IF NOT EXISTS coreinsight;

CREATE TABLE IF NOT EXISTS coreinsight.t_ca_node (
    id varchar(64) PRIMARY KEY,
    node_name varchar(255) NOT NULL,
    node_host varchar(255) NOT NULL,
    node_port integer NOT NULL,
    status varchar(32) NOT NULL DEFAULT 'online',
    max_concurrency integer NOT NULL DEFAULT 4,
    running_count integer NOT NULL DEFAULT 0,
    cpu_usage numeric(8,2),
    memory_usage numeric(8,2),
    last_heartbeat timestamp without time zone,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    update_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS coreinsight.t_ca_account (
    id varchar(128) PRIMARY KEY,
    node_id varchar(64) NOT NULL REFERENCES coreinsight.t_ca_node(id),
    account_id varchar(128),
    account_name varchar(255),
    auth_provider varchar(64),
    auth_status varchar(32) NOT NULL DEFAULT 'not_login',
    expires_at bigint,
    config_dir varchar(1000) NOT NULL,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    update_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT uq_ca_account_identity UNIQUE (auth_provider, account_id)
);

CREATE TABLE IF NOT EXISTS coreinsight.t_ca_workspace (
    id varchar(128) PRIMARY KEY,
    name varchar(255) NOT NULL,
    node_id varchar(64) NOT NULL REFERENCES coreinsight.t_ca_node(id),
    account_id varchar(128) NOT NULL REFERENCES coreinsight.t_ca_account(id),
    workspace_path varchar(1000) NOT NULL,
    repo_path varchar(1000),
    repo_url varchar(2000),
    status varchar(32) NOT NULL DEFAULT 'ready',
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    update_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS coreinsight.t_ca_session (
    id varchar(64) PRIMARY KEY,
    workspace_id varchar(128) NOT NULL REFERENCES coreinsight.t_ca_workspace(id),
    node_id varchar(64) NOT NULL REFERENCES coreinsight.t_ca_node(id),
    account_id varchar(128) NOT NULL REFERENCES coreinsight.t_ca_account(id),
    codeagent_session_id varchar(64),
    title varchar(500),
    status varchar(32) NOT NULL DEFAULT 'ready',
    current_pid bigint,
    create_user varchar(128),
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    update_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS coreinsight.t_ca_session_message (
    id varchar(64) PRIMARY KEY,
    session_id varchar(64) NOT NULL REFERENCES coreinsight.t_ca_session(id),
    role varchar(32) NOT NULL,
    content text,
    raw_result text,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE INDEX idx_ca_node_status ON coreinsight.t_ca_node(status);
CREATE INDEX idx_ca_node_heartbeat ON coreinsight.t_ca_node(last_heartbeat);
CREATE INDEX idx_ca_account_node ON coreinsight.t_ca_account(node_id);
CREATE INDEX idx_ca_workspace_node ON coreinsight.t_ca_workspace(node_id);
CREATE INDEX idx_ca_workspace_account ON coreinsight.t_ca_workspace(account_id);
CREATE INDEX idx_ca_session_workspace ON coreinsight.t_ca_session(workspace_id);
CREATE INDEX idx_ca_session_node ON coreinsight.t_ca_session(node_id);
CREATE INDEX idx_ca_message_session_time ON coreinsight.t_ca_session_message(session_id, create_time);
