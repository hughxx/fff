-- MySQL 8.0 初始化脚本；db_auto_create=True 时可不手工执行。

CREATE DATABASE IF NOT EXISTS codeagent CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;

USE codeagent;

CREATE TABLE IF NOT EXISTS t_ca_node (
	id VARCHAR(64) NOT NULL, 
	node_name VARCHAR(255) NOT NULL, 
	node_host VARCHAR(255) NOT NULL, 
	node_port INTEGER NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	running_count INTEGER NOT NULL, 
	cpu_usage NUMERIC(8, 2), 
	memory_usage NUMERIC(8, 2), 
	last_heartbeat DATETIME, 
	create_time DATETIME NOT NULL, 
	update_time DATETIME NOT NULL, 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE IF NOT EXISTS t_ca_account (
	id VARCHAR(128) NOT NULL, 
	node_id VARCHAR(64) NOT NULL, 
	account_id VARCHAR(128), 
	account_name VARCHAR(255), 
	auth_provider VARCHAR(64), 
	auth_status VARCHAR(32) NOT NULL, 
	expires_at BIGINT, 
	config_dir VARCHAR(1000) NOT NULL, 
	create_time DATETIME NOT NULL, 
	update_time DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_ca_account_identity UNIQUE (node_id, auth_provider, account_id), 
	FOREIGN KEY(node_id) REFERENCES t_ca_node (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE IF NOT EXISTS t_ca_workspace (
	id VARCHAR(128) NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	node_id VARCHAR(64) NOT NULL, 
	account_id VARCHAR(128) NOT NULL, 
	python_version VARCHAR(8) NOT NULL DEFAULT '3.10', 
	status VARCHAR(32) NOT NULL, 
	create_time DATETIME NOT NULL, 
	update_time DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(node_id) REFERENCES t_ca_node (id), 
	FOREIGN KEY(account_id) REFERENCES t_ca_account (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE IF NOT EXISTS t_ca_workspace_account (
	workspace_id VARCHAR(128) NOT NULL,
	account_id VARCHAR(128) NOT NULL,
	default_model VARCHAR(128),
	PRIMARY KEY (workspace_id, account_id),
	FOREIGN KEY(workspace_id) REFERENCES t_ca_workspace (id),
	FOREIGN KEY(account_id) REFERENCES t_ca_account (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE IF NOT EXISTS t_ca_node_setting (
	node_id VARCHAR(64) NOT NULL,
	auth_refresh_seconds INTEGER NOT NULL,
	create_time DATETIME NOT NULL,
	update_time DATETIME NOT NULL,
	PRIMARY KEY (node_id),
	FOREIGN KEY(node_id) REFERENCES t_ca_node (id) ON DELETE CASCADE
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE IF NOT EXISTS t_ca_command_task (
	id VARCHAR(64) NOT NULL,
	workspace_id VARCHAR(128) NOT NULL,
	node_id VARCHAR(64) NOT NULL,
	command TEXT NOT NULL,
	timeout_seconds FLOAT NOT NULL,
	status VARCHAR(32) NOT NULL,
	exit_code INTEGER,
	stdout LONGTEXT NOT NULL,
	stderr LONGTEXT NOT NULL,
	timed_out BOOL NOT NULL,
	current_pid BIGINT,
	create_time DATETIME NOT NULL,
	update_time DATETIME NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY(workspace_id) REFERENCES t_ca_workspace (id) ON DELETE CASCADE,
	FOREIGN KEY(node_id) REFERENCES t_ca_node (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE IF NOT EXISTS t_ca_session (
	id VARCHAR(64) NOT NULL, 
	workspace_id VARCHAR(128) NOT NULL, 
	node_id VARCHAR(64) NOT NULL, 
	account_id VARCHAR(128) NOT NULL, 
	codeagent_session_id VARCHAR(64), 
	title VARCHAR(500), 
	status VARCHAR(32) NOT NULL, 
	current_pid BIGINT, 
	create_user VARCHAR(128), 
	create_time DATETIME NOT NULL, 
	update_time DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(workspace_id) REFERENCES t_ca_workspace (id), 
	FOREIGN KEY(node_id) REFERENCES t_ca_node (id), 
	FOREIGN KEY(account_id) REFERENCES t_ca_account (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE IF NOT EXISTS t_ca_session_message (
	id VARCHAR(64) NOT NULL, 
	session_id VARCHAR(64) NOT NULL, 
	`role` VARCHAR(32) NOT NULL, 
	content LONGTEXT, 
	raw_result LONGTEXT, 
	create_time DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES t_ca_session (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_t_ca_node_last_heartbeat ON t_ca_node (last_heartbeat);

CREATE INDEX ix_t_ca_node_status ON t_ca_node (status);

CREATE INDEX ix_t_ca_account_node_id ON t_ca_account (node_id);

CREATE INDEX ix_t_ca_workspace_account_id ON t_ca_workspace (account_id);

CREATE INDEX ix_t_ca_workspace_node_id ON t_ca_workspace (node_id);

CREATE INDEX ix_t_ca_session_node_id ON t_ca_session (node_id);

CREATE INDEX ix_t_ca_session_workspace_id ON t_ca_session (workspace_id);

CREATE INDEX ix_t_ca_command_task_workspace_id ON t_ca_command_task (workspace_id);

CREATE INDEX ix_t_ca_command_task_node_id ON t_ca_command_task (node_id);

CREATE INDEX ix_t_ca_command_task_status ON t_ca_command_task (status);

CREATE INDEX idx_ca_message_session_time ON t_ca_session_message (session_id, create_time);


CREATE TABLE t_ca_session_task (
	id VARCHAR(64) NOT NULL, 
	session_id VARCHAR(64) NOT NULL, 
	node_id VARCHAR(64) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	input LONGTEXT NOT NULL, 
	model VARCHAR(128), 
	result LONGTEXT, 
	error LONGTEXT, 
	create_time DATETIME NOT NULL, 
	update_time DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES t_ca_session (id) ON DELETE CASCADE, 
	FOREIGN KEY(node_id) REFERENCES t_ca_node (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin

;
CREATE INDEX ix_t_ca_session_task_status ON t_ca_session_task (status);
CREATE INDEX ix_t_ca_session_task_node_id ON t_ca_session_task (node_id);
CREATE INDEX ix_t_ca_session_task_session_id ON t_ca_session_task (session_id);


CREATE TABLE t_ca_session_task_event (
	task_id VARCHAR(64) NOT NULL, 
	sequence INTEGER NOT NULL, 
	payload LONGTEXT NOT NULL, 
	PRIMARY KEY (task_id, sequence), 
	FOREIGN KEY(task_id) REFERENCES t_ca_session_task (id) ON DELETE CASCADE
)CHARSET=utf8mb4 COLLATE utf8mb4_bin

;
