from fastapi import APIRouter, Query, Request

from entity.request import CommandTaskRequest

router = APIRouter(
    prefix="/workspaces/{workspace_id}/command-tasks", tags=["Command Task"]
)


async def local_services(workspace_id, request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    return services, response


@router.post("", status_code=202)
async def create_command_task(
    workspace_id: str, body: CommandTaskRequest, request: Request
):
    services, response = await local_services(workspace_id, request)
    if response is not None:
        return response
    return await services.commands.create_task(workspace_id, body)


@router.get("")
async def list_command_tasks(workspace_id: str, request: Request,
                             page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=200)):
    services, response = await local_services(workspace_id, request)
    if response is not None:
        return response
    return await services.commands.list_tasks(workspace_id, page, page_size)


@router.get("/{task_id}")
async def get_command_task(workspace_id: str, task_id: str, request: Request):
    services, response = await local_services(workspace_id, request)
    if response is not None:
        return response
    return await services.commands.get_task(workspace_id, task_id)


@router.post("/{task_id}/cancel")
async def cancel_command_task(workspace_id: str, task_id: str, request: Request):
    services, response = await local_services(workspace_id, request)
    if response is not None:
        return response
    return await services.commands.cancel_task(workspace_id, task_id)
