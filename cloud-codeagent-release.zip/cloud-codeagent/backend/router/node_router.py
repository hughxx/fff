from fastapi import APIRouter, Query, Request
from entity.request import NodeAuthRefreshRequest

router = APIRouter(prefix="/nodes", tags=["Node"])


@router.get("")
async def list_nodes(
    request: Request, page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=200)
):
    return await request.app.state.services.nodes.list(page, page_size)


@router.get("/{node_id}")
async def get_node(node_id: str, request: Request):
    return await request.app.state.services.nodes.get(node_id)


@router.get("/{node_id}/settings")
async def get_node_settings(node_id: str, request: Request):
    services = request.app.state.services
    response = await services.routing.node(request, node_id)
    if response is not None:
        return response
    return await services.nodes.get_settings(node_id)


@router.put("/{node_id}/settings/auth-refresh")
async def set_node_auth_refresh(
    node_id: str, body: NodeAuthRefreshRequest, request: Request
):
    services = request.app.state.services
    response = await services.routing.node(request, node_id)
    if response is not None:
        return response
    return await services.nodes.set_auth_refresh(node_id, body.auth_refresh_seconds)
