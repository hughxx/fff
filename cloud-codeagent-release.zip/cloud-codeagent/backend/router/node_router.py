from fastapi import APIRouter, Query, Request
from entity.request import NodeConcurrencyRequest

router = APIRouter(prefix="/nodes", tags=["Node"])


@router.get("")
async def list_nodes(
    request: Request, page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=200)
):
    return await request.app.state.services.nodes.list(page, page_size)


@router.get("/{node_id}")
async def get_node(node_id: str, request: Request):
    return await request.app.state.services.nodes.get(node_id)


@router.put("/{node_id}/concurrency")
async def set_node_concurrency(node_id: str, body: NodeConcurrencyRequest, request: Request):
    services = request.app.state.services
    response = await services.routing.node(request, node_id)
    if response is not None:
        return response
    return await services.nodes.set_concurrency(node_id, body.max_concurrency)
