from fastapi import APIRouter, Query, Request

router = APIRouter(prefix="/nodes", tags=["Node"])


@router.get("")
async def list_nodes(
    request: Request, page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=200)
):
    return await request.app.state.services.nodes.list(page, page_size)


@router.get("/{node_id}")
async def get_node(node_id: str, request: Request):
    return await request.app.state.services.nodes.get(node_id)
