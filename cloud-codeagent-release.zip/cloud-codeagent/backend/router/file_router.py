from fastapi import APIRouter, Query, Request

from entity.request import FileCreateRequest, FileWriteRequest

router = APIRouter(prefix="/workspaces/{workspace_id}/files", tags=["File"])


@router.get("")
async def list_files(workspace_id: str, request: Request, path: str = Query(".", max_length=1000)):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.files.list(workspace_id, path)


@router.get("/content")
async def read_file(
    workspace_id: str, request: Request, path: str = Query(..., min_length=1, max_length=1000)
):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.files.read(workspace_id, path)


@router.post("", status_code=201)
async def create_file(workspace_id: str, body: FileCreateRequest, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.files.create(workspace_id, body)


@router.put("")
async def write_file(workspace_id: str, body: FileWriteRequest, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.files.write(workspace_id, body)


@router.delete("")
async def delete_file(
    workspace_id: str, request: Request, path: str = Query(..., min_length=1, max_length=1000)
):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.files.delete(workspace_id, path)
