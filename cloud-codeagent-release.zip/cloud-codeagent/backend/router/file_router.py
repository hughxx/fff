from fastapi import APIRouter, Query, Request

from entity.request import DirectoryCreateRequest, FileWriteRequest

router = APIRouter(prefix="/workspaces/{workspace_id}/files", tags=["File"])


@router.get("")
async def list_files(workspace_id: str, request: Request, path: str = Query(".", max_length=1000)):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.files.list(workspace_id, path)


@router.get("/content")
async def read_file(
    workspace_id: str, request: Request, path: str = Query(..., min_length=1, max_length=1000)
):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.files.read(workspace_id, path)


@router.get("/download")
async def download_file(
    workspace_id: str, request: Request, path: str = Query(..., min_length=1, max_length=1000)
):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.files.download(workspace_id, path)


@router.post("/directories", status_code=201)
async def create_directory(workspace_id: str, body: DirectoryCreateRequest, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.files.create_directory(workspace_id, body.path)


@router.post("/upload", status_code=201)
async def upload_file(
    workspace_id: str, request: Request, path: str = Query(..., min_length=1, max_length=1000)
):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    if request.headers.get("content-type", "").split(";", 1)[0].lower() != "application/octet-stream":
        from utils.errors import AppError

        raise AppError(415, "上传文件需使用 application/octet-stream")
    return await services.files.upload(workspace_id, path, request.stream())


@router.post("/upload-zip", status_code=201)
async def upload_zip(
    workspace_id: str, request: Request, path: str = Query(..., min_length=1, max_length=1000)
):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    if request.headers.get("content-type", "").split(";", 1)[0].lower() != "application/zip":
        from utils.errors import AppError

        raise AppError(415, "ZIP 上传需使用 application/zip")
    return await services.files.upload_zip(workspace_id, path, request.stream())


@router.put("")
async def write_file(workspace_id: str, body: FileWriteRequest, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.files.write(workspace_id, body)


@router.delete("")
async def delete_file(
    workspace_id: str, request: Request, path: str = Query(..., min_length=1, max_length=1000)
):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.files.delete(workspace_id, path)
