from typing import Optional

from fastapi import APIRouter, Query, Request
from starlette.responses import StreamingResponse

from entity.request import MessageRequest, SessionRequest

router = APIRouter(prefix="/sessions", tags=["Session"])


@router.post("", status_code=201)
async def create_session(body: SessionRequest, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", body.workspace_id)
    if response is not None:
        return response
    return await services.sessions.create(body)


@router.get("")
async def list_sessions(
    request: Request,
    workspace_id: Optional[str] = None,
    keyword: Optional[str] = Query(None, max_length=500),
    created_by: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=200),
):
    return await request.app.state.services.sessions.list(
        page, page_size, workspace_id, keyword, created_by
    )


@router.get("/{session_id}")
async def get_session(session_id: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "session", session_id)
    if response is not None:
        return response
    return await services.sessions.get(session_id)


@router.post(
    "/{session_id}/messages",
    responses={
        200: {
            "content": {
                "application/json": {},
                "application/x-ndjson": {},
            }
        }
    },
)
async def send_message(
    session_id: str, body: MessageRequest, request: Request, stream: bool = False
):
    services = request.app.state.services
    response = await services.routing.resource(request, "session", session_id)
    if response is not None:
        return response
    entry = await services.sessions.start_message(session_id, body.input, stream, body.model)
    if stream:
        return StreamingResponse(
            services.sessions.events(entry),
            media_type="application/x-ndjson",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )
    return await services.sessions.result(entry)


@router.post("/{session_id}/cancel")
async def cancel_session(session_id: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "session", session_id)
    if response is not None:
        return response
    return await services.sessions.cancel(session_id)


@router.post("/{session_id}/tasks", status_code=202)
async def create_task(session_id: str, body: MessageRequest, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "session", session_id)
    if response is not None:
        return response
    return await services.sessions.create_task(session_id, body.input, body.model)


@router.get("/{session_id}/tasks/{task_id}")
async def get_task(session_id: str, task_id: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "session", session_id)
    if response is not None:
        return response
    return await services.sessions.get_task(session_id, task_id)


@router.post("/{session_id}/tasks/{task_id}/cancel")
async def cancel_task(session_id: str, task_id: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "session", session_id)
    if response is not None:
        return response
    return await services.sessions.cancel_task(session_id, task_id)


@router.get('/{session_id}/tasks/{task_id}/events')
async def task_events(session_id: str, task_id: str, request: Request, after: int = Query(0, ge=0)):
    services = request.app.state.services
    response = await services.routing.resource(request, 'session', session_id)
    if response is not None:
        return response
    await services.sessions.get_task(session_id, task_id)
    return StreamingResponse(services.sessions.task_events(session_id, task_id, after),
                             media_type='application/x-ndjson',
                             headers={'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no'})


@router.delete("/{session_id}")
async def delete_session(session_id: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "session", session_id)
    if response is not None:
        return response
    return await services.sessions.delete(session_id)
