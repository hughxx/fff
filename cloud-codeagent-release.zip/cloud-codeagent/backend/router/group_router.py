from fastapi import APIRouter, Request
from entity.request import GroupRequest

router = APIRouter(prefix='/account-groups', tags=['AccountGroup'])


@router.get('')
async def groups(request: Request):
    return await request.app.state.services.groups.list()


@router.post('', status_code=201)
async def create(body: GroupRequest, request: Request):
    s = request.app.state.services
    forwarded = await s.routing.node(request, body.node_id)
    if forwarded is not None:
        return forwarded
    return await s.groups.save(body)


@router.put('/{group_id}')
async def update(group_id: str, body: GroupRequest, request: Request):
    s = request.app.state.services
    group = await s.db.run(lambda db: s.groups.get_group(db, group_id))
    forwarded = await s.routing.node(request, group.node_id)
    if forwarded is not None:
        return forwarded
    return await s.groups.save(body, group_id)


@router.delete('/{group_id}')
async def remove(group_id: str, request: Request):
    s = request.app.state.services
    group = await s.db.run(lambda db: s.groups.get_group(db, group_id))
    forwarded = await s.routing.node(request, group.node_id)
    if forwarded is not None:
        return forwarded
    return await s.groups.remove(group_id)
