from typing import Optional

from fastapi import APIRouter, Query, Request

from entity.request import AccountDeleteRequest, LoginRequest

router = APIRouter(prefix="/accounts", tags=["Account"])


@router.get("")
async def list_accounts(
    request: Request,
    node_id: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=200),
):
    return await request.app.state.services.accounts.list(page, page_size, node_id)


@router.post("/login", status_code=202)
async def login(body: LoginRequest, request: Request):
    services = request.app.state.services
    response = (
        await services.routing.resource(request, "account", body.account_id)
        if body.account_id
        else await services.routing.node(request, body.node_id or services.nodes.node_id)
    )
    if response is not None:
        return response
    return await services.accounts.login(body)


@router.get("/{account_id}")
async def get_account(account_id: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "account", account_id)
    if response is not None:
        return response
    return await services.accounts.get(account_id)


@router.get("/{account_id}/models")
async def list_models(account_id: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "account", account_id)
    if response is not None:
        return response
    return await services.accounts.models(account_id)


@router.delete("/{account_id}")
async def delete_account(account_id: str, request: Request, body: Optional[AccountDeleteRequest] = None):
    services = request.app.state.services
    response = await services.routing.resource(request, "account", account_id)
    if response is not None:
        return response
    return await services.accounts.delete(account_id, body.replacements if body is not None else None)


@router.get('/{account_id}/replacement-options')
async def replacement_options(account_id: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, 'account', account_id)
    if response is not None:
        return response
    return await services.accounts.replacement_options(account_id)
