from typing import Optional

from fastapi import APIRouter, Query, Request

from entity.request import WorkspaceRequest

router = APIRouter(prefix="/workspaces", tags=["Workspace"])


@router.get("")
async def list_workspaces(
    request: Request,
    node_id: Optional[str] = None,
    account_id: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=200),
):
    return await request.app.state.services.workspaces.list(page, page_size, node_id, account_id)


@router.post("", status_code=201)
async def create_workspace(body: WorkspaceRequest, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "account", body.account_id)
    if response is not None:
        return response
    return await services.workspaces.create(body)


@router.get("/{workspace_id}")
async def get_workspace(workspace_id: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.workspaces.get(workspace_id)


@router.delete("/{workspace_id}")
async def delete_workspace(workspace_id: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.workspaces.delete(workspace_id)
