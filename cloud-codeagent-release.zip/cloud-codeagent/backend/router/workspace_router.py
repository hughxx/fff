from typing import Optional

from fastapi import APIRouter, Query, Request

from entity.request import CommandRequest, WorkspaceAccountRequest, WorkspaceModelRequest, WorkspacePythonRequest, WorkspaceRequest

router = APIRouter(prefix="/workspaces", tags=["Workspace"])


@router.get("")
async def list_workspaces(
    request: Request,
    node_id: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=200),
):
    return await request.app.state.services.workspaces.list(page, page_size, node_id)


@router.post("", status_code=201)
async def create_workspace(body: WorkspaceRequest, request: Request):
    services = request.app.state.services
    if body.account_id:
        account = await services.db.run(
            lambda db: services.accounts.dao.get(db, body.account_id)
        )
    else:
        account = await services.accounts.random_for_workspace()
        body = body.model_copy(update={"account_id": account.id})
    response = await services.routing.node(
        request, account.node_id, json_body=body.model_dump(exclude_none=True)
    )
    if response is not None:
        return response
    return await services.workspaces.create(body)


@router.get("/{workspace_id}")
async def get_workspace(workspace_id: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.workspaces.get(workspace_id)


@router.put("/{workspace_id}/python")
async def set_workspace_python(workspace_id: str, body: WorkspacePythonRequest, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.workspaces.set_python_version(workspace_id, body.python_version)


@router.post("/{workspace_id}/accounts", status_code=201)
async def add_workspace_account(workspace_id: str, body: WorkspaceAccountRequest, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.workspaces.add_account(workspace_id, body.account_id)


@router.delete("/{workspace_id}/accounts/{account_id}")
async def remove_workspace_account(workspace_id: str, account_id: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.workspaces.remove_account(workspace_id, account_id)


@router.put("/{workspace_id}/accounts/{account_id}/model")
async def set_workspace_model(workspace_id: str, account_id: str, body: WorkspaceModelRequest, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.workspaces.set_model(workspace_id, account_id, body.model)


@router.post("/{workspace_id}/commands")
async def execute_command(workspace_id: str, body: CommandRequest, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.commands.execute(workspace_id, body)


@router.delete("/{workspace_id}")
async def delete_workspace(workspace_id: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.workspaces.delete(workspace_id)
