from fastapi import APIRouter, Request

from service.skill_service import MAX_ARCHIVE_BYTES
from utils.errors import AppError

router = APIRouter(prefix="/workspaces/{workspace_id}/skills", tags=["Skill"])


@router.get("")
async def list_skills(workspace_id: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.skills.list(workspace_id)


@router.post("", status_code=201)
async def create_skill(workspace_id: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.skills.install(workspace_id, await read_zip(request))


async def read_zip(request: Request):
    if (
        request.headers.get("content-type", "").split(";", 1)[0].strip().lower()
        != "application/zip"
    ):
        raise AppError(415, "请上传 application/zip 格式的 Skill 包")
    data = bytearray()
    async for chunk in request.stream():
        data.extend(chunk)
        if len(data) > MAX_ARCHIVE_BYTES:
            raise AppError(413, "Skill ZIP 超过 16 MiB")
    return bytes(data)


@router.get("/{name}")
async def get_skill(workspace_id: str, name: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.skills.get(workspace_id, name)


@router.put("/{name}")
async def replace_skill(workspace_id: str, name: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.skills.install(workspace_id, await read_zip(request), expected_name=name)


@router.delete("/{name}")
async def delete_skill(workspace_id: str, name: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.skills.delete(workspace_id, name)
