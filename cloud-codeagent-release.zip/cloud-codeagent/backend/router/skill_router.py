from fastapi import APIRouter, Request

from entity.request import SkillRequest

router = APIRouter(prefix="/workspaces/{workspace_id}/skills", tags=["Skill"])


@router.get("")
async def list_skills(workspace_id: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.skills.list(workspace_id)


@router.post("", status_code=201)
async def create_skill(workspace_id: str, body: SkillRequest, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.skills.create(workspace_id, body)


@router.get("/{name}")
async def get_skill(workspace_id: str, name: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.skills.get(workspace_id, name)


@router.delete("/{name}")
async def delete_skill(workspace_id: str, name: str, request: Request):
    services = request.app.state.services
    response = await services.routing.resource(request, "workspace", workspace_id)
    if response is not None:
        return response
    return await services.skills.delete(workspace_id, name)
