from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


class RequestModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=False)


class LoginRequest(RequestModel):
    node_id: Optional[str] = Field(default=None, max_length=64)
    account_id: Optional[str] = Field(default=None, max_length=128)
    account_name: Optional[str] = Field(default=None, max_length=255)


class WorkspaceRequest(RequestModel):
    name: str = Field(min_length=1, max_length=128, pattern=r"^[a-zA-Z0-9][a-zA-Z0-9_-]*$")
    account_id: str = Field(min_length=1, max_length=128)
    repo_url: Optional[str] = Field(default=None, max_length=2000)


class SessionRequest(RequestModel):
    workspace_id: str = Field(min_length=1, max_length=128)
    title: Optional[str] = Field(default=None, max_length=500)
    created_by: Optional[str] = Field(default=None, max_length=128)


class MessageRequest(RequestModel):
    input: str = Field(min_length=1, max_length=100_000)

    @field_validator("input")
    @classmethod
    def validate_input(cls, value: str) -> str:
        if not value.strip() or "\x00" in value:
            raise ValueError("input 不得为空白或包含 NUL")
        return value


class FileCreateRequest(RequestModel):
    path: str = Field(min_length=1, max_length=1000)
    type: Literal["file", "directory"] = "file"
    content: str = ""


class FileWriteRequest(RequestModel):
    path: str = Field(min_length=1, max_length=1000)
    content: str


class SkillRequest(RequestModel):
    name: str = Field(min_length=1, max_length=64, pattern=r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
    content: str = Field(min_length=1)
