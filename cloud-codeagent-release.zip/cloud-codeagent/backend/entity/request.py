from typing import Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


class RequestModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=False)


class LoginRequest(RequestModel):
    node_id: Optional[str] = Field(default=None, max_length=64)
    account_id: Optional[str] = Field(default=None, max_length=128)
    account_name: Optional[str] = Field(default=None, max_length=255)


class WorkspaceRequest(RequestModel):
    name: str = Field(min_length=1, max_length=128, pattern=r"^[a-zA-Z0-9][a-zA-Z0-9_-]*$")
    node_id: Optional[str] = Field(default=None, min_length=1, max_length=64)


class SessionRequest(RequestModel):
    workspace_id: str = Field(min_length=1, max_length=128)
    title: Optional[str] = Field(default=None, max_length=500)
    created_by: Optional[str] = Field(default=None, max_length=128)


class MessageRequest(RequestModel):
    input: str = Field(min_length=1, max_length=100_000)

    @field_validator("input")
    @classmethod
    def validate_input(cls, value: str) -> str:
        if not value.strip() or "\x00" in value:
            raise ValueError("input 不得为空白或包含 NUL")
        return value


class DirectoryCreateRequest(RequestModel):
    path: str = Field(min_length=1, max_length=1000)


class FileWriteRequest(RequestModel):
    path: str = Field(min_length=1, max_length=1000)
    content: str
