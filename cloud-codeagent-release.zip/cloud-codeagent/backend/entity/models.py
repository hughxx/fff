from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import (
    BigInteger,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.mysql import LONGTEXT
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

MYSQL_TABLE_OPTIONS = {"mysql_charset": "utf8mb4", "mysql_collate": "utf8mb4_bin"}
MESSAGE_TEXT = Text().with_variant(LONGTEXT(), "mysql")


def utcnow() -> datetime:
    # 数据库存无时区的 UTC 时间，接口统一返回带时区的 ISO 8601。
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Base(DeclarativeBase):
    pass


class Timestamps:
    create_time: Mapped[datetime] = mapped_column(default=utcnow)
    update_time: Mapped[datetime] = mapped_column(default=utcnow, onupdate=utcnow)


class Node(Timestamps, Base):
    __tablename__ = "t_ca_node"
    __table_args__ = MYSQL_TABLE_OPTIONS
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    node_name: Mapped[str] = mapped_column(String(255))
    node_host: Mapped[str] = mapped_column(String(255))
    node_port: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(32), default="online", index=True)
    max_concurrency: Mapped[int] = mapped_column(default=4)
    running_count: Mapped[int] = mapped_column(default=0)
    cpu_usage: Mapped[Optional[float]] = mapped_column(Numeric(8, 2))
    memory_usage: Mapped[Optional[float]] = mapped_column(Numeric(8, 2))
    last_heartbeat: Mapped[Optional[datetime]] = mapped_column(index=True)


class Account(Timestamps, Base):
    __tablename__ = "t_ca_account"
    __table_args__ = (
        UniqueConstraint("auth_provider", "account_id", name="uq_ca_account_identity"),
        MYSQL_TABLE_OPTIONS,
    )
    id: Mapped[str] = mapped_column(String(128), primary_key=True)
    node_id: Mapped[str] = mapped_column(ForeignKey(Node.id), index=True)
    account_id: Mapped[Optional[str]] = mapped_column(String(128))
    account_name: Mapped[Optional[str]] = mapped_column(String(255))
    auth_provider: Mapped[Optional[str]] = mapped_column(String(64))
    auth_status: Mapped[str] = mapped_column(String(32), default="not_login")
    expires_at: Mapped[Optional[int]] = mapped_column(BigInteger)
    config_dir: Mapped[str] = mapped_column(String(1000))


class Workspace(Timestamps, Base):
    __tablename__ = "t_ca_workspace"
    __table_args__ = MYSQL_TABLE_OPTIONS
    id: Mapped[str] = mapped_column(String(128), primary_key=True)
    name: Mapped[str] = mapped_column(String(255))
    node_id: Mapped[str] = mapped_column(ForeignKey(Node.id), index=True)
    account_id: Mapped[str] = mapped_column(ForeignKey(Account.id), index=True)
    status: Mapped[str] = mapped_column(String(32), default="ready")


class AgentSession(Timestamps, Base):
    __tablename__ = "t_ca_session"
    __table_args__ = MYSQL_TABLE_OPTIONS
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    workspace_id: Mapped[str] = mapped_column(ForeignKey(Workspace.id), index=True)
    node_id: Mapped[str] = mapped_column(ForeignKey(Node.id), index=True)
    account_id: Mapped[str] = mapped_column(ForeignKey(Account.id))
    codeagent_session_id: Mapped[Optional[str]] = mapped_column(String(64))
    title: Mapped[Optional[str]] = mapped_column(String(500))
    status: Mapped[str] = mapped_column(String(32), default="ready")
    current_pid: Mapped[Optional[int]] = mapped_column(BigInteger)
    create_user: Mapped[Optional[str]] = mapped_column(String(128))


class SessionMessage(Base):
    __tablename__ = "t_ca_session_message"
    __table_args__ = (Index("idx_ca_message_session_time", "session_id", "create_time"), MYSQL_TABLE_OPTIONS)
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    session_id: Mapped[str] = mapped_column(ForeignKey(AgentSession.id))
    role: Mapped[str] = mapped_column(String(32))
    content: Mapped[Optional[str]] = mapped_column(MESSAGE_TEXT)
    raw_result: Mapped[Optional[str]] = mapped_column(MESSAGE_TEXT)
    create_time: Mapped[datetime] = mapped_column(default=utcnow)
