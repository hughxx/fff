from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import (
    BigInteger,
    Boolean,
    Float,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.mysql import LONGTEXT
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

MYSQL_TABLE_OPTIONS = {"mysql_charset": "utf8mb4", "mysql_collate": "utf8mb4_bin"}
MESSAGE_TEXT = Text().with_variant(LONGTEXT(), "mysql")


def utcnow() -> datetime:
    # 数据库存无时区的 UTC 时间，接口统一返回带时区的 ISO 8601。
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Base(DeclarativeBase):
    pass


class Timestamps:
    create_time: Mapped[datetime] = mapped_column(default=utcnow)
    update_time: Mapped[datetime] = mapped_column(default=utcnow, onupdate=utcnow)


class Node(Timestamps, Base):
    __tablename__ = "t_ca_node"
    __table_args__ = MYSQL_TABLE_OPTIONS
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    node_name: Mapped[str] = mapped_column(String(255))
    node_host: Mapped[str] = mapped_column(String(255))
    node_port: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(32), default="online", index=True)
    running_count: Mapped[int] = mapped_column(default=0)
    cpu_usage: Mapped[Optional[float]] = mapped_column(Numeric(8, 2))
    memory_usage: Mapped[Optional[float]] = mapped_column(Numeric(8, 2))
    last_heartbeat: Mapped[Optional[datetime]] = mapped_column(index=True)


class NodeSetting(Timestamps, Base):
    __tablename__ = "t_ca_node_setting"
    __table_args__ = MYSQL_TABLE_OPTIONS
    node_id: Mapped[str] = mapped_column(
        ForeignKey(Node.id, ondelete="CASCADE"), primary_key=True
    )
    auth_refresh_seconds: Mapped[int] = mapped_column(Integer, default=86400)


class Account(Timestamps, Base):
    __tablename__ = "t_ca_account"
    __table_args__ = (
        UniqueConstraint("node_id", "auth_provider", "account_id", name="uq_ca_account_identity"),
        MYSQL_TABLE_OPTIONS,
    )
    id: Mapped[str] = mapped_column(String(128), primary_key=True)
    node_id: Mapped[str] = mapped_column(ForeignKey(Node.id), index=True)
    account_id: Mapped[Optional[str]] = mapped_column(String(128))
    account_name: Mapped[Optional[str]] = mapped_column(String(255))
    auth_provider: Mapped[Optional[str]] = mapped_column(String(64))
    auth_status: Mapped[str] = mapped_column(String(32), default="not_login")
    expires_at: Mapped[Optional[int]] = mapped_column(BigInteger)
    config_dir: Mapped[str] = mapped_column(String(1000))


class Workspace(Timestamps, Base):
    __tablename__ = "t_ca_workspace"
    __table_args__ = MYSQL_TABLE_OPTIONS
    id: Mapped[str] = mapped_column(String(128), primary_key=True)
    name: Mapped[str] = mapped_column(String(255))
    node_id: Mapped[str] = mapped_column(ForeignKey(Node.id), index=True)
    account_id: Mapped[str] = mapped_column(ForeignKey(Account.id), index=True)
    python_version: Mapped[str] = mapped_column(String(8), default="3.10")
    status: Mapped[str] = mapped_column(String(32), default="ready")


class WorkspaceAccount(Base):
    __tablename__ = "t_ca_workspace_account"
    __table_args__ = MYSQL_TABLE_OPTIONS
    workspace_id: Mapped[str] = mapped_column(ForeignKey(Workspace.id), primary_key=True)
    account_id: Mapped[str] = mapped_column(ForeignKey(Account.id), primary_key=True)
    default_model: Mapped[Optional[str]] = mapped_column(String(128))


class CommandTask(Timestamps, Base):
    __tablename__ = "t_ca_command_task"
    __table_args__ = MYSQL_TABLE_OPTIONS
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    workspace_id: Mapped[str] = mapped_column(
        ForeignKey(Workspace.id, ondelete="CASCADE"), index=True
    )
    node_id: Mapped[str] = mapped_column(ForeignKey(Node.id), index=True)
    command: Mapped[str] = mapped_column(Text)
    timeout_seconds: Mapped[float] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(32), default="queued", index=True)
    exit_code: Mapped[Optional[int]] = mapped_column(Integer)
    stdout: Mapped[str] = mapped_column(MESSAGE_TEXT, default="")
    stderr: Mapped[str] = mapped_column(MESSAGE_TEXT, default="")
    timed_out: Mapped[bool] = mapped_column(Boolean, default=False)
    current_pid: Mapped[Optional[int]] = mapped_column(BigInteger)


class AgentSession(Timestamps, Base):
    __tablename__ = "t_ca_session"
    __table_args__ = MYSQL_TABLE_OPTIONS
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    workspace_id: Mapped[str] = mapped_column(ForeignKey(Workspace.id), index=True)
    node_id: Mapped[str] = mapped_column(ForeignKey(Node.id), index=True)
    account_id: Mapped[str] = mapped_column(ForeignKey(Account.id))
    codeagent_session_id: Mapped[Optional[str]] = mapped_column(String(64))
    title: Mapped[Optional[str]] = mapped_column(String(500))
    status: Mapped[str] = mapped_column(String(32), default="ready")
    current_pid: Mapped[Optional[int]] = mapped_column(BigInteger)
    create_user: Mapped[Optional[str]] = mapped_column(String(128))


class SessionTask(Timestamps, Base):
    __tablename__ = "t_ca_session_task"
    __table_args__ = MYSQL_TABLE_OPTIONS
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    session_id: Mapped[str] = mapped_column(ForeignKey(AgentSession.id, ondelete="CASCADE"), index=True)
    node_id: Mapped[str] = mapped_column(ForeignKey(Node.id), index=True)
    status: Mapped[str] = mapped_column(String(32), default="running", index=True)
    input: Mapped[str] = mapped_column(MESSAGE_TEXT)
    model: Mapped[Optional[str]] = mapped_column(String(128))
    result: Mapped[Optional[str]] = mapped_column(MESSAGE_TEXT)
    error: Mapped[Optional[str]] = mapped_column(MESSAGE_TEXT)


class SessionTaskEvent(Base):
    __tablename__ = 't_ca_session_task_event'
    __table_args__ = MYSQL_TABLE_OPTIONS
    task_id: Mapped[str] = mapped_column(ForeignKey(SessionTask.id, ondelete='CASCADE'), primary_key=True)
    sequence: Mapped[int] = mapped_column(Integer, primary_key=True)
    payload: Mapped[str] = mapped_column(MESSAGE_TEXT)


class SessionMessage(Base):
    __tablename__ = "t_ca_session_message"
    __table_args__ = (Index("idx_ca_message_session_time", "session_id", "create_time"), MYSQL_TABLE_OPTIONS)
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    session_id: Mapped[str] = mapped_column(ForeignKey(AgentSession.id))
    role: Mapped[str] = mapped_column(String(32))
    content: Mapped[Optional[str]] = mapped_column(MESSAGE_TEXT)
    raw_result: Mapped[Optional[str]] = mapped_column(MESSAGE_TEXT)
    create_time: Mapped[datetime] = mapped_column(default=utcnow)
