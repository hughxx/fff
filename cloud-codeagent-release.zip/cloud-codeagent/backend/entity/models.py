from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import (
    BigInteger,
    ForeignKey,
    Index,
    Integer,
    MetaData,
    Numeric,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


def utcnow() -> datetime:
    # GaussDB 表按文档使用不带时区的 timestamp，统一存储 UTC。
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Base(DeclarativeBase):
    metadata = MetaData(schema="coreinsight")


class Timestamps:
    create_time: Mapped[datetime] = mapped_column(default=utcnow)
    update_time: Mapped[datetime] = mapped_column(default=utcnow, onupdate=utcnow)


class Node(Timestamps, Base):
    __tablename__ = "t_ca_node"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    node_name: Mapped[str] = mapped_column(String(255))
    node_host: Mapped[str] = mapped_column(String(255))
    node_port: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(32), default="online", index=True)
    max_concurrency: Mapped[int] = mapped_column(default=4)
    running_count: Mapped[int] = mapped_column(default=0)
    cpu_usage: Mapped[Optional[float]] = mapped_column(Numeric(8, 2))
    memory_usage: Mapped[Optional[float]] = mapped_column(Numeric(8, 2))
    last_heartbeat: Mapped[Optional[datetime]] = mapped_column(index=True)


class Account(Timestamps, Base):
    __tablename__ = "t_ca_account"
    __table_args__ = (
        UniqueConstraint("auth_provider", "account_id", name="uq_ca_account_identity"),
    )
    id: Mapped[str] = mapped_column(String(128), primary_key=True)
    node_id: Mapped[str] = mapped_column(ForeignKey(Node.id), index=True)
    account_id: Mapped[Optional[str]] = mapped_column(String(128))
    account_name: Mapped[Optional[str]] = mapped_column(String(255))
    auth_provider: Mapped[Optional[str]] = mapped_column(String(64))
    auth_status: Mapped[str] = mapped_column(String(32), default="not_login")
    expires_at: Mapped[Optional[int]] = mapped_column(BigInteger)
    config_dir: Mapped[str] = mapped_column(String(1000))


class Workspace(Timestamps, Base):
    __tablename__ = "t_ca_workspace"
    id: Mapped[str] = mapped_column(String(128), primary_key=True)
    name: Mapped[str] = mapped_column(String(255))
    node_id: Mapped[str] = mapped_column(ForeignKey(Node.id), index=True)
    account_id: Mapped[str] = mapped_column(ForeignKey(Account.id), index=True)
    workspace_path: Mapped[str] = mapped_column(String(1000))
    repo_path: Mapped[Optional[str]] = mapped_column(String(1000))
    repo_url: Mapped[Optional[str]] = mapped_column(String(2000))
    status: Mapped[str] = mapped_column(String(32), default="ready")


class AgentSession(Timestamps, Base):
    __tablename__ = "t_ca_session"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    workspace_id: Mapped[str] = mapped_column(ForeignKey(Workspace.id), index=True)
    node_id: Mapped[str] = mapped_column(ForeignKey(Node.id), index=True)
    account_id: Mapped[str] = mapped_column(ForeignKey(Account.id))
    codeagent_session_id: Mapped[Optional[str]] = mapped_column(String(64))
    title: Mapped[Optional[str]] = mapped_column(String(500))
    status: Mapped[str] = mapped_column(String(32), default="ready")
    current_pid: Mapped[Optional[int]] = mapped_column(BigInteger)
    create_user: Mapped[Optional[str]] = mapped_column(String(128))


class SessionMessage(Base):
    __tablename__ = "t_ca_session_message"
    __table_args__ = (Index("idx_ca_message_session_time", "session_id", "create_time"),)
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    session_id: Mapped[str] = mapped_column(ForeignKey(AgentSession.id))
    role: Mapped[str] = mapped_column(String(32))
    content: Mapped[Optional[str]] = mapped_column(Text)
    raw_result: Mapped[Optional[str]] = mapped_column(Text)
    create_time: Mapped[datetime] = mapped_column(default=utcnow)
