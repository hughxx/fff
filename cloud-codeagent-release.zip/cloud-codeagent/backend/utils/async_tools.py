import asyncio
import contextvars
from functools import partial


async def to_thread(function, *args, **kwargs):
    """在线程池执行阻塞操作，并保留调用方上下文，兼容 Python 3.8。"""
    context = contextvars.copy_context()
    operation = partial(context.run, function, *args, **kwargs)
    return await asyncio.get_running_loop().run_in_executor(None, operation)
