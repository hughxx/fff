import logging
import os
import signal

import uvicorn

logger = logging.getLogger(__name__)


class DiagnosticServer(uvicorn.Server):
    def handle_exit(self, sig, frame):
        # Uvicorn 关闭完成后会重新触发信号，必须在关闭前写入日志。
        logger.warning(
            "收到退出信号 signal=%s (%s) pid=%s，将停止服务",
            signal.Signals(sig).name,
            sig,
            os.getpid(),
        )
        super().handle_exit(sig, frame)
