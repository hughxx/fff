import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from uuid import uuid4

from filelock import FileLock, Timeout


def job_directory(settings, task_id):
    return settings.state_dir / 'session-runners' / task_id


def launch(settings, task_id):
    root = settings.state_dir / 'session-runners'
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    source = Path(__file__).resolve().parents[1]
    files = sorted(p for name in ('config', 'dao', 'entity', 'service', 'utils')
                   for p in (source / name).glob('*.py'))
    digest = hashlib.sha256(b''.join(p.relative_to(source).as_posix().encode() + p.read_bytes() for p in files)).hexdigest()
    runtime = root / ('runtime-' + digest)
    with FileLock(root / 'runtime.lock'):
        if not runtime.exists():
            temporary = root / ('staging-' + uuid4().hex)
            temporary.mkdir(mode=0o700)
            for file in files:
                target = temporary / file.relative_to(source)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(file, target)
            temporary.rename(runtime)
    directory = job_directory(settings, task_id)
    directory.mkdir(mode=0o700)
    data = settings.model_dump(mode='json')
    data['db_password'] = settings.db_password.get_secret_value()
    if settings.database_url:
        data['database_url'] = settings.database_url.get_secret_value()
    request = directory / 'request.json'
    with request.open('x', encoding='utf-8') as output:
        json.dump({'settings': data, 'task_id': task_id}, output)
    if os.name != 'nt':
        request.chmod(0o600)
    options = {'start_new_session': True} if os.name != 'nt' else {
        'creationflags': subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP}
    with (directory / 'worker.log').open('ab') as output:
        process = subprocess.Popen([sys.executable, '-m', 'utils.session_worker', str(directory)],
            cwd=runtime, stdin=subprocess.DEVNULL, stdout=output, stderr=output,
            close_fds=True, **options)
    # Retain the handle in the caller to reap it, without terminating on web shutdown.
    return process


def alive(settings, task_id):
    directory = job_directory(settings, task_id)
    if not directory.exists():
        return False
    try:
        with FileLock(directory / 'worker.lock', timeout=0):
            # Allow a newly spawned worker to acquire its lock.
            request = directory / 'request.json'
            return not (directory / 'ready').exists() and request.exists() and time.time() - request.stat().st_mtime < 15
    except Timeout:
        return True


def request_cancel(settings, task_id):
    directory = job_directory(settings, task_id)
    if directory.exists():
        (directory / 'cancel').touch()
