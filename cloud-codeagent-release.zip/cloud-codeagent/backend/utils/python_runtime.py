import os
from pathlib import Path

from utils.errors import AppError


def python_env(settings, version):
    configured = settings.python_executables.get(version)
    if not configured:
        raise AppError(422, "不支持该 Python 版本")
    executable = Path(configured).expanduser().resolve()
    if not executable.is_file() or not os.access(str(executable), os.X_OK):
        raise AppError(503, f"Python {version} 未安装，请检查 config/settings.py 中的解释器路径")
    env = {**os.environ, "PYTHON": str(executable)}
    if os.name != "nt":
        shims = settings.state_dir / "python" / version
        shims.mkdir(parents=True, exist_ok=True)
        for name in ("python", "python3"):
            link = shims / name
            if link.is_symlink() and link.resolve() != executable:
                link.unlink()
            if not link.exists():
                link.symlink_to(executable)
        env["PATH"] = str(shims) + os.pathsep + env.get("PATH", "")
    return env
