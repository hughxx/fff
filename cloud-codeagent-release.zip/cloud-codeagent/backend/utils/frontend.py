from pathlib import Path
from typing import Optional

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles


def mount_frontend(app: FastAPI, directory: Optional[Path]) -> None:
    """托管已构建的控制台；页面使用 hash 路由，原有 API 路径不受影响。"""
    if directory is None:
        return
    directory = directory.expanduser().resolve()
    index = directory / "index.html"
    if not index.is_file():
        return

    @app.api_route("/", methods=["GET", "HEAD"], include_in_schema=False)
    @app.api_route("/index.html", methods=["GET", "HEAD"], include_in_schema=False)
    async def frontend_index():
        return FileResponse(index, media_type="text/html", headers={"Cache-Control": "no-cache"})

    favicon = directory / "favicon.svg"
    if favicon.is_file():

        @app.api_route("/favicon.svg", methods=["GET", "HEAD"], include_in_schema=False)
        async def frontend_favicon():
            return FileResponse(favicon, media_type="image/svg+xml")

    assets = directory / "assets"
    if assets.is_dir():
        app.mount("/assets", StaticFiles(directory=assets), name="frontend-assets")
