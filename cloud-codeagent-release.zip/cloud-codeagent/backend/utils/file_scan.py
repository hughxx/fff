"""Bounded directory scans shared by file statistics and tree views."""
import os
import stat
from contextlib import contextmanager
from pathlib import Path

from utils.errors import AppError
from utils.paths import safe_path


@contextmanager
def scan_errors():
    try:
        yield
    except FileNotFoundError as exc:
        raise AppError(404, "目录不存在或扫描期间文件已被移除") from exc
    except PermissionError as exc:
        raise AppError(403, "没有权限读取目录或其内容") from exc
    except OSError as exc:
        raise AppError(409, "目录读取失败，文件可能正在变化，请重试") from exc


class ScanBudget:
    def __init__(self, limit):
        self.limit = limit
        self.used = 0

    def consume(self):
        self.used += 1
        if self.used > self.limit:
            raise AppError(413, "扫描条目超过 max_entries，请缩小目录或深度，或提高限制")


def entries(root, directory, budget):
    safe_path(root, directory.relative_to(root).as_posix(), allow_root=True)
    result = []
    with os.scandir(directory) as source:
        for entry in source:
            budget.consume()
            child = Path(entry.path)
            info = entry.stat(follow_symlinks=False)
            link = entry.is_symlink() or (hasattr(child, "is_junction") and child.is_junction())
            kind = "symlink" if link else (
                "directory" if stat.S_ISDIR(info.st_mode) else
                "file" if stat.S_ISREG(info.st_mode) else "other"
            )
            result.append({
                "name": entry.name, "path": child.relative_to(root).as_posix(),
                "type": kind, "size": info.st_size,
            })
    return sorted(result, key=lambda item: item["name"])


def scan(root, target, max_depth, budget, with_tree=False):
    if not stat.S_ISDIR(target.stat().st_mode):
        raise AppError(400, "目标必须是目录")
    totals = {
        "file_count": 0, "directory_count": 0, "total_size_bytes": 0,
        "skipped_symlink_count": 0, "other_count": 0, "depth_limited": False,
    }
    tree = []
    pending = [(target, 1, tree)]
    while pending:
        directory, depth, output = pending.pop()
        children = entries(root, directory, budget)
        if with_tree:
            output.extend(children)
        for item in children:
            kind = item["type"]
            if kind == "file":
                totals["file_count"] += 1
                totals["total_size_bytes"] += item["size"]
            elif kind == "symlink":
                totals["skipped_symlink_count"] += 1
            elif kind == "other":
                totals["other_count"] += 1
            else:
                totals["directory_count"] += 1
                expand = max_depth is None or depth < max_depth
                if not expand:
                    totals["depth_limited"] = True
                child_output = []
                if with_tree:
                    item["expanded"] = expand
                    if expand:
                        item["children"] = child_output
                if expand:
                    pending.append((root / item["path"], depth + 1, child_output))
    return totals, tree
