import json
import logging
import time
from datetime import datetime, timezone
from uuid import uuid4

logger = logging.getLogger(__name__)


class ExecutionLog:
    """Append-only per-turn diagnostics, independent of the saved final answer."""

    def __init__(self, root, session_id):
        self.file = None
        self.path = None
        self.started = time.monotonic()
        try:
            directory = root / '.codeagent-logs'
            if directory.is_symlink():
                raise OSError('Log directory must not be a symlink')
            directory.mkdir(mode=0o700, parents=True, exist_ok=True)
            cutoff = time.time() - 7 * 86400
            for old in directory.glob('*.jsonl'):
                if not old.is_symlink() and old.is_file() and old.stat().st_mtime < cutoff:
                    old.unlink()
            stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')
            self.path = directory / f'{stamp}_{session_id}_{uuid4().hex}.jsonl'
            self.file = self.path.open('x', encoding='utf-8')
        except OSError:
            logger.exception('Cannot create execution log for session %s', session_id)

    def write(self, event, **data):
        if self.file is None:
            return
        try:
            record = dict(time=datetime.now(timezone.utc).isoformat(),
                          elapsed_seconds=round(time.monotonic() - self.started, 3),
                          event=event, **data)
            self.file.write(json.dumps(record, ensure_ascii=False) + '\n')
            self.file.flush()
        except (OSError, ValueError):
            logger.exception('Cannot write execution log %s', self.path)
            self.close()

    def output(self, channel, chunk):
        self.write(channel, text=chunk.decode('utf-8', errors='replace'))

    def close(self):
        if self.file is not None:
            try:
                self.file.close()
            except OSError:
                logger.exception('Cannot close execution log %s', self.path)
            self.file = None
