from datetime import datetime, timezone
from decimal import Decimal


def record(value, aliases=None):
    aliases = aliases or {}
    result = {}
    for column in value.__table__.columns:
        item = getattr(value, column.name)
        if isinstance(item, datetime):
            item = item.replace(tzinfo=timezone.utc).isoformat()
        elif isinstance(item, Decimal):
            item = float(item)
        result[aliases.get(column.name, column.name)] = item
    return result


def session_record(value):
    result = record(
        value,
        {
            "id": "session_id",
            "create_time": "created_at",
            "update_time": "updated_at",
            "create_user": "created_by",
        },
    )
    result.pop("current_pid", None)
    return result
