from datetime import datetime, timezone
from decimal import Decimal

from utils.errors import AppError


def record(value, aliases=None):
    aliases = aliases or {}
    result = {}
    for column in value.__table__.columns:
        item = getattr(value, column.name)
        if isinstance(item, datetime):
            item = item.replace(tzinfo=timezone.utc).isoformat()
        elif isinstance(item, Decimal):
            item = float(item)
        result[aliases.get(column.name, column.name)] = item
    return result


def workspace_relative_path(value):
    expected = f"workspaces/{value.id}"
    if value.workspace_path != expected:
        raise AppError(409, "工作区相对路径与 ID 不一致")
    return expected


def workspace_record(value):
    workspace_relative_path(value)
    result = record(value)
    result.pop("account_id", None)
    return result


def session_record(value):
    result = record(
        value,
        {
            "id": "session_id",
            "create_time": "created_at",
            "update_time": "updated_at",
            "create_user": "created_by",
        },
    )
    result.pop("current_pid", None)
    result.pop("account_id", None)
    return result
