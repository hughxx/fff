import os
import shutil
import tempfile
from pathlib import Path, PurePosixPath, PureWindowsPath

from utils.errors import AppError


def safe_path(root: Path, relative: str, *, allow_root=False) -> Path:
    root = root.resolve()
    if "\x00" in relative or "\\" in relative:
        raise AppError(400, "路径包含非法字符")
    posix, windows = PurePosixPath(relative), PureWindowsPath(relative)
    if posix.is_absolute() or windows.is_absolute() or windows.drive or ".." in posix.parts:
        raise AppError(400, "禁止绝对路径和目录逃逸")
    target = root.joinpath(*posix.parts)
    # 拒绝路径中的符号链接和 Windows junction，包括指向工作区内部的链接。
    current = root
    for part in posix.parts:
        current = current / part
        if current.is_symlink() or (hasattr(current, "is_junction") and current.is_junction()):
            raise AppError(400, "文件 API 不允许访问符号链接")
    resolved = target.resolve()
    if not resolved.is_relative_to(root) or (resolved == root and not allow_root):
        raise AppError(400, "目标路径必须位于工作区内部")
    return target


def atomic_write(path: Path, content: str):
    descriptor, temporary = tempfile.mkstemp(prefix=".ca-", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="") as output:
            output.write(content)
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


def remove_managed_dir(root: Path, target: Path):
    checked = safe_path(root, target.name)
    if checked != target or not target.resolve().is_relative_to(root.resolve()):
        raise AppError(400, "运行目录不在配置的数据目录内")
    if checked.exists():
        shutil.rmtree(checked)
