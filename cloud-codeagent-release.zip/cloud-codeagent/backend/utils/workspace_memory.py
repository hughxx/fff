import json

from utils.errors import AppError
from utils.paths import safe_path, atomic_write


def memory_settings(root, enabled=None, fill_missing=False):
    if not root.is_dir():
        raise AppError(404, '工作区目录不存在')
    path = safe_path(root, '.cac/settings.local.json')
    try:
        content = json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
    except (ValueError, UnicodeError) as exc:
        raise AppError(409, 'settings.local.json 不是有效 JSON，请修复后重试；未覆盖原文件') from exc
    if not isinstance(content, dict):
        raise AppError(409, 'settings.local.json 必须是 JSON 对象；未覆盖原文件')
    if enabled is not None or (fill_missing and 'autoMemoryEnabled' not in content):
        content['autoMemoryEnabled'] = enabled if enabled is not None else False
        path.parent.mkdir(parents=True, exist_ok=True)
        atomic_write(path, json.dumps(content, ensure_ascii=False, indent=2) + '\n')
    value = content.get('autoMemoryEnabled')
    if type(value) is not bool:
        raise AppError(409, 'autoMemoryEnabled 缺失或不是布尔值，请设置记忆开关')
    return {'autoMemoryEnabled': value}
