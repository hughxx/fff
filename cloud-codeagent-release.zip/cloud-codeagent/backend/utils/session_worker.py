"""Detached per-task runner. Its code and state live outside the release directory."""
import asyncio
import json
import logging
import sys
from pathlib import Path
from types import SimpleNamespace

from filelock import FileLock
from config.database import Database
from config.settings import Settings
from entity.models import Account, AgentSession, SessionTask, Workspace
from service.session_service import Execution, SessionService
from service.account_service import AccountService
from utils.codeagent import CodeAgentClient
from utils.paths import safe_path


async def run(directory):
    request = json.loads((directory / 'request.json').read_text(encoding='utf-8'))
    settings = Settings(**request['settings'])
    db = Database(settings)
    def load(session):
        task = session.get(SessionTask, request['task_id'])
        if task is None or task.status != 'running':
            return None
        item = session.get(AgentSession, task.session_id)
        return task, item, session.get(Workspace, item.workspace_id), session.get(Account, item.account_id)
    try:
        data = await db.run(load)
        if data is None:
            return
        task, item, workspace, account = data
        nodes = SimpleNamespace(node_id=task.node_id)
        cli = CodeAgentClient(settings)
        service = SessionService(db, settings, nodes,
            AccountService(db, settings, nodes, cli),
            SimpleNamespace(root=lambda w: safe_path(settings.workspaces_dir, w.id)), cli)
        entry = Execution(queue=asyncio.Queue(), task_id=task.id)
        entry.task = asyncio.create_task(service._execute(entry, item, workspace, account, task.input, True, task.model))
        await entry.started.wait()
        while not entry.task.done():
            if (directory / 'cancel').exists():
                await service.stop_entry(entry)
                break
            await asyncio.wait({entry.task}, timeout=0.2)
        await entry.task
    finally:
        await db.close()


if __name__ == '__main__':
    job_dir = Path(sys.argv[1]).resolve()
    logging.basicConfig(level=logging.INFO)
    with FileLock(job_dir / 'worker.lock', timeout=0):
        (job_dir / 'ready').touch()
        asyncio.run(run(job_dir))
