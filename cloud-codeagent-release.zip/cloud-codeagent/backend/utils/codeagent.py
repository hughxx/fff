import asyncio
import contextlib
import json
import os
import signal
import subprocess
from pathlib import Path

from utils.errors import AppError


async def stop_process(process, grace: float):
    if process.returncode is not None:
        return
    try:
        if os.name == "nt":
            process.send_signal(signal.CTRL_BREAK_EVENT)
        else:
            os.killpg(process.pid, signal.SIGINT)
    except (ProcessLookupError, PermissionError, OSError):
        with contextlib.suppress(ProcessLookupError):
            process.terminate()
    try:
        await asyncio.wait_for(process.wait(), grace)
    except TimeoutError:
        with contextlib.suppress(ProcessLookupError):
            if os.name == "nt":
                # taskkill 的参数独立传递，不经过 shell。
                killer = await asyncio.create_subprocess_exec(
                    "taskkill",
                    "/PID",
                    str(process.pid),
                    "/T",
                    "/F",
                    stdout=asyncio.subprocess.DEVNULL,
                    stderr=asyncio.subprocess.DEVNULL,
                )
                await killer.wait()
            else:
                os.killpg(process.pid, signal.SIGKILL)
        await process.wait()


async def drain_tail(reader, limit=8192):
    tail = b""
    while chunk := await reader.read(4096):
        tail = (tail + chunk)[-limit:]
    return tail


class CodeAgentClient:
    def __init__(self, settings):
        self.settings = settings

    async def spawn(self, args, *, cwd: Path, config_dir: Path, merge_stderr=False):
        env = {**os.environ, "CODEAGENT3_CONFIG_DIR": str(config_dir)}
        return await self.spawn_command(
            [*self.settings.codeagent_command, *args],
            cwd=cwd,
            env=env,
            merge_stderr=merge_stderr,
        )

    async def spawn_command(self, command, *, cwd, env=None, merge_stderr=False):
        options = (
            {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP}
            if os.name == "nt"
            else {"start_new_session": True}
        )
        try:
            return await asyncio.create_subprocess_exec(
                *command,
                cwd=str(cwd),
                env=env,
                stdin=asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT if merge_stderr else asyncio.subprocess.PIPE,
                limit=self.settings.max_output_bytes,
                **options,
            )
        except (FileNotFoundError, PermissionError, OSError) as exc:
            raise AppError(503, "无法启动本地命令，请检查 CodeAgent/Git 安装及目录权限") from exc

    async def collect(self, process, *, timeout=None):
        stderr = asyncio.create_task(drain_tail(process.stderr))
        output = bytearray()
        try:
            async with asyncio.timeout(timeout or self.settings.command_timeout):
                while chunk := await process.stdout.read(65536):
                    output.extend(chunk)
                    if len(output) > self.settings.max_output_bytes:
                        raise AppError(502, "命令输出超过限制")
                await process.wait()
                await stderr
            if process.returncode != 0:
                # stderr 可能包含凭据或授权 URL，不直接返回给调用方。
                raise AppError(502, f"本地命令执行失败，退出码 {process.returncode}")
            return bytes(output)
        except TimeoutError as exc:
            raise AppError(504, "本地命令执行超时") from exc
        finally:
            drain = asyncio.create_task(drain_tail(process.stdout))
            await stop_process(process, self.settings.cancel_grace_seconds)
            await drain
            await stderr

    async def json_command(self, args, *, cwd, config_dir):
        process = await self.spawn(args, cwd=cwd, config_dir=config_dir)
        raw = await self.collect(process)
        try:
            data = json.loads(raw)
            if not isinstance(data, dict):
                raise ValueError("expected object")
            return data
        except (ValueError, UnicodeError) as exc:
            raise AppError(502, "CodeAgent 返回了无效的 JSON") from exc

    async def auth_status(self, config_dir):
        return await self.json_command(
            ["auth", "status", "--json"], cwd=config_dir, config_dir=config_dir
        )

    def message_args(self, session_id, text, stream):
        args = [
            "-p",
            text,
            "--output-format",
            "stream-json" if stream else "json",
            "--skip-safe-check",
        ]
        if session_id:
            args.extend(["-s", session_id])
        if stream:
            args.append("--verbose")
        return args
