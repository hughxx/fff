import asyncio
import contextlib
import json
import logging
import os
import signal
import subprocess
from pathlib import Path

from async_timeout import timeout as async_timeout

from utils.errors import AppError
from utils.logging_utils import redact_output

logger = logging.getLogger(__name__)


def valid_auth_status(data):
    return (
        isinstance(data, dict)
        and isinstance(data.get("loggedIn"), bool)
        and isinstance(data.get("expired", False), bool)
        and not data.get("error")
        and not data.get("is_error")
    )


def parse_auth_status(raw):
    text = raw.decode("utf-8") if isinstance(raw, bytes) else raw
    lines = text.splitlines()
    while lines and not lines[0].strip():
        lines.pop(0)
    if lines and lines[0].startswith("New version available:"):
        lines.pop(0)
        if lines and lines[0].startswith("You can run the 'codeagent update'"):
            lines.pop(0)
    return json.loads("\n".join(lines))


def logged_out_result(raw):
    try:
        data = parse_auth_status(raw)
    except (ValueError, UnicodeError):
        return False
    return valid_auth_status(data) and data["loggedIn"] is False


async def stop_process(process, grace: float):
    if process.returncode is not None:
        return
    try:
        if os.name == "nt":
            process.send_signal(signal.CTRL_BREAK_EVENT)
        else:
            os.killpg(process.pid, signal.SIGINT)
    except (ProcessLookupError, PermissionError, OSError):
        with contextlib.suppress(ProcessLookupError):
            process.terminate()
    try:
        await asyncio.wait_for(process.wait(), grace)
    except asyncio.TimeoutError:
        with contextlib.suppress(ProcessLookupError):
            if os.name == "nt":
                # taskkill 的参数独立传递，不经过 shell。
                killer = await asyncio.create_subprocess_exec(
                    "taskkill",
                    "/PID",
                    str(process.pid),
                    "/T",
                    "/F",
                    stdout=asyncio.subprocess.DEVNULL,
                    stderr=asyncio.subprocess.DEVNULL,
                )
                await killer.wait()
            else:
                os.killpg(process.pid, signal.SIGKILL)
        await process.wait()


async def drain_tail(reader, limit=8192, buffer=None):
    tail = buffer if buffer is not None else bytearray()
    while chunk := await reader.read(4096):
        tail.extend(chunk)
        del tail[:-limit]
    return bytes(tail)


class CodeAgentClient:
    def __init__(self, settings):
        self.settings = settings

    async def spawn(self, args, *, cwd: Path, config_dir: Path, merge_stderr=False, extra_env=None):
        env = {**os.environ, **(extra_env or {}), "CODEAGENT3_CONFIG_DIR": str(config_dir)}
        return await self.spawn_command(
            [*self.settings.codeagent_command, *args],
            cwd=cwd,
            env=env,
            merge_stderr=merge_stderr,
        )

    async def spawn_command(self, command, *, cwd, env=None, merge_stderr=False):
        options = (
            {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP}
            if os.name == "nt"
            else {"start_new_session": True}
        )
        try:
            return await asyncio.create_subprocess_exec(
                *command,
                cwd=str(cwd),
                env=env,
                stdin=asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT if merge_stderr else asyncio.subprocess.PIPE,
                limit=self.settings.max_output_bytes,
                **options,
            )
        except (FileNotFoundError, PermissionError, OSError) as exc:
            logger.exception("无法启动本地命令 executable=%s cwd=%s", command[0], cwd)
            raise AppError(503, "无法启动本地命令，请检查 CodeAgent 安装及目录权限") from exc

    async def collect(self, process, *, timeout=None, operation="CLI", allow_logged_out=False):
        stderr_output = bytearray()
        stderr = asyncio.create_task(drain_tail(process.stderr, buffer=stderr_output))
        output = bytearray()
        try:
            async with async_timeout(timeout or self.settings.command_timeout):
                while chunk := await process.stdout.read(65536):
                    output.extend(chunk)
                    if len(output) > self.settings.max_output_bytes:
                        logger.error(
                            "本地命令输出超过限制 operation=%s pid=%s limit=%s stderr=%s",
                            operation,
                            process.pid,
                            self.settings.max_output_bytes,
                            redact_output(bytes(stderr_output)),
                        )
                        raise AppError(502, "命令输出超过限制")
                await process.wait()
                await asyncio.shield(stderr)
            # auth status 用退出码 1 表示尚未登录；仅接受有效的未登录状态 JSON。
            expected_logged_out = (
                allow_logged_out and process.returncode == 1 and logged_out_result(bytes(output))
            )
            if process.returncode != 0 and not expected_logged_out:
                logger.error(
                    "本地命令失败 operation=%s pid=%s exit_code=%s stdout=%s stderr=%s",
                    operation,
                    process.pid,
                    process.returncode,
                    redact_output(bytes(output)),
                    redact_output(stderr.result()),
                )
                raise AppError(502, f"本地命令执行失败，退出码 {process.returncode}")
            return bytes(output)
        except asyncio.TimeoutError as exc:
            logger.error(
                "本地命令超时 operation=%s pid=%s timeout=%s stdout=%s stderr=%s",
                operation,
                process.pid,
                timeout or self.settings.command_timeout,
                redact_output(bytes(output)),
                redact_output(bytes(stderr_output)),
            )
            raise AppError(504, "本地命令执行超时") from exc
        finally:
            drain = asyncio.create_task(drain_tail(process.stdout))
            await stop_process(process, self.settings.cancel_grace_seconds)
            await drain
            await stderr

    async def json_command(self, args, *, cwd, config_dir, allow_logged_out=False):
        operation = " ".join(args[:2])
        process = await self.spawn(args, cwd=cwd, config_dir=config_dir)
        raw = await self.collect(process, operation=operation, allow_logged_out=allow_logged_out)
        try:
            data = parse_auth_status(raw) if allow_logged_out else json.loads(raw)
            if not isinstance(data, dict):
                raise ValueError("expected object")
            return data
        except (ValueError, UnicodeError) as exc:
            logger.error(
                "本地命令返回无效 JSON operation=%s pid=%s output=%s",
                operation,
                process.pid,
                redact_output(raw),
            )
            raise AppError(502, "CodeAgent 返回了无效的 JSON") from exc

    async def auth_status(self, config_dir):
        status = await self.json_command(
            ["auth", "status", "--json"],
            cwd=config_dir,
            config_dir=config_dir,
            allow_logged_out=True,
        )
        if not valid_auth_status(status):
            logger.error(
                "认证状态格式错误 operation=auth status output=%s",
                redact_output(json.dumps(status)),
            )
            raise AppError(502, "CodeAgent 返回了无效的认证状态")
        return status

    async def models(self, config_dir):
        process = await self.spawn(["models", "-v"], cwd=config_dir, config_dir=config_dir)
        return (await self.collect(process, operation="models -v")).decode("utf-8", errors="replace")

    def message_args(self, session_id, text, stream, model=None):
        args = [
            "-p",
            text,
            "--output-format",
            "stream-json" if stream else "json",
            "--skip-safe-check",
        ]
        if session_id:
            args.extend(["-s", session_id])
        if model:
            args[:0] = ["--model", model]
        if stream:
            args.append("--verbose")
        return args
