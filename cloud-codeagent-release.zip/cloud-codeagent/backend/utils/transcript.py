from uuid import uuid4


class Transcript:
    """Group assistant text by scope and message, never by the whole CLI run."""

    def __init__(self):
        self.messages = {}
        self.seen = set()
        self.last_root = None

    def accept(self, event):
        if event.get('type') != 'assistant':
            return None
        uuid = event.get('uuid')
        if uuid and uuid in self.seen:
            return None
        if uuid:
            self.seen.add(uuid)
        message = event.get('message') or {}
        text = ''.join(b.get('text', '') for b in message.get('content', [])
                       if isinstance(b, dict) and b.get('type') == 'text')
        if not text:
            return None
        parent = event.get('parent_tool_use_id') or event.get('_cac_agentId')
        key = (parent, message.get('id') or uuid or uuid4().hex)
        row = self.messages.setdefault(key, {'id': f'msg_{uuid4().hex}', 'content': '', 'raw': event})
        row['content'] += text
        row['raw'] = {**event, 'message': {**message, 'content': [{'type': 'text', 'text': row['content']}]}}
        if not parent:
            self.last_root = row
        return row

    def final_match(self, final):
        if self.last_root and self.last_root['content'].strip() == str(final.get('result', '')).strip():
            return self.last_root['id']
        return None
