import logging
import re


def redact_output(value, secrets=(), limit=8192):
    """保留诊断文本，隐藏常见凭据、授权链接和已知配置密钥。"""
    text = value.decode("utf-8", errors="replace") if isinstance(value, bytes) else str(value)
    text = re.sub(r"\x1b\[[0-9;]*m", "", text)
    for secret in secrets:
        if secret:
            text = text.replace(secret, "[REDACTED]")
    text = re.sub(r"https?://[^\s<>\"']+", "[URL REDACTED]", text)
    text = re.sub(r"(?i)\bBearer\s+[^\s,;\"']+", "Bearer [REDACTED]", text)
    text = re.sub(
        r"(?i)([\"']?(?:[\w-]*token|password|passwd|secret|client_secret|api[_-]?key|"
        r"authorization|cookie|set-cookie|code_verifier)[\"']?\s*[:=]\s*)"
        r"(?:\"(?:\\.|[^\"\\])*\"|'(?:\\.|[^'\\])*'|[^\s,;]+)",
        r"\1[REDACTED]",
        text,
    )
    text = re.sub(r"\beyJ[\w-]+\.[\w-]+\.[\w-]+\b", "[REDACTED]", text)
    return text if limit is None else text[:limit]


class RedactingFormatter(logging.Formatter):
    def __init__(self, secrets=()):
        super().__init__("%(asctime)s %(levelname)s %(name)s %(message)s")
        self.secrets = secrets

    def format(self, record):
        return redact_output(super().format(record), self.secrets, limit=None)
