"""Detached shell runner with persisted output and cancellation mailbox."""
import asyncio
import contextlib
import json
import logging
import sys
from pathlib import Path
from types import SimpleNamespace

from filelock import FileLock
from config.database import Database
from config.settings import Settings
from entity.models import CommandTask, Workspace
from service.command_service import CommandService, CommandExecution
from utils.paths import safe_path
from utils.python_runtime import python_env

logger = logging.getLogger(__name__)


async def run(directory):
    request = json.loads((directory / 'request.json').read_text(encoding='utf-8'))
    settings = Settings(**request['settings'])
    db = Database(settings)
    task_id = request['task_id']
    entry = CommandExecution()
    try:
        def load(session):
            item = session.get(CommandTask, task_id)
            if item is None or item.status not in ('queued', 'running'):
                return None
            return item, session.get(Workspace, item.workspace_id)
        data = await db.run(load)
        if data is None:
            return
        item, workspace = data
        service = CommandService(db, settings, SimpleNamespace(node_id=item.node_id), None)
        if (directory / 'cancel').exists():
            await service._finish(task_id, 'cancelled', None, b'', b'', False)
            return
        cwd = safe_path(settings.workspaces_dir, workspace.id)
        env = python_env(settings, workspace.python_version)
        entry.task = asyncio.create_task(service._execute_task(
            task_id, cwd, item.command, item.timeout_seconds, env, entry))
        last_output = None
        while not entry.task.done():
            if (directory / 'cancel').exists():
                entry.cancelled = True
                entry.task.cancel()
                break
            output = (bytes(entry.stdout), bytes(entry.stderr))
            if output != last_output:
                def save(session):
                    current = session.get(CommandTask, task_id)
                    if current and current.status in ('queued', 'running'):
                        current.stdout = output[0].decode('utf-8', errors='replace')
                        current.stderr = output[1].decode('utf-8', errors='replace')
                try:
                    await db.run(save)
                    last_output = output
                except Exception:
                    logger.exception('Could not persist partial output task_id=%s', task_id)
            await asyncio.wait({entry.task}, timeout=0.2)
        with contextlib.suppress(asyncio.CancelledError):
            await entry.task
        if entry.cancelled:
            await service._finish(task_id, 'cancelled', None, entry.stdout, entry.stderr, False)
    finally:
        if entry.task and not entry.task.done():
            entry.task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await entry.task
        await db.close()


if __name__ == '__main__':
    directory = Path(sys.argv[1]).resolve()
    logging.basicConfig(level=logging.INFO)
    with FileLock(directory / 'worker.lock', timeout=0):
        (directory / 'ready').touch()
        asyncio.run(run(directory))
