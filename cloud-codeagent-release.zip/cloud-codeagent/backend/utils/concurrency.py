import asyncio


class DynamicSemaphore:
    """A per-node limit that can be changed while requests are running."""

    def __init__(self, limit=None):
        self.limit = limit
        self.active = 0
        self.changed = asyncio.Event()

    async def acquire(self):
        while self.limit is not None and self.active >= self.limit:
            await self.changed.wait()
            self.changed.clear()
        self.active += 1

    def release(self):
        self.active -= 1
        self.changed.set()

    def set_limit(self, limit):
        self.limit = limit
        self.changed.set()

    async def __aenter__(self):
        await self.acquire()
        return self

    async def __aexit__(self, exc_type, exc, traceback):
        self.release()
