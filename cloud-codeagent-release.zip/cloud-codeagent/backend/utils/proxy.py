import httpx
from starlette.background import BackgroundTask
from starlette.responses import Response, StreamingResponse

from utils.errors import AppError

HOP_HEADERS = {
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailer",
    "transfer-encoding",
    "upgrade",
    "host",
    "content-length",
}


async def forward_request(client: httpx.AsyncClient, request, node):
    if request.headers.get("x-ca-forwarded"):
        raise AppError(508, "资源归属不一致，已停止循环转发")
    host = f"[{node.node_host}]" if ":" in node.node_host else node.node_host
    url = httpx.URL(f"http://{host}:{node.node_port}").copy_with(
        raw_path=request.scope.get("raw_path", request.url.path.encode())
        + (b"?" + request.scope["query_string"] if request.scope["query_string"] else b"")
    )
    excluded = HOP_HEADERS | {
        part.strip().lower() for part in request.headers.get("connection", "").split(",")
    }
    headers = {k: v for k, v in request.headers.items() if k.lower() not in excluded}
    headers["x-ca-forwarded"] = "1"
    headers["accept-encoding"] = "identity"
    outgoing = client.build_request(
        request.method, url, headers=headers, content=await request.body()
    )
    try:
        upstream = await client.send(outgoing, stream=True)
    except httpx.RequestError as exc:
        raise AppError(503, "所属节点暂时无法连接") from exc
    excluded = HOP_HEADERS | {
        part.strip().lower() for part in upstream.headers.get("connection", "").split(",")
    }
    response_headers = {k: v for k, v in upstream.headers.items() if k.lower() not in excluded}
    if "application/x-ndjson" in upstream.headers.get("content-type", ""):

        async def relay():
            try:
                async for chunk in upstream.aiter_raw():
                    yield chunk
            finally:
                await upstream.aclose()

        return StreamingResponse(
            relay(),
            status_code=upstream.status_code,
            headers=response_headers,
            background=BackgroundTask(upstream.aclose),
        )
    try:
        body = await upstream.aread()
        response_headers.pop("content-encoding", None)
        return Response(body, status_code=upstream.status_code, headers=response_headers)
    finally:
        await upstream.aclose()
