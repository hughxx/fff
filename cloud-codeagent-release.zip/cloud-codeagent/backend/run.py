import argparse
import logging

import uvicorn

from config.settings import Settings
from main import create_app


def main():
    parser = argparse.ArgumentParser(description="启动 Cloud CodeAgent 同构节点")
    parser.add_argument("--host", help="节点间可访问的 IP 或主机名")
    parser.add_argument("--port", type=int, help="HTTP 端口")
    parser.add_argument("--concurrency", type=int, help="本节点 CodeAgent 最大并发数")
    args = {key: value for key, value in vars(parser.parse_args()).items() if value is not None}
    settings = Settings(**args)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    # 一个节点一个 ASGI 进程；CLI 并发由 SessionService 内的 semaphore 管理。
    uvicorn.run(
        create_app(settings),
        host=settings.host,
        port=settings.port,
        workers=1,
        timeout_graceful_shutdown=int(settings.cancel_grace_seconds + 10),
    )


if __name__ == "__main__":
    main()
