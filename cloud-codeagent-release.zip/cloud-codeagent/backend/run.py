import argparse
import logging
import os
import sys

from config.logging_config import configure_logging

logger = logging.getLogger(__name__)


class LoggingArgumentParser(argparse.ArgumentParser):
    def error(self, message):
        logger.error("启动参数错误: %s", message)
        super().error(message)


def main(argv=None):
    log_path = configure_logging()
    logger.info("启动诊断日志: %s", log_path)
    logger.info(
        "启动进程 pid=%s python=%s executable=%s",
        os.getpid(),
        sys.version.split()[0],
        sys.executable,
    )
    try:
        return start(argv)
    except KeyboardInterrupt:
        logger.warning("服务因键盘中断退出 exit_code=130")
        raise SystemExit(130) from None
    except SystemExit as exc:
        if exc.code:
            logger.error("服务退出 exit_code=%s，请查看上方的具体错误", exc.code)
        raise
    except Exception:
        logger.exception("服务启动或运行失败 exit_code=1")
        raise SystemExit(1) from None


def start(argv):
    parser = LoggingArgumentParser(description="启动 Cloud CodeAgent 同构节点")
    parser.add_argument("--host", help="节点间可访问的 IP 或主机名")
    parser.add_argument("--port", type=int, help="HTTP 端口")
    args = {key: value for key, value in vars(parser.parse_args(argv)).items() if value is not None}
    # 延迟导入，确保缺失依赖和配置校验异常也能留下完整堆栈。
    from config.settings import Settings

    settings = Settings(**args)
    log_path = configure_logging(settings)
    logger.info("服务日志文件: %s", log_path)
    logger.info(
        "启动配置 host=%s port=%s",
        settings.host,
        settings.port,
    )

    import uvicorn

    from main import create_app
    from utils.server import DiagnosticServer

    # 一个节点一个 ASGI 进程；各会话及命令可独立运行。
    config = uvicorn.Config(
        create_app(settings),
        host=settings.host,
        port=settings.port,
        workers=1,
        log_config=None,
        timeout_graceful_shutdown=int(settings.cancel_grace_seconds + 10),
    )
    server = DiagnosticServer(config)
    server.run()
    if not server.started:
        logger.error("应用未完成启动 exit_code=3")
        raise SystemExit(3)
    if server.lifespan.shutdown_failed:
        logger.error("应用关闭失败 exit_code=1")
        raise SystemExit(1)
    logger.info("服务已正常退出 exit_code=0")
    return 0


if __name__ == "__main__":
    sys.exit(main())
