import io
import logging
import re
import shutil
import stat
import tempfile
import zipfile
from pathlib import Path, PureWindowsPath
from uuid import uuid4

import yaml

from utils.async_tools import to_thread
from utils.errors import AppError
from utils.paths import safe_path

logger = logging.getLogger(__name__)

MAX_ARCHIVE_BYTES = 16 * 1024 * 1024
MAX_TOTAL_BYTES = 64 * 1024 * 1024
MAX_ENTRY_BYTES = 16 * 1024 * 1024
MAX_ENTRIES = 512


class SkillService:
    def __init__(self, files):
        self.files = files

    @staticmethod
    def skill_path(name):
        if (
            not isinstance(name, str)
            or not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name)
            or len(name) > 64
        ):
            raise AppError(400, "Skill 名称格式无效")
        return f".cac/skills/{name}"

    def metadata(self, name, content):
        self.files.check_content(content)
        lines = content.splitlines()
        if not lines or lines[0] != "---":
            raise AppError(400, "SKILL.md 必须以 YAML front matter 开始")
        try:
            end = lines.index("---", 1)
            metadata = yaml.safe_load("\n".join(lines[1:end]))
        except (ValueError, yaml.YAMLError) as exc:
            raise AppError(400, "SKILL.md 的 YAML front matter 无效") from exc
        if not isinstance(metadata, dict):
            raise AppError(400, "SKILL.md 的 YAML front matter 无效")
        if name is None:
            name = metadata.get("name")
        self.skill_path(name)
        if (
            metadata.get("name") != name
            or not isinstance(metadata.get("description"), str)
            or not metadata["description"].strip()
        ):
            raise AppError(400, "front matter 的 name 必须与目录一致，description 不得为空")
        return {"name": name, "description": metadata["description"]}

    @staticmethod
    def archive_parts(info):
        name = info.filename
        if not name or name.startswith("/") or "\\" in name or "\x00" in name:
            raise AppError(400, "ZIP 包含非法路径")
        parts = name.rstrip("/").split("/")
        if any(part in ("", ".", "..") or ":" in part for part in parts):
            raise AppError(400, "ZIP 包含非法路径")
        if PureWindowsPath(name).drive:
            raise AppError(400, "ZIP 包含非法路径")
        kind = stat.S_IFMT(info.external_attr >> 16)
        if kind not in (0, stat.S_IFDIR if info.is_dir() else stat.S_IFREG):
            raise AppError(400, "ZIP 不允许符号链接或特殊文件")
        if info.flag_bits & 1:
            raise AppError(400, "ZIP 不支持加密文件")
        return tuple(parts)

    def unpack(self, data, expected_name=None):
        if not data or len(data) > MAX_ARCHIVE_BYTES:
            raise AppError(413, "Skill ZIP 不能为空或超过 16 MiB")
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                infos = archive.infolist()
                if len(infos) > MAX_ENTRIES:
                    raise AppError(413, "Skill ZIP 文件数量超过限制")
                files, directories, seen, total = {}, set(), set(), 0
                for info in infos:
                    parts = self.archive_parts(info)
                    folded = "/".join(parts).casefold()
                    if folded in seen:
                        raise AppError(400, "ZIP 包含重复路径")
                    seen.add(folded)
                    if info.is_dir():
                        directories.add(parts)
                        continue
                    if info.file_size > MAX_ENTRY_BYTES or total + info.file_size > MAX_TOTAL_BYTES:
                        raise AppError(413, "Skill ZIP 解压后超过大小限制")
                    with archive.open(info) as source:
                        content = source.read(MAX_ENTRY_BYTES + 1)
                    total += len(content)
                    if len(content) > MAX_ENTRY_BYTES or total > MAX_TOTAL_BYTES:
                        raise AppError(413, "Skill ZIP 解压后超过大小限制")
                    files[parts] = content
        except (zipfile.BadZipFile, RuntimeError, EOFError, NotImplementedError, ValueError) as exc:
            raise AppError(400, "无效的 Skill ZIP 文件") from exc

        manifests = [parts for parts in files if parts[-1] == "SKILL.md"]
        if len(manifests) != 1:
            raise AppError(400, "ZIP 必须包含且只包含一个 SKILL.md")
        prefix = manifests[0][:-1]
        if (
            len(prefix) > 3
            or (len(prefix) == 2 and prefix[0] != "skills")
            or (len(prefix) == 3 and prefix[:2] != (".cac", "skills"))
        ):
            raise AppError(400, "ZIP 目录应为 Skill 名称/SKILL.md")
        for parts in directories:
            if prefix and parts[: len(prefix)] != prefix and prefix[: len(parts)] != parts:
                raise AppError(400, "ZIP 只能包含一个 Skill 目录")
        for parts in files:
            if any(parts[:index] in files for index in range(1, len(parts))):
                raise AppError(400, "ZIP 文件与目录路径冲突")
        try:
            content = files[manifests[0]].decode("utf-8")
        except UnicodeError as exc:
            raise AppError(400, "SKILL.md 必须是 UTF-8 文本") from exc
        metadata = self.metadata(None, content)
        name = metadata["name"]
        if (prefix and prefix[-1] != name) or (expected_name and expected_name != name):
            raise AppError(400, "ZIP 目录、SKILL.md 名称与目标 Skill 必须一致")
        extracted = {}
        for parts, content in files.items():
            if parts[: len(prefix)] != prefix or len(parts) <= len(prefix):
                raise AppError(400, "ZIP 只能包含一个 Skill 目录")
            extracted[parts[len(prefix) :]] = content
        return metadata, extracted

    async def list(self, workspace_id):
        listing = await self.files.list(workspace_id, ".cac/skills")
        items = []
        for child in listing["items"]:
            if child["type"] == "directory" and not child["name"].startswith("."):
                try:
                    item = await self.get(workspace_id, child["name"])
                    items.append(
                        {
                            "name": item["name"],
                            "description": item["description"],
                            "files": item["files"],
                        }
                    )
                except AppError as exc:
                    items.append({"name": child["name"], "error": exc.detail})
        return {"items": items, "total": len(items)}

    async def get(self, workspace_id, name):
        relative = self.skill_path(name)

        def operation(root):
            directory = safe_path(root, relative)
            manifest = safe_path(root, relative + "/SKILL.md")
            if not manifest.is_file():
                raise AppError(404, "SKILL.md 不存在")
            if manifest.stat().st_size > self.files.settings.max_file_bytes:
                raise AppError(413, "SKILL.md 超过文件大小限制")
            try:
                content = manifest.read_text(encoding="utf-8")
            except UnicodeError as exc:
                raise AppError(415, "SKILL.md 必须是 UTF-8 文本") from exc
            metadata = self.metadata(name, content)
            paths = []
            for item in directory.rglob("*"):
                safe_path(root, item.relative_to(root).as_posix())
                if item.is_file():
                    paths.append(item.relative_to(directory).as_posix())
            return {**metadata, "content": content, "files": sorted(paths)}

        return await self.files._operate(workspace_id, operation)

    async def install(self, workspace_id, data, *, expected_name=None):
        metadata, contents = await to_thread(self.unpack, data, expected_name)
        relative = self.skill_path(metadata["name"])

        def operation(root):
            parent = safe_path(root, ".cac/skills")
            target = safe_path(root, relative)
            if expected_name and not target.is_dir():
                raise AppError(404, "Skill 不存在")
            if not expected_name and target.exists():
                raise AppError(409, "Skill 已存在")
            staging = Path(tempfile.mkdtemp(prefix=".skill-", dir=parent))
            backup = None
            try:
                for parts, content in contents.items():
                    file = staging.joinpath(*parts)
                    file.parent.mkdir(parents=True, exist_ok=True)
                    with file.open("xb") as output:
                        output.write(content)
                if expected_name:
                    backup = parent / (".skill-backup-" + uuid4().hex)
                    target.rename(backup)
                try:
                    staging.rename(target)
                except BaseException:
                    if backup:
                        backup.rename(target)
                    raise
                if backup:
                    try:
                        shutil.rmtree(backup)
                    except OSError:
                        logger.exception("清理旧 Skill 目录失败 path=%s", backup)
                return {**metadata, "files": sorted("/".join(parts) for parts in contents)}
            finally:
                if staging.exists():
                    shutil.rmtree(staging)

        return await self.files._operate(workspace_id, operation)

    async def delete(self, workspace_id, name):
        return await self.files.delete(workspace_id, self.skill_path(name))
