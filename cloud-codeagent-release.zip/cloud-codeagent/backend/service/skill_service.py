import re

import yaml

from utils.errors import AppError
from utils.paths import atomic_write, safe_path


class SkillService:
    def __init__(self, files):
        self.files = files

    @staticmethod
    def skill_path(name):
        if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name) or len(name) > 64:
            raise AppError(400, "Skill 名称格式无效")
        return f".cac/skills/{name}"

    def metadata(self, name, content):
        self.files.check_content(content)
        lines = content.splitlines()
        if not lines or lines[0] != "---":
            raise AppError(400, "SKILL.md 必须以 YAML front matter 开始")
        try:
            end = lines.index("---", 1)
            metadata = yaml.safe_load("\n".join(lines[1:end]))
        except (ValueError, yaml.YAMLError) as exc:
            raise AppError(400, "SKILL.md 的 YAML front matter 无效") from exc
        if (
            not isinstance(metadata, dict)
            or metadata.get("name") != name
            or not isinstance(metadata.get("description"), str)
            or not metadata["description"].strip()
        ):
            raise AppError(400, "front matter 的 name 必须与路径一致，description 不得为空")
        return {"name": name, "description": metadata["description"]}

    async def list(self, workspace_id):
        listing = await self.files.list(workspace_id, ".cac/skills")
        items = []
        for child in listing["items"]:
            if child["type"] == "directory":
                try:
                    item = await self.get(workspace_id, child["name"])
                    items.append({"name": item["name"], "description": item["description"]})
                except AppError as exc:
                    items.append({"name": child["name"], "error": exc.detail})
        return {"items": items, "total": len(items)}

    async def get(self, workspace_id, name):
        file = await self.files.read(workspace_id, self.skill_path(name) + "/SKILL.md")
        return {**self.metadata(name, file["content"]), "content": file["content"]}

    async def create(self, workspace_id, body):
        metadata = self.metadata(body.name, body.content)
        relative = self.skill_path(body.name)

        def operation(root):
            directory = safe_path(root, relative)
            directory.parent.mkdir(parents=True, exist_ok=True)
            directory.mkdir()
            try:
                atomic_write(directory / "SKILL.md", body.content)
            except BaseException:
                (directory / "SKILL.md").unlink(missing_ok=True)
                directory.rmdir()
                raise
            return {**metadata, "content": body.content}

        return await self.files._operate(workspace_id, operation)

    async def delete(self, workspace_id, name):
        return await self.files.delete(workspace_id, self.skill_path(name))
