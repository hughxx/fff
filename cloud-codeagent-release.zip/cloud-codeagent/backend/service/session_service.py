import asyncio
import contextlib
import json
import logging
import random
import time
from dataclasses import dataclass, field
from typing import Dict, Optional
from uuid import uuid4
from sqlalchemy import or_, select


from dao.account_dao import AccountDao
from dao.session_dao import SessionDao
from dao.workspace_dao import WorkspaceDao
from entity.models import Account, AgentSession, SessionMessage, WorkspaceAccount, SessionTask, SessionTaskEvent
from utils.codeagent import drain_tail, stop_process
from utils.errors import AppError
from utils.execution_log import ExecutionLog
from utils.transcript import Transcript
from utils.detached_tasks import launch, alive, request_cancel
from utils.async_tools import to_thread
from utils.python_runtime import python_env
from utils.serialization import record, session_record

logger = logging.getLogger(__name__)


@dataclass
class Execution:
    queue: asyncio.Queue
    started: asyncio.Event = field(default_factory=asyncio.Event)
    done: asyncio.Event = field(default_factory=asyncio.Event)
    process: object = None
    task: Optional[asyncio.Task] = None
    cancelled: bool = False
    finishing: bool = False
    log: object = None
    task_id: Optional[str] = None
    sequence: int = 0
    error: Optional[AppError] = None
    result: Optional[dict] = None
    final_line: Optional[bytes] = None


class SessionService:
    def __init__(self, database, settings, nodes, accounts, workspaces, cli):
        self.db, self.settings, self.nodes = database, settings, nodes
        self.accounts, self.workspaces, self.cli = accounts, workspaces, cli
        self.dao = SessionDao()
        self.executions: Dict[str, Execution] = {}
        self.worker_processes = []
        self.worker_monitor = None
        self.detached_count = 0
        self.launching = set()

    def running_count(self):
        return self.detached_count + sum(
            entry.process is not None and entry.process.returncode is None
            for entry in self.executions.values()
        )

    @contextlib.asynccontextmanager
    async def _slot(self, entry):
        try:
            yield
        finally:
            entry.finishing = True
            if entry.process:
                drain = asyncio.create_task(drain_tail(
                    entry.process.stdout,
                    on_chunk=lambda chunk: entry.log.output('stdout', chunk) if entry.log else None,
                ))
                await stop_process(entry.process, self.settings.cancel_grace_seconds)
                await drain

    async def create(self, body):
        async with self.workspaces.mutation_lock:

            def insert(db):
                workspace = WorkspaceDao().get(db, body.workspace_id, lock=True)
                if workspace.node_id != self.nodes.node_id or workspace.status != "ready":
                    raise AppError(409, "工作区不属于本节点或尚未就绪")
                if body.account_id:
                    account_id = body.account_id
                else:
                    candidates = db.scalars(
                        select(WorkspaceAccount.account_id)
                        .join(Account, Account.id == WorkspaceAccount.account_id)
                        .where(
                            WorkspaceAccount.workspace_id == workspace.id,
                            WorkspaceAccount.available.is_(True),
                            Account.auth_status == "logged_in",
                            or_(Account.expires_at.is_(None), Account.expires_at > time.time() * 1000),
                        )
                    ).all()
                    if not candidates:
                        raise AppError(503, "工作区没有可用的已登录账号")
                    account_id = random.choice(candidates)
                link = db.get(WorkspaceAccount, (workspace.id, account_id))
                if link is None:
                    raise AppError(409, "账号未关联此工作区")
                if not link.available:
                    raise AppError(409, "此账号已在工作区停用，请先启用或选择其他账号")
                item = self.dao.add(
                    db,
                    id=f"sess_{uuid4().hex}",
                    workspace_id=workspace.id,
                    node_id=workspace.node_id,
                    account_id=account_id,
                    title=body.title,
                    create_user=body.created_by,
                )
                return session_record(item)

            return await self.db.run(insert)

    async def list(self, page, page_size, workspace_id=None, keyword=None, created_by=None):
        filters = []
        if workspace_id:
            filters.append(AgentSession.workspace_id == workspace_id)
        if keyword:
            filters.append(AgentSession.title.contains(keyword, autoescape=True))
        if created_by:
            filters.append(AgentSession.create_user == created_by)

        def query(db):
            items, total = self.dao.page(db, filters=filters, page=page, page_size=page_size)
            account_ids = {item.account_id for item in items}
            accounts = {a.id: a for a in db.scalars(select(Account).where(Account.id.in_(account_ids)))} if account_ids else {}
            return {"items": [self.account_view(item, accounts.get(item.account_id)) for item in items], "total": total}

        return await self.db.run(query)

    @staticmethod
    def account_view(session, account):
        result = session_record(session)
        result['account_name'] = account.account_name if account else None
        result['account_identity'] = account.account_id if account else None
        return result

    async def get(self, session_id):
        def query(db):
            session = self.dao.get(db, session_id)
            item = self.account_view(session, db.get(Account, session.account_id))
            item['active_task_id'] = db.scalar(select(SessionTask.id).where(
                SessionTask.session_id == session_id, SessionTask.status == 'running'))
            item["messages"] = [
                record(message, {"create_time": "created_at"})
                for message in self.dao.messages(db, session_id)
            ]
            return item

        return await self.db.run(query)

    async def start_message(self, session_id, text, stream, model=None):
        preparation = asyncio.create_task(self._prepare_message(session_id, text, stream, model))
        try:
            return await asyncio.shield(preparation)
        except asyncio.CancelledError:
            entry = await preparation
            await self.stop_entry(entry)
            raise

    async def create_task(self, session_id, text, model=None):
        task_id = f"task_{uuid4().hex}"
        preparation = asyncio.create_task(self._prepare_message(session_id, text, True, model, task_id))
        try:
            await asyncio.shield(preparation)
        except asyncio.CancelledError:
            # Submission disconnect must not cancel an accepted background task.
            await preparation
            raise
        return {"task_id": task_id, "session_id": session_id, "status": "running"}

    async def get_task(self, session_id, task_id):
        def query(db):
            task = db.get(SessionTask, task_id)
            if task is None or task.session_id != session_id:
                raise AppError(404, "任务不存在")
            result = record(task)
            result['task_id'] = result.pop('id')
            result['result'] = json.loads(task.result) if task.result else None
            return result
        return await self.db.run(query)

    async def cancel_task(self, session_id, task_id):
        await self.get_task(session_id, task_id)
        entry = self.executions.get(session_id)
        if entry and entry.task_id == task_id:
            await self.stop_entry(entry)
        else:
            await to_thread(request_cancel, self.settings, task_id)
            for _ in range(100):
                await self.recover_tasks()
                if (await self.get_task(session_id, task_id))['status'] != 'running':
                    break
                await asyncio.sleep(0.1)
        task = await self.get_task(session_id, task_id)
        return {"success": True, "task_id": task_id, "status": task['status']}

    async def task_events(self, session_id, task_id, after=0):
        # Durable cursor replay: subscribers neither own nor cancel execution.
        while True:
            def read(db):
                task = db.get(SessionTask, task_id)
                if task is None or task.session_id != session_id:
                    raise AppError(404, '任务不存在')
                rows = db.scalars(select(SessionTaskEvent).where(
                    SessionTaskEvent.task_id == task_id, SessionTaskEvent.sequence > after
                ).order_by(SessionTaskEvent.sequence).limit(200)).all()
                return [(r.sequence, r.payload) for r in rows], task.status, task.result, task.error
            rows, status, result, error = await self.db.run(read)
            for sequence, payload in rows:
                event = json.loads(payload)
                event['event_id'] = sequence
                yield (json.dumps(event, ensure_ascii=False) + '\n').encode()
                after = sequence
                if event.get('type') == 'result':
                    return
            if not rows and status != 'running':
                final = json.loads(result) if result else {
                    'type': 'result', 'is_error': True, 'result': error or '任务已结束',
                }
                final['event_id'] = after + 1
                yield (json.dumps(final, ensure_ascii=False) + '\n').encode()
                return
            if not rows:
                yield b'{"type":"heartbeat"}\n'
                await asyncio.sleep(1)

    async def recover_tasks(self):
        tasks = await self.db.run(lambda db: list(db.scalars(select(SessionTask).where(
            SessionTask.node_id == self.nodes.node_id, SessionTask.status == 'running'))))
        dead = [task.id for task in tasks if task.id not in self.launching
                and not await to_thread(alive, self.settings, task.id)]
        self.detached_count = len(tasks) - len(dead)
        def recover(db):
            for task in db.scalars(select(SessionTask).where(
                SessionTask.node_id == self.nodes.node_id,
                SessionTask.status == 'running',
                SessionTask.id.in_(dead),
            )):
                task.status = 'failed'
                task.error = '独立任务运行器已退出，执行中断'
                item = self.dao.get(db, task.session_id)
                item.status, item.current_pid = 'error', None
                db.add(SessionMessage(id=f'msg_{uuid4().hex}', session_id=task.session_id,
                                      role='system', content=task.error))
        await self.db.run(recover)

    async def start(self):
        await self.recover_tasks()
        async def monitor():
            while True:
                await asyncio.sleep(2)
                try:
                    self.worker_processes = [p for p in self.worker_processes if p.poll() is None]
                    await self.recover_tasks()
                except Exception:
                    logger.exception('独立任务状态检查失败')
        self.worker_monitor = asyncio.create_task(monitor())

    async def _prepare_message(self, session_id, text, stream, model, task_id=None):
        if task_id:
            self.launching.add(task_id)
        try:
            return await self._prepare_impl(session_id, text, stream, model, task_id)
        finally:
            self.launching.discard(task_id)

    async def _prepare_impl(self, session_id, text, stream, model, task_id=None):
        def claim(db):
            item = self.dao.claim(db, session_id, "running")
            workspace = WorkspaceDao().get(db, item.workspace_id)
            account = AccountDao().get(db, item.account_id)
            if workspace.status != "ready" or item.node_id != self.nodes.node_id:
                raise AppError(409, "会话工作区不可用")
            if account.auth_status != "logged_in" or (
                account.expires_at and account.expires_at <= time.time() * 1000
            ):
                raise AppError(409, "账号未登录或认证已过期")
            if not item.title:
                item.title = text[:100]
            db.add(
                SessionMessage(
                    id=f"msg_{uuid4().hex}", session_id=session_id, role="user", content=text
                )
            )
            link = db.get(WorkspaceAccount, (workspace.id, account.id))
            if link is None:
                raise AppError(409, "会话账号已从工作区移除")
            if not link.available:
                raise AppError(409, "此账号已在工作区停用，请先启用再继续会话")
            if task_id:
                db.add(SessionTask(id=task_id, session_id=session_id, node_id=item.node_id,
                                   input=text, model=model or link.default_model, status='running'))
            return item, workspace, account, link.default_model

        item, workspace, account, default_model = await self.db.run(claim)
        if task_id:
            try:
                process = await to_thread(launch, self.settings, task_id)
                self.worker_processes.append(process)
                self.detached_count += 1
            except Exception:
                logger.exception('独立任务启动失败: %s', task_id)
                def fail(db):
                    task = db.get(SessionTask, task_id)
                    task.status, task.error = 'failed', '独立任务启动失败'
                    self.dao.get(db, session_id).status = 'error'
                await self.db.run(fail)
                raise AppError(503, '独立任务启动失败')
            return None
        entry = Execution(queue=asyncio.Queue(maxsize=self.settings.stream_queue_size))
        entry.task_id = task_id
        self.executions[session_id] = entry
        entry.task = asyncio.create_task(
            self._execute(entry, item, workspace, account, text, stream, model or default_model)
        )
        await entry.started.wait()
        return entry

    async def _execute(self, entry, session, workspace, account, text, stream, model):
        stderr = None
        final = None
        status = "error"
        transcript = Transcript()
        try:
            entry.started.set()
            entry.log = ExecutionLog(self.workspaces.root(workspace), session.id)
            entry.log.write('start', platform_session_id=session.id,
                            codeagent_session_id=session.codeagent_session_id,
                            account_id=account.id, model=model, stream=stream,
                            python_version=workspace.python_version, input=text)
            # 同一会话仍保持独占执行；不同会话不限制并发。
            async with self._slot(entry):
                args = self.cli.message_args(
                    session.codeagent_session_id, text, stream, model
                )
                process = await self.cli.spawn(
                    args,
                    cwd=self.workspaces.root(workspace),
                    config_dir=self.accounts.config_path(account),
                    extra_env=python_env(self.settings, workspace.python_version),
                )
                entry.process = process
                entry.log.write('spawned', pid=process.pid,
                                command=[*self.settings.codeagent_command, *args])
                stderr = asyncio.create_task(drain_tail(
                    process.stderr, on_chunk=lambda chunk: entry.log.output('stderr', chunk)
                ))
                await self.db.run(
                    lambda db: setattr(self.dao.get(db, session.id), "current_pid", process.pid)
                )
                if stream:
                    while line := await process.stdout.readline():
                        entry.log.output('stdout', line)
                        if not line.strip():
                            continue
                        try:
                            event = json.loads(line)
                            if not isinstance(event, dict):
                                raise ValueError("expected object")
                        except (ValueError, UnicodeError) as exc:
                            raise AppError(502, "CodeAgent 返回了无效的 NDJSON") from exc
                        row = transcript.accept(event)
                        if row or (entry.task_id and event.get('type') != 'result'):
                            entry.sequence += 1
                            def save_partial(db):
                                if entry.task_id:
                                    db.add(SessionTaskEvent(task_id=entry.task_id, sequence=entry.sequence,
                                                            payload=json.dumps(event, ensure_ascii=False)))
                                if not row:
                                    return
                                message = db.get(SessionMessage, row['id'])
                                if message is None:
                                    message = SessionMessage(id=row['id'], session_id=session.id, role='assistant')
                                    db.add(message)
                                message.content = row['content']
                                message.raw_result = json.dumps(row['raw'], ensure_ascii=False)
                            await self.db.run(save_partial)
                        if event.get("type") == "result":
                            entry.log.write('result_received', result=event)
                            final = event
                            entry.final_line = line if line.endswith(b"\n") else line + b"\n"
                        elif not entry.task_id:
                            # 原始事件逐行转发；最终 result 在历史落库后才发送。
                            await entry.queue.put(
                                line if line.endswith(b"\n") else line + b"\n"
                            )
                else:
                    raw = bytearray()
                    while chunk := await process.stdout.read(65536):
                        entry.log.output('stdout', chunk)
                        raw.extend(chunk)
                        if len(raw) > self.settings.max_output_bytes:
                            raise AppError(502, "CodeAgent 返回内容超过限制")
                    try:
                        final = json.loads(raw)
                    except (ValueError, UnicodeError) as exc:
                        raise AppError(502, "CodeAgent 返回了无效的 JSON") from exc
                entry.log.write('stdout_closed')
                await process.wait()
                entry.log.write('process_exited', exit_code=process.returncode)
                await stderr
                entry.log.write('stderr_closed')
                if not isinstance(final, dict) or final.get("type") != "result":
                    raise AppError(502, "CodeAgent 未返回最终 result")
                if process.returncode != 0 and not final.get("is_error"):
                    raise AppError(502, f"CodeAgent 异常退出，退出码 {process.returncode}")
                cli_session_id = final.get("session_id")
                valid_id = isinstance(cli_session_id, str) and 0 < len(cli_session_id) <= 64
                if not valid_id and not (final.get("is_error") and cli_session_id is None):
                    raise AppError(502, "CodeAgent result 缺少有效的 session_id")
                status = "error" if final.get("is_error") else "idle"
        except asyncio.CancelledError:
            entry.cancelled, status = True, "cancelled"
            entry.error = AppError(409, "会话执行已取消")
        except AppError as exc:
            entry.error = exc
        except Exception:
            logger.exception("会话执行失败: %s", session.id)
            entry.error = AppError(502, "会话执行失败")
        finally:
            entry.finishing = True
            try:
                if entry.process:
                    await stop_process(entry.process, self.settings.cancel_grace_seconds)
                if stderr:
                    await stderr
                if entry.error:
                    final = {
                        "type": "result",
                        "subtype": "error_platform",
                        "is_error": True,
                        "result": entry.error.detail,
                        "session_id": session.codeagent_session_id,
                        "platform_session_id": session.id,
                    }

                def finish(db):
                    item = self.dao.get(db, session.id)
                    item.status, item.current_pid = status, None
                    if entry.task_id:
                        task = db.get(SessionTask, entry.task_id)
                        task.status = {'idle': 'success', 'cancelled': 'cancelled'}.get(status, 'failed')
                        task.result = json.dumps(final, ensure_ascii=False)
                        task.error = entry.error.detail if entry.error else (
                            str(final.get('result', '')) if final and final.get('is_error') else None
                        )
                        entry.sequence += 1
                        db.add(SessionTaskEvent(task_id=entry.task_id, sequence=entry.sequence,
                                                payload=json.dumps(final, ensure_ascii=False)))
                    if final and not entry.error and final.get("session_id"):
                        item.codeagent_session_id = final["session_id"]
                    match = transcript.final_match(final) if final and not entry.error else None
                    if match:
                        db.get(SessionMessage, match).raw_result = json.dumps(final, ensure_ascii=False)
                    else:
                        db.add(SessionMessage(
                            id=f"msg_{uuid4().hex}",
                            session_id=session.id,
                            role="system" if entry.error else "assistant",
                            content=str(final.get("result", "")) if final else "",
                            raw_result=json.dumps(final, ensure_ascii=False),
                        ))

                if entry.log:
                    entry.log.write('save_started', status=status, result=final)
                await self.db.run(finish)
                if entry.log:
                    entry.log.write('save_completed', status=status)
                entry.result = final
            except Exception:
                logger.exception("会话清理或结果保存失败: %s", session.id)
                entry.error = AppError(503, "会话结果保存失败，请检查数据库状态")
                if entry.task_id:
                    try:
                        def fail_task(db):
                            task = db.get(SessionTask, entry.task_id)
                            task.status, task.error = 'failed', entry.error.detail
                            item = self.dao.get(db, session.id)
                            item.status, item.current_pid = 'error', None
                        await self.db.run(fail_task)
                    except Exception:
                        logger.exception('异步任务失败状态保存失败: %s', entry.task_id)
            finally:
                if entry.log:
                    entry.log.write('finished', status=status,
                                    error=entry.error.detail if entry.error else None,
                                    exit_code=entry.process.returncode if entry.process else None)
                    entry.log.close()
                entry.done.set()
                self.executions.pop(session.id, None)

    async def result(self, entry):
        try:
            await asyncio.shield(entry.task)
        except asyncio.CancelledError:
            await self.stop_entry(entry)
            raise
        if entry.error:
            raise entry.error
        return entry.result

    async def events(self, entry):
        try:
            while not entry.done.is_set() or not entry.queue.empty():
                get = asyncio.create_task(entry.queue.get())
                done = asyncio.create_task(entry.done.wait())
                try:
                    await asyncio.wait([get, done], return_when=asyncio.FIRST_COMPLETED)
                    if get.done():
                        yield get.result()
                finally:
                    get.cancel()
                    done.cancel()
                    await asyncio.gather(get, done, return_exceptions=True)
            final = entry.result or {
                "type": "result",
                "subtype": "error_platform",
                "is_error": True,
                "result": entry.error.detail if entry.error else "执行失败",
            }
            yield (
                entry.final_line
                if entry.final_line and not entry.error
                else (json.dumps(final, ensure_ascii=False) + "\n").encode()
            )
        finally:
            # 断线立即取消，无独立 events API 或后台不可观测的运行。
            if not entry.done.is_set():
                cleanup = asyncio.create_task(self.stop_entry(entry))
                with contextlib.suppress(asyncio.CancelledError):
                    await asyncio.shield(cleanup)

    async def stop_entry(self, entry):
        if entry.task and not entry.task.done():
            if not entry.cancelled and not entry.finishing:
                entry.cancelled = True
                entry.task.cancel()
            await asyncio.shield(entry.task)

    async def cancel(self, session_id):
        task_id = await self.db.run(lambda db: db.scalar(select(SessionTask.id).where(
            SessionTask.session_id == session_id, SessionTask.status == 'running')))
        if task_id:
            result = await self.cancel_task(session_id, task_id)
            state = await self.db.run(lambda db: self.dao.get(db, session_id).status)
            return {'success': True, 'status': state}
        entry = self.executions.get(session_id)
        if entry:
            await self.stop_entry(entry)
            state = await self.db.run(lambda db: self.dao.get(db, session_id).status)
            return {"success": True, "status": state}
        session = await self.db.run(lambda db: self.dao.get(db, session_id))
        if session.status == "running":
            raise AppError(409, "本节点未找到执行进程；需检查节点状态")
        return {"success": True, "status": session.status}

    async def delete(self, session_id):
        def reserve(db):
            previous = self.dao.get(db, session_id, lock=True).status
            return self.dao.claim(db, session_id, "deleting"), previous

        item, previous = await self.db.run(reserve)
        try:
            cli_cleanup = True
            if item.codeagent_session_id:
                process = None
                try:
                    workspace = await self.db.run(lambda db: WorkspaceDao().get(db, item.workspace_id))
                    account = await self.db.run(lambda db: AccountDao().get(db, item.account_id))
                    process = await self.cli.spawn(
                        ["sessions", "delete", item.codeagent_session_id],
                        cwd=self.workspaces.root(workspace),
                        config_dir=self.accounts.config_path(account),
                        extra_env=python_env(self.settings, workspace.python_version),
                    )
                    await self.cli.collect(process, timeout=min(5, self.settings.command_timeout))
                except Exception:
                    cli_cleanup = False
                    logger.warning("CodeAgent 本地会话清理失败，继续删除平台会话 session_id=%s", session_id, exc_info=True)
                finally:
                    if process:
                        await stop_process(process, self.settings.cancel_grace_seconds)

            def remove(db):
                for task in db.scalars(select(SessionTask).where(SessionTask.session_id == session_id)):
                    db.delete(task)
                db.flush()
                self.dao.delete_messages(db, session_id)
                self.dao.delete(db, self.dao.get(db, session_id))

            await self.db.run(remove)
        except BaseException:
            await self.db.run(lambda db: setattr(self.dao.get(db, session_id), "status", previous))
            raise
        return {"success": True, "cli_cleanup": cli_cleanup}

    async def close(self):
        if self.worker_monitor:
            self.worker_monitor.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self.worker_monitor
        await asyncio.gather(
            *(self.stop_entry(entry) for entry in list(self.executions.values())),
            return_exceptions=True,
        )
