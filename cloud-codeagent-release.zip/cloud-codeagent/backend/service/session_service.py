import asyncio
import contextlib
import json
import logging
import time
from dataclasses import dataclass, field
from typing import Dict, Optional
from uuid import uuid4

from async_timeout import timeout as async_timeout

from dao.account_dao import AccountDao
from dao.session_dao import SessionDao
from dao.workspace_dao import WorkspaceDao
from entity.models import AgentSession, SessionMessage
from utils.codeagent import drain_tail, stop_process
from utils.errors import AppError
from utils.serialization import record, session_record

logger = logging.getLogger(__name__)


@dataclass
class Execution:
    queue: asyncio.Queue
    started: asyncio.Event = field(default_factory=asyncio.Event)
    done: asyncio.Event = field(default_factory=asyncio.Event)
    process: object = None
    task: Optional[asyncio.Task] = None
    cancelled: bool = False
    finishing: bool = False
    error: Optional[AppError] = None
    result: Optional[dict] = None
    final_line: Optional[bytes] = None


class SessionService:
    def __init__(self, database, settings, nodes, accounts, workspaces, cli):
        self.db, self.settings, self.nodes = database, settings, nodes
        self.accounts, self.workspaces, self.cli = accounts, workspaces, cli
        self.dao = SessionDao()
        self.semaphore = asyncio.Semaphore(settings.concurrency)
        self.executions: Dict[str, Execution] = {}

    def running_count(self):
        return sum(
            entry.process is not None and entry.process.returncode is None
            for entry in self.executions.values()
        )

    @contextlib.asynccontextmanager
    async def _slot(self, entry):
        async with self.semaphore:
            try:
                yield
            finally:
                # 确认旧进程退出后才释放并发名额。
                entry.finishing = True
                if entry.process:
                    drain = asyncio.create_task(drain_tail(entry.process.stdout))
                    await stop_process(entry.process, self.settings.cancel_grace_seconds)
                    await drain

    async def create(self, body):
        async with self.workspaces.mutation_lock:

            def insert(db):
                workspace = WorkspaceDao().get(db, body.workspace_id, lock=True)
                if workspace.node_id != self.nodes.node_id or workspace.status != "ready":
                    raise AppError(409, "工作区不属于本节点或尚未就绪")
                item = self.dao.add(
                    db,
                    id=f"sess_{uuid4().hex}",
                    workspace_id=workspace.id,
                    node_id=workspace.node_id,
                    account_id=workspace.account_id,
                    title=body.title,
                    create_user=body.created_by,
                )
                return session_record(item)

            return await self.db.run(insert)

    async def list(self, page, page_size, workspace_id=None, keyword=None, created_by=None):
        filters = []
        if workspace_id:
            filters.append(AgentSession.workspace_id == workspace_id)
        if keyword:
            filters.append(AgentSession.title.contains(keyword, autoescape=True))
        if created_by:
            filters.append(AgentSession.create_user == created_by)

        def query(db):
            items, total = self.dao.page(db, filters=filters, page=page, page_size=page_size)
            return {"items": [session_record(item) for item in items], "total": total}

        return await self.db.run(query)

    async def get(self, session_id):
        def query(db):
            item = session_record(self.dao.get(db, session_id))
            item["messages"] = [
                record(message, {"create_time": "created_at"})
                for message in self.dao.messages(db, session_id)
            ]
            return item

        return await self.db.run(query)

    async def start_message(self, session_id, text, stream):
        preparation = asyncio.create_task(self._prepare_message(session_id, text, stream))
        try:
            return await asyncio.shield(preparation)
        except asyncio.CancelledError:
            entry = await preparation
            await self.stop_entry(entry)
            raise

    async def _prepare_message(self, session_id, text, stream):
        def claim(db):
            item = self.dao.claim(db, session_id, "running")
            workspace = WorkspaceDao().get(db, item.workspace_id)
            account = AccountDao().get(db, item.account_id)
            if workspace.status != "ready" or item.node_id != self.nodes.node_id:
                raise AppError(409, "会话工作区不可用")
            if account.auth_status != "logged_in" or (
                account.expires_at and account.expires_at <= time.time() * 1000
            ):
                raise AppError(409, "账号未登录或认证已过期")
            if not item.title:
                item.title = text[:100]
            db.add(
                SessionMessage(
                    id=f"msg_{uuid4().hex}", session_id=session_id, role="user", content=text
                )
            )
            return item, workspace, account

        item, workspace, account = await self.db.run(claim)
        entry = Execution(queue=asyncio.Queue(maxsize=self.settings.stream_queue_size))
        self.executions[session_id] = entry
        entry.task = asyncio.create_task(
            self._execute(entry, item, workspace, account, text, stream)
        )
        await entry.started.wait()
        return entry

    async def _execute(self, entry, session, workspace, account, text, stream):
        stderr = None
        final = None
        status = "error"
        try:
            entry.started.set()
            # 超时包含队列等待；排队状态也占用该 Session 的独占执行权。
            async with async_timeout(self.settings.message_timeout):
                async with self._slot(entry):
                    args = self.cli.message_args(session.codeagent_session_id, text, stream)
                    process = await self.cli.spawn(
                        args,
                        cwd=self.workspaces.root(workspace),
                        config_dir=self.accounts.config_path(account),
                    )
                    entry.process = process
                    stderr = asyncio.create_task(drain_tail(process.stderr))
                    await self.db.run(
                        lambda db: setattr(self.dao.get(db, session.id), "current_pid", process.pid)
                    )
                    if stream:
                        while line := await process.stdout.readline():
                            if not line.strip():
                                continue
                            try:
                                event = json.loads(line)
                                if not isinstance(event, dict):
                                    raise ValueError("expected object")
                            except (ValueError, UnicodeError) as exc:
                                raise AppError(502, "CodeAgent 返回了无效的 NDJSON") from exc
                            if event.get("type") == "result":
                                final = event
                                entry.final_line = line if line.endswith(b"\n") else line + b"\n"
                            else:
                                # 原始事件逐行转发；最终 result 在历史落库后才发送。
                                await entry.queue.put(
                                    line if line.endswith(b"\n") else line + b"\n"
                                )
                    else:
                        raw = bytearray()
                        while chunk := await process.stdout.read(65536):
                            raw.extend(chunk)
                            if len(raw) > self.settings.max_output_bytes:
                                raise AppError(502, "CodeAgent 返回内容超过限制")
                        try:
                            final = json.loads(raw)
                        except (ValueError, UnicodeError) as exc:
                            raise AppError(502, "CodeAgent 返回了无效的 JSON") from exc
                    await process.wait()
                    await stderr
                    if not isinstance(final, dict) or final.get("type") != "result":
                        raise AppError(502, "CodeAgent 未返回最终 result")
                    if process.returncode != 0 and not final.get("is_error"):
                        raise AppError(502, f"CodeAgent 异常退出，退出码 {process.returncode}")
                    cli_session_id = final.get("session_id")
                    valid_id = isinstance(cli_session_id, str) and 0 < len(cli_session_id) <= 64
                    if not valid_id and not (final.get("is_error") and cli_session_id is None):
                        raise AppError(502, "CodeAgent result 缺少有效的 session_id")
                    status = "error" if final.get("is_error") else "idle"
        except asyncio.CancelledError:
            entry.cancelled, status = True, "cancelled"
            entry.error = AppError(409, "会话执行已取消")
        except asyncio.TimeoutError:
            entry.error = AppError(504, "会话执行超时（包含排队等待）")
        except AppError as exc:
            entry.error = exc
        except Exception:
            logger.exception("会话执行失败: %s", session.id)
            entry.error = AppError(502, "会话执行失败")
        finally:
            entry.finishing = True
            try:
                if entry.process:
                    await stop_process(entry.process, self.settings.cancel_grace_seconds)
                if stderr:
                    await stderr
                if entry.error:
                    final = {
                        "type": "result",
                        "subtype": "error_platform",
                        "is_error": True,
                        "result": entry.error.detail,
                        "session_id": session.codeagent_session_id,
                        "platform_session_id": session.id,
                    }

                def finish(db):
                    item = self.dao.get(db, session.id)
                    item.status, item.current_pid = status, None
                    if final and not entry.error and final.get("session_id"):
                        item.codeagent_session_id = final["session_id"]
                    db.add(
                        SessionMessage(
                            id=f"msg_{uuid4().hex}",
                            session_id=session.id,
                            role="system" if entry.error else "assistant",
                            content=str(final.get("result", "")) if final else "",
                            raw_result=json.dumps(final, ensure_ascii=False),
                        )
                    )

                await self.db.run(finish)
                entry.result = final
            except Exception:
                logger.exception("会话清理或结果保存失败: %s", session.id)
                entry.error = AppError(503, "会话结果保存失败，请检查数据库状态")
            finally:
                entry.done.set()
                self.executions.pop(session.id, None)

    async def result(self, entry):
        try:
            await asyncio.shield(entry.task)
        except asyncio.CancelledError:
            await self.stop_entry(entry)
            raise
        if entry.error:
            raise entry.error
        return entry.result

    async def events(self, entry):
        try:
            while not entry.done.is_set() or not entry.queue.empty():
                get = asyncio.create_task(entry.queue.get())
                done = asyncio.create_task(entry.done.wait())
                try:
                    await asyncio.wait([get, done], return_when=asyncio.FIRST_COMPLETED)
                    if get.done():
                        yield get.result()
                finally:
                    get.cancel()
                    done.cancel()
                    await asyncio.gather(get, done, return_exceptions=True)
            final = entry.result or {
                "type": "result",
                "subtype": "error_platform",
                "is_error": True,
                "result": entry.error.detail if entry.error else "执行失败",
            }
            yield (
                entry.final_line
                if entry.final_line and not entry.error
                else (json.dumps(final, ensure_ascii=False) + "\n").encode()
            )
        finally:
            # 断线立即取消，无独立 events API 或后台不可观测的运行。
            if not entry.done.is_set():
                cleanup = asyncio.create_task(self.stop_entry(entry))
                with contextlib.suppress(asyncio.CancelledError):
                    await asyncio.shield(cleanup)

    async def stop_entry(self, entry):
        if entry.task and not entry.task.done():
            if not entry.cancelled and not entry.finishing:
                entry.cancelled = True
                entry.task.cancel()
            await asyncio.shield(entry.task)

    async def cancel(self, session_id):
        entry = self.executions.get(session_id)
        if entry:
            await self.stop_entry(entry)
            state = await self.db.run(lambda db: self.dao.get(db, session_id).status)
            return {"success": True, "status": state}
        session = await self.db.run(lambda db: self.dao.get(db, session_id))
        if session.status == "running":
            raise AppError(409, "本节点未找到执行进程；需检查节点状态")
        return {"success": True, "status": session.status}

    async def delete(self, session_id):
        def reserve(db):
            previous = self.dao.get(db, session_id, lock=True).status
            return self.dao.claim(db, session_id, "deleting"), previous

        item, previous = await self.db.run(reserve)
        try:
            if item.codeagent_session_id:
                workspace = await self.db.run(lambda db: WorkspaceDao().get(db, item.workspace_id))
                account = await self.db.run(lambda db: AccountDao().get(db, item.account_id))
                process = await self.cli.spawn(
                    ["sessions", "delete", item.codeagent_session_id],
                    cwd=self.workspaces.root(workspace),
                    config_dir=self.accounts.config_path(account),
                )
                await self.cli.collect(process)

            def remove(db):
                self.dao.delete_messages(db, session_id)
                self.dao.delete(db, self.dao.get(db, session_id))

            await self.db.run(remove)
        except BaseException:
            await self.db.run(lambda db: setattr(self.dao.get(db, session_id), "status", previous))
            raise
        return {"success": True}

    async def close(self):
        await asyncio.gather(
            *(self.stop_entry(entry) for entry in list(self.executions.values())),
            return_exceptions=True,
        )
