import asyncio
from pathlib import Path

from dao.workspace_dao import WorkspaceDao
from entity.models import Workspace
from utils.async_tools import to_thread
from utils.errors import AppError
from utils.paths import remove_managed_dir, safe_path
from utils.serialization import workspace_record


class WorkspaceService:
    def __init__(self, database, settings, nodes, accounts):
        self.db, self.settings, self.nodes = database, settings, nodes
        self.accounts = accounts
        self.dao = WorkspaceDao()
        self.mutation_lock = asyncio.Lock()

    async def list(self, page, page_size, node_id=None):
        filters = []
        if node_id:
            filters.append(Workspace.node_id == node_id)

        def query(db):
            items, total = self.dao.page(db, filters=filters, page=page, page_size=page_size)
            return {"items": [workspace_record(item) for item in items], "total": total}

        return await self.db.run(query)

    async def get(self, workspace_id):
        return await self.db.run(lambda db: workspace_record(self.dao.get(db, workspace_id)))

    async def local(self, workspace_id):
        workspace = await self.db.run(lambda db: self.dao.get(db, workspace_id))
        if workspace.node_id != self.nodes.node_id:
            raise AppError(409, "资源不属于本节点")
        if workspace.status != "ready":
            raise AppError(409, "工作区尚未就绪")
        return workspace

    def root(self, workspace):
        path = safe_path(self.settings.workspaces_dir, workspace.id)
        if path.resolve() != Path(workspace.workspace_path).resolve():
            raise AppError(409, "工作区目录与当前节点配置不一致")
        return path

    async def create(self, body):
        if body.node_id and body.node_id != self.nodes.node_id:
            raise AppError(409, "目标节点与当前节点不一致")
        root = safe_path(self.settings.workspaces_dir, body.name)
        if root.exists():
            raise AppError(409, "工作区目录已存在，不自动接管本地文件")
        async with self.accounts.mutation_lock:

            def reserve(db):
                account = self.accounts.allocate_for_workspace(db)
                return self.dao.add(
                    db,
                    id=body.name,
                    name=body.name,
                    node_id=account.node_id,
                    account_id=account.id,
                    workspace_path=str(root),
                    status="creating",
                )

            workspace = await self.db.run(reserve)
        try:
            root.mkdir(mode=0o700)
            for name in ("skills", "mcp", "agents", "hooks"):
                (root / ".cac" / name).mkdir(parents=True)
            await self.db.run(lambda db: setattr(self.dao.get(db, workspace.id), "status", "ready"))
        except BaseException:
            await self.db.run(lambda db: setattr(self.dao.get(db, workspace.id), "status", "error"))
            raise
        return await self.get(workspace.id)

    async def delete(self, workspace_id):
        async with self.mutation_lock:

            def reserve(db):
                workspace = self.dao.get(db, workspace_id, lock=True)
                if workspace.status in {"creating", "deleting"}:
                    raise AppError(409, "工作区正在创建或删除")
                if self.dao.has_sessions(db, workspace_id):
                    raise AppError(409, "请先删除工作区关联的会话")
                workspace.status = "deleting"
                return workspace

            workspace = await self.db.run(reserve)
            try:
                await to_thread(
                    remove_managed_dir, self.settings.workspaces_dir, self.root(workspace)
                )
                await self.db.run(lambda db: self.dao.delete(db, self.dao.get(db, workspace_id)))
            except BaseException:
                await self.db.run(
                    lambda db: setattr(self.dao.get(db, workspace_id), "status", "error")
                )
                raise
        return {"success": True}
