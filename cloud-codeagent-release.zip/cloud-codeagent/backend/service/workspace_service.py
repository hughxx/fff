import asyncio
from sqlalchemy import select

from dao.workspace_dao import WorkspaceDao
from entity.models import AgentSession, CommandTask, Workspace, WorkspaceAccount
from utils.async_tools import to_thread
from utils.errors import AppError
from utils.paths import remove_managed_dir, safe_path
from utils.python_runtime import python_env
from utils.serialization import workspace_record


class WorkspaceService:
    def __init__(self, database, settings, nodes, accounts):
        self.db, self.settings, self.nodes = database, settings, nodes
        self.accounts = accounts
        self.dao = WorkspaceDao()
        self.mutation_lock = asyncio.Lock()

    async def list(self, page, page_size, node_id=None):
        filters = []
        if node_id:
            filters.append(Workspace.node_id == node_id)

        def query(db):
            items, total = self.dao.page(db, filters=filters, page=page, page_size=page_size)
            return {"items": [self.view(db, item) for item in items], "total": total}

        return await self.db.run(query)

    async def get(self, workspace_id):
        return await self.db.run(lambda db: self.view(db, self.dao.get(db, workspace_id)))

    def view(self, db, workspace):
        result = workspace_record(workspace)
        links = db.scalars(
            select(WorkspaceAccount).where(WorkspaceAccount.workspace_id == workspace.id)
        ).all()
        result["accounts"] = [
            {"account_id": link.account_id, "default_model": link.default_model}
            for link in links
        ]
        return result

    async def local(self, workspace_id):
        workspace = await self.db.run(lambda db: self.dao.get(db, workspace_id))
        if workspace.node_id != self.nodes.node_id:
            raise AppError(409, "资源不属于本节点")
        if workspace.status != "ready":
            raise AppError(409, "工作区尚未就绪")
        return workspace

    def root(self, workspace):
        return safe_path(self.settings.workspaces_dir, workspace.id)

    async def create(self, body):
        python_env(self.settings, body.python_version)
        root = safe_path(self.settings.workspaces_dir, body.name)
        if root.exists():
            raise AppError(409, "工作区目录已存在，不自动接管本地文件")
        async with self.accounts.mutation_lock:

            def reserve(db):
                account = self.accounts.select_for_workspace(db, body.account_id)
                workspace = self.dao.add(
                    db,
                    id=body.name,
                    name=body.name,
                    node_id=account.node_id,
                    account_id=account.id,
                    python_version=body.python_version,
                    status="creating",
                )
                db.add(WorkspaceAccount(workspace_id=workspace.id, account_id=account.id))
                return workspace

            workspace = await self.db.run(reserve)
        try:
            root.mkdir(mode=0o700)
            for name in ("skills", "mcp", "agents", "hooks"):
                (root / ".cac" / name).mkdir(parents=True)
            await self.db.run(lambda db: setattr(self.dao.get(db, workspace.id), "status", "ready"))
        except BaseException:
            await self.db.run(lambda db: setattr(self.dao.get(db, workspace.id), "status", "error"))
            raise
        return await self.get(workspace.id)

    async def set_python_version(self, workspace_id, version):
        # 子进程在启动时复制环境；已运行的命令不受这次修改影响。
        python_env(self.settings, version)
        async with self.mutation_lock:
            def update(db):
                workspace = self.dao.get(db, workspace_id, lock=True)
                if workspace.status != "ready":
                    raise AppError(409, "工作区尚未就绪")
                workspace.python_version = version

            await self.db.run(update)
        return await self.get(workspace_id)

    async def delete(self, workspace_id):
        async with self.mutation_lock:

            def reserve(db):
                workspace = self.dao.get(db, workspace_id, lock=True)
                if workspace.status in {"creating", "deleting"}:
                    raise AppError(409, "工作区正在创建或删除")
                if self.dao.has_sessions(db, workspace_id):
                    raise AppError(409, "请先删除工作区关联的会话")
                if db.scalar(
                    select(CommandTask.id)
                    .where(
                        CommandTask.workspace_id == workspace_id,
                        CommandTask.status.in_(("queued", "running")),
                    )
                    .limit(1)
                ):
                    raise AppError(409, "请先取消工作区正在执行的命令任务")
                workspace.status = "deleting"
                return workspace

            workspace = await self.db.run(reserve)
            try:
                await to_thread(
                    remove_managed_dir, self.settings.workspaces_dir, self.root(workspace)
                )
                def finish(db):
                    for link in db.scalars(select(WorkspaceAccount).where(WorkspaceAccount.workspace_id == workspace_id)):
                        db.delete(link)
                    self.dao.delete(db, self.dao.get(db, workspace_id))

                await self.db.run(finish)
            except BaseException:
                await self.db.run(
                    lambda db: setattr(self.dao.get(db, workspace_id), "status", "error")
                )
                raise
        return {"success": True}

    async def add_account(self, workspace_id, account_id):
        async with self.accounts.mutation_lock:
            def update(db):
                workspace = self.dao.get(db, workspace_id, lock=True)
                account = self.accounts.select_for_workspace(db, account_id)
                if workspace.node_id != account.node_id:
                    raise AppError(409, "账号与工作区必须属于同一节点")
                if db.get(WorkspaceAccount, (workspace_id, account_id)):
                    raise AppError(409, "账号已关联工作区")
                db.add(WorkspaceAccount(workspace_id=workspace_id, account_id=account_id))

            await self.db.run(update)
        return await self.get(workspace_id)

    async def remove_account(self, workspace_id, account_id):
        def update(db):
            workspace = self.dao.get(db, workspace_id, lock=True)
            link = db.get(WorkspaceAccount, (workspace_id, account_id))
            if link is None:
                raise AppError(404, "工作区未关联此账号")
            if db.scalar(select(AgentSession.id).where(AgentSession.workspace_id == workspace_id, AgentSession.account_id == account_id).limit(1)):
                raise AppError(409, "请先删除该账号在工作区中的会话")
            links = db.scalars(select(WorkspaceAccount).where(WorkspaceAccount.workspace_id == workspace_id)).all()
            if len(links) == 1:
                raise AppError(409, "工作区至少保留一个账号")
            db.delete(link)
            if workspace.account_id == account_id:
                workspace.account_id = next(item.account_id for item in links if item.account_id != account_id)

        await self.db.run(update)
        return await self.get(workspace_id)

    async def set_model(self, workspace_id, account_id, model):
        def update(db):
            self.dao.get(db, workspace_id)
            link = db.get(WorkspaceAccount, (workspace_id, account_id))
            if link is None:
                raise AppError(404, "工作区未关联此账号")
            link.default_model = model

        await self.db.run(update)
        return await self.get(workspace_id)
