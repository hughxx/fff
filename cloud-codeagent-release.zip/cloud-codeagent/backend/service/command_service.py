import asyncio
import contextlib
import logging
import os
import subprocess
from dataclasses import dataclass, field
from typing import Dict, Optional
from uuid import uuid4

from sqlalchemy import select

from dao.command_task_dao import CommandTaskDao
from entity.models import CommandTask
from utils.codeagent import stop_process
from utils.async_tools import to_thread
from utils.detached_tasks import launch, alive, request_cancel
from utils.errors import AppError
from utils.python_runtime import python_env
from utils.serialization import record

logger = logging.getLogger(__name__)


@dataclass
class CommandExecution:
    stdout: bytearray = field(default_factory=bytearray)
    stderr: bytearray = field(default_factory=bytearray)
    process: object = None
    task: Optional[asyncio.Task] = None
    cancelled: bool = False


class CommandService:
    def __init__(self, database, settings, nodes, workspaces):
        self.db, self.settings, self.nodes = database, settings, nodes
        self.workspaces = workspaces
        self.dao = CommandTaskDao()
        self.executions: Dict[str, CommandExecution] = {}
        self.launching = set()
        self.worker_processes = []
        self.monitor = None
        self.active_count = 0

    def running_count(self):
        return self.active_count

    async def recover(self):
        tasks = await self.db.run(lambda db: db.scalars(select(CommandTask).where(
            CommandTask.node_id == self.nodes.node_id,
            CommandTask.status.in_(("queued", "running")),
        )).all())
        self.active_count = len(tasks)
        for task in tasks:
            if task.id in self.launching or await to_thread(alive, self.settings, task.id):
                continue
            def fail(db):
                item = self.dao.get(db, task.id, lock=True)
                if item.status in ('queued', 'running'):
                    item.status, item.current_pid = 'failed', None
                    item.stderr = (item.stderr or '') + '\nCommand worker exited before completion'
            await self.db.run(fail)

    async def start(self):
        await self.recover()
        if self.monitor:
            return
        async def monitor():
            while True:
                await asyncio.sleep(1)
                try:
                    self.worker_processes = [p for p in self.worker_processes if p.poll() is None]
                    await self.recover()
                except Exception:
                    logger.exception('Command worker recovery failed')
        self.monitor = asyncio.create_task(monitor())

    async def execute(self, workspace_id, body):
        _, cwd, env = await self._context(workspace_id)
        return await self._run(cwd, body.command, body.timeout_seconds, env)

    async def create_task(self, workspace_id, body):
        operation = asyncio.create_task(self._create_task(workspace_id, body))
        try:
            return await asyncio.shield(operation)
        except asyncio.CancelledError:
            await operation
            raise

    async def _create_task(self, workspace_id, body):
        async with self.workspaces.mutation_lock:
            return await self._create_task_locked(workspace_id, body)

    async def _create_task_locked(self, workspace_id, body):
        workspace, cwd, env = await self._context(workspace_id)
        task_id = f"task_{uuid4().hex}"

        self.launching.add(task_id)
        try:
            await self.db.run(
                lambda db: self.dao.add(
                    db,
                    id=task_id,
                    workspace_id=workspace.id,
                    node_id=workspace.node_id,
                    command=body.command,
                    timeout_seconds=body.timeout_seconds,
                    status="queued",
                    stdout="",
                    stderr="",
                    timed_out=False,
                )
            )
            process = await to_thread(launch, self.settings, task_id, 'utils.command_worker')
            self.worker_processes.append(process)
        except Exception:
            def fail_launch(db):
                item = db.get(CommandTask, task_id)
                if item:
                    item.status = 'failed'
                    item.stderr = 'Command worker could not be started'
            await self.db.run(fail_launch)
            raise
        finally:
            self.launching.discard(task_id)
        return {"task_id": task_id, "status": "queued"}

    async def get_task(self, workspace_id, task_id):
        item = await self.db.run(
            lambda db: self.dao.get_for_workspace(db, workspace_id, task_id)
        )
        result = self._task_record(item)
        execution = self.executions.get(task_id)
        if execution and result["status"] in {"queued", "running"}:
            result["stdout"] = execution.stdout.decode("utf-8", errors="replace")
            result["stderr"] = execution.stderr.decode("utf-8", errors="replace")
        return result

    async def list_tasks(self, workspace_id, page, page_size):
        await self.workspaces.local(workspace_id)
        def query(db):
            items, total = self.dao.page(db, filters=[CommandTask.workspace_id == workspace_id],
                                         page=page, page_size=page_size)
            # Summaries omit potentially large stdout/stderr; detail is fetched on selection.
            return {"items": [{k: v for k, v in self._task_record(item).items()
                               if k not in ('stdout', 'stderr')} for item in items], "total": total}
        return await self.db.run(query)

    async def cancel_task(self, workspace_id, task_id):
        item = await self.db.run(lambda db: self.dao.get_for_workspace(db, workspace_id, task_id))
        if item.status in ('queued', 'running'):
            await to_thread(request_cancel, self.settings, task_id)
            for _ in range(100):
                await self.recover()
                item = await self.db.run(lambda db: self.dao.get_for_workspace(db, workspace_id, task_id))
                if item.status not in ('queued', 'running'):
                    break
                await asyncio.sleep(0.1)
        return {"success": True, "status": item.status}

    async def _context(self, workspace_id):
        workspace = await self.workspaces.local(workspace_id)
        cwd = self.workspaces.root(workspace)
        if not cwd.is_dir():
            raise AppError(404, "工作区目录不存在")
        return workspace, cwd, python_env(self.settings, workspace.python_version)

    def _options(self):
        return (
            {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP}
            if os.name == "nt"
            else {"start_new_session": True}
        )

    async def _spawn(self, cwd, command, env):
        return await asyncio.create_subprocess_shell(
            command,
            cwd=str(cwd),
            env=env,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            **self._options(),
        )

    async def _collect(self, reader, output, total):
        while chunk := await reader.read(65536):
            total[0] += len(chunk)
            if total[0] > self.settings.max_output_bytes:
                raise AppError(413, "命令输出超过大小限制")
            output.extend(chunk)

    async def _run_process(self, process, timeout_seconds, stdout, stderr):
        total = [0]
        readers = [
            asyncio.create_task(self._collect(process.stdout, stdout, total)),
            asyncio.create_task(self._collect(process.stderr, stderr, total)),
        ]
        timed_out = False
        try:
            await asyncio.wait_for(
                asyncio.gather(*readers, process.wait()), timeout_seconds
            )
        except asyncio.TimeoutError:
            timed_out = True
            await stop_process(process, self.settings.cancel_grace_seconds)
        except BaseException:
            await stop_process(process, self.settings.cancel_grace_seconds)
            raise
        finally:
            for reader in readers:
                if not reader.done():
                    reader.cancel()
            await asyncio.gather(*readers, return_exceptions=True)
        return timed_out

    async def _run(self, cwd, command, timeout_seconds, env):
        process = await self._spawn(cwd, command, env)
        stdout, stderr = bytearray(), bytearray()
        timed_out = await self._run_process(process, timeout_seconds, stdout, stderr)
        return {
            "exit_code": process.returncode,
            "stdout": stdout.decode("utf-8", errors="replace"),
            "stderr": stderr.decode("utf-8", errors="replace"),
            "timed_out": timed_out,
        }

    async def _execute_task(self, task_id, cwd, command, timeout_seconds, env, execution):
        try:
            if execution.cancelled:
                await self._finish(
                    task_id, "cancelled", None, execution.stdout, execution.stderr, False
                )
                return
            process = await self._spawn(cwd, command, env)
            execution.process = process

            def running(db):
                item = self.dao.get(db, task_id)
                if item.status == "cancelled":
                    return False
                item.status, item.current_pid = "running", process.pid
                return True

            if not await self.db.run(running):
                execution.cancelled = True
                await stop_process(process, self.settings.cancel_grace_seconds)
                return
            timed_out = await self._run_process(
                process, timeout_seconds, execution.stdout, execution.stderr
            )
            status = (
                "cancelled"
                if execution.cancelled
                else "success"
                if process.returncode == 0 and not timed_out
                else "failed"
            )
            await self._finish(
                task_id,
                status,
                None if execution.cancelled else process.returncode,
                execution.stdout,
                execution.stderr,
                timed_out,
            )
        except asyncio.CancelledError:
            execution.cancelled = True
            if execution.process:
                await stop_process(execution.process, self.settings.cancel_grace_seconds)
            await self._finish(
                task_id, "cancelled", None, execution.stdout, execution.stderr, False
            )
            raise
        except Exception as exc:
            logger.exception("异步命令任务失败 task_id=%s", task_id)
            if execution.stderr:
                execution.stderr.extend(b"\n")
            execution.stderr.extend(str(exc).encode("utf-8", errors="replace"))
            await self._finish(
                task_id, "failed", None, execution.stdout, execution.stderr, False
            )
        finally:
            self.executions.pop(task_id, None)

    async def _finish(self, task_id, status, exit_code, stdout, stderr, timed_out):
        def finish(db):
            item = self.dao.get(db, task_id)
            if item.status == "cancelled":
                status_value, exit_value = "cancelled", None
            else:
                status_value, exit_value = status, exit_code
            item.status = status_value
            item.exit_code = exit_value
            item.stdout = stdout.decode("utf-8", errors="replace")
            item.stderr = stderr.decode("utf-8", errors="replace")
            item.timed_out = timed_out
            item.current_pid = None

        await self.db.run(finish)

    def _task_record(self, item):
        result = record(item, {"id": "task_id"})
        result.pop("current_pid", None)
        result.pop("node_id", None)
        return result

    async def close(self):
        if self.monitor:
            self.monitor.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self.monitor
            self.monitor = None
