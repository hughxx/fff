import asyncio
import os
import subprocess

from utils.codeagent import stop_process
from utils.errors import AppError
from utils.python_runtime import python_env


class CommandService:
    def __init__(self, settings, workspaces):
        self.settings = settings
        self.workspaces = workspaces
        self.semaphore = asyncio.Semaphore(settings.concurrency)

    async def execute(self, workspace_id, body):
        workspace = await self.workspaces.local(workspace_id)
        cwd = self.workspaces.root(workspace)
        if not cwd.is_dir():
            raise AppError(404, "工作区目录不存在")
        env = python_env(self.settings, workspace.python_version)
        async with self.semaphore:
            return await self._run(cwd, body, env)

    async def _run(self, cwd, body, env):
        options = (
            {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP}
            if os.name == "nt"
            else {"start_new_session": True}
        )
        process = await asyncio.create_subprocess_shell(
            body.command,
            cwd=str(cwd),
            env=env,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            **options,
        )
        stdout = bytearray()
        stderr = bytearray()
        total = 0

        async def collect(reader, output):
            nonlocal total
            while chunk := await reader.read(65536):
                total += len(chunk)
                if total > self.settings.max_output_bytes:
                    raise AppError(413, "命令输出超过大小限制")
                output.extend(chunk)

        readers = [
            asyncio.create_task(collect(process.stdout, stdout)),
            asyncio.create_task(collect(process.stderr, stderr)),
        ]
        timed_out = False
        try:
            await asyncio.wait_for(
                asyncio.gather(*readers, process.wait()), body.timeout_seconds
            )
        except asyncio.TimeoutError:
            timed_out = True
            await stop_process(process, self.settings.cancel_grace_seconds)
        except BaseException:
            await stop_process(process, self.settings.cancel_grace_seconds)
            raise
        finally:
            for reader in readers:
                if not reader.done():
                    reader.cancel()
            await asyncio.gather(*readers, return_exceptions=True)

        return {
            "exit_code": process.returncode,
            "stdout": stdout.decode("utf-8", errors="replace"),
            "stderr": stderr.decode("utf-8", errors="replace"),
            "timed_out": timed_out,
        }
