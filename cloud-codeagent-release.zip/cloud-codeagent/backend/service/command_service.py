import asyncio
import logging
import os
import subprocess
from dataclasses import dataclass, field
from typing import Dict, Optional
from uuid import uuid4

from sqlalchemy import update

from dao.command_task_dao import CommandTaskDao
from entity.models import CommandTask, utcnow
from utils.codeagent import stop_process
from utils.errors import AppError
from utils.python_runtime import python_env
from utils.serialization import record

logger = logging.getLogger(__name__)


@dataclass
class CommandExecution:
    stdout: bytearray = field(default_factory=bytearray)
    stderr: bytearray = field(default_factory=bytearray)
    process: object = None
    task: Optional[asyncio.Task] = None
    cancelled: bool = False


class CommandService:
    def __init__(self, database, settings, nodes, workspaces):
        self.db, self.settings, self.nodes = database, settings, nodes
        self.workspaces = workspaces
        self.dao = CommandTaskDao()
        self.executions: Dict[str, CommandExecution] = {}

    def running_count(self):
        return sum(
            entry.process is not None and entry.process.returncode is None
            for entry in self.executions.values()
        )

    async def start(self):
        def recover(db):
            db.execute(
                update(CommandTask)
                .where(
                    CommandTask.node_id == self.nodes.node_id,
                    CommandTask.status.in_(("queued", "running")),
                )
                .values(
                    status="failed",
                    current_pid=None,
                    stderr="服务重启，命令任务执行中断",
                    update_time=utcnow(),
                )
            )

        await self.db.run(recover)

    async def execute(self, workspace_id, body):
        _, cwd, env = await self._context(workspace_id)
        return await self._run(cwd, body.command, body.timeout_seconds, env)

    async def create_task(self, workspace_id, body):
        workspace, cwd, env = await self._context(workspace_id)
        task_id = f"task_{uuid4().hex}"

        await self.db.run(
            lambda db: self.dao.add(
                db,
                id=task_id,
                workspace_id=workspace.id,
                node_id=workspace.node_id,
                command=body.command,
                timeout_seconds=body.timeout_seconds,
                status="queued",
                stdout="",
                stderr="",
                timed_out=False,
            )
        )
        execution = CommandExecution()
        self.executions[task_id] = execution
        execution.task = asyncio.create_task(
            self._execute_task(task_id, cwd, body.command, body.timeout_seconds, env, execution)
        )
        return {"task_id": task_id, "status": "queued"}

    async def get_task(self, workspace_id, task_id):
        item = await self.db.run(
            lambda db: self.dao.get_for_workspace(db, workspace_id, task_id)
        )
        result = self._task_record(item)
        execution = self.executions.get(task_id)
        if execution and result["status"] in {"queued", "running"}:
            result["stdout"] = execution.stdout.decode("utf-8", errors="replace")
            result["stderr"] = execution.stderr.decode("utf-8", errors="replace")
        return result

    async def cancel_task(self, workspace_id, task_id):
        def cancel(db):
            item = self.dao.get_for_workspace(db, workspace_id, task_id, lock=True)
            if item.status in {"queued", "running"}:
                item.status = "cancelled"
                item.current_pid = None
            return item.status

        status = await self.db.run(cancel)
        execution = self.executions.get(task_id)
        if execution and status == "cancelled":
            execution.cancelled = True
            if execution.process:
                await stop_process(execution.process, self.settings.cancel_grace_seconds)
            if execution.task:
                await execution.task
        return {"success": True, "status": status}

    async def _context(self, workspace_id):
        workspace = await self.workspaces.local(workspace_id)
        cwd = self.workspaces.root(workspace)
        if not cwd.is_dir():
            raise AppError(404, "工作区目录不存在")
        return workspace, cwd, python_env(self.settings, workspace.python_version)

    def _options(self):
        return (
            {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP}
            if os.name == "nt"
            else {"start_new_session": True}
        )

    async def _spawn(self, cwd, command, env):
        return await asyncio.create_subprocess_shell(
            command,
            cwd=str(cwd),
            env=env,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            **self._options(),
        )

    async def _collect(self, reader, output, total):
        while chunk := await reader.read(65536):
            total[0] += len(chunk)
            if total[0] > self.settings.max_output_bytes:
                raise AppError(413, "命令输出超过大小限制")
            output.extend(chunk)

    async def _run_process(self, process, timeout_seconds, stdout, stderr):
        total = [0]
        readers = [
            asyncio.create_task(self._collect(process.stdout, stdout, total)),
            asyncio.create_task(self._collect(process.stderr, stderr, total)),
        ]
        timed_out = False
        try:
            await asyncio.wait_for(
                asyncio.gather(*readers, process.wait()), timeout_seconds
            )
        except asyncio.TimeoutError:
            timed_out = True
            await stop_process(process, self.settings.cancel_grace_seconds)
        except BaseException:
            await stop_process(process, self.settings.cancel_grace_seconds)
            raise
        finally:
            for reader in readers:
                if not reader.done():
                    reader.cancel()
            await asyncio.gather(*readers, return_exceptions=True)
        return timed_out

    async def _run(self, cwd, command, timeout_seconds, env):
        process = await self._spawn(cwd, command, env)
        stdout, stderr = bytearray(), bytearray()
        timed_out = await self._run_process(process, timeout_seconds, stdout, stderr)
        return {
            "exit_code": process.returncode,
            "stdout": stdout.decode("utf-8", errors="replace"),
            "stderr": stderr.decode("utf-8", errors="replace"),
            "timed_out": timed_out,
        }

    async def _execute_task(self, task_id, cwd, command, timeout_seconds, env, execution):
        try:
            if execution.cancelled:
                await self._finish(
                    task_id, "cancelled", None, execution.stdout, execution.stderr, False
                )
                return
            process = await self._spawn(cwd, command, env)
            execution.process = process

            def running(db):
                item = self.dao.get(db, task_id)
                if item.status == "cancelled":
                    return False
                item.status, item.current_pid = "running", process.pid
                return True

            if not await self.db.run(running):
                execution.cancelled = True
                await stop_process(process, self.settings.cancel_grace_seconds)
                return
            timed_out = await self._run_process(
                process, timeout_seconds, execution.stdout, execution.stderr
            )
            status = (
                "cancelled"
                if execution.cancelled
                else "success"
                if process.returncode == 0 and not timed_out
                else "failed"
            )
            await self._finish(
                task_id,
                status,
                None if execution.cancelled else process.returncode,
                execution.stdout,
                execution.stderr,
                timed_out,
            )
        except asyncio.CancelledError:
            execution.cancelled = True
            if execution.process:
                await stop_process(execution.process, self.settings.cancel_grace_seconds)
            await self._finish(
                task_id, "cancelled", None, execution.stdout, execution.stderr, False
            )
            raise
        except Exception as exc:
            logger.exception("异步命令任务失败 task_id=%s", task_id)
            if execution.stderr:
                execution.stderr.extend(b"\n")
            execution.stderr.extend(str(exc).encode("utf-8", errors="replace"))
            await self._finish(
                task_id, "failed", None, execution.stdout, execution.stderr, False
            )
        finally:
            self.executions.pop(task_id, None)

    async def _finish(self, task_id, status, exit_code, stdout, stderr, timed_out):
        def finish(db):
            item = self.dao.get(db, task_id)
            if item.status == "cancelled":
                status_value, exit_value = "cancelled", None
            else:
                status_value, exit_value = status, exit_code
            item.status = status_value
            item.exit_code = exit_value
            item.stdout = stdout.decode("utf-8", errors="replace")
            item.stderr = stderr.decode("utf-8", errors="replace")
            item.timed_out = timed_out
            item.current_pid = None

        await self.db.run(finish)

    def _task_record(self, item):
        result = record(item, {"id": "task_id"})
        result.pop("current_pid", None)
        result.pop("node_id", None)
        return result

    async def close(self):
        entries = list(self.executions.values())
        for entry in entries:
            entry.cancelled = True
            if entry.process:
                await stop_process(entry.process, self.settings.cancel_grace_seconds)
        await asyncio.gather(
            *(entry.task for entry in entries if entry.task), return_exceptions=True
        )
