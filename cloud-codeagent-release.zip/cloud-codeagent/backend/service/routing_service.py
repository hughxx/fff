from dao.account_dao import AccountDao
from dao.session_dao import SessionDao
from dao.workspace_dao import WorkspaceDao
from utils.proxy import forward_request


class RoutingService:
    def __init__(self, database, nodes, http_client):
        self.db, self.nodes, self.http = database, nodes, http_client
        self.daos = {"account": AccountDao(), "workspace": WorkspaceDao(), "session": SessionDao()}

    async def resource(self, request, kind, resource_id):
        resource = await self.db.run(lambda db: self.daos[kind].get(db, resource_id))
        return await self.node(request, resource.node_id)

    async def node(self, request, node_id, json_body=None):
        if node_id == self.nodes.node_id:
            return None
        node = await self.nodes.owner(node_id)
        return await forward_request(self.http, request, node, json_body=json_body)
