import asyncio
import contextlib
import logging
import socket
from datetime import timedelta
from uuid import uuid4

import psutil
from filelock import FileLock, Timeout

from dao.node_dao import NodeDao
from dao.session_dao import SessionDao
from entity.models import Node, utcnow
from utils.errors import AppError
from utils.paths import atomic_write
from utils.serialization import record

logger = logging.getLogger(__name__)


class NodeService:
    def __init__(self, database, settings):
        self.db, self.settings = database, settings
        self.dao = NodeDao()
        self.node_id = ""
        self.running_count = lambda: 0
        self.heartbeat_task = None
        self.lock = None

    async def start(self):
        for path in (
            self.settings.state_dir,
            self.settings.accounts_dir,
            self.settings.workspaces_dir,
        ):
            path.mkdir(parents=True, exist_ok=True)
        self.lock = FileLock(self.settings.state_dir / "node.lock", thread_local=False)
        try:
            self.lock.acquire(timeout=0)
        except Timeout as exc:
            raise RuntimeError("当前数据目录已运行一个节点；每个节点只能启动一个服务进程") from exc
        identity = self.settings.state_dir / "node-id"
        if not identity.exists():
            atomic_write(identity, str(uuid4()))
        self.node_id = identity.read_text(encoding="utf-8").strip()
        if not self.node_id or len(self.node_id) > 64:
            raise RuntimeError("node-id 文件内容无效")

        def register(db):
            node = db.get(Node, self.node_id)
            if node is None:
                node = self.dao.add(
                    db,
                    id=self.node_id,
                    node_name=socket.gethostname(),
                    node_host=self.settings.host,
                    node_port=self.settings.port,
                )
            node.node_name = socket.gethostname()
            node.node_host, node.node_port = self.settings.host, self.settings.port
            node.max_concurrency = self.settings.concurrency
            node.status, node.running_count = "online", 0
            node.last_heartbeat = utcnow()
            SessionDao().recover(db, self.node_id)
            self.dao.recover_resources(db, self.node_id)

        await self.db.run(register)
        psutil.cpu_percent()
        self.heartbeat_task = asyncio.create_task(self._heartbeat())

    async def _heartbeat(self):
        while True:
            try:
                cpu, memory = psutil.cpu_percent(), psutil.virtual_memory().percent
                count = self.running_count()

                def update(db, cpu=cpu, memory=memory, count=count):
                    node = self.dao.get(db, self.node_id)
                    node.cpu_usage, node.memory_usage = cpu, memory
                    node.running_count = count
                    node.status, node.last_heartbeat = "online", utcnow()

                await self.db.run(update)
            except Exception:
                logger.exception("节点心跳更新失败")
            await asyncio.sleep(self.settings.heartbeat_seconds)

    def is_online(self, node):
        return (
            node.status == "online"
            and node.last_heartbeat is not None
            and node.last_heartbeat > utcnow() - timedelta(seconds=self.settings.node_stale_seconds)
        )

    def _view(self, db, node):
        result = record(node)
        result["status"] = "online" if self.is_online(node) else "offline"
        result.update(self.dao.counts(db, node.id))
        return result

    async def list(self, page, page_size):
        def query(db):
            items, total = self.dao.page(db, page=page, page_size=page_size)
            return {"items": [self._view(db, item) for item in items], "total": total}

        return await self.db.run(query)

    async def get(self, node_id):
        return await self.db.run(lambda db: self._view(db, self.dao.get(db, node_id)))

    async def owner(self, node_id):
        node = await self.db.run(lambda db: self.dao.get(db, node_id))
        if not self.is_online(node):
            raise AppError(503, "所属节点已离线或心跳过期")
        return node

    async def close(self):
        if self.heartbeat_task:
            self.heartbeat_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self.heartbeat_task

            def offline(db):
                node = self.dao.get(db, self.node_id)
                node.status, node.running_count = "offline", 0
                node.last_heartbeat = utcnow()

            try:
                await self.db.run(offline)
            except Exception:
                logger.exception("节点离线状态更新失败")
        if self.lock and self.lock.is_locked:
            self.lock.release()
