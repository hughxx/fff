"""Only explicit model availability failures produce workspace warnings."""
import re

from sqlalchemy import select

from entity.models import Account, AccountModelFailure, Workspace, WorkspaceAccount, utcnow


def unavailable_model(error, requested=None):
    pattern = r'(?:模型|model)\s*["\'“‘`]([^"\'”’`\s]+)["\'”’`]\s*(?:不存在|不可用|无权限|不支持|is not available|is unavailable|not found|does not exist)'
    match = re.search(pattern, error, re.IGNORECASE)
    if match:
        return match.group(1)[:128]
    if requested and re.search(r'模型不存在|模型不可用|无权使用.*模型|model[_ ]not[_ ]found|model unavailable|model is not available|model access denied', error, re.IGNORECASE):
        return requested
    return None


async def record_failure(database, account_id, model, error):
    def save(db):
        item = db.get(AccountModelFailure, (account_id, model))
        if item is None:
            db.add(AccountModelFailure(account_id=account_id, model=model, error=error))
        else:
            item.error, item.detected_at = error, utcnow()
    await database.run(save)


async def clear_failure(database, account_id, model):
    def clear(db):
        item = db.get(AccountModelFailure, (account_id, model))
        if item:
            db.delete(item)
    await database.run(clear)


async def workspace_alerts(database):
    def query(db):
        rows = db.execute(select(AccountModelFailure, Workspace, Account)
            .join(Account, Account.id == AccountModelFailure.account_id)
            .join(WorkspaceAccount, (WorkspaceAccount.account_id == Account.id) &
                  (WorkspaceAccount.default_model == AccountModelFailure.model))
            .join(Workspace, Workspace.id == WorkspaceAccount.workspace_id)
            .order_by(Workspace.id, Account.id, AccountModelFailure.model)).all()
        return {'items': [{'workspace_id': w.id, 'workspace_name': w.name,
            'account_id': a.id, 'account_name': a.account_name or a.account_id or a.id,
            'model': f.model, 'error': f.error,
            'detected_at': f.detected_at.isoformat() + 'Z'} for f, w, a in rows]}
    return await database.run(query)
