import asyncio
import contextlib
import json
import logging
import time
from datetime import datetime, timezone

from sqlalchemy import select

from entity.models import Account
from utils.paths import atomic_write
from utils.logging_utils import redact_output
from service.model_alerts import unavailable_model, record_failure, clear_failure

logger = logging.getLogger(__name__)
INTERVAL = 86400
EARLY = 3600
RETRY = 300


def next_due(now, expires_at):
    due = min(now + INTERVAL, expires_at / 1000 - EARLY) if expires_at else now + INTERVAL
    return max(now + RETRY, due)


def stamp(value):
    return datetime.fromtimestamp(value, timezone.utc).isoformat()


class AccountKeepalive:
    def __init__(self, accounts):
        self.accounts = accounts
        self.path = accounts.settings.state_dir / 'account-keepalive.json'
        self.state = {}
        self.task = None

    async def start(self):
        if self.path.exists():
            try:
                self.state = json.loads(self.path.read_text(encoding='utf-8'))
                if not isinstance(self.state, dict):
                    raise ValueError('invalid state')
            except (OSError, ValueError):
                logger.exception('保活调度记录读取失败，将重新检查所有账号')
                self.state = {}
        logger.info('账号自动保活启动 interval=86400 early=3600 retry=300 poll=30 timezone=UTC')
        self.task = asyncio.create_task(self.loop())

    async def loop(self):
        while True:
            try:
                await self.tick()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception('账号保活调度失败，30秒后重试')
            await asyncio.sleep(30)

    async def tick(self):
        service = self.accounts
        accounts = await service.db.run(lambda db: db.scalars(
            select(Account).where(Account.node_id == service.nodes.node_id)
        ).all())
        for account in accounts:
            if not account.account_id or account.id in service.logins:
                continue
            record = self.state.get(account.id, {})
            due = record.get('next_at', 0)
            # A newly observed earlier expiry must advance the schedule, but failures
            # retain their backoff instead of retrying on every scheduler tick.
            if record.get('expires_at') != account.expires_at and account.expires_at:
                due = min(due, account.expires_at / 1000 - EARLY)
            if time.time() < due:
                continue
            async with service.mutation_lock:
                current = await service.db.run(lambda db: db.get(Account, account.id))
                if current is None or current.id in service.logins:
                    continue
                service.keepalive_running.add(current.id)
            try:
                await self.execute(current)
            finally:
                service.keepalive_running.discard(current.id)

    async def execute(self, account):
        service = self.accounts
        now = time.time()
        logger.info('账号保活开始 account_id=%s previous_expires_at=%s', account.id, account.expires_at)
        result = dict(self.state.get(account.id, {}))
        result.update(next_at=now + RETRY, expires_at=account.expires_at,
                      last_attempt=now, status='running', last_error=None)
        result['history'] = [h for h in result.get('history', []) if h.get('time', 0) >= now - 7 * INTERVAL][-99:]
        self.state[account.id] = result
        atomic_write(self.path, json.dumps(self.state, ensure_ascii=False))

        async def attempt(model):
            args = ['-p', '你好', '--output-format', 'json', '--skip-safe-check']
            if model:
                args.extend(['--model', model])
            record = {'time': time.time(), 'model': model, 'status': 'failed', 'error': None}
            try:
                response = await service.cli.json_command(args, cwd=directory,
                    config_dir=service.config_path(account))
                if response.get('type') != 'result' or response.get('is_error') is not False:
                    raise RuntimeError(str(response.get('result') or 'CodeAgent 未返回成功结果'))
                record['status'] = 'success'
                result['model'] = model
                if model:
                    await clear_failure(service.db, account.id, model)
                return True
            except Exception as exc:
                record['error'] = redact_output(getattr(exc, 'command_error', None) or str(exc))[:2000]
                result['last_error'] = record['error']
                failed_model = unavailable_model(record['error'], model)
                if failed_model:
                    try:
                        await record_failure(service.db, account.id, failed_model, record['error'])
                    except Exception:
                        logger.exception('保存模型告警失败 account_id=%s', account.id)
                logger.warning('账号保活模型尝试失败 account_id=%s model=%s error=%s', account.id, model or 'default', record['error'])
                return False
            finally:
                result['history'] = (result['history'] + [record])[-100:]
                atomic_write(self.path, json.dumps(self.state, ensure_ascii=False))
        try:
            directory = service.settings.state_dir / 'account-keepalive' / account.id
            directory.mkdir(parents=True, exist_ok=True)
            # Fresh turn, dedicated cwd, account-specific credentials; no workspace
            # session or model override is used.
            succeeded = await attempt(None)
            if not succeeded:
                available = await service.models(account.id, require_logged_in=False)
                candidates = list(dict.fromkeys(m['value'] for m in available['models'] if m.get('value')))
                for model in candidates:
                    if await attempt(model):
                        succeeded = True
                        break
            if not succeeded:
                raise RuntimeError(result['last_error'] or '没有可用的明确模型，保活失败')
            status = await service.refresh(account)
            updated = await service.db.run(lambda db: service.dao.get(db, account.id))
            result['expires_at'] = updated.expires_at
            if status != 'logged_in' or (updated.expires_at and updated.expires_at <= time.time() * 1000):
                raise RuntimeError('发送后账号仍未登录或已过期，需要重新登录')
            now = time.time()
            result.update(last_success=now, next_at=next_due(now, updated.expires_at), status='success', last_error=None)
            logger.info('账号保活成功 account_id=%s expires_at=%s next_at=%s',
                        account.id, updated.expires_at, stamp(result['next_at']))
        except asyncio.CancelledError:
            logger.info('账号保活中止 account_id=%s，服务恢复后重试', account.id)
            result.update(status='failed', last_error='服务停止，保活中断', next_at=time.time())
            atomic_write(self.path, json.dumps(self.state, ensure_ascii=False))
            raise
        except Exception as exc:
            result.update(status='failed', last_error=redact_output(str(exc))[:2000])
            result['next_at'] = time.time() + RETRY
            logger.exception('账号保活失败 account_id=%s retry_at=%s', account.id, stamp(result['next_at']))
            try:
                await service.refresh(account)
            except Exception:
                logger.exception('保活失败后认证状态查询失败 account_id=%s', account.id)
        self.state[account.id] = result
        atomic_write(self.path, json.dumps(self.state, ensure_ascii=False))

    def view(self, account_id):
        result = dict(self.state.get(account_id, {}))
        result['history'] = list(reversed([h for h in result.get('history', [])
            if h.get('time', 0) >= time.time() - 7 * INTERVAL]))
        return result

    async def close(self):
        if self.task:
            self.task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self.task
