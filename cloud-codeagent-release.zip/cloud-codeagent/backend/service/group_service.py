import asyncio
import contextlib
import logging
from uuid import uuid4
from sqlalchemy import select, delete
from entity.models import (Account, AccountGroup, AccountGroupMember, WorkspaceGroup,
    Workspace, WorkspaceAccount, GroupModelNotice)
from utils.errors import AppError
from utils.serialization import record

logger = logging.getLogger(__name__)


class GroupService:
    def __init__(self, db, accounts, nodes):
        self.db, self.accounts, self.nodes = db, accounts, nodes
        self.task = None

    def get_group(self, db, group_id, lock=False):
        item = db.get(AccountGroup, group_id, with_for_update=lock)
        if item is None:
            raise AppError(404, '账号组不存在')
        return item

    def view(self, db, group):
        result = record(group)
        result['members'] = [record(m) for m in db.scalars(select(AccountGroupMember).where(
            AccountGroupMember.group_id == group.id).order_by(AccountGroupMember.account_id))]
        return result

    async def list(self):
        return await self.db.run(lambda db: {'items': [self.view(db, g) for g in db.scalars(
            select(AccountGroup).order_by(AccountGroup.create_time, AccountGroup.id))]})

    def sync(self, db, group_id, workspace_id=None):
        members = list(db.scalars(select(AccountGroupMember).where(AccountGroupMember.group_id == group_id)))
        bindings = list(db.scalars(select(WorkspaceGroup).where(WorkspaceGroup.group_id == group_id)))
        for binding in bindings:
            if workspace_id and binding.workspace_id != workspace_id:
                continue
            db.execute(delete(WorkspaceAccount).where(WorkspaceAccount.workspace_id == binding.workspace_id))
            for m in members:
                db.add(WorkspaceAccount(workspace_id=binding.workspace_id, account_id=m.account_id,
                    default_model=m.model, available=m.available))
            workspace = db.get(Workspace, binding.workspace_id)
            if members and workspace.account_id not in [m.account_id for m in members]:
                workspace.account_id = members[0].account_id

    async def save(self, body, group_id=None):
        if body.node_id != self.nodes.node_id:
            raise AppError(409, '账号组不属于本节点')
        if len({m.account_id for m in body.members}) != len(body.members):
            raise AppError(400, '账号组不能重复添加同一账号')
        for member in body.members:
            account = await self.db.run(lambda db: self.accounts.dao.get(db, member.account_id))
            if account.node_id != body.node_id:
                raise AppError(409, '组内账号必须属于同一节点')
            existing = await self.db.run(lambda db: db.get(AccountGroupMember, (group_id, member.account_id))) if group_id else None
            if existing and existing.model == member.model:
                continue
            models = await self.accounts.models(account.id, require_logged_in=False)
            values = [m['value'] for m in models['models'] if m.get('value')]
            if member.model not in values:
                raise AppError(409, '所选模型不在该账号最新可用列表中，请重新获取')
        def save(db):
            if group_id:
                group = self.get_group(db, group_id, True)
                if group.node_id != body.node_id:
                    raise AppError(409, '不能修改账号组所属节点')
                group.name = body.name
            else:
                group = AccountGroup(id='group-' + uuid4().hex, name=body.name, node_id=body.node_id)
                db.add(group)
                db.flush()
            db.execute(delete(AccountGroupMember).where(AccountGroupMember.group_id == group.id))
            db.execute(delete(GroupModelNotice).where(GroupModelNotice.group_id == group.id))
            for m in body.members:
                db.add(AccountGroupMember(group_id=group.id, **m.model_dump()))
            db.flush()
            self.sync(db, group.id)
            return self.view(db, group)
        return await self.db.run(save)

    async def remove(self, group_id):
        def remove(db):
            group = self.get_group(db, group_id, True)
            if db.scalar(select(WorkspaceGroup.workspace_id).where(WorkspaceGroup.group_id == group_id).limit(1)):
                raise AppError(409, '请先给关联工作区切换账号组')
            db.delete(group)
        await self.db.run(remove)
        return {'success': True}

    def bind(self, db, workspace, group_id):
        group = self.get_group(db, group_id, True)
        if workspace.node_id != group.node_id:
            raise AppError(409, '只能使用同节点账号组')
        binding = db.get(WorkspaceGroup, workspace.id)
        if binding:
            binding.group_id = group_id
        else:
            db.add(WorkspaceGroup(workspace_id=workspace.id, group_id=group_id))
        db.flush()
        self.sync(db, group_id, workspace.id)

    async def migrate(self):
        # One binding per workspace makes this idempotent across nodes/restarts.
        def migrate(db):
            for w in db.scalars(select(Workspace).where(Workspace.node_id == self.nodes.node_id).with_for_update()):
                if db.get(WorkspaceGroup, w.id):
                    continue
                g = AccountGroup(id='group-' + uuid4().hex, name=w.name, node_id=w.node_id)
                db.add(g)
                db.flush()
                for old in db.scalars(select(WorkspaceAccount).where(WorkspaceAccount.workspace_id == w.id)):
                    db.add(AccountGroupMember(group_id=g.id, account_id=old.account_id,
                        model=old.default_model, available=old.available, fallback=True))
                db.add(WorkspaceGroup(workspace_id=w.id, group_id=g.id))
        await self.db.run(migrate)

    async def check_account(self, account_id):
        result = await self.accounts.models(account_id, require_logged_in=False)
        values = list(dict.fromkeys(m['value'] for m in result['models'] if m.get('value')))
        if not values:
            return values
        def update(db):
            members = list(db.scalars(select(AccountGroupMember).where(AccountGroupMember.account_id == account_id).with_for_update()))
            for m in members:
                if m.model in values:
                    notice = db.get(GroupModelNotice, (m.group_id, account_id))
                    if notice and notice.new_model is None and notice.old_model == m.model:
                        db.delete(notice)
                    continue
                notice = db.get(GroupModelNotice, (m.group_id, account_id))
                if not notice:
                    notice = GroupModelNotice(group_id=m.group_id, account_id=account_id, old_model=m.model or '(未配置)')
                    db.add(notice)
                notice.old_model, notice.new_model = m.model or '(未配置)', values[0] if m.fallback else None
                if m.fallback:
                    m.model = values[0]
                    db.flush()
                    self.sync(db, m.group_id)
        await self.db.run(update)
        return values

    async def reported_failure(self, account_id, failed_model):
        latest = await self.accounts.models(account_id, require_logged_in=False)
        choices = [m['value'] for m in latest['models'] if m.get('value') and m['value'] != failed_model]
        def update(db):
            for member in db.scalars(select(AccountGroupMember).where(AccountGroupMember.account_id == account_id,
                    AccountGroupMember.model == failed_model).with_for_update()):
                notice = db.get(GroupModelNotice, (member.group_id, account_id))
                if notice is None:
                    notice = GroupModelNotice(group_id=member.group_id, account_id=account_id, old_model=failed_model)
                    db.add(notice)
                notice.old_model = failed_model
                notice.new_model = choices[0] if choices and member.fallback else None
                if notice.new_model:
                    member.model = notice.new_model
                    db.flush()
                    self.sync(db, member.group_id)
        await self.db.run(update)

    async def resolve_model(self, workspace_id, account_id, requested):
        values = await self.check_account(account_id)
        if not values:
            raise AppError(409, '没有可用模型列表，请到账号组查看命令返回结果')
        def select_model(db):
            binding = db.get(WorkspaceGroup, workspace_id)
            member = db.get(AccountGroupMember, (binding.group_id, account_id)) if binding else None
            if not member or not member.available:
                raise AppError(409, '账号组已变化，请重新发送')
            selected = requested or member.model
            if selected in values:
                return selected
            if member.fallback:
                return values[0]
            raise AppError(409, '配置模型当前不可用且未启用模型降级，请重新配置')
        return await self.db.run(select_model)

    async def retry_model(self, workspace_id, account_id, failed, attempted):
        def member(db):
            binding = db.get(WorkspaceGroup, workspace_id)
            return db.get(AccountGroupMember, (binding.group_id, account_id)) if binding else None
        current = await self.db.run(member)
        if not current or not current.available or not current.fallback:
            return None
        latest = await self.accounts.models(account_id, require_logged_in=False)
        choices = [m['value'] for m in latest['models'] if m.get('value') and m['value'] not in attempted]
        if not choices:
            return None
        replacement = choices[0]
        def update(db):
            live = db.get(AccountGroupMember, (current.group_id, account_id), with_for_update=True)
            if not live or not live.fallback or not live.available:
                return False
            if live.model == failed:
                notice = db.get(GroupModelNotice, (live.group_id, account_id))
                if notice is None:
                    notice = GroupModelNotice(group_id=live.group_id, account_id=account_id, old_model=failed)
                    db.add(notice)
                notice.old_model, notice.new_model = failed, replacement
                live.model = replacement
                db.flush()
                self.sync(db, live.group_id)
            return True
        return replacement if await self.db.run(update) else None

    async def notices(self):
        def query(db):
            items = []
            for n, g, a, w in db.execute(select(GroupModelNotice, AccountGroup, Account, Workspace)
                .join(AccountGroup, AccountGroup.id == GroupModelNotice.group_id)
                .join(Account, Account.id == GroupModelNotice.account_id)
                .join(WorkspaceGroup, WorkspaceGroup.group_id == AccountGroup.id)
                .join(Workspace, Workspace.id == WorkspaceGroup.workspace_id)):
                items.append({'workspace_id': w.id, 'workspace_name': w.name, 'account_id': a.id,
                    'account_name': a.account_name or a.account_id or a.id, 'model': n.old_model,
                    'new_model': n.new_model, 'error': ('已自动切换为 ' + n.new_model) if n.new_model else '未自动替换，请检查模型降级设置及最新可用列表',
                    'detected_at': n.update_time.isoformat() + 'Z'})
            return {'items': items}
        return await self.db.run(query)

    async def start(self):
        await self.migrate()
        async def loop():
            while True:
                try:
                    ids = await self.db.run(lambda db: list(db.scalars(select(Account.id)
                        .join(AccountGroupMember, AccountGroupMember.account_id == Account.id)
                        .where(Account.node_id == self.nodes.node_id).distinct())))
                except Exception:
                    logger.exception('模型检查调度读取失败，60秒后重试')
                    await asyncio.sleep(60)
                    continue
                for aid in ids:
                    try:
                        await self.check_account(aid)
                    except Exception:
                        logger.exception('账号组模型可用性检查失败 account_id=%s', aid)
                await asyncio.sleep(3600)
        self.task = asyncio.create_task(loop())

    async def close(self):
        if self.task:
            self.task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self.task
