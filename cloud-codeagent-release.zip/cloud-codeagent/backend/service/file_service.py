import os
import shutil
import stat
import tempfile
from pathlib import Path
from zipfile import BadZipFile, ZipFile

from starlette.responses import FileResponse

from utils.async_tools import to_thread
from utils.errors import AppError
from utils.paths import atomic_write, safe_path


class FileService:
    def __init__(self, settings, workspaces):
        self.settings, self.workspaces = settings, workspaces

    async def _operate(self, workspace_id, operation):
        async with self.workspaces.mutation_lock:
            workspace = await self.workspaces.local(workspace_id)
            root = self.workspaces.root(workspace)
            return await to_thread(operation, root)

    def check_content(self, content):
        if len(content.encode("utf-8")) > self.settings.max_file_bytes:
            raise AppError(413, "文件内容超过大小限制")

    async def list(self, workspace_id, path):
        def operation(root):
            target = safe_path(root, path, allow_root=True)
            if not target.is_dir():
                raise AppError(404, "目录不存在")
            items = []
            for child in sorted(target.iterdir(), key=lambda item: item.name):
                link = child.is_symlink() or (hasattr(child, "is_junction") and child.is_junction())
                items.append(
                    {
                        "name": child.name,
                        "path": child.relative_to(root).as_posix(),
                        "type": "symlink" if link else ("directory" if child.is_dir() else "file"),
                        "size": child.lstat().st_size,
                    }
                )
            return {"path": path, "items": items}

        return await self._operate(workspace_id, operation)

    async def read(self, workspace_id, path):
        def operation(root):
            target = safe_path(root, path)
            if not target.is_file():
                raise AppError(404, "文件不存在")
            with target.open("rb") as source:
                content = source.read(self.settings.max_file_bytes + 1)
            if len(content) > self.settings.max_file_bytes:
                raise AppError(413, "文件内容超过大小限制")
            try:
                text = content.decode("utf-8")
            except UnicodeDecodeError as exc:
                raise AppError(415, "仅支持读取 UTF-8 文本文件") from exc
            return {"path": path, "content": text}

        return await self._operate(workspace_id, operation)

    async def create_directory(self, workspace_id, path):
        def operation(root):
            target = safe_path(root, path)
            try:
                target.mkdir()
            except FileExistsError as exc:
                raise AppError(409, "目录已存在") from exc
            return {"path": path, "type": "directory"}

        return await self._operate(workspace_id, operation)

    async def upload(self, workspace_id, path, chunks):
        async with self.workspaces.mutation_lock:
            workspace = await self.workspaces.local(workspace_id)
            root = self.workspaces.root(workspace)
            target = safe_path(root, path)
            if target.exists():
                raise AppError(409, "文件已存在")
            target.parent.mkdir(parents=True, exist_ok=True)
            descriptor, temporary = tempfile.mkstemp(prefix=".ca-upload-", dir=target.parent)
            size = 0
            try:
                with os.fdopen(descriptor, "wb") as output:
                    async for chunk in chunks:
                        size += len(chunk)
                        if size > self.settings.max_upload_bytes:
                            raise AppError(413, "上传文件超过大小限制")
                        await to_thread(output.write, chunk)
                try:
                    await to_thread(os.link, temporary, target)
                except FileExistsError as exc:
                    raise AppError(409, "文件已存在") from exc
            finally:
                Path(temporary).unlink(missing_ok=True)
            return {"path": path, "type": "file", "size": size}

    async def upload_zip(self, workspace_id, path, chunks):
        async with self.workspaces.mutation_lock:
            workspace = await self.workspaces.local(workspace_id)
            root = self.workspaces.root(workspace)
            target = safe_path(root, path)
            if target.exists():
                raise AppError(409, "目标目录已存在")
            target.parent.mkdir(parents=True, exist_ok=True)
            descriptor, temporary = tempfile.mkstemp(prefix=".ca-zip-", dir=target.parent)
            staging = None
            size = 0
            try:
                with os.fdopen(descriptor, "wb") as output:
                    async for chunk in chunks:
                        size += len(chunk)
                        if size > self.settings.max_upload_bytes:
                            raise AppError(413, "ZIP 文件超过上传大小限制")
                        await to_thread(output.write, chunk)

                def extract():
                    nonlocal staging
                    staging = Path(tempfile.mkdtemp(prefix=".ca-extract-", dir=target.parent))
                    total = 0
                    try:
                        with ZipFile(temporary) as archive:
                            members = archive.infolist()
                            if not members or len(members) > 10000:
                                raise AppError(400, "ZIP 为空或文件数量超过限制")
                            for member in members:
                                name = member.filename
                                if (
                                    not name
                                    or name.startswith("/")
                                    or "\\" in name
                                    or "\x00" in name
                                    or any(part in ("", ".", "..") or ":" in part for part in name.rstrip("/").split("/"))
                                    or stat.S_ISLNK(member.external_attr >> 16)
                                ):
                                    raise AppError(400, "ZIP 包含非法路径或符号链接")
                                total += member.file_size
                                if total > self.settings.max_upload_bytes:
                                    raise AppError(413, "ZIP 解压后超过大小限制")
                            for member in members:
                                destination = staging.joinpath(*member.filename.rstrip("/").split("/"))
                                if member.is_dir():
                                    destination.mkdir(parents=True, exist_ok=True)
                                else:
                                    destination.parent.mkdir(parents=True, exist_ok=True)
                                    with archive.open(member) as source, destination.open("xb") as output:
                                        shutil.copyfileobj(source, output)
                        if target.exists():
                            raise AppError(409, "目标目录已存在")
                        staging.rename(target)
                    except (BadZipFile, RuntimeError) as exc:
                        raise AppError(400, "ZIP 文件无效或已损坏") from exc

                await to_thread(extract)
                return {"path": path, "type": "directory", "size": size}
            finally:
                Path(temporary).unlink(missing_ok=True)
                if staging is not None and staging.exists():
                    shutil.rmtree(staging)

    async def download(self, workspace_id, path):
        def operation(root):
            target = safe_path(root, path)
            if not target.is_file():
                raise AppError(404, "文件不存在")
            return target

        target = await self._operate(workspace_id, operation)
        return FileResponse(target, media_type="application/octet-stream", filename=target.name)

    async def write(self, workspace_id, body):
        self.check_content(body.content)

        def operation(root):
            target = safe_path(root, body.path)
            if not target.exists():
                raise AppError(404, "文件不存在")
            if target.is_dir():
                raise AppError(409, "目标是目录")
            atomic_write(target, body.content)
            return {"success": True, "path": body.path}

        return await self._operate(workspace_id, operation)

    async def delete(self, workspace_id, path):
        def operation(root):
            target = safe_path(root, path)
            if not target.exists():
                raise AppError(404, "文件或目录不存在")
            if target.is_dir():
                shutil.rmtree(target)
            else:
                target.unlink()
            return {"success": True}

        return await self._operate(workspace_id, operation)
