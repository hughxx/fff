import asyncio
import shutil

from utils.errors import AppError
from utils.paths import atomic_write, safe_path


class FileService:
    def __init__(self, settings, workspaces):
        self.settings, self.workspaces = settings, workspaces

    async def _operate(self, workspace_id, operation):
        async with self.workspaces.mutation_lock:
            workspace = await self.workspaces.local(workspace_id)
            root = self.workspaces.root(workspace)
            return await asyncio.to_thread(operation, root)

    def check_content(self, content):
        if len(content.encode("utf-8")) > self.settings.max_file_bytes:
            raise AppError(413, "文件内容超过大小限制")

    async def list(self, workspace_id, path):
        def operation(root):
            target = safe_path(root, path, allow_root=True)
            if not target.is_dir():
                raise AppError(404, "目录不存在")
            items = []
            for child in sorted(target.iterdir(), key=lambda item: item.name):
                link = child.is_symlink() or (hasattr(child, "is_junction") and child.is_junction())
                items.append(
                    {
                        "name": child.name,
                        "path": child.relative_to(root).as_posix(),
                        "type": "symlink" if link else ("directory" if child.is_dir() else "file"),
                        "size": child.lstat().st_size,
                    }
                )
            return {"path": path, "items": items}

        return await self._operate(workspace_id, operation)

    async def read(self, workspace_id, path):
        def operation(root):
            target = safe_path(root, path)
            if not target.is_file():
                raise AppError(404, "文件不存在")
            with target.open("rb") as source:
                content = source.read(self.settings.max_file_bytes + 1)
            if len(content) > self.settings.max_file_bytes:
                raise AppError(413, "文件内容超过大小限制")
            try:
                text = content.decode("utf-8")
            except UnicodeDecodeError as exc:
                raise AppError(415, "仅支持读取 UTF-8 文本文件") from exc
            return {"path": path, "content": text}

        return await self._operate(workspace_id, operation)

    async def create(self, workspace_id, body):
        self.check_content(body.content)

        def operation(root):
            target = safe_path(root, body.path)
            if body.type == "directory":
                target.mkdir()
            else:
                with target.open("x", encoding="utf-8", newline="") as output:
                    output.write(body.content)
            return {"path": body.path, "type": body.type}

        return await self._operate(workspace_id, operation)

    async def write(self, workspace_id, body):
        self.check_content(body.content)

        def operation(root):
            target = safe_path(root, body.path)
            if target.is_dir():
                raise AppError(409, "目标是目录")
            atomic_write(target, body.content)
            return {"success": True, "path": body.path}

        return await self._operate(workspace_id, operation)

    async def delete(self, workspace_id, path):
        def operation(root):
            target = safe_path(root, path)
            if not target.exists():
                raise AppError(404, "文件或目录不存在")
            if target.is_dir():
                shutil.rmtree(target)
            else:
                target.unlink()
            return {"success": True}

        return await self._operate(workspace_id, operation)
