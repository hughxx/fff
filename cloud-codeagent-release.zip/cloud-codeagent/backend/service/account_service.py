import asyncio
import contextlib
import logging
import re
from pathlib import Path
from uuid import uuid4

from async_timeout import timeout as async_timeout

from dao.account_dao import AccountDao
from entity.models import Account
from utils.async_tools import to_thread
from utils.codeagent import stop_process
from utils.errors import AppError
from utils.logging_utils import redact_output
from utils.paths import remove_managed_dir, safe_path
from utils.serialization import record

logger = logging.getLogger(__name__)


class AccountService:
    def __init__(self, database, settings, nodes, cli):
        self.db, self.settings, self.nodes, self.cli = database, settings, nodes, cli
        self.dao = AccountDao()
        self.logins = {}
        self.mutation_lock = asyncio.Lock()

    async def list(self, page, page_size, node_id=None):
        filters = [Account.node_id == node_id] if node_id else []

        def query(db):
            items, total = self.dao.page(db, filters=filters, page=page, page_size=page_size)
            return {"items": [record(item) for item in items], "total": total}

        return await self.db.run(query)

    async def get(self, account_id, refresh=False):
        account = await self.db.run(lambda db: self.dao.get(db, account_id))
        if refresh:
            await self.refresh(account)
            account = await self.db.run(lambda db: self.dao.get(db, account_id))
        result = record(account)
        if account_id in self.logins:
            result["login_url"] = self.logins[account_id]["url"]
        return result

    def config_path(self, account):
        path = safe_path(self.settings.accounts_dir, account.id)
        if path.resolve() != Path(account.config_dir).resolve():
            raise AppError(409, "账号目录与当前节点配置不一致")
        return path

    async def refresh(self, account):
        try:
            return await self._refresh_status(account)
        except Exception:
            logger.exception("账号认证状态检查失败 account_id=%s", account.id)
            raise

    async def _refresh_status(self, account):
        status = await self.cli.auth_status(self.config_path(account))

        def update(db):
            item = self.dao.get(db, account.id, lock=True)
            logged_in = status.get("loggedIn") is True
            item.auth_status = (
                "expired" if status.get("expired") else ("logged_in" if logged_in else "not_login")
            )
            if logged_in:
                if not status.get("accountId"):
                    raise AppError(502, "认证状态缺少 accountId")
                item.account_id = str(status["accountId"])
                item.auth_provider = status.get("authProvider") or "unknown"
                item.expires_at = status.get("expiresAt")
            return item.auth_status

        return await self.db.run(update)

    async def login(self, body):
        async with self.mutation_lock:
            if body.account_id:
                account = await self.db.run(lambda db: self.dao.get(db, body.account_id))
                account_id = account.id
                if body.node_id and body.node_id != account.node_id:
                    raise AppError(409, "账号不能迁移至其他节点")
                if account_id in self.logins:
                    return {
                        "login_id": account_id,
                        "account_id": account_id,
                        "status": "waiting_login",
                        "login_url": self.logins[account_id]["url"],
                    }
                directory = self.config_path(account)
                directory.mkdir(mode=0o700, exist_ok=True)
                await self.db.run(
                    lambda db: setattr(self.dao.get(db, account_id), "auth_status", "waiting_login")
                )
            else:
                account_id = f"account-{uuid4().hex}"
                directory = safe_path(self.settings.accounts_dir, account_id)
                directory.mkdir(mode=0o700)
                try:
                    account = await self.db.run(
                        lambda db: self.dao.add(
                            db,
                            id=account_id,
                            node_id=self.nodes.node_id,
                            account_name=body.account_name,
                            config_dir=str(directory),
                            auth_status="waiting_login",
                        )
                    )
                except BaseException:
                    remove_managed_dir(self.settings.accounts_dir, directory)
                    raise
            ready = asyncio.get_running_loop().create_future()
            entry = {"url": None, "task": None}
            self.logins[account_id] = entry
            entry["task"] = asyncio.create_task(self._watch_login(account, ready, entry))
        try:
            await asyncio.wait_for(asyncio.shield(ready), self.settings.login_url_timeout)
        except asyncio.TimeoutError:
            pass
        item = await self.get(account_id)
        return {
            "login_id": account_id,
            "account_id": account_id,
            "status": item["auth_status"],
            "login_url": entry["url"],
        }

    async def _watch_login(self, account, ready, entry):
        process, reader = None, None
        output_tail = bytearray()
        try:
            path = self.config_path(account)
            logger.info("开始账号登录 account_id=%s config_dir=%s", account.id, path)
            process = await self.cli.spawn(
                ["auth", "login"], cwd=path, config_dir=path, merge_stderr=True
            )

            async def capture_url():
                while line := await process.stdout.readline():
                    output_tail.extend(redact_output(line).encode("utf-8"))
                    del output_tail[:-8192]
                    text = re.sub(r"\x1b\[[0-9;]*m", "", line.decode("utf-8", errors="replace"))
                    match = re.search(r"https?://[^\s<>\"']+", text)
                    if match:
                        entry["url"] = match.group(0)
                        if not ready.done():
                            ready.set_result(True)

            reader = asyncio.create_task(capture_url())
            async with async_timeout(self.settings.login_timeout):
                while True:
                    await asyncio.sleep(self.settings.login_poll_seconds)
                    state = await self.refresh(account)
                    if state == "logged_in":
                        logger.info("账号登录成功 account_id=%s", account.id)
                        return
                    # 等待登录期间，未登录状态仍对外显示 waiting_login。
                    await self.db.run(
                        lambda db: setattr(
                            self.dao.get(db, account.id), "auth_status", "waiting_login"
                        )
                    )
                    if process.returncode is not None and process.returncode != 0:
                        raise AppError(
                            502, f"CodeAgent 登录进程异常退出，退出码 {process.returncode}"
                        )
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception(
                "账号登录失败 account_id=%s pid=%s exit_code=%s login_output=%s",
                account.id,
                process.pid if process else None,
                process.returncode if process else None,
                redact_output(bytes(output_tail)),
            )
            try:
                await self.db.run(
                    lambda db: setattr(self.dao.get(db, account.id), "auth_status", "error")
                )
            except Exception:
                logger.exception("保存账号登录失败状态时数据库不可用")
        finally:
            if process:
                await stop_process(process, self.settings.cancel_grace_seconds)
            if reader:
                reader.cancel()
                with contextlib.suppress(asyncio.CancelledError, ValueError):
                    await reader
            if not ready.done():
                ready.set_result(False)
            self.logins.pop(account.id, None)

    async def delete(self, account_id):
        async with self.mutation_lock:

            def check(db):
                account = self.dao.get(db, account_id, lock=True)
                if self.dao.has_workspaces(db, account_id):
                    raise AppError(409, "请先删除账号关联的工作区")
                return account

            account = await self.db.run(check)
            entry = self.logins.pop(account_id, None)
            if entry:
                entry["task"].cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await entry["task"]
            await to_thread(
                remove_managed_dir, self.settings.accounts_dir, self.config_path(account)
            )
            await self.db.run(lambda db: self.dao.delete(db, self.dao.get(db, account_id)))
        return {"success": True}

    async def close(self):
        tasks = [entry["task"] for entry in self.logins.values()]
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
