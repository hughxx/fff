import asyncio
import contextlib
import json
import logging
import random
import re
import time
from pathlib import Path
from uuid import uuid4

from async_timeout import timeout as async_timeout
from sqlalchemy import or_, select

from dao.account_dao import AccountDao
from entity.models import Account, Node
from utils.async_tools import to_thread
from utils.codeagent import stop_process
from utils.errors import AppError
from utils.logging_utils import redact_output
from utils.paths import remove_managed_dir, safe_path
from utils.serialization import record

logger = logging.getLogger(__name__)


class AccountService:
    def __init__(self, database, settings, nodes, cli):
        self.db, self.settings, self.nodes, self.cli = database, settings, nodes, cli
        self.dao = AccountDao()
        self.logins = {}
        self.mutation_lock = asyncio.Lock()
        self.refresh_task = None
        self.refresh_changed = asyncio.Event()

    def set_refresh_seconds(self, _seconds):
        self.refresh_changed.set()

    async def start(self):
        self.refresh_task = asyncio.create_task(self._refresh_loop())

    async def _refresh_loop(self):
        while True:
            self.refresh_changed.clear()
            await self.refresh_all()
            try:
                await asyncio.wait_for(
                    self.refresh_changed.wait(), self.nodes.auth_refresh_seconds
                )
            except asyncio.TimeoutError:
                pass

    async def refresh_all(self):
        accounts = await self.db.run(
            lambda db: db.scalars(
                select(Account).where(Account.node_id == self.nodes.node_id)
            ).all()
        )
        for account in accounts:
            if account.id in self.logins:
                continue
            try:
                await self._refresh_status(account)
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("自动刷新账号认证状态失败 account_id=%s", account.id)

    async def list(self, page, page_size, node_id=None):
        filters = [Account.node_id == node_id] if node_id else []

        def query(db):
            items, total = self.dao.page(db, filters=filters, page=page, page_size=page_size)
            return {"items": [record(item) for item in items], "total": total}

        return await self.db.run(query)

    async def get(self, account_id, refresh=False):
        account = await self.db.run(lambda db: self.dao.get(db, account_id))
        if refresh:
            await self.refresh(account)
            account = await self.db.run(lambda db: self.dao.get(db, account_id))
        result = record(account)
        if account_id in self.logins:
            result["login_url"] = self.logins[account_id]["url"]
        return result

    def config_path(self, account):
        path = safe_path(self.settings.accounts_dir, account.id)
        if path.resolve() != Path(account.config_dir).resolve():
            raise AppError(409, "账号目录与当前节点配置不一致")
        return path

    def select_for_workspace(self, db, account_id):
        account = self.dao.get(db, account_id, lock=True)
        if account.node_id != self.nodes.node_id:
            raise AppError(409, "账号不属于目标节点")
        if account.auth_status != "logged_in" or (
            account.expires_at and account.expires_at <= time.time() * 1000
        ):
            raise AppError(503, "所选账号未登录或认证已过期")
        return account

    async def random_for_workspace(self):
        now = time.time() * 1000

        def choose(db):
            accounts = db.scalars(
                select(Account)
                .where(
                    Account.auth_status == "logged_in",
                    or_(Account.expires_at.is_(None), Account.expires_at > now),
                )
            ).all()
            available = [
                account
                for account in accounts
                if self.nodes.is_online(db.get(Node, account.node_id))
            ]
            if not available:
                raise AppError(503, "没有可用的已登录账号")
            return random.choice(available)

        return await self.db.run(choose)

    async def models(self, account_id):
        account = await self.db.run(lambda db: self.dao.get(db, account_id))
        if account.auth_status != "logged_in":
            raise AppError(409, "账号尚未登录")
        raw = await self.cli.models(self.config_path(account))
        models = []
        for start in (raw.find("{"), raw.find("[")):
            if start < 0:
                continue
            try:
                data = json.loads(raw[start:])
            except ValueError:
                continue
            entries = data.get("models", []) if isinstance(data, dict) else data
            if isinstance(entries, list):
                for entry in entries:
                    if isinstance(entry, str):
                        models.append({"value": entry, "label": entry, "description": ""})
                    elif isinstance(entry, dict):
                        value = entry.get("value", entry.get("id", entry.get("model")))
                        if value is None or isinstance(value, str) and value:
                            models.append({
                                "value": value,
                                "label": entry.get("label") or value or "Default (recommended)",
                                "description": entry.get("description") or "",
                            })
            break
        return {"models": models, "raw": raw}

    async def refresh(self, account):
        try:
            return await self._refresh_status(account)
        except Exception:
            logger.exception("账号认证状态检查失败 account_id=%s", account.id)
            raise

    async def _refresh_status(self, account):
        status = await self.cli.auth_status(self.config_path(account))
        login_pending = account.id in self.logins

        def update(db):
            item = self.dao.get(db, account.id, lock=True)
            logged_in = status.get("loggedIn") is True
            if logged_in:
                item.auth_status = "expired" if status.get("expired") else "logged_in"
            elif login_pending:
                # 一次事务保存等待状态，避免前端读到中间的 not_login 并停止轮询。
                item.auth_status = "waiting_login"
            else:
                item.auth_status = "expired" if status.get("expired") else "not_login"
            if logged_in:
                if not status.get("accountId"):
                    raise AppError(502, "认证状态缺少 accountId")
                item.account_id = str(status["accountId"])
                item.auth_provider = status.get("authProvider") or "unknown"
                item.expires_at = status.get("expiresAt")
            return item.auth_status

        return await self.db.run(update)

    async def login(self, body):
        async with self.mutation_lock:
            if body.account_id:
                account = await self.db.run(lambda db: self.dao.get(db, body.account_id))
                account_id = account.id
                if body.node_id and body.node_id != account.node_id:
                    raise AppError(409, "账号不能迁移至其他节点")
                if account_id in self.logins:
                    return {
                        "login_id": account_id,
                        "account_id": account_id,
                        "status": "waiting_login",
                        "login_url": self.logins[account_id]["url"],
                    }
                directory = self.config_path(account)
                directory.mkdir(mode=0o700, exist_ok=True)
                await self.db.run(
                    lambda db: setattr(self.dao.get(db, account_id), "auth_status", "waiting_login")
                )
            else:
                account_id = f"account-{uuid4().hex}"
                directory = safe_path(self.settings.accounts_dir, account_id)
                directory.mkdir(mode=0o700)
                try:
                    account = await self.db.run(
                        lambda db: self.dao.add(
                            db,
                            id=account_id,
                            node_id=self.nodes.node_id,
                            account_name=body.account_name,
                            config_dir=str(directory),
                            auth_status="waiting_login",
                        )
                    )
                except BaseException:
                    remove_managed_dir(self.settings.accounts_dir, directory)
                    raise
            ready = asyncio.get_running_loop().create_future()
            entry = {"url": None, "task": None}
            self.logins[account_id] = entry
            entry["task"] = asyncio.create_task(self._watch_login(account, ready, entry))
        try:
            await asyncio.wait_for(asyncio.shield(ready), self.settings.login_url_timeout)
        except asyncio.TimeoutError:
            pass
        item = await self.get(account_id)
        return {
            "login_id": account_id,
            "account_id": account_id,
            "status": item["auth_status"],
            "login_url": entry["url"],
        }

    async def _watch_login(self, account, ready, entry):
        process, reader = None, None
        output_tail = bytearray()
        try:
            path = self.config_path(account)
            logger.info("开始账号登录 account_id=%s config_dir=%s", account.id, path)
            process = await self.cli.spawn(
                ["auth", "login"],
                cwd=path,
                config_dir=path,
                merge_stderr=True,
            )

            async def capture_url():
                while line := await process.stdout.readline():
                    output_tail.extend(redact_output(line).encode("utf-8"))
                    del output_tail[:-8192]
                    text = re.sub(r"\x1b\[[0-9;]*m", "", line.decode("utf-8", errors="replace"))
                    match = re.search(r"https?://[^\s<>\"']+", text)
                    if match:
                        entry["url"] = match.group(0)
                        if not ready.done():
                            ready.set_result(True)

            reader = asyncio.create_task(capture_url())
            async with async_timeout(self.settings.login_timeout):
                while True:
                    await asyncio.sleep(self.settings.login_poll_seconds)
                    if reader.done():
                        reader.result()
                    state = await self.refresh(account)
                    if state == "logged_in":
                        logger.info("账号登录成功 account_id=%s", account.id)
                        return
                    if process.returncode is not None and process.returncode != 0:
                        raise AppError(
                            502, f"CodeAgent 登录进程异常退出，退出码 {process.returncode}"
                        )
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception(
                "账号登录失败 account_id=%s pid=%s exit_code=%s login_output=%s",
                account.id,
                process.pid if process else None,
                process.returncode if process else None,
                redact_output(bytes(output_tail)),
            )
            try:
                await self.db.run(
                    lambda db: setattr(self.dao.get(db, account.id), "auth_status", "error")
                )
            except Exception:
                logger.exception("保存账号登录失败状态时数据库不可用")
        finally:
            if process:
                await stop_process(process, self.settings.cancel_grace_seconds)
            if reader:
                reader.cancel()
                with contextlib.suppress(asyncio.CancelledError, ValueError):
                    await reader
            if not ready.done():
                ready.set_result(False)
            self.logins.pop(account.id, None)

    async def delete(self, account_id):
        async with self.mutation_lock:

            def check(db):
                account = self.dao.get(db, account_id, lock=True)
                if self.dao.has_workspaces(db, account_id):
                    raise AppError(409, "请先删除账号关联的工作区")
                return account

            account = await self.db.run(check)
            entry = self.logins.pop(account_id, None)
            if entry:
                entry["task"].cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await entry["task"]
            await to_thread(
                remove_managed_dir, self.settings.accounts_dir, self.config_path(account)
            )
            await self.db.run(lambda db: self.dao.delete(db, self.dao.get(db, account_id)))
        return {"success": True}

    async def close(self):
        if self.refresh_task:
            self.refresh_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self.refresh_task
        tasks = [entry["task"] for entry in self.logins.values()]
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
