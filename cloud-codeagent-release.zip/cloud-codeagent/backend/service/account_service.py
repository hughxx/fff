import asyncio
import contextlib
import json
import logging
import random
import re
import time
from pathlib import Path
from uuid import uuid4

from async_timeout import timeout as async_timeout
from sqlalchemy import or_, select

from dao.account_dao import AccountDao
from service.account_keepalive import AccountKeepalive
from entity.models import AccountGroupMember
from entity.models import Account, Node, Workspace, WorkspaceAccount, AgentSession, SessionMessage
from utils.async_tools import to_thread
from utils.codeagent import stop_process
from utils.errors import AppError
from utils.logging_utils import redact_output
from utils.paths import remove_managed_dir, safe_path
from utils.serialization import record

logger = logging.getLogger(__name__)


class AccountService:
    def __init__(self, database, settings, nodes, cli):
        self.db, self.settings, self.nodes, self.cli = database, settings, nodes, cli
        self.dao = AccountDao()
        self.logins = {}
        self.mutation_lock = asyncio.Lock()
        self.keepalive_running = set()
        self.keepalive = AccountKeepalive(self)

    async def list(self, page, page_size, node_id=None):
        filters = [Account.node_id == node_id] if node_id else []

        def query(db):
            items, total = self.dao.page(db, filters=filters, page=page, page_size=page_size)
            return {"items": [record(item) for item in items], "total": total}

        return await self.db.run(query)

    async def get(self, account_id):
        account = await self.db.run(lambda db: self.dao.get(db, account_id))
        result = record(account)
        if account_id in self.logins:
            result["login_url"] = self.logins[account_id]["url"]
        return result

    def config_path(self, account):
        path = safe_path(self.settings.accounts_dir, account.id)
        if path.resolve() != Path(account.config_dir).resolve():
            raise AppError(409, "账号目录与当前节点配置不一致")
        return path

    def select_for_workspace(self, db, account_id):
        account = self.dao.get(db, account_id, lock=True)
        if account.node_id != self.nodes.node_id:
            raise AppError(409, "账号不属于目标节点")
        if account.auth_status != "logged_in" or (
            account.expires_at and account.expires_at <= time.time() * 1000
        ):
            raise AppError(503, "所选账号未登录或认证已过期")
        return account

    async def random_for_workspace(self):
        now = time.time() * 1000

        def choose(db):
            accounts = db.scalars(
                select(Account)
                .where(
                    Account.auth_status == "logged_in",
                    or_(Account.expires_at.is_(None), Account.expires_at > now),
                )
            ).all()
            available = [
                account
                for account in accounts
                if self.nodes.is_online(db.get(Node, account.node_id))
            ]
            if not available:
                raise AppError(503, "没有可用的已登录账号")
            return random.choice(available)

        return await self.db.run(choose)

    async def models(self, account_id, require_logged_in=True):
        account = await self.db.run(lambda db: self.dao.get(db, account_id))
        if require_logged_in and account.auth_status != "logged_in":
            raise AppError(409, "账号尚未登录")
        raw = await self.cli.models(self.config_path(account))
        models = []
        for start in (raw.find("{"), raw.find("[")):
            if start < 0:
                continue
            try:
                data = json.loads(raw[start:])
            except ValueError:
                continue
            entries = data.get("models", []) if isinstance(data, dict) else data
            if isinstance(entries, list):
                for entry in entries:
                    if isinstance(entry, str):
                        models.append({"value": entry, "label": entry, "description": ""})
                    elif isinstance(entry, dict):
                        value = entry.get("value", entry.get("id", entry.get("model")))
                        if value is None or isinstance(value, str) and value:
                            models.append({
                                "value": value,
                                "label": entry.get("label") or value or "Default (recommended)",
                                "description": entry.get("description") or "",
                            })
            break
        return {"models": models, "raw": raw}

    async def refresh(self, account):
        try:
            return await self._refresh_status(account)
        except Exception:
            logger.exception("账号认证状态检查失败 account_id=%s", account.id)
            raise

    async def _refresh_status(self, account):
        status = await self.cli.auth_status(self.config_path(account))
        login_pending = account.id in self.logins

        def update(db):
            item = self.dao.get(db, account.id, lock=True)
            logged_in = status.get("loggedIn") is True
            if logged_in:
                item.auth_status = "expired" if status.get("expired") else "logged_in"
            elif login_pending:
                # 一次事务保存等待状态，避免前端读到中间的 not_login 并停止轮询。
                item.auth_status = "waiting_login"
            else:
                item.auth_status = "expired" if status.get("expired") else "not_login"
            if logged_in:
                if not status.get("accountId"):
                    raise AppError(502, "认证状态缺少 accountId")
                item.account_id = str(status["accountId"])
                item.auth_provider = status.get("authProvider") or "unknown"
                item.expires_at = status.get("expiresAt")
            return item.auth_status

        return await self.db.run(update)

    async def login(self, body):
        async with self.mutation_lock:
            if body.account_id in self.keepalive_running:
                raise AppError(409, '该账号正在保活，请稍后重试登录')
            if body.account_id:
                account = await self.db.run(lambda db: self.dao.get(db, body.account_id))
                account_id = account.id
                if body.node_id and body.node_id != account.node_id:
                    raise AppError(409, "账号不能迁移至其他节点")
                if account_id in self.logins:
                    return {
                        "login_id": account_id,
                        "account_id": account_id,
                        "status": "waiting_login",
                        "login_url": self.logins[account_id]["url"],
                    }
                directory = self.config_path(account)
                directory.mkdir(mode=0o700, exist_ok=True)
                await self.db.run(
                    lambda db: setattr(self.dao.get(db, account_id), "auth_status", "waiting_login")
                )
            else:
                account_id = f"account-{uuid4().hex}"
                directory = safe_path(self.settings.accounts_dir, account_id)
                directory.mkdir(mode=0o700)
                try:
                    account = await self.db.run(
                        lambda db: self.dao.add(
                            db,
                            id=account_id,
                            node_id=self.nodes.node_id,
                            account_name=body.account_name,
                            config_dir=str(directory),
                            auth_status="waiting_login",
                        )
                    )
                except BaseException:
                    remove_managed_dir(self.settings.accounts_dir, directory)
                    raise
            ready = asyncio.get_running_loop().create_future()
            entry = {"url": None, "task": None}
            self.logins[account_id] = entry
            entry["task"] = asyncio.create_task(self._watch_login(account, ready, entry))
        try:
            await asyncio.wait_for(asyncio.shield(ready), self.settings.login_url_timeout)
        except asyncio.TimeoutError:
            pass
        item = await self.get(account_id)
        return {
            "login_id": account_id,
            "account_id": account_id,
            "status": item["auth_status"],
            "login_url": entry["url"],
        }

    async def _watch_login(self, account, ready, entry):
        process, reader = None, None
        output_tail = bytearray()
        try:
            path = self.config_path(account)
            logger.info("开始账号登录 account_id=%s config_dir=%s", account.id, path)
            process = await self.cli.spawn(
                ["auth", "login"],
                cwd=path,
                config_dir=path,
                merge_stderr=True,
            )

            async def capture_url():
                while line := await process.stdout.readline():
                    output_tail.extend(redact_output(line).encode("utf-8"))
                    del output_tail[:-8192]
                    text = re.sub(r"\x1b\[[0-9;]*m", "", line.decode("utf-8", errors="replace"))
                    match = re.search(r"https?://[^\s<>\"']+", text)
                    if match:
                        entry["url"] = match.group(0)
                        if not ready.done():
                            ready.set_result(True)

            reader = asyncio.create_task(capture_url())
            async with async_timeout(self.settings.login_timeout):
                while True:
                    await asyncio.sleep(self.settings.login_poll_seconds)
                    if reader.done():
                        reader.result()
                    state = await self.refresh(account)
                    if state == "logged_in":
                        logger.info("账号登录成功 account_id=%s", account.id)
                        return
                    if process.returncode is not None and process.returncode != 0:
                        raise AppError(
                            502, f"CodeAgent 登录进程异常退出，退出码 {process.returncode}"
                        )
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception(
                "账号登录失败 account_id=%s pid=%s exit_code=%s login_output=%s",
                account.id,
                process.pid if process else None,
                process.returncode if process else None,
                redact_output(bytes(output_tail)),
            )
            try:
                await self.db.run(
                    lambda db: setattr(self.dao.get(db, account.id), "auth_status", "error")
                )
            except Exception:
                logger.exception("保存账号登录失败状态时数据库不可用")
        finally:
            if process:
                await stop_process(process, self.settings.cancel_grace_seconds)
            if reader:
                reader.cancel()
                with contextlib.suppress(asyncio.CancelledError, ValueError):
                    await reader
            if not ready.done():
                ready.set_result(False)
            self.logins.pop(account.id, None)

    def replacement_query(self, workspace, account_id):
        return select(Account).join(WorkspaceAccount, WorkspaceAccount.account_id == Account.id).where(
            WorkspaceAccount.workspace_id == workspace.id, Account.id != account_id,
            WorkspaceAccount.available.is_(True),
            Account.node_id == workspace.node_id, Account.auth_status == 'logged_in',
            or_(Account.expires_at.is_(None), Account.expires_at > time.time() * 1000),
        ).order_by(Account.create_time, Account.id)

    async def replacement_options(self, account_id):
        def query(db):
            self.dao.get(db, account_id)
            workspaces = db.scalars(select(Workspace).where(or_(
                Workspace.id.in_(select(WorkspaceAccount.workspace_id).where(WorkspaceAccount.account_id == account_id)),
                Workspace.id.in_(select(AgentSession.workspace_id).where(AgentSession.account_id == account_id)),
                Workspace.account_id == account_id,
            )).order_by(Workspace.id)).all()
            return {'workspaces': [{
                'workspace_id': w.id, 'name': w.name, 'node_id': w.node_id,
                'candidates': [{'id': a.id, 'name': a.account_name or a.account_id or a.id,
                                'expires_at': a.expires_at}
                               for a in db.scalars(self.replacement_query(w, account_id))],
            } for w in workspaces]}
        return await self.db.run(query)

    async def delete(self, account_id, replacements=None):
        async with self.mutation_lock:
            if account_id in self.keepalive_running:
                raise AppError(409, '该账号正在保活，请稍后重试删除')
            if account_id in self.logins:
                raise AppError(409, '账号正在登录，请等待登录结束后删除')
            def remove(db):
                account = self.dao.get(db, account_id, lock=True)
                workspaces = db.scalars(select(Workspace).where(or_(
                    Workspace.id.in_(select(WorkspaceAccount.workspace_id).where(WorkspaceAccount.account_id == account_id)),
                    Workspace.id.in_(select(AgentSession.workspace_id).where(AgentSession.account_id == account_id)),
                    Workspace.account_id == account_id,
                )).order_by(Workspace.id).with_for_update()).all()
                if replacements is not None and set(replacements) != {w.id for w in workspaces}:
                    raise AppError(409, '请为每个关联工作区选择替代账号；工作区关联可能已变化，请重新打开删除窗口')
                for workspace in workspaces:
                    self.reassign_workspace(db, workspace, account_id,
                        replacements[workspace.id] if replacements is not None else None)
                db.flush()
                for member in db.scalars(select(AccountGroupMember).where(AccountGroupMember.account_id == account_id)):
                    if not db.scalar(select(AccountGroupMember.account_id).where(AccountGroupMember.group_id == member.group_id,
                            AccountGroupMember.account_id != account_id).limit(1)):
                        raise AppError(409, '该账号是账号组的最后一个账号，请先在账号组添加替代账号')
                    db.delete(member)
                db.flush()
                self.dao.delete(db, account)
                return account
            account = await self.db.run(remove)
            cleanup = True
            try:
                await to_thread(remove_managed_dir, self.settings.accounts_dir, self.config_path(account))
            except FileNotFoundError:
                pass
            except Exception:
                cleanup = False
                logger.exception('账号已删除，但本地凭据目录清理失败 account_id=%s', account_id)
        return {"success": True, "credentials_cleanup": cleanup}

    def reassign_workspace(self, db, workspace, account_id, replacement_account_id=None):
        if workspace.status != 'ready':
            raise AppError(409, f'工作区 {workspace.id} 尚未就绪，暂不能移除账号')
        sessions = db.scalars(select(AgentSession).where(
            AgentSession.workspace_id == workspace.id, AgentSession.account_id == account_id
        ).order_by(AgentSession.id).with_for_update()).all()
        if any(s.status in ('running', 'deleting') for s in sessions):
            raise AppError(409, f'工作区 {workspace.id} 存在该账号正在执行或删除的会话，请先停止或等待结束')
        statement = self.replacement_query(workspace, account_id)
        if replacement_account_id is not None:
            statement = statement.where(Account.id == replacement_account_id)
        replacement = db.scalar(statement.limit(1).with_for_update())
        if replacement is None:
            raise AppError(409, f'工作区 {workspace.id} 没有可用的替代账号，或所选账号已失效。请先启用、重新登录已有账号，或添加一个已登录且未过期的同节点账号')
        for session in sessions:
            session.account_id = replacement.id
            session.codeagent_session_id = None
            session.current_pid = None
            db.add(SessionMessage(id=f'msg_{uuid4().hex}', session_id=session.id, role='system',
                content='原账号已移除，会话已切换到工作区其他账号。平台历史保留，下次执行将建立新的 CodeAgent 上下文。'))
        if workspace.account_id == account_id:
            workspace.account_id = replacement.id
        link = db.get(WorkspaceAccount, (workspace.id, account_id))
        if link:
            db.delete(link)

    async def close(self):
        await self.keepalive.close()
        tasks = [entry["task"] for entry in self.logins.values()]
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
