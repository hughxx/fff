#!/usr/bin/env bash
set -euo pipefail

release_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ -n "${PYTHON_BIN:-}" ]]; then
    python_command="$PYTHON_BIN"
elif [[ -x "$release_dir/.venv/bin/python" ]]; then
    python_command="$release_dir/.venv/bin/python"
else
    python_command="python3"
fi

cd "$release_dir/backend"
exec "$python_command" run.py "$@"
