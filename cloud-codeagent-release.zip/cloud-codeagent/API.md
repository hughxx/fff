# 后端接口文档

本文档对应当前 FastAPI 实现。服务启动后可访问 `/docs` 查看交互式 OpenAPI 页面；以下示例使用对外统一前缀 `/api`。同一业务路由也可省略 `/api` 调用。当前平台不要求 API Key；部署时应由所在网络控制访问范围。

## 通用约定

- 基础地址示例：`http://<host>:<port>/api`。JSON 请求使用 `Content-Type: application/json`；Skill 上传使用 `application/zip`，请求体直接是 ZIP 二进制，不是 multipart 表单。
- 列表响应为 `{"items": [...], "total": 0}`。支持分页的列表使用 `page`（从 1 开始，默认 1）和 `page_size`（1～200，默认 20）；Skill 列表一次返回全部，不支持分页。
- 时间字段为 UTC ISO 8601 字符串，或 `null`；账号 `expires_at` 为毫秒时间戳，或 `null`。
- 成功删除通常返回 `{"success": true}`。错误返回 `{"detail": "错误说明"}`；参数校验错误的 `detail` 是数组。
- 常见状态码：`400` 非法路径/ZIP/业务输入，`404` 资源不存在，`409` 冲突或关联资源未清理，`413` 文件/ZIP 超限，`415` 不支持的文件编码或媒体类型，`422` 请求参数校验失败，`502` 本地 CLI 或节点转发失败，`503` 节点/数据库/账号不可用，`504` 执行超时。实际错误说明以响应为准。
- 多节点模式下，工作区、账号、会话相关请求会转发到资源所属节点。创建工作区可指定 `account_id`；省略时从集群中已登录、未过期且节点在线的账号中随机选择，工作区落在实际选中账号所属节点。

## 健康与节点

| 方法 | 路径 | 参数 | 返回 |
| --- | --- | --- | --- |
| GET | `/health` 或 `/api/health` | 无 | `{"status":"ok","node_id":"..."}` |
| GET | `/api/nodes` | `page`, `page_size` | 节点分页列表 |
| GET | `/api/nodes/{node_id}` | 路径中的节点 ID | 节点详情 |

节点对象包含 `id`、`node_name`、`node_host`、`node_port`、`status`（`online`/`offline`）、`running_count`、`cpu_usage`、`memory_usage`、`last_heartbeat`、`create_time`、`update_time`，以及 `accounts_count`、`workspaces_count` 资源计数。

## 账号

| 方法 | 路径 | 参数/请求体 | 返回 |
| --- | --- | --- | --- |
| GET | `/api/accounts` | 可选 `node_id`, `page`, `page_size` | 账号分页列表 |
| GET | `/api/accounts/{account_id}` | 无 | 数据库中保存的账号详情，不触发 CLI 认证检查 |
| POST | `/api/accounts/login` | JSON：`node_id?`, `account_id?`, `account_name?` | `202`，登录信息 |
| GET | `/api/accounts/{account_id}/models` | 无 | `{"models":[{"value":null,"label":"Default (recommended)","description":"..."},{"value":"Glm-5.2","label":"Glm-5.2","description":"..."}],"raw":"..."}`；按该账号执行 `codeagent models -v` |
| DELETE | `/api/accounts/{account_id}` | 无 | `{"success":true}` |

首次登录可发送 `{"node_id":"node-01","account_name":"开发账号"}`；`node_id` 省略时使用当前节点。重新登录已有账号时发送 `{"account_id":"account-..."}`。登录响应为 `{"login_id":"...","account_id":"...","status":"waiting_login","login_url":"https://..."}`；`login_url` 可能暂时为 `null`。调用方打开授权链接，并轮询账号详情查看 `auth_status`。账号详情还包含节点、CLI 身份、认证提供方、到期时间、配置目录和创建/更新时间；认证状态可能为 `waiting_login`、`logged_in`、`not_login`、`expired` 或 `error`。有工作区绑定的账号不能直接删除。


```bash
curl -X POST 'http://<host>:<port>/api/accounts/login' \
  -H 'Content-Type: application/json' \
  -d '{"account_name":"开发账号"}'
curl 'http://<host>:<port>/api/accounts/account-xxx'
```

## 工作区

| 方法 | 路径 | 参数/请求体 | 返回 |
| --- | --- | --- | --- |
| GET | `/api/workspaces` | 可选 `node_id`, `page`, `page_size` | 工作区分页列表 |
| POST | `/api/workspaces` | JSON：`name`，可选 `account_id`, `python_version` | `201`，工作区对象 |
| GET | `/api/workspaces/{workspace_id}` | 无 | 工作区对象 |
| DELETE | `/api/workspaces/{workspace_id}` | 无 | `{"success":true}` |
| POST | `/api/workspaces/{workspace_id}/commands` | JSON：`command`，可选 `timeout_seconds` | `{"exit_code":0,"stdout":"...","stderr":"...","timed_out":false}` |
| POST | `/api/workspaces/{workspace_id}/command-tasks` | JSON：`command`，可选 `timeout_seconds` | `202`，`{"task_id":"task_...","status":"queued"}` |
| GET | `/api/workspaces/{workspace_id}/command-tasks/{task_id}` | 无 | 异步命令任务详情 |
| POST | `/api/workspaces/{workspace_id}/command-tasks/{task_id}/cancel` | 无 | `{"success":true,"status":"cancelled"}` |

`name` 同时是工作区 ID，只允许以英文字母或数字开头，后续使用英文字母、数字、`_`、`-`，最长 128 字符。`account_id` 可选；不传时随机选择集群中可用的已登录账号。工作区创建在实际选中账号所属节点，响应中的 `account_id` 表示最终账号。`python_version` 可选，支持 `3.10`（默认）和 `3.12`。工作区对象包含 `id`、`name`、`node_id`、`account_id`、`accounts`、`python_version`、`status`、`create_time`、`update_time`；后端通过 ID 定位目录，接口不暴露服务器路径。状态通常为 `ready`，也可能为 `creating`、`error`、`deleting`。删除工作区前须先删除其会话。

命令接口在工作区所属节点上运行系统 shell，工作目录为该工作区根目录，使用后端服务进程的系统用户权限。`timeout_seconds` 默认 60 秒、最大 1800 秒；超时会终止命令并返回 `timed_out=true`。stdout 与 stderr 合计最多 16 MiB，超限返回 413。非零退出码仍返回 HTTP 200，调用方应检查 `exit_code`。不支持交互式输入，输入流关闭。路径转发和节点归属规则与文件接口相同。

异步 Command Task 使用相同的 shell、工作目录、Python 环境、输出限制和进程组终止方式。创建接口的 `timeout_seconds` 默认及最大值均为 1800 秒，并立即返回任务 ID。任务状态为 `queued`、`running`、`success`、`failed` 或 `cancelled`；超时任务状态为 `failed` 且 `timed_out=true`。查询结果包含 `task_id`、`workspace_id`、`command`、`timeout_seconds`、`status`、`exit_code`、`stdout`、`stderr`、`timed_out`、`create_time` 和 `update_time`。运行期间查询可看到已经收集的输出，任务结束后结果保存在数据库。服务重启时仍处于 `queued` 或 `running` 的本节点任务会标记为 `failed`，错误信息为“服务重启，命令任务执行中断”。取消接口会终止整个命令进程组。删除工作区前必须先取消运行中的命令任务；删除工作区会同时删除其已结束的任务记录。

```bash
curl -X POST 'http://<host>:<port>/api/workspaces/demo/command-tasks' \
  -H 'Content-Type: application/json' \
  -d '{"command":"python3 script.py","timeout_seconds":1800}'
curl 'http://<host>:<port>/api/workspaces/demo/command-tasks/task_xxx'
curl -X POST 'http://<host>:<port>/api/workspaces/demo/command-tasks/task_xxx/cancel'
```

```bash
curl -X POST 'http://<host>:<port>/api/workspaces' \
  -H 'Content-Type: application/json' -d '{"name":"demo"}'
```

## 文件

以下路径中的 `{workspace_id}` 为工作区 ID，文件 `path` 相对于工作区根目录；目录列表默认 `path=.`。路径不允许绝对路径、`..`、符号链接或 Windows junction。文本接口只处理 UTF-8；单个文本文件大小上限由后端配置控制，默认 2 MiB。

| 方法 | 路径 | 参数/请求体 | 返回 |
| --- | --- | --- | --- |
| GET | `/api/workspaces/{workspace_id}/files` | 查询参数 `path`，默认 `.` | `{"path":".","items":[...]}` |
| GET | `/api/workspaces/{workspace_id}/files/content` | 必填查询参数 `path` | `{"path":"...","content":"..."}` |
| GET | `/api/workspaces/{workspace_id}/files/download` | 必填查询参数 `path` | 原始文件字节，含下载文件名 |
| POST | `/api/workspaces/{workspace_id}/files/directories` | JSON：`path` | `201`，`{"path":"...","type":"directory"}` |
| POST | `/api/workspaces/{workspace_id}/files/upload` | 查询参数 `path`，请求体为原始文件字节，`Content-Type: application/octet-stream` | `201`，`{"path":"...","type":"file","size":N}` |
| PUT | `/api/workspaces/{workspace_id}/files` | JSON：`path`, `content` | `{"success":true,"path":"..."}` |
| DELETE | `/api/workspaces/{workspace_id}/files` | 必填查询参数 `path` | `{"success":true}` |

目录项包含 `name`、`path`、`type`（`file`、`directory` 或 `symlink`）、`size`。文件上传不限制格式，单文件上限默认 512 MiB；上传嵌套路径会自动创建父目录，目标已存在返回 409。PUT 只编辑已有 UTF-8 文本文件，默认上限 2 MiB；读取二进制文件请使用下载接口。删除目录会递归删除其内容。

## Skill ZIP

| 方法 | 路径 | 请求体 | 返回 |
| --- | --- | --- | --- |
| GET | `/api/workspaces/{workspace_id}/skills` | 无 | `{"items":[...],"total":N}` |
| POST | `/api/workspaces/{workspace_id}/skills` | 原始 ZIP，`Content-Type: application/zip` | `201`，Skill 信息 |
| GET | `/api/workspaces/{workspace_id}/skills/{name}` | 无 | Skill 详情，含 `SKILL.md` 文本 |
| PUT | `/api/workspaces/{workspace_id}/skills/{name}` | 原始 ZIP，`Content-Type: application/zip` | 替换整个 Skill 目录后的信息 |
| DELETE | `/api/workspaces/{workspace_id}/skills/{name}` | 无 | `{"success":true}` |

一个 ZIP 只包含一个 Skill。支持包内直接放 `SKILL.md` 和其他文件，也支持 `my-skill/`、`skills/my-skill/`、`.cac/skills/my-skill/` 作为根目录。安装位置为工作区的 `.cac/skills/<name>/`，所有其他文件和子目录一同保留。`SKILL.md` 必须是 UTF-8，开头须有 YAML front matter，例如：

```markdown
---
name: my-skill
description: 示例 Skill
---

# 使用说明
```

目录名、front matter 的 `name` 和 PUT 路径中的 `{name}` 必须一致；名称只能使用小写字母、数字及中划线，最长 64 字符。ZIP 上限 16 MiB，最多 512 个条目，单文件解压后上限 16 MiB，总解压量上限 64 MiB。非法路径、重复文件、符号链接等会被拒绝。PUT 是整个目录替换，旧 ZIP 中有而新 ZIP 中没有的文件会被移除。列表项含 `name`、`description`、`files`；详情额外含 `content`（`SKILL.md` 文本）。

```bash
curl -X POST 'http://<host>:<port>/api/workspaces/demo/skills' \
  -H 'Content-Type: application/zip' --data-binary '@my-skill.zip'
curl -X PUT 'http://<host>:<port>/api/workspaces/demo/skills/my-skill' \
  -H 'Content-Type: application/zip' --data-binary '@my-skill-updated.zip'
```

## 会话与消息

| 方法 | 路径 | 参数/请求体 | 返回 |
| --- | --- | --- | --- |
| GET | `/api/sessions` | 可选 `workspace_id`, `keyword`（搜索标题）, `created_by`, `page`, `page_size` | 会话分页列表 |
| POST | `/api/sessions` | JSON：`workspace_id`，可选 `account_id`, `title`, `created_by`；不传账号时从工作区可用账号中随机选择 | `201`，会话对象 |
| GET | `/api/sessions/{session_id}` | 无 | 会话详情，额外含 `messages` |
| POST | `/api/sessions/{session_id}/messages` | JSON：`{"input":"..."}`；可选 `stream=true/false`（默认 false） | `200`，JSON 或 NDJSON |
| POST | `/api/sessions/{session_id}/cancel` | 无 | `{"success":true,"status":"..."}` |
| DELETE | `/api/sessions/{session_id}` | 无 | `{"success":true,"cli_cleanup":true}`；CLI 清理失败时为 `false`，不阻塞平台会话删除 |

会话对象中的 ID 字段叫 `session_id`，并包含 `workspace_id`、实际选中的 `account_id`、`node_id`、`codeagent_session_id`、`title`、`status`、`created_by`、`created_at`、`updated_at`。详情中的 `messages` 按时间排序，包含消息 ID、`session_id`、`role`、`content`、`raw_result`、`created_at`。会话状态可见 `ready`、`running`、`idle`、`error`、`cancelled` 等。`created_by` 仅是筛选标签，不是认证身份。

`stream=false` 返回 CodeAgent 最终 `result` JSON 对象。`stream=true` 返回 `application/x-ndjson`，每行一个 CodeAgent JSON 事件；最后一行为 `type=result` 事件。事件字段由本地 CLI 输出决定，平台会原样转发中间事件；平台错误会用 `subtype=error_platform`、`is_error=true` 的最终事件表示。流式连接断开会取消本次执行；同一会话同一时刻只能运行一条消息。

```bash
curl -X POST 'http://<host>:<port>/api/sessions' \
  -H 'Content-Type: application/json' -d '{"workspace_id":"demo","title":"首次会话"}'

curl -N -X POST 'http://<host>:<port>/api/sessions/sess_xxx/messages?stream=true' \
  -H 'Content-Type: application/json' -d '{"input":"请介绍当前工作区"}'
```

JSON 请求不允许未定义字段。调用消息接口前，工作区须就绪且其绑定账号须已登录；否则接口会返回对应业务错误。

发送消息请求体支持可选 `model`，例如 `{"input":"继续分析","model":"Glm-5.2"}`。优先使用本轮 `model`，其次使用该工作区与该账号的 `default_model`；两者都未设置时由 CodeAgent 选择默认模型。模型值作为独立的 `--model` 参数传给 CLI，不通过 shell 拼接。
# ZIP 文件夹上传

工作区账号与模型：`POST /api/workspaces/{workspace_id}/accounts` 请求体 `{"account_id":"account-..."}`，关联同节点账号，返回工作区对象；`DELETE /api/workspaces/{workspace_id}/accounts/{account_id}` 移除关联，返回工作区对象；`PUT /api/workspaces/{workspace_id}/accounts/{account_id}/model` 请求体 `{"model":"Glm-5.2-Auto"}` 或 `{"model":null}`，设置该工作区使用该账号时的默认模型。工作区对象的 `accounts` 是 `[{"account_id":"...","default_model":null}]`。新建会话默认不传 `account_id`，后端从工作区关联且已登录、未过期的账号中随机选择；显式传入时必须属于工作区。模型优先级：本轮消息 `model` > 工作区账号关联的 `default_model` > CodeAgent 默认模型。空默认模型不会产生 `--model` 参数。

工作区 Python：`POST /api/workspaces` 可选传 `"python_version":"3.10"` 或 `"3.12"`，默认 3.10。`PUT /api/workspaces/{workspace_id}/python` 请求体 `{"python_version":"3.12"}`，返回更新后的工作区对象。由工作区所属节点验证解释器已安装；未登记版本返回 422，解释器路径不存在返回 503。更新只影响之后启动的命令和 CodeAgent 会话轮次，不影响正在运行的进程。


`POST /api/workspaces/{workspace_id}/files/upload-zip?path=.`：请求头为 `Content-Type: application/zip`，请求体为原始 ZIP 字节。`path` 默认为工作区根目录，也可指定已有的相对目录；ZIP 内容直接解压到该目录，不额外创建 ZIP 同名目录。传 `create_folder=true` 时，`path` 必须是尚不存在的新目录，服务端将 ZIP 内容放入其中。成功返回 HTTP 201 和 `{"path":".","type":"directory","size":压缩包字节数}`。同名目录会合并；已有同路径文件或文件与目录类型冲突返回 409。ZIP 无效或包含越界路径、符号链接返回 400，压缩包或解压内容超过上传大小限制返回 413。支持跨节点转发。
前端“上传文件夹”弹窗可选择本地文件夹或 ZIP，并可勾选“为 ZIP 创建同名文件夹”；默认不勾选。ZIP 作为临时上传文件解压，成功或失败都会清理临时 ZIP，不会在工作区留下压缩包。文件浏览器打开期间每 3 秒读取一次当前目录列表。
# 会话异步执行

账号删除与移除规则：`DELETE /api/accounts/{id}` 会在一个数据库事务中，将各关联工作区的会话迁到该工作区另一个已登录、未过期的同节点账号，并移除旧关联。替代账号按创建时间、ID 顺序选择。任一工作区无可用替代账号或旧账号存在 running/deleting 会话，返回 409 并整体回滚。`DELETE /api/workspaces/{workspace_id}/accounts/{account_id}` 对单工作区应用同样规则。平台历史保留并增加切换说明，旧 codeagent_session_id 清空，下次执行建立新的 CLI 上下文，使用新账号的工作区默认模型。不会复制旧 CLI 本地历史。全局删除返回 `{ "success": true, "credentials_cleanup": true }`；若数据库删除成功但凭据目录清理失败，后者为 false，详细错误写服务日志。

- `GET /api/sessions/{session_id}/tasks/{task_id}/events?after=0`：可断线重连的 NDJSON 事件订阅，按 event_id 回放，不因订阅断开取消任务。会话详情 active_task_id 用于恢复正在执行的任务。新增 t_ca_session_task_event 表自动创建。

- `POST /api/sessions/{session_id}/tasks`：请求 `{ "input": "任务内容", "model": "Glm-5.2" }`（model 可选），立即返回 202 和 task_id、session_id、status。
- `GET /api/sessions/{session_id}/tasks/{task_id}`：查询持久化任务状态、最终 result、error 和时间。
- `POST /api/sessions/{session_id}/tasks/{task_id}/cancel`：取消指定任务，已结束则返回实际终态。

详细参数和完整返回示例见 USER_API.md 的“CodeAgent 会话异步任务”。异步任务独立于请求连接，无执行时长上限；同一会话不允许并行执行。新增 t_ca_session_task 表由启动自动创建，无需清空数据。异步会话由独立运行器执行，Web 后端重启后恢复查询及取消，不重新启动 CodeAgent；机器及执行进程重启不自动续跑。
# 通用文件查询扩展

原有 `GET /api/workspaces/{workspace_id}/files?path=.` 默认返回不变。可选 `include_counts=true` 给目录增加 counts；`count_depth=1`（1～100）控制每个目录内部统计层数；`max_entries=100000`（1～1000000）限制整个 counts 请求扫描条目数。

新增/更新：

- `GET /api/workspaces/{workspace_id}/files/stats`：path 默认 `.`，mode 为 recursive（默认）或 direct；max_depth 可选 1～100，recursive 不传则不限深度，direct 固定 1；max_entries 默认 100000，最大 1000000。
- `GET /api/workspaces/{workspace_id}/files/tree`：path 默认 `.`，max_depth 默认 3（1～100），max_entries 默认 10000（1～100000）。返回嵌套 items，目录带 expanded，已展开目录带 children。

统计字段：file_count、directory_count（不含起点）、total_size_bytes、skipped_symlink_count、other_count、depth_limited。没有叶子统计模式。层数 1 为直属内容，深度边界目录计入 directory_count 但不扫描内部；depth_limited=true 表示不能将数量当成完整递归总数。超过条目预算返回 413，不返回部分结果；其他错误为 400/403/404/409/422。

路径均相对工作区，支持节点转发，不跟随符号链接，不执行 Shell。完整参数、响应示例和旧接口兼容约定见 USER_API.md 的“通用文件浏览、统计与目录树”。
