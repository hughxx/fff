# 后端接口文档

本文档对应当前 FastAPI 实现。服务启动后可访问 `/docs` 查看交互式 OpenAPI 页面；以下示例使用对外统一前缀 `/api`。同一业务路由也可省略 `/api` 调用。当前平台不要求 API Key；部署时应由所在网络控制访问范围。

## 通用约定

- 基础地址示例：`http://<host>:<port>/api`。JSON 请求使用 `Content-Type: application/json`；Skill 上传使用 `application/zip`，请求体直接是 ZIP 二进制，不是 multipart 表单。
- 列表响应为 `{"items": [...], "total": 0}`。支持分页的列表使用 `page`（从 1 开始，默认 1）和 `page_size`（1～200，默认 20）；Skill 列表一次返回全部，不支持分页。
- 时间字段为 UTC ISO 8601 字符串，或 `null`；账号 `expires_at` 为毫秒时间戳，或 `null`。
- 成功删除通常返回 `{"success": true}`。错误返回 `{"detail": "错误说明"}`；参数校验错误的 `detail` 是数组。
- 常见状态码：`400` 非法路径/ZIP/业务输入，`404` 资源不存在，`409` 冲突或关联资源未清理，`413` 文件/ZIP 超限，`415` 不支持的文件编码或媒体类型，`422` 请求参数校验失败，`502` 本地 CLI 或节点转发失败，`503` 节点/数据库/账号不可用，`504` 执行超时。实际错误说明以响应为准。
- 多节点请求自动转发到资源所属节点。创建工作区可选传 `group_id`；不传时自动创建工作区同名组，工作区在该账号组所属节点创建。详见 [账号组与模型配置](ACCOUNT_GROUPS.md)。

## 健康与节点

| 方法 | 路径 | 参数 | 返回 |
| --- | --- | --- | --- |
| GET | `/health` 或 `/api/health` | 无 | `{"status":"ok","node_id":"..."}` |
| GET | `/api/nodes` | `page`, `page_size` | 节点分页列表 |
| GET | `/api/nodes/{node_id}` | 路径中的节点 ID | 节点详情 |

节点对象包含 `id`、`node_name`、`node_host`、`node_port`、`status`（`online`/`offline`）、`running_count`、`cpu_usage`、`memory_usage`、`last_heartbeat`、`create_time`、`update_time`，以及 `accounts_count`、`workspaces_count` 资源计数。

## 账号

| 方法 | 路径 | 参数/请求体 | 返回 |
| --- | --- | --- | --- |
| GET | `/api/accounts` | 可选 `node_id`, `page`, `page_size` | 账号分页列表 |
| GET | `/api/accounts/{account_id}` | 无 | 数据库中保存的账号详情，不触发 CLI 认证检查 |
| POST | `/api/accounts/login` | JSON：`node_id?`, `account_id?`, `account_name?` | `202`，登录信息 |
| GET | `/api/accounts/{account_id}/models` | 无 | `{"models":[{"value":null,"label":"Default (recommended)","description":"..."},{"value":"Glm-5.2","label":"Glm-5.2","description":"..."}],"raw":"..."}`；按该账号执行 `codeagent models -v` |
| DELETE | `/api/accounts/{account_id}` | 无 | `{"success":true}` |

首次登录可发送 `{"node_id":"node-01","account_name":"开发账号"}`；`node_id` 省略时使用当前节点。重新登录已有账号时发送 `{"account_id":"account-..."}`。登录响应为 `{"login_id":"...","account_id":"...","status":"waiting_login","login_url":"https://..."}`；`login_url` 可能暂时为 `null`。调用方打开授权链接，并轮询账号详情查看 `auth_status`。账号详情还包含节点、CLI 身份、认证提供方、到期时间、配置目录和创建/更新时间；认证状态可能为 `waiting_login`、`logged_in`、`not_login`、`expired` 或 `error`。删除账号会将其会话转给工作区其他可用账号；无替代账号或仍有执行中会话时拒绝删除。


```bash
curl -X POST 'http://<host>:<port>/api/accounts/login' \
  -H 'Content-Type: application/json' \
  -d '{"account_name":"开发账号"}'
curl 'http://<host>:<port>/api/accounts/account-xxx'
```

## 工作区

| 方法 | 路径 | 参数/请求体 | 返回 |
| --- | --- | --- | --- |
| GET | `/api/workspaces` | 可选 `node_id`, `page`, `page_size` | 工作区分页列表 |
| POST | `/api/workspaces` | JSON：`name` 必填；`group_id`、`account_id`、`python_version`、`autoMemoryEnabled` 可选 | `201`，工作区对象 |
| GET | `/api/workspaces/{workspace_id}` | 无 | 工作区对象 |
| DELETE | `/api/workspaces/{workspace_id}` | 无 | `{"success":true}` |
| POST | `/api/workspaces/{workspace_id}/commands` | JSON：`command`，可选 `timeout_seconds` | `{"exit_code":0,"stdout":"...","stderr":"...","timed_out":false}` |
| POST | `/api/workspaces/{workspace_id}/command-tasks` | JSON：`command`，可选 `timeout_seconds` | `202`，`{"task_id":"task_...","status":"queued"}` |
| GET | `/api/workspaces/{workspace_id}/command-tasks/{task_id}` | 无 | 异步命令任务详情 |
| POST | `/api/workspaces/{workspace_id}/command-tasks/{task_id}/cancel` | 无 | `{"success":true,"status":"cancelled"}` |

`name` 同时是工作区 ID，只允许以英文字母或数字开头，后续使用英文字母、数字、`_`、`-`，最长 128 字符。`group_id` 可选；不传时使用指定 account_id 或随机可用账号创建同名组，工作区创建于账号所属节点。`python_version` 支持 `3.10`（默认）和 `3.12`。返回 `id`、`name`、`node_id`、`group_id`、`account_id`、只读 `accounts`、`python_version`、`status`、`create_time`、`update_time`。路径不对外暴露。删除工作区自动删除关联会话历史；执行中任务需先停止。

命令接口在工作区所属节点上运行系统 shell，工作目录为该工作区根目录，使用后端服务进程的系统用户权限。`timeout_seconds` 默认 60 秒、最大 1800 秒；超时会终止命令并返回 `timed_out=true`。stdout 与 stderr 合计最多 16 MiB，超限返回 413。非零退出码仍返回 HTTP 200，调用方应检查 `exit_code`。不支持交互式输入，输入流关闭。路径转发和节点归属规则与文件接口相同。

异步 Command Task 使用相同的 shell、工作目录、Python 环境、输出限制和进程组终止方式。创建接口的 `timeout_seconds` 默认及最大值均为 1800 秒，并立即返回任务 ID。任务状态为 `queued`、`running`、`success`、`failed` 或 `cancelled`；超时任务状态为 `failed` 且 `timed_out=true`。查询结果包含 `task_id`、`workspace_id`、`command`、`timeout_seconds`、`status`、`exit_code`、`stdout`、`stderr`、`timed_out`、`create_time` 和 `update_time`。运行期间查询可看到已经收集的输出，任务结束后结果保存在数据库。异步 Shell 任务由独立运行器执行，Web 重启后可继续查询和取消；运行器已退出但未完成的任务标记 failed，保留已保存输出，不自动重试执行。取消接口会终止整个命令进程组。删除工作区前必须先取消运行中的命令任务；删除工作区会同时删除其已结束的任务记录。

```bash
curl -X POST 'http://<host>:<port>/api/workspaces/demo/command-tasks' \
  -H 'Content-Type: application/json' \
  -d '{"command":"python3 script.py","timeout_seconds":1800}'
curl 'http://<host>:<port>/api/workspaces/demo/command-tasks/task_xxx'
curl -X POST 'http://<host>:<port>/api/workspaces/demo/command-tasks/task_xxx/cancel'
```

```bash
curl -X POST 'http://<host>:<port>/api/workspaces' \
  -H 'Content-Type: application/json' -d '{"name":"demo","group_id":"group-xxx"}'
```

## 文件

以下路径中的 `{workspace_id}` 为工作区 ID，文件 `path` 相对于工作区根目录；目录列表默认 `path=.`。路径不允许绝对路径、`..`、符号链接或 Windows junction。文本接口只处理 UTF-8；单个文本文件大小上限由后端配置控制，默认 2 MiB。

| 方法 | 路径 | 参数/请求体 | 返回 |
| --- | --- | --- | --- |
| GET | `/api/workspaces/{workspace_id}/files` | 查询参数 `path`，默认 `.` | `{"path":".","items":[...]}` |
| GET | `/api/workspaces/{workspace_id}/files/content` | 必填查询参数 `path` | `{"path":"...","content":"..."}` |
| GET | `/api/workspaces/{workspace_id}/files/download` | 必填查询参数 `path` | 原始文件字节，含下载文件名 |
| POST | `/api/workspaces/{workspace_id}/files/directories` | JSON：`path` | `201`，`{"path":"...","type":"directory"}` |
| POST | `/api/workspaces/{workspace_id}/files/upload` | 查询参数 `path`，请求体为原始文件字节，`Content-Type: application/octet-stream` | `201`，`{"path":"...","type":"file","size":N}` |
| PUT | `/api/workspaces/{workspace_id}/files` | JSON：`path`, `content` | `{"success":true,"path":"..."}` |
| DELETE | `/api/workspaces/{workspace_id}/files` | 必填查询参数 `path` | `{"success":true}` |

目录项包含 `name`、`path`、`type`（`file`、`directory` 或 `symlink`）、`size`。文件上传不限制格式，单文件上限默认 512 MiB；上传嵌套路径会自动创建父目录，目标已存在返回 409。PUT 只编辑已有 UTF-8 文本文件，默认上限 2 MiB；读取二进制文件请使用下载接口。删除目录会递归删除其内容。

## Skill ZIP

| 方法 | 路径 | 请求体 | 返回 |
| --- | --- | --- | --- |
| GET | `/api/workspaces/{workspace_id}/skills` | 无 | `{"items":[...],"total":N}` |
| POST | `/api/workspaces/{workspace_id}/skills` | 原始 ZIP，`Content-Type: application/zip` | `201`，Skill 信息 |
| GET | `/api/workspaces/{workspace_id}/skills/{name}` | 无 | Skill 详情，含 `SKILL.md` 文本 |
| PUT | `/api/workspaces/{workspace_id}/skills/{name}` | 原始 ZIP，`Content-Type: application/zip` | 替换整个 Skill 目录后的信息 |
| DELETE | `/api/workspaces/{workspace_id}/skills/{name}` | 无 | `{"success":true}` |

一个 ZIP 只包含一个 Skill。支持包内直接放 `SKILL.md` 和其他文件，也支持 `my-skill/`、`skills/my-skill/`、`.cac/skills/my-skill/` 作为根目录。安装位置为工作区的 `.cac/skills/<name>/`，所有其他文件和子目录一同保留。`SKILL.md` 必须是 UTF-8，开头须有 YAML front matter，例如：

```markdown
---
name: my-skill
description: 示例 Skill
---

# 使用说明
```

目录名、front matter 的 `name` 和 PUT 路径中的 `{name}` 必须一致；名称只能使用小写字母、数字及中划线，最长 64 字符。ZIP 上限 16 MiB，最多 512 个条目，单文件解压后上限 16 MiB，总解压量上限 64 MiB。非法路径、重复文件、符号链接等会被拒绝。PUT 是整个目录替换，旧 ZIP 中有而新 ZIP 中没有的文件会被移除。列表项含 `name`、`description`、`files`；详情额外含 `content`（`SKILL.md` 文本）。

```bash
curl -X POST 'http://<host>:<port>/api/workspaces/demo/skills' \
  -H 'Content-Type: application/zip' --data-binary '@my-skill.zip'
curl -X PUT 'http://<host>:<port>/api/workspaces/demo/skills/my-skill' \
  -H 'Content-Type: application/zip' --data-binary '@my-skill-updated.zip'
```

## 会话与消息

| 方法 | 路径 | 参数/请求体 | 返回 |
| --- | --- | --- | --- |
| GET | `/api/sessions` | 可选 `workspace_id`, `keyword`（搜索标题）, `created_by`, `page`, `page_size` | 会话分页列表 |
| POST | `/api/sessions` | JSON：`workspace_id`，可选 `account_id`, `title`, `created_by`；不传账号时从工作区可用账号中随机选择 | `201`，会话对象 |
| GET | `/api/sessions/{session_id}` | 无 | 会话详情，额外含 `messages` |
| POST | `/api/sessions/{session_id}/messages` | JSON：`{"input":"..."}`；可选 `stream=true/false`（默认 false） | `200`，JSON 或 NDJSON |
| POST | `/api/sessions/{session_id}/cancel` | 无 | `{"success":true,"status":"..."}` |
| DELETE | `/api/sessions/{session_id}` | 无 | `{"success":true,"cli_cleanup":true}`；CLI 清理失败时为 `false`，不阻塞平台会话删除 |

会话对象中的 ID 字段叫 `session_id`，并包含 `workspace_id`、实际选中的 `account_id`、`node_id`、`codeagent_session_id`、`title`、`status`、`created_by`、`created_at`、`updated_at`。详情中的 `messages` 按时间排序，包含消息 ID、`session_id`、`role`、`content`、`raw_result`、`created_at`。会话状态可见 `ready`、`running`、`idle`、`error`、`cancelled` 等。`created_by` 仅是筛选标签，不是认证身份。

`stream=false` 返回 CodeAgent 最终 `result` JSON 对象。`stream=true` 返回 `application/x-ndjson`，每行一个 CodeAgent JSON 事件；最后一行为 `type=result` 事件。事件字段由本地 CLI 输出决定，平台会原样转发中间事件；平台错误会用 `subtype=error_platform`、`is_error=true` 的最终事件表示。流式连接断开会取消本次执行；同一会话同一时刻只能运行一条消息。

```bash
curl -X POST 'http://<host>:<port>/api/sessions' \
  -H 'Content-Type: application/json' -d '{"workspace_id":"demo","title":"首次会话"}'

curl -N -X POST 'http://<host>:<port>/api/sessions/sess_xxx/messages?stream=true' \
  -H 'Content-Type: application/json' -d '{"input":"请介绍当前工作区"}'
```

JSON 请求不允许未定义字段。调用消息接口前，工作区须就绪且其绑定账号须已登录；否则接口会返回对应业务错误。

发送消息支持可选 `model`。优先使用本轮 model，其次使用当前账号组成员配置的具体模型。CLI 始终传具体 `--model`，模型不可用按组成员 fallback 策略处理。详见 [账号组与模型配置](ACCOUNT_GROUPS.md)。
# ZIP 文件夹上传

工作区账号与模型统一在账号组配置。工作区只通过 `PUT /api/workspaces/{workspace_id}/account-group` 切换引用。旧成员增删及模型设置接口返回 409。详见 [账号组与模型配置](ACCOUNT_GROUPS.md)。

工作区 Python：`POST /api/workspaces` 可选传 `"python_version":"3.10"` 或 `"3.12"`，默认 3.10。`PUT /api/workspaces/{workspace_id}/python` 请求体 `{"python_version":"3.12"}`，返回更新后的工作区对象。由工作区所属节点验证解释器已安装；未登记版本返回 422，解释器路径不存在返回 503。更新只影响之后启动的命令和 CodeAgent 会话轮次，不影响正在运行的进程。


`POST /api/workspaces/{workspace_id}/files/upload-zip?path=.`：请求头为 `Content-Type: application/zip`，请求体为原始 ZIP 字节。`path` 默认为工作区根目录，也可指定已有的相对目录；ZIP 内容直接解压到该目录，不额外创建 ZIP 同名目录。传 `create_folder=true` 时，`path` 必须是尚不存在的新目录，服务端将 ZIP 内容放入其中。成功返回 HTTP 201 和 `{"path":".","type":"directory","size":压缩包字节数}`。同名目录会合并；已有同路径文件或文件与目录类型冲突返回 409。ZIP 无效或包含越界路径、符号链接返回 400，压缩包或解压内容超过上传大小限制返回 413。支持跨节点转发。
前端“上传文件夹”弹窗可选择本地文件夹或 ZIP，并可勾选“为 ZIP 创建同名文件夹”；默认不勾选。ZIP 作为临时上传文件解压，成功或失败都会清理临时 ZIP，不会在工作区留下压缩包。文件浏览器打开期间每 3 秒读取一次当前目录列表。
# 会话异步执行

删除账号保留手动替代账号与历史保留能力；不能删除组的最后一个成员，且执行中会话会阻止删除。工作区不再单独移除成员，应编辑账号组或切换组。全局删除返回 `{"success":true,"credentials_cleanup":true}`；清理凭据失败时后者 false，原因写服务日志。

- `GET /api/sessions/{session_id}/tasks/{task_id}/events?after=0`：可断线重连的 NDJSON 事件订阅，按 event_id 回放，不因订阅断开取消任务。会话详情 active_task_id 用于恢复正在执行的任务。新增 t_ca_session_task_event 表自动创建。

- `POST /api/sessions/{session_id}/tasks`：请求 `{ "input": "任务内容", "model": "Glm-5.2" }`（model 可选），立即返回 202 和 task_id、session_id、status。
- `GET /api/sessions/{session_id}/tasks/{task_id}`：查询持久化任务状态、最终 result、error 和时间。
- `POST /api/sessions/{session_id}/tasks/{task_id}/cancel`：取消指定任务，已结束则返回实际终态。

详细参数和完整返回示例见 USER_API.md 的“CodeAgent 会话异步任务”。异步任务独立于请求连接，无执行时长上限；同一会话不允许并行执行。新增 t_ca_session_task 表由启动自动创建，无需清空数据。异步会话由独立运行器执行，Web 后端重启后恢复查询及取消，不重新启动 CodeAgent；机器及执行进程重启不自动续跑。
# 通用文件查询扩展

原有 `GET /api/workspaces/{workspace_id}/files?path=.` 默认返回不变。可选 `include_counts=true` 给目录增加 counts；`count_depth=1`（1～100）控制每个目录内部统计层数；`max_entries=100000`（1～1000000）限制整个 counts 请求扫描条目数。

新增/更新：

- `GET /api/workspaces/{workspace_id}/files/stats`：path 默认 `.`，mode 为 recursive（默认）或 direct；max_depth 可选 1～100，recursive 不传则不限深度，direct 固定 1；max_entries 默认 100000，最大 1000000。
- `GET /api/workspaces/{workspace_id}/files/tree`：path 默认 `.`，max_depth 默认 3（1～100），max_entries 默认 10000（1～100000）。返回嵌套 items，目录带 expanded，已展开目录带 children。

统计字段：file_count、directory_count（不含起点）、total_size_bytes、skipped_symlink_count、other_count、depth_limited。没有叶子统计模式。层数 1 为直属内容，深度边界目录计入 directory_count 但不扫描内部；depth_limited=true 表示不能将数量当成完整递归总数。超过条目预算返回 413，不返回部分结果；其他错误为 400/403/404/409/422。

路径均相对工作区，支持节点转发，不跟随符号链接，不执行 Shell。完整参数、响应示例和旧接口兼容约定见 USER_API.md 的“通用文件浏览、统计与目录树”。
# 补充：Shell 任务列表与初始化

GET `/api/workspaces/{workspace_id}/command-tasks` 支持 page（默认 1）和 page_size（默认 20，最大 200），返回 `{"items":[任务摘要],"total":N}`。摘要不含 stdout/stderr，其余字段同任务详情，按创建时间倒序；详情接口读取持久化输出。支持跨节点转发。

Shell 异步任务与异步对话都由独立运行器执行，Web 重启后继续查询和取消；旧同步接口不变。取消等待后返回真实状态，未停止时继续轮询，不能仅凭 success=true 判断进程已停止。

MySQL 首次建表通过 GET_LOCK/RELEASE_LOCK 串行检查和创建缺失表，锁等待 120 秒；初始化不再执行旧数据补齐。保活同账号操作冲突返回 409，不阻塞其他账号管理。
# 手动选择替代账号

GET `/api/accounts/{account_id}/replacement-options` 返回账号关联的工作区及每个工作区的可用替代账号，自动转发到账号所属节点。候选账号已绑定对应工作区、属于同节点、已登录且未过期，并排除待删除账号；无候选时返回空 candidates，不能按绑定账号数量判断可用性。

DELETE `/api/accounts/{account_id}` 支持可选 JSON 请求体：`{"replacements":{"工作区ID":"替代账号资源ID"}}`。提供映射时必须覆盖该账号的全部关联工作区，无关联时传空映射；缺项、多项或选择失效返回 409，整次事务回滚。省略请求体保持旧调用方式，自动选择可用账号。

旧工作区移除账号接口返回 409；请编辑账号组。组变更后已有会话在下次执行时切换可用账号。
# 工作区账号启用状态

通过账号组 PUT 请求的 `members[].available` 配置；旧工作区 available 接口返回 409。参见 [账号组配置](ACCOUNT_GROUPS.md)。

停用现在是账号组成员配置，影响所有引用工作区。当前任务继续，下次执行若原账号不可用则选择组内其他可用账号；全部不可用则拒绝执行。认证状态与 available 开关相互独立。
# 会话当前账号信息

会话列表和会话详情返回 `account_id`（平台账号记录 ID），并增加 `account_name`（账号备注名，可为 null）和 `account_identity`（CodeAgent 登录身份，例如工号，可为 null）。这些字段表示当前绑定账号，账号替换后随之更新，不代表所有历史消息都由该账号执行。不返回登录凭据。
# 工作区磁盘用量

`GET /api/workspaces/{workspace_id}/disk-usage?refresh=false` 自动转发到所属节点。默认缓存 300 秒，`refresh=true` 强制重新统计。返回 HTTP 200：

```json
{"total_size_bytes":130,"codeagent_log_size_bytes":30,"other_size_bytes":100,"file_count":2,"disk_free_bytes":1073741824,"skipped_symlink_count":0,"measured_at":"2026-10-26T08:00:00+00:00"}
```

大小为普通文件逻辑大小之和，包含隐藏文件，不跟随符号链接。`.codeagent-logs` 下所有实际保留的普通文件计入日志用量，已包含在总用量中；不是后端服务日志，也不是数据库会话历史大小。磁盘剩余空间为节点共享空间。扫描不是文件系统快照，文件持续写入时结果为近似值。超过一百万条目返回 413，权限不足 403，扫描期间文件消失 404，其他文件读取错误 409；错误不返回零用量。首次请求及强制刷新等待扫描完成，不阻塞事件循环。
# 账号保活记录

`GET /api/accounts/{account_id}/keepalive`：自动转发到账号所属节点，只查询记录，不触发保活。

返回 `last_attempt`、`last_success`、`next_at`（Unix 秒时间戳，尚无记录时字段不存在），`status`（running/success/failed）、`last_error`、`model`（最近成功发送使用的显式模型，null 表示未指定），`history`（倒序的模型尝试记录：time/model/status/error）。每个账号保存近 7 天最多 100 次尝试。记录保存在节点 `.cloud-codeagent/account-keepalive.json`，服务重启后保留；旧版本已丢失的成功时间无法还原。

保活先不传模型；发送失败后实时查询该账号模型列表，跳过默认空值、去重，依次使用明确模型执行，首次成功即停止，不修改账号配置。列表为空、获取失败或全部模型失败则 5 分钟后重试。失败后也尝试查询认证状态，但查询失败不会伪造已过期状态。尝试 success 只表示该次发送成功，整体保活 success 还需认证状态查询确认有效。上次成功时间不会因后续失败被清空。页面“刷新记录”仅重新查询日志。
# 首页模型告警

模型检测、降级与首页告警详见 [账号组与模型配置](ACCOUNT_GROUPS.md)。
# 工作区自动记忆

创建工作区请求增加可选布尔字段 `autoMemoryEnabled`，默认 false。创建 `.cac` 后写入 `.cac/settings.local.json`。`GET /api/workspaces/{workspace_id}/memory` 返回 `{"autoMemoryEnabled":false}`；`PUT` 同一路径，请求体 `{"autoMemoryEnabled":true}`，返回更新后的同结构对象。字段严格接受布尔值，其他配置键保留。接口自动转发到工作区所属节点。JSON 损坏或不是对象返回 409，不覆盖原文件。读取时字段缺失或不是布尔值返回 409。

该配置供下次启动的 CodeAgent 执行读取，不终止正在执行的任务，不删除已有记忆。平台不承诺正在运行的 CLI 热更新。
