# 后端接口文档

本文档对应当前 FastAPI 实现。服务启动后可访问 `/docs` 查看交互式 OpenAPI 页面；以下示例使用对外统一前缀 `/api`。同一业务路由也可省略 `/api` 调用。当前平台不要求 API Key；部署时应由所在网络控制访问范围。

## 通用约定

- 基础地址示例：`http://<host>:<port>/api`。JSON 请求使用 `Content-Type: application/json`；Skill 上传使用 `application/zip`，请求体直接是 ZIP 二进制，不是 multipart 表单。
- 列表响应为 `{"items": [...], "total": 0}`。支持分页的列表使用 `page`（从 1 开始，默认 1）和 `page_size`（1～200，默认 20）；Skill 列表一次返回全部，不支持分页。
- 时间字段为 UTC ISO 8601 字符串，或 `null`；账号 `expires_at` 为毫秒时间戳，或 `null`。
- 成功删除通常返回 `{"success": true}`。错误返回 `{"detail": "错误说明"}`；参数校验错误的 `detail` 是数组。
- 常见状态码：`400` 非法路径/ZIP/业务输入，`404` 资源不存在，`409` 冲突或关联资源未清理，`413` 文件/ZIP 超限，`415` 不支持的文件编码或媒体类型，`422` 请求参数校验失败，`502` 本地 CLI 或节点转发失败，`503` 节点/数据库/账号不可用，`504` 执行超时。实际错误说明以响应为准。
- 多节点模式下，工作区、账号、会话相关请求会转发到资源所属节点。创建工作区时 `node_id` 可选，省略时使用当前接入节点。工作区绑定的账号由该节点自动分配，调用方无需传账号 ID。

## 健康与节点

| 方法 | 路径 | 参数 | 返回 |
| --- | --- | --- | --- |
| GET | `/health` 或 `/api/health` | 无 | `{"status":"ok","node_id":"..."}` |
| GET | `/api/nodes` | `page`, `page_size` | 节点分页列表 |
| GET | `/api/nodes/{node_id}` | 路径中的节点 ID | 节点详情 |

节点对象包含 `id`、`node_name`、`node_host`、`node_port`、`status`（`online`/`offline`）、`max_concurrency`、`running_count`、`cpu_usage`、`memory_usage`、`last_heartbeat`、`create_time`、`update_time`，以及 `accounts_count`、`workspaces_count` 资源计数。

## 账号

| 方法 | 路径 | 参数/请求体 | 返回 |
| --- | --- | --- | --- |
| GET | `/api/accounts` | 可选 `node_id`, `page`, `page_size` | 账号分页列表 |
| POST | `/api/accounts/login` | JSON：`node_id?`, `account_id?`, `account_name?` | `202`，登录信息 |
| GET | `/api/accounts/{account_id}` | 可选 `refresh=false` | 账号详情；`refresh=true` 时调用 CLI 刷新认证状态 |
| DELETE | `/api/accounts/{account_id}` | 无 | `{"success":true}` |

首次登录可发送 `{"node_id":"node-01","account_name":"开发账号"}`；`node_id` 省略时使用当前节点。重新登录已有账号时发送 `{"account_id":"account-..."}`。登录响应为 `{"login_id":"...","account_id":"...","status":"waiting_login","login_url":"https://..."}`；`login_url` 可能暂时为 `null`。调用方打开授权链接，并轮询账号详情查看 `auth_status`。账号详情还包含节点、CLI 身份、认证提供方、到期时间、配置目录和创建/更新时间；认证状态可能为 `waiting_login`、`logged_in`、`not_login`、`expired` 或 `error`。有工作区绑定的账号不能直接删除。

```bash
curl -X POST 'http://<host>:<port>/api/accounts/login' \
  -H 'Content-Type: application/json' \
  -d '{"account_name":"开发账号"}'
curl 'http://<host>:<port>/api/accounts/account-xxx?refresh=true'
```

## 工作区

| 方法 | 路径 | 参数/请求体 | 返回 |
| --- | --- | --- | --- |
| GET | `/api/workspaces` | 可选 `node_id`, `page`, `page_size` | 工作区分页列表 |
| POST | `/api/workspaces` | JSON：`name`，可选 `node_id` | `201`，工作区对象 |
| GET | `/api/workspaces/{workspace_id}` | 无 | 工作区对象 |
| DELETE | `/api/workspaces/{workspace_id}` | 无 | `{"success":true}` |

`name` 同时是工作区 ID，只允许以英文字母或数字开头，后续使用英文字母、数字、`_`、`-`，最长 128 字符。创建时后端在节点上分配已登录账号并建立本地目录。工作区对象包含 `id`、`name`、`node_id`、`status`、`create_time`、`update_time`；后端通过 ID 定位目录，接口不暴露服务器路径。调用方不会收到内部账号绑定 ID。状态通常为 `ready`，也可能为 `creating`、`error`、`deleting`。删除工作区前须先删除其会话。

```bash
curl -X POST 'http://<host>:<port>/api/workspaces' \
  -H 'Content-Type: application/json' -d '{"name":"demo"}'
```

## 文件

以下路径中的 `{workspace_id}` 为工作区 ID，文件 `path` 相对于工作区根目录；目录列表默认 `path=.`。路径不允许绝对路径、`..`、符号链接或 Windows junction。文本接口只处理 UTF-8；单个文本文件大小上限由后端配置控制，默认 2 MiB。

| 方法 | 路径 | 参数/请求体 | 返回 |
| --- | --- | --- | --- |
| GET | `/api/workspaces/{workspace_id}/files` | 查询参数 `path`，默认 `.` | `{"path":".","items":[...]}` |
| GET | `/api/workspaces/{workspace_id}/files/content` | 必填查询参数 `path` | `{"path":"...","content":"..."}` |
| GET | `/api/workspaces/{workspace_id}/files/download` | 必填查询参数 `path` | 原始文件字节，含下载文件名 |
| POST | `/api/workspaces/{workspace_id}/files/directories` | JSON：`path` | `201`，`{"path":"...","type":"directory"}` |
| POST | `/api/workspaces/{workspace_id}/files/upload` | 查询参数 `path`，请求体为原始文件字节，`Content-Type: application/octet-stream` | `201`，`{"path":"...","type":"file","size":N}` |
| PUT | `/api/workspaces/{workspace_id}/files` | JSON：`path`, `content` | `{"success":true,"path":"..."}` |
| DELETE | `/api/workspaces/{workspace_id}/files` | 必填查询参数 `path` | `{"success":true}` |

目录项包含 `name`、`path`、`type`（`file`、`directory` 或 `symlink`）、`size`。文件上传不限制格式，单文件上限默认 512 MiB；上传嵌套路径会自动创建父目录，目标已存在返回 409。PUT 只编辑已有 UTF-8 文本文件，默认上限 2 MiB；读取二进制文件请使用下载接口。删除目录会递归删除其内容。

## Skill ZIP

| 方法 | 路径 | 请求体 | 返回 |
| --- | --- | --- | --- |
| GET | `/api/workspaces/{workspace_id}/skills` | 无 | `{"items":[...],"total":N}` |
| POST | `/api/workspaces/{workspace_id}/skills` | 原始 ZIP，`Content-Type: application/zip` | `201`，Skill 信息 |
| GET | `/api/workspaces/{workspace_id}/skills/{name}` | 无 | Skill 详情，含 `SKILL.md` 文本 |
| PUT | `/api/workspaces/{workspace_id}/skills/{name}` | 原始 ZIP，`Content-Type: application/zip` | 替换整个 Skill 目录后的信息 |
| DELETE | `/api/workspaces/{workspace_id}/skills/{name}` | 无 | `{"success":true}` |

一个 ZIP 只包含一个 Skill。支持包内直接放 `SKILL.md` 和其他文件，也支持 `my-skill/`、`skills/my-skill/`、`.cac/skills/my-skill/` 作为根目录。安装位置为工作区的 `.cac/skills/<name>/`，所有其他文件和子目录一同保留。`SKILL.md` 必须是 UTF-8，开头须有 YAML front matter，例如：

```markdown
---
name: my-skill
description: 示例 Skill
---

# 使用说明
```

目录名、front matter 的 `name` 和 PUT 路径中的 `{name}` 必须一致；名称只能使用小写字母、数字及中划线，最长 64 字符。ZIP 上限 16 MiB，最多 512 个条目，单文件解压后上限 16 MiB，总解压量上限 64 MiB。非法路径、重复文件、符号链接等会被拒绝。PUT 是整个目录替换，旧 ZIP 中有而新 ZIP 中没有的文件会被移除。列表项含 `name`、`description`、`files`；详情额外含 `content`（`SKILL.md` 文本）。

```bash
curl -X POST 'http://<host>:<port>/api/workspaces/demo/skills' \
  -H 'Content-Type: application/zip' --data-binary '@my-skill.zip'
curl -X PUT 'http://<host>:<port>/api/workspaces/demo/skills/my-skill' \
  -H 'Content-Type: application/zip' --data-binary '@my-skill-updated.zip'
```

## 会话与消息

| 方法 | 路径 | 参数/请求体 | 返回 |
| --- | --- | --- | --- |
| GET | `/api/sessions` | 可选 `workspace_id`, `keyword`（搜索标题）, `created_by`, `page`, `page_size` | 会话分页列表 |
| POST | `/api/sessions` | JSON：`workspace_id`，可选 `title`, `created_by` | `201`，会话对象 |
| GET | `/api/sessions/{session_id}` | 无 | 会话详情，额外含 `messages` |
| POST | `/api/sessions/{session_id}/messages` | JSON：`{"input":"..."}`；可选 `stream=true/false`（默认 false） | `200`，JSON 或 NDJSON |
| POST | `/api/sessions/{session_id}/cancel` | 无 | `{"success":true,"status":"..."}` |
| DELETE | `/api/sessions/{session_id}` | 无 | `{"success":true}` |

会话对象中的 ID 字段叫 `session_id`，并包含 `workspace_id`、`node_id`、`codeagent_session_id`、`title`、`status`、`created_by`、`created_at`、`updated_at`。详情中的 `messages` 按时间排序，包含消息 ID、`session_id`、`role`、`content`、`raw_result`、`created_at`。会话状态可见 `ready`、`running`、`idle`、`error`、`cancelled` 等。`created_by` 仅是筛选标签，不是认证身份。

`stream=false` 返回 CodeAgent 最终 `result` JSON 对象。`stream=true` 返回 `application/x-ndjson`，每行一个 CodeAgent JSON 事件；最后一行为 `type=result` 事件。事件字段由本地 CLI 输出决定，平台会原样转发中间事件；平台错误会用 `subtype=error_platform`、`is_error=true` 的最终事件表示。流式连接断开会取消本次执行；同一会话同一时刻只能运行一条消息。

```bash
curl -X POST 'http://<host>:<port>/api/sessions' \
  -H 'Content-Type: application/json' -d '{"workspace_id":"demo","title":"首次会话"}'

curl -N -X POST 'http://<host>:<port>/api/sessions/sess_xxx/messages?stream=true' \
  -H 'Content-Type: application/json' -d '{"input":"请介绍当前工作区"}'
```

JSON 请求不允许未定义字段。调用消息接口前，工作区须就绪且其绑定账号须已登录；否则接口会返回对应业务错误。
