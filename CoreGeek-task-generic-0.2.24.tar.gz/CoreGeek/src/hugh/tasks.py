"""Multi-turn task/sandbox protocol. Commands are returned to the platform only."""
import ast
import hashlib
import json
from pathlib import Path
import re
import shlex
from .world import pos, point, distance
from .treasure import grounded_treasure

SANDBOX_SOURCE = Path(__file__).with_name("task_sandbox.py").read_text(encoding="utf-8")
RUNTIME_SOURCE = Path(__file__).with_name("task_runtime.py").read_text(encoding="utf-8")
MARKER = "HUGH_TASK:"


def clip(text, limit):
    return text if len(text) <= limit else text[:limit // 2] + "\n[...middle omitted...]\n" + text[-limit // 2:]


def json_object(text):
    decoder = json.JSONDecoder()
    found = []
    for match in re.finditer(r"\{", text or ""):
        try:
            value, _ = decoder.raw_decode(text[match.start():])
            if isinstance(value, dict):
                found.append(value)
        except (ValueError, TypeError):
            pass
    return next((v for v in found if any(k in v for k in (
        "executeCmd", "taskAnswer", "treasure", "python", "python_candidates", "discover", "resume"))), None)


def discover_command(description, request_id="bootstrap", profiles=None):
    request = json.dumps({"description": description, "id": request_id, "runtime_source": RUNTIME_SOURCE,
                          "profiles": profiles or []}, ensure_ascii=False)
    return "python3 -c " + shlex.quote(SANDBOX_SOURCE) + " " + shlex.quote(request)


def fingerprint(command):
    value = re.sub(r"t\d+-r\d+-q\d+", "REQUEST_ID", command.strip())
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def api_command(runner, decision):
    if decision.get("resume"):
        payload = {"resume": True}
    elif isinstance(decision.get("python"), str) or isinstance(decision.get("python_candidates"), list):
        codes = decision.get("python_candidates") or [decision["python"]]
        if not 1 <= len(codes) <= 3 or not all(isinstance(code, str) and code for code in codes):
            raise ValueError("python_candidates must contain one to three Python programs")
        if sum(len(code) for code in codes) > 22000:
            raise ValueError("candidate programs exceed the source budget")
        for code in codes:
            ast.parse(code)
        payload = ({"python": codes[0]} if len(codes) == 1 else {"python_candidates": codes})
        payload["resumable"] = decision.get("resumable") is True
    else:
        raise ValueError("Return python or python_candidates")
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True)
    payload["id"] = decision["requestId"]
    command = "python3 -X utf8 " + shlex.quote(runner) + " " + shlex.quote(json.dumps(payload, ensure_ascii=False))
    if len(command.encode("utf-8")) > 60000:
        raise ValueError("Task command exceeds the platform size limit")
    return command, fingerprint(canonical)


def validate_answer(answer, *unused):
    try:
        value = answer if isinstance(answer, str) else json.dumps(answer, ensure_ascii=False, allow_nan=False)
        if answer is None or not value or len(value.encode("utf-8")) > 24000:
            raise ValueError("答案为空或超过提交长度")
    except (ValueError, TypeError) as error:
        return None, str(error)
    return answer, ""


def encode_answer(answer):
    # Models sometimes call json.dumps before report(); unwrap one container
    # layer. Preserve ordinary strings because some task contracts explicitly
    # require plain text rather than a JSON string literal.
    if isinstance(answer, str) and answer.lstrip().startswith(("{", "[")):
        try:
            parsed = json.loads(answer)
            if isinstance(parsed, (dict, list)):
                answer = parsed
        except ValueError:
            pass
    return (answer if isinstance(answer, str) else
            json.dumps(answer, ensure_ascii=False, sort_keys=True, separators=(",", ":")))


def verified_result(answer, proof):
    from .task_runtime import digest
    if not isinstance(proof, dict) or proof.get("method") != "runtime_evidence_v2":
        return False
    try:
        if proof.get("answer_sha256") != digest(answer):
            return False
        sources, checks = proof.get("sources"), proof.get("checks")
        if not isinstance(sources, list) or not isinstance(checks, list) or not (sources or checks):
            return False
        for receipt in sources:
            if (not isinstance(receipt, dict) or receipt.get("complete") is not True
                    or receipt.get("kind") not in ("dataset", "file", "http_single")
                    or not re.fullmatch(r"[0-9a-f]{64}", str(receipt.get("data_sha256", "")))):
                return False
            if receipt["kind"] == "dataset":
                count, total = receipt.get("count"), receipt.get("total")
                if (type(count) is not int or count < 0 or type(receipt.get("pages")) is not int
                        or receipt["pages"] < 1 or (total is not None and (type(total) is not int or total != count))):
                    return False
        return all(isinstance(c, dict) and type(c.get("exit_code")) is int and c["exit_code"] == 0
                   and c.get("truncated") is False for c in checks)
    except (ValueError, TypeError):
        return False


def recover_single_field_verifier_answer(packet, task_text):
    """Recover a checker value when model glue fails after a real success.

    The key and value label come from the current task's own JSON submission
    example and the successful verifier output.  No task name, field name, or
    expected value is built in.
    """
    from .task_runtime import digest

    if not isinstance(packet, dict) or packet.get("status") != "answer":
        return packet
    proof, answer = packet.get("proof"), packet.get("answer")
    checks = proof.get("checks", []) if isinstance(proof, dict) else []
    if not checks or not isinstance(task_text, str):
        return packet
    templates = []
    for block in re.findall(r"```(?:json)?\s*(\{.*?\})\s*```", task_text, flags=re.I | re.S):
        try:
            value = json.loads(block)
            if isinstance(value, dict) and len(value) == 1:
                templates.append(value)
        except ValueError:
            continue
    if len(templates) != 1:
        return packet
    key, sample = next(iter(templates[0].items()))
    if isinstance(answer, dict) and key in answer:
        return packet
    outputs = [c.get("output", "") for c in checks if isinstance(c, dict)
               and c.get("exit_code") == 0 and c.get("truncated") is False]
    match = None
    for output in reversed(outputs):
        found = re.search(r"(?im)^\s*" + re.escape(str(key)) + r"\s*:\s*(.+?)\s*$", output)
        if found:
            match = found.group(1).strip().strip('"\'')
            break
    if not match:
        return packet
    value = match
    if type(sample) is int and re.fullmatch(r"-?\d+", match):
        value = int(match)
    elif type(sample) is float:
        try:
            value = float(match)
        except ValueError:
            return packet
    elif type(sample) is bool and match.lower() in ("true", "false"):
        value = match.lower() == "true"
    recovered = {key: value}
    packet = dict(packet)
    packet["answer"] = recovered
    packet["proof"] = dict(proof, answer_sha256=digest(recovered))
    packet.setdefault("warnings", []).append("Recovered answer from current task template and successful verifier output")
    return packet


class Tasks:
    def __init__(self):
        self.active = ""
        self.start = 0
        self.deadline = 0
        self.booted = False
        self.history = []
        self.pending = ""
        self.pending_round = 0
        self.pending_id = ""
        self.last_command = ""
        self.last_fingerprint = ""
        self.inflight = None
        self.sequence = 0
        self.context = {}
        self.kind = "unknown"
        self.submitted = set()
        self.news = []
        self.news_seen = set()
        self.news_version = 0
        self.news_requested = 0
        self.daily_calls = 0
        self.call_day = 0
        self.treasure = None
        self.treasure_done = False
        self.treasure_attempt = -1
        self.treasure_trip = None
        self.treasure_attempts = set()
        self.iron_block_until = 0
        self.iron_block_from = 0
        self.ready = None
        self.ready_from_runtime = False
        self.api_profiles = {}
        self.collection_status = ""
        self.consumed_ids = set()
        self.reply_hashes = set()

    def update(self, w):
        if self.call_day != w.day:
            self.call_day, self.daily_calls = w.day, 0
        for key, text in (w.raw.get("worldNews") or {}).items():
            if not text or (key, text) in self.news_seen:
                continue
            self.news_seen.add((key, text))
            self.news.append({"day": w.day, "kind": key, "text": text})
            if key == "folkLegends":
                self.news_version += 1
            if key == "officialNews" and "铁" in text:
                if "恢复开采" in text and "完成" in text:
                    self.iron_block_until = 0
                elif "无法采集" in text or "停工" in text:
                    future = "明日" in text or "明天" in text
                    self.iron_block_from = w.day + int(future)
                    self.iron_block_until = w.day + (2 if future else 0)
        active = w.raw.get("phaseTask") or ""
        if active != self.active:
            # Reset BEFORE reading outputs, which may still belong to the old task.
            self.active, self.start = active, w.round
            self.booted, self.ready, self.history = False, None, []
            self.ready_from_runtime = False
            self.last_command, self.inflight, self.context = "", None, {}
            self.last_fingerprint = ""
            self.collection_status = ""
            self.kind, self.submitted = "generic", set()
            if self.pending in ("task", "preview"):
                self.pending, self.pending_id = "", ""
            task = min(w.tasks, key=lambda t: distance(w.pioneer.pos, pos(t["taskPosition"])) if w.pioneer else 0, default={})
            self.deadline = w.round + int(task.get("timeoutRounds") or 15) - 1
        response = w.raw.get("llmResp") or ""
        if self.pending == "news" and not response and w.round > self.pending_round + 1:
            self.pending = ""
            self.news_requested = max(0, self.news_version - 1)
        if any(e.get("errorCode") == 5 for e in w.raw.get("errors") or []):
            self.daily_calls = 3
        # A submitted value is only final when the platform accepts it and
        # closes the task. If the task remains active with an explicit error,
        # allow a corrected or re-encoded value instead of suppressing it as a
        # duplicate. This does not depend on error prose or a task schema.
        if self.active and self.submitted and w.raw.get("errors"):
            self.submitted.clear()
        if self.pending == "preview" and w.round > self.pending_round:
            if response and w.round == self.pending_round + 1:
                self.context["initial_model_reply"] = clip(response, 3000)
            else:
                self.history.append({"model_error": "Missing first-round task preview"})
            self.pending, self.pending_id = "", ""
        elif self.pending == "task" and w.round > self.pending_round:
            obj = json_object(response)
            supplied = obj.get("requestId") if obj else None
            task_id = re.match(r"t(\d+)-", str(supplied or ""))
            stale = (str(supplied) in self.consumed_ids or
                     (task_id and int(task_id[1]) != self.start) or
                     hashlib.sha256(response.encode("utf-8")).hexdigest() in self.reply_hashes)
            # The platform returns the one outstanding reply on the next turn.
            # Bind it here; the model need not copy or increment an internal ID.
            if obj and w.round == self.pending_round + 1 and not stale:
                self.ready = {**obj, "requestId": self.pending_id}
                self.ready_from_runtime = False
                self.reply_hashes.add(hashlib.sha256(response.encode("utf-8")).hexdigest())
                if supplied and supplied != self.pending_id:
                    self.history.append({"protocol_note": "Bound fresh reply to current request", "received_id": supplied})
            else:
                self.history.append({"model_error": "Missing, stale or late model reply", "received_requestId": supplied})
            self.consumed_ids.add(self.pending_id)
            self.pending = ""
        elif self.pending == "news" and response:
            # Old model replies cannot override explicit public evidence.
            self.pending = ""
        if self.inflight and w.round > self.inflight["round"]:
            flight, self.inflight = self.inflight, None
            result = (w.raw.get("lastCmdResult") or "") if w.round == flight["round"] + 1 else ""
            self.consume_result(flight, result)
        self.history = self.history[-5:]
        treasure_result = int(w.raw.get("lastSummonTreasureResult") or 0)
        if treasure_result in (1, 4):
            self.treasure_done = True
        elif treasure_result in (2, 3):
            self.treasure = None  # Legal failed attempts consume items; do not retry blindly.
        candidate = grounded_treasure(self.news, w)
        if candidate and self.treasure_key(candidate) not in self.treasure_attempts and not self.treasure_done:
            self.treasure = candidate
        elif self.treasure and (self.treasure["day"] < w.day or self.treasure_key(self.treasure) in self.treasure_attempts):
            self.treasure = None

    def next_id(self, w):
        self.sequence += 1
        return f"t{self.start}-r{w.round}-q{self.sequence}"

    def send_command(self, w, command, request_id, bootstrap=False, digest=None, managed=False):
        self.last_command = command
        self.last_fingerprint = digest or fingerprint(command)
        self.inflight = {"round": w.round, "command": command,
                         "id": request_id, "bootstrap": bootstrap, "managed": managed}
        return "", command

    def prompt_context(self, w, request_id):
        stable_keys = ("task_file", "task_text", "materials", "files", "runner", "config",
                       "previous_task_evidence", "initial_model_reply", "collections")
        task_context = {key: self.context[key] for key in stable_keys if key in self.context}
        # Raw HTTP bodies and old generated programs make prompts grow past
        # 30k after a few retries. Keep the current request plus concise latest
        # evidence; the runtime state still retains the complete data.
        for key in ("observation", "error", "note", "stderr", "traceback", "processes", "warnings"):
            if key in self.context:
                task_context[key] = clip(json.dumps(self.context[key], ensure_ascii=False), 4500)
        history = []
        for event in self.history[-2:]:
            history.append({key: clip(json.dumps(value, ensure_ascii=False), 2200)
                            for key, value in event.items()})
        return {"task_notice": self.active, "round": w.round,
                "remaining_rounds": max(0, self.deadline - w.round), "requestId": request_id,
                "task_context": task_context, "history": history,
                "official_feedback": w.raw.get("errors") or []}

    def send_with_prompt(self, w, command, request_id, *, bootstrap=False, digest=None, managed=False):
        _, sent = self.send_command(w, command, request_id, bootstrap=bootstrap, digest=digest, managed=managed)
        self.pending = "preview" if bootstrap else "task"
        self.pending_round, self.pending_id = w.round, request_id
        prompt = self.preview_prompt(w, request_id) if bootstrap else self.task_prompt(self.prompt_context(w, request_id))
        return prompt, sent

    def consume_result(self, flight, result):
        success = result.startswith("[exitCode:0]\n") and "[TRUNCATED]" not in result
        packet = None
        if success:
            for line in result.splitlines():
                if line.startswith(MARKER):
                    try:
                        value = json.loads(line[len(MARKER):])
                        if isinstance(value, dict) and value.get("id") == flight["id"]:
                            packet = value
                    except ValueError:
                        pass
        if packet and flight["bootstrap"] and isinstance(packet.get("context"), dict):
            preview = self.context.get("initial_model_reply")
            self.context = packet["context"]
            if preview:
                self.context["initial_model_reply"] = preview
            self.kind = "generic"
        if packet and flight.get("managed"):
            packet = recover_single_field_verifier_answer(packet, self.context.get("task_text", ""))
            for key in ("observation", "config", "collections", "http_history", "output", "stderr",
                        "traceback", "processes", "warnings", "error", "note"):
                if key in packet:
                    self.context[key] = packet[key]
                elif key in ("error", "note", "traceback", "stderr", "warnings", "processes"):
                    self.context.pop(key, None)
            self.collection_status = packet.get("status", "")
            profile = packet.get("profile")
            if isinstance(profile, dict) and profile.get("successful_requests"):
                self.api_profiles[fingerprint(json.dumps(profile, sort_keys=True))] = profile
                self.api_profiles = dict(list(self.api_profiles.items())[-3:])
            if packet.get("status") == "answer":
                self.ready = {"taskAnswer": packet.get("answer"), "proof": packet.get("proof")}
                self.ready_from_runtime = True
        # stderr from child processes may be OUTSIDE the structured packet.
        outside = "\n".join(line for line in result.splitlines() if not line.startswith(MARKER))
        self.context["command_output"] = clip(outside if packet else result, 6000)
        code = flight["command"]
        if flight.get("managed"):
            try:
                code = json.loads(shlex.split(code)[-1]).get("python", "resume previous script")
            except (ValueError, IndexError):
                pass
        summary = {k: packet[k] for k in ("status", "error", "traceback", "note") if packet and k in packet}
        self.history.append({"executeCmd": "read current task materials" if flight["bootstrap"] else clip(code, 3500),
                             "result": summary or clip(result, 3000) or "No command result received",
                             "external_output": clip(outside, 2500)})

    def run(self, w, actor, commands):
        if not self.active or actor.id in commands.busy:
            return "", ""
        if not self.booted:
            self.booted = True
            commands.busy.add(actor.id)
            if w.round >= self.deadline:
                return "", ""
            request_id = self.next_id(w)
            return self.send_with_prompt(w, discover_command(self.active, request_id, list(self.api_profiles.values())),
                                         request_id, bootstrap=True)
        if self.inflight or self.pending == "task":
            commands.busy.add(actor.id)
            return "", ""
        if self.ready:
            decision, self.ready = self.ready, None
            from_runtime, self.ready_from_runtime = self.ready_from_runtime, False
            if "taskAnswer" in decision:
                answer, error = validate_answer(decision["taskAnswer"])
                if not from_runtime or not verified_result(answer, decision.get("proof")):
                    error = "答案必须来自当前实际执行，附带已读取数据源或成功验证进程的证据；不能直接声明完成"
                encoded = encode_answer(answer)
                if error or encoded in self.submitted:
                    self.history.append({"answer_error": error or "答案已经提交，请依据官方反馈修正"})
                elif commands.add(actor, "submitAnswer", taskAnswer=encoded):
                    self.submitted.add(encoded)
                    return "", ""
            elif w.round < self.deadline:
                try:
                    request_id = decision["requestId"]
                    if self.context.get("runner"):
                        command, signature = api_command(self.context["runner"], decision)
                        managed, bootstrap = True, False
                    elif isinstance(decision.get("discover"), str):
                        command = discover_command(decision["discover"], request_id, list(self.api_profiles.values()))
                        signature, managed, bootstrap = fingerprint(command), False, True
                    elif isinstance(decision.get("executeCmd"), str):
                        command = decision["executeCmd"]
                        signature, managed, bootstrap = fingerprint(command), False, False
                    else:
                        raise ValueError("尚未找到任务文件，请先定位，再用 discover 指定完整路径")
                    if not command or len(command.encode("utf-8")) > 100000:
                        raise ValueError("命令为空或过长")
                    if signature == self.last_fingerprint and decision.get("retry") is not True:
                        raise ValueError("禁止无变化地重复执行；仅实际临时故障需要重试时可声明 retry=true")
                    commands.busy.add(actor.id)
                    # After discovery, execute only the chosen program. A
                    # speculative prompt cannot see this command's result and
                    # was the main source of slow, obsolete LLM work.
                    return self.send_command(w, command, request_id, bootstrap=bootstrap,
                                             digest=signature, managed=managed)
                except (ValueError, SyntaxError, TypeError, KeyError) as error:
                    self.history.append({"command_error": str(error)})
        commands.busy.add(actor.id)
        if self.collection_status == "progress" and self.context.get("runner") and w.round < self.deadline:
            self.collection_status = "resuming"
            request_id = self.next_id(w)
            command, signature = api_command(self.context["runner"], {"requestId": request_id, "resume": True})
            return self.send_command(w, command, request_id, digest=signature, managed=True)
        if self.deadline - w.round < 2:
            return "", ""
        request_id = self.next_id(w)
        self.pending, self.pending_round, self.pending_id = "task", w.round, request_id
        return self.task_prompt(self.prompt_context(w, request_id)), ""

    def preview_prompt(self, w, request_id):
        return (
            "The first command is reading every Markdown file near the current official task. Its result arrives next "
            "round. From the notice alone, list what must be resolved after the materials arrive. Do not guess names, "
            "fields, values, paths, answer formats, or taskAnswer. Return brief JSON with keys goal, evidence_needed, "
            "verification_needed, unknowns.\n" + json.dumps(
                {"task_notice": self.active, "round": w.round, "requestId": request_id}, ensure_ascii=False))

    def task_prompt(self, context):
        return (
            "Solve the current official task only from this turn's materials and real execution feedback. "
            "The subject, file names, variables, API contract, data shape, requested computation, verifier, and answer "
            "format may all change. Derive every one from task_context.task_text and task_context.materials. "
            "Treat examples as examples and actual service or process results as authoritative. Never reuse values or "
            "answers from an earlier task.\n"
            "Return JSON only. Prefer {\"python_candidates\":[\"program 1\",\"program 2\"],"
            "\"resumable\":false}; one strong program may use {\"python\":\"...\"}. "
            "Provide at most three candidates and keep combined source under 22000 characters. Candidates run in order "
            "inside one command and stop at the first verified report. Each must be independently safe and justified by "
            "the current materials. When an HTTP document may be stale, provide two candidates or one adaptive program; "
            "start with probe, inspect its actual status/JSON/text, and perform bounded corrections in that same program. "
            "Do not spend one game round correcting only one observed error. Do not invent field names, paths, credentials, "
            "or parameters merely to fill the candidate list.\n"
            "Prevent common failures before execution: inspect every supplied Markdown document; preserve exact answer "
            "types and keys; encode non-ASCII query values through params; inspect JSON containers before indexing; follow "
            "pagination using returned metadata; never infer completeness from requested page size; do not deduplicate "
            "without a documented unique key; distinguish authentication errors from parameter errors. When a requirement "
            "selects records equal to a literal value, locate the actual response field by checking which observed field "
            "contains that exact value; never guess a plausible or near-synonym field name. For any nonnumeric ordering, "
            "build the comparison from the current requirement and assert that every distinct observed value has an "
            "explicit rank before reporting; a fallback rank is not a valid result. Use absolute paths "
            "or WORKDIR; preserve physical blank lines and existing content for line-number requirements; run the real "
            "verifier and require exit code zero; never fabricate tokens, data, or success output.\n"
            "Injected functions: probe, probe_many, fetch_json, collect, read_source, run, report, lookup, "
            "response_shape, list_paths, matching_fields, ranked_min, remaining_seconds. matching_fields(rows,value) "
            "finds response keys containing an exact required literal; require exactly one match. "
            "ranked_min(rows,value_key,ranks,result_key) rejects incomplete rank maps. Do not import network libraries. HTTP is limited to services "
            "in current materials. For a task requiring all records, prefer rows=collect(request={...}); it discovers the "
            "single nested record list and common returned paging metadata, rejects incomplete pages, and returns rows. "
            "Call forms: probe(url=...,params=...,headers=...) returns status/json/text; fetch_json(request_dict) or "
            "fetch_json(url=...,params=...,headers=...) returns JSON; collect(request_dict), collect(url=...,params=...,...), "
            "or collect(name,request={...},records_path=[...],pagination={...},id_path=[...]) returns a verified complete list. "
            "Never pass a response body to collect. Use read_source for complete files or documented single resources, and "
            "run for actual verification. Finish with report(answer, sources=[names actually read], checks=[successful "
            "process ids]); at least one real evidence item is required. Set resumable=true only for idempotent long reads. "
            "Pass the exact requested JSON value to report: use a dict for an object and never call json.dumps on it. "
            "Do not output taskAnswer, ANSWER, COMPLETE, or claimed evidence. React to real errors while preserving proven "
            "settings and leave a round for command results and submission.\n"
            + json.dumps(context, ensure_ascii=False)
        )

    def news_prompt(self, w):
        return ""  # Explicit clues are parsed locally; missing clues stay unknown.

    def available(self, w):
        return [t for t in w.tasks if t.get("isValid") is True and int(t.get("coldDownRounds") or 0) == 0]

    def task_goals(self, w, task):
        target = pos(task["taskPosition"])
        name = w.zones.get(target)
        cells = {p for p, kind in w.zones.items() if name and kind == name} or {target}
        return {p for cell in cells for p in w.stand_cells(cell)}

    def accept(self, w, actor, commands):
        route = commands.route(actor)
        choices = []
        for task in self.available(w):
            goals = self.task_goals(w, task)
            stand = route.best(goals)
            if stand is not None:
                choices.append((route.cost[stand], pos(task["taskPosition"]), goals))
        if not choices:
            return False
        _, _, goals = min(choices)
        if actor.pos in goals:
            return commands.add(actor, "acceptTask")
        return commands.walk(actor, goals)

    @staticmethod
    def treasure_key(t):
        return (tuple(t["pos"]), t["day"], t["phase"], tuple(sorted(t["items"])))

    def treasure_action(self, w, actor, commands, allow_travel=True):
        t = self.treasure
        if not t or self.treasure_done or self.treasure_key(t) in self.treasure_attempts:
            return False
        if w.day > t["day"] or (w.day == t["day"] and t["phase"] == "day" and not w.daylight):
            self.treasure = None
            return False
        key = self.treasure_key(t)
        if not allow_travel:
            # Once the expedition has begun, reserve the pioneer while the
            # temporary operator arrives. Do not recall both actors to the gun.
            if self.treasure_trip == key and w.base and w.base.hp >= w.base.max_hp * 0.4:
                commands.busy.add(actor.id)
                return True
            self.treasure_trip = None
            return False
        missing = [name for name in t["items"] if not actor.bag[name]]
        if missing:
            if w.day < max(1, t["day"] - 2):
                return False
            if commands.gold < w.shop_prices[missing[0]]:
                return False
            return commands.buy(actor, missing[0]) or commands.walk(actor, {p for s in w.near("weaponShop") for p in w.stand_cells(s)})
        route = commands.route(actor)
        stand = route.best(w.stand_cells(t["pos"]))
        if stand is None:
            return False
        travel = route.steps[stand]
        start = (t["day"] - 1) * 130 + (71 if t["phase"] == "night" else 1)
        depart = start - travel - 8
        if t["phase"] == "day" and t["day"] > 1:
            # A morning opening competes with the other player. Leave during
            # the preceding daylight, giving the backup time to take over.
            preceding_dusk = (t["day"] - 2) * 130 + 70
            depart = min(depart, preceding_dusk - travel - 8)
        if self.treasure_trip != key and w.round < depart:
            return False
        self.treasure_trip = key
        if commands.adjacent(actor, t["pos"]):
            if w.round < start:
                commands.busy.add(actor.id)
                return True
            if t["phase"] == "day" and not w.daylight:
                return False
            self.treasure_attempt = self.news_version
            self.treasure_attempts.add(self.treasure_key(t))
            self.treasure_trip = None
            return commands.add(actor, "summonTreasure", targetPos=[point(t["pos"])], item=t["items"])
        return commands.approach(actor, t["pos"])
