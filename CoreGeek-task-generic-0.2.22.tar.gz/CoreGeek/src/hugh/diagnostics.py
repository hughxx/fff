"""Bounded, asynchronous stdout diagnostics and lossless turn traces."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import itertools
import json
import logging
import queue
import shlex
import threading
import uuid

LOGGER = logging.getLogger("hugh")
VERSION = "0.2.22"
CHUNK_SIZE = 1600


def compact(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def session_state(engine, mode, gap_ms):
    task = engine.tasks
    flight = task.inflight or {}
    return {"mode": mode, "reason": engine.decision_reason,
            "request_gap_ms": gap_ms,
            "defense": engine.defense_status,
            "treasure": {"plan": {k: task.treasure[k] for k in ("pos", "day", "phase", "items")} if task.treasure else None,
                         "travelling": task.treasure_trip is not None, "done": task.treasure_done},
            "task": {"active": bool(task.active), "kind": task.kind,
                     "start": task.start, "deadline": task.deadline,
                     "pending": task.pending, "pending_id": task.pending_id,
                     "pending_round": task.pending_round,
                     "command_id": flight.get("id"), "command_round": flight.get("round"),
                     "collection_status": task.collection_status,
                     "collection": task.context.get("collections"),
                     "previous_task_evidence": len(task.context.get("previous_task_evidence") or []),
                     "last_events": task.history[-2:]}}


def utf8_chunks(text, limit=CHUNK_SIZE):
    start, size = 0, 0
    for index, char in enumerate(text):
        n = len(char.encode("utf-8"))
        if size + n > limit:
            yield text[start:index]
            start, size = index, 0
        size += n
    if start < len(text):
        yield text[start:]


def readable_fields(record):
    """Literal multiline task text alongside the complete plain JSON trace."""
    request, response = record.get("request") or {}, record.get("response") or {}
    for prefix, obj, fields in (("IN", request, ("phaseTask", "llmResp", "lastCmdResult", "errors")),
                                ("OUT", response, ("prompt", "executeCmd", "roleCommandMap"))):
        for name in fields:
            value = obj.get(name)
            if value:
                yield prefix + "." + name, value if isinstance(value, str) else compact(value)
    result = request.get("lastCmdResult") or ""
    for line in result.splitlines():
        if not line.startswith("HUGH_TASK:"):
            continue
        try:
            packet = json.loads(line[len("HUGH_TASK:"):])
            context = packet.get("context") or {}
            for name in ("task_text", "spec", "api_docs", "checker_output"):
                if context.get(name):
                    yield "OFFICIAL." + name, context[name]
            for name, value in (context.get("materials") or {}).items():
                if isinstance(value, str):
                    yield "OFFICIAL.material." + name, value
            if packet.get("output"):
                yield "EXECUTION.output", packet["output"] if isinstance(packet["output"], str) else compact(packet["output"])
        except (ValueError, AttributeError):
            pass
    command = response.get("executeCmd") or ""
    if command:
        try:
            packet = json.loads(shlex.split(command)[-1])
            if isinstance(packet, dict) and isinstance(packet.get("python"), str):
                yield "OUT.python_source", packet["python"]
        except (ValueError, IndexError):
            pass


def turn_summary(record):
    request = record.get("request") or {}
    response = record.get("response") or {}
    team = request.get("teamOur") or {}
    roles = team.get("roles") or []
    live = [r for r in roles if isinstance(r, dict) and isinstance(r.get("health"), (int, float)) and r["health"] > 0]
    bases = [r for r in live if r.get("roleType") == "station"]
    actors = [r for r in live if r.get("roleType") in ("worker", "pioneer")]
    towers = [r for r in live if r.get("roleType") in ("rocket", "gatling", "railgun")]
    walls = [r for r in live if r.get("roleType") == "wall"]
    commands = {}
    for uid, command in (response.get("roleCommandMap") or {}).items():
        command = dict(command)
        if "taskAnswer" in command:
            command["taskAnswer"] = {"chars": len(command["taskAnswer"])}
        commands[uid] = command
    feedback = request.get("lastRoundRoleActionResults") or {}
    failed = [str(uid) for uid, result in feedback.items() if result is False]
    task = (record.get("diagnostics") or {}).get("task") or {}
    return {"id": record["id"], "round": record.get("roundNo"), "team": team.get("type"),
            "gold": team.get("goldNum"), "score": team.get("totalScore"),
            "base_hp": [r["health"] for r in bases], "alive_actors": len(actors),
            "actors": [{"id": r.get("id"), "kind": r.get("roleType"), "hp": r["health"],
                        "pos": r.get("pos"), "bag": dict(Counter(r.get("backpack") or []))} for r in actors[:3]],
            "towers": [{"id": r.get("id"), "hp": r["health"], "level": r.get("level"),
                        "cooldown": r.get("cooldown")} for r in towers[:3]],
            "walls": len(walls), "robots": len((request.get("robot") or {}).get("roles") or []),
            "actions": commands, "failed_previous_actions": failed[:16],
            "error_codes": [e.get("errorCode") for e in (request.get("errors") or [])[:8] if isinstance(e, dict)],
            "reason": (record.get("diagnostics") or {}).get("reason"),
            "mode": (record.get("diagnostics") or {}).get("mode"),
            "task": {k: task.get(k) for k in ("active", "kind", "pending", "deadline")},
            "defense": (record.get("diagnostics") or {}).get("defense"),
            "treasure_result": request.get("lastSummonTreasureResult", 0),
            "treasure": (record.get("diagnostics") or {}).get("treasure"),
            "prompt_chars": len(response.get("prompt") or ""),
            "executeCmd_chars": len(response.get("executeCmd") or ""),
            "llmResp_chars": len(request.get("llmResp") or ""),
            "lastCmdResult_chars": len(request.get("lastCmdResult") or ""),
            "ms": record.get("elapsedMs"),
            "request_gap_ms": (record.get("diagnostics") or {}).get("request_gap_ms"),
            "response_sent": (record.get("http") or {}).get("response_sent"),
            "exception": (record.get("error") or {}).get("message")}


class TraceWriter:
    """Never wait for the platform log collector in an HTTP handler.

    At most 128 turn records / 4 MiB of encoded logs are queued. Dropped records
    are explicitly announced once the collector can consume output again.
    """
    def __init__(self, logger=LOGGER, max_bytes=4 * 1024 * 1024):
        self.logger = logger
        self.prefix = uuid.uuid4().hex[:12]
        self.sequence = itertools.count(1)
        self.queue = queue.Queue(maxsize=128)
        self.max_bytes = max_bytes
        self.queued_bytes = 0
        self.dropped = 0
        self.lock = threading.Lock()
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self._write, name="hugh-stdout", daemon=True)
        self.thread.start()

    def next_id(self):
        return self.prefix + "-" + str(next(self.sequence))

    def emit(self, record):
        record = dict(record, ts=datetime.now(timezone.utc).isoformat(), version=VERSION)
        try:
            raw = compact(record).encode("utf-8")
            plain = raw.decode("utf-8")
            try:
                summary = turn_summary(record)
            except Exception as exc:
                summary = {"id": record["id"], "round": record.get("roundNo"),
                           "summary_error": str(exc)[:160]}
            text = compact(summary)
            if len(text.encode("utf-8")) > 3400:
                # Exact contents remain in the trace, even when the readable
                # summary must shrink to fit a platform log line.
                for actor in summary["actors"]:
                    actor.pop("bag", None)
                summary["actions"] = {k: v.get("action") for k, v in summary["actions"].items()}
                summary["exception"] = (summary.get("exception") or "")[:160]
                text = compact(summary)
            if len(text.encode("utf-8")) > 3400:
                text = compact({"id": record["id"], "round": record.get("roundNo"),
                                "reason": str(summary.get("reason"))[:80],
                                "base_hp": summary.get("base_hp"), "alive_actors": summary.get("alive_actors"),
                                "summary_trimmed": True})
            details = list(readable_fields(record))
            item = (record["id"], hashlib.sha256(raw).hexdigest(), text, plain, details, record.get("roundNo"))
        except Exception as exc:
            # Diagnostics must never turn a successful decision into a failure.
            item = (record["id"], "", compact({"id": record["id"], "diagnostic_error": str(exc)}), "", [], record.get("roundNo"))
        size = len(item[2].encode("utf-8")) + len(item[3].encode("utf-8")) + sum(len(v.encode("utf-8")) for _, v in item[4])
        with self.lock:
            if self.stop.is_set() or self.queued_bytes + size > self.max_bytes:
                self.dropped += 1
                return False
            try:
                self.queue.put_nowait((item, size))
                self.queued_bytes += size
            except queue.Full:
                self.dropped += 1
                return False
        return True

    def _write(self):
        while not self.stop.is_set() or not self.queue.empty():
            try:
                item, size = self.queue.get(timeout=0.1)
            except queue.Empty:
                continue
            trace_id, digest, summary, plain, details, round_no = item
            try:
                with self.lock:
                    dropped, self.dropped = self.dropped, 0
                if dropped:
                    self.logger.warning("HUGH_TRACE_DROPPED count=%d reason=stdout_backpressure", dropped)
                self.logger.info("HUGH_TURN %s", summary)
                parts = list(utf8_chunks(plain))
                for part, value in enumerate(parts, 1):
                    self.logger.info("HUGH_TRACE id=%s part=%s/%s sha256=%s codec=json data=%s",
                                     trace_id, part, len(parts), digest, value)
                for name, value in details:
                    self.logger.info("HUGH_TEXT_BEGIN id=%s round=%s field=%s", trace_id, round_no, name)
                    for line in value.split("\n"):
                        for chunk in list(utf8_chunks(line)) or [""]:
                            self.logger.info("HUGH_TEXT r=%s %s | %s", round_no, name, chunk)
                    self.logger.info("HUGH_TEXT_END id=%s round=%s field=%s", trace_id, round_no, name)
            except Exception:
                with self.lock:
                    self.dropped += 1
            finally:
                with self.lock:
                    self.queued_bytes -= size
                self.queue.task_done()
        with self.lock:
            dropped, self.dropped = self.dropped, 0
        if dropped:
            self.logger.warning("HUGH_TRACE_DROPPED count=%d reason=stdout_backpressure", dropped)

    def close(self, timeout=2):
        self.stop.set()
        self.thread.join(timeout=timeout)
