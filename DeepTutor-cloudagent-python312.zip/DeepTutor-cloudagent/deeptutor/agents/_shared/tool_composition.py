"""Per-turn tool composition policy shared by chat / quiz pipelines.

Owns the rule "given the user's composer toggles + the turn's context
flags, what tools should be enabled?". Lives outside any single pipeline
so chat and quiz can't disagree about which tools the user controls vs.
which the pipeline auto-mounts.

Two pieces:

* :data:`AUTO_MOUNTED_TOOLS` — tools whose mounting is owned by the
  pipeline (auto-on under specific conditions), not by user toggles.
  Membership here hides the tool from the user's composer / settings UI.
* :func:`compose_enabled_tools` — pure function that takes the user's
  toggled list + a :class:`ToolMountFlags` and returns the final, ordered
  enabled-tool list for one turn.

Callers resolve their own flags (chat checks selected KBs / source index
/ memory / notebooks; quiz reuses chat's policy verbatim).
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
import json
from typing import Any

from deeptutor.tools.builtin import (
    BUILTIN_TOOL_NAMES,
    CONFIGURABLE_BUILTIN_TOOL_NAMES,
    USER_TOGGLEABLE_TOOL_NAMES,
)

# Tools whose mounting is owned by the pipeline (auto-on under specific
# context conditions), not by the user's composer toggles. Membership here
# hides the tool from ``{tool_list}`` until its corresponding condition fires
# in :func:`compose_enabled_tools`. Derived from
# ``CONFIGURABLE_BUILTIN_TOOL_NAMES`` so the partner config surface and the
# auto-mount set can never drift apart.
AUTO_MOUNTED_TOOLS: frozenset[str] = frozenset(CONFIGURABLE_BUILTIN_TOOL_NAMES)

# Conditional auto-mounts: tool name -> the ``ToolMountFlags`` attribute that
# gates it. Single source of truth shared by the default composition (mount
# when the flag is set) and the authoritative capability path (a capability's
# declared built-in is dropped when its gate is unmet — e.g. ``rag`` without a KB).
# Insertion order fixes the default surface's conditional-tool order.
_CONDITIONAL_MOUNT_FLAGS: dict[str, str] = {
    "preprint": "has_scientific_research",
    "research_audit": "has_scientific_research",
    "research_lit": "has_scientific_research",
    "rag": "has_kb",
    "kb_files": "has_kb",
    "knowledge_frontier": "has_kb",
    "read_source": "has_sources",
    "read_memory": "has_memory",
    "list_notebook": "has_notebooks",
    "write_note": "has_notebooks",
    "question_bank": "has_question_bank",
    "read_skill": "has_skills",
    "load_tools": "has_deferred_tools",
    # The single execution surface for source code and shell scripts.
    "exec": "has_exec",
    "mastery_topics": "has_mastery_topics",
    "mastery_sessions": "has_mastery_nav",
    "mastery_open_session": "has_mastery_nav",
    "mastery_new_session": "has_mastery_nav",
}

# Built-ins that survive an exclusive knowledge capability when other KBs are
# co-selected: retrieval over them, and enumeration of what they hold.
_KB_COEXISTING_TOOLS: tuple[str, ...] = ("rag", "kb_files", "knowledge_frontier")

# The workspace is the user's shared content surface, not a capability or an
# optional enhancement.  These tools therefore survive exclusive capability
# surfaces and per-partner built-in filters.
WORKSPACE_BASELINE_TOOLS: tuple[str, ...] = (
    "workspace_list",
    "workspace_read",
    "workspace_search",
    "workspace_present",
)


def default_optional_tools(excluded: Iterable[str] = ()) -> list[str]:
    """Return the user-toggleable tool list (chat's default set).

    Sourced from :mod:`deeptutor.tools.builtin` so the /settings/tools UI
    and the pipelines can never disagree about which tools the user
    actually controls.
    """
    excluded_set = frozenset(excluded)
    return [
        name
        for name in USER_TOGGLEABLE_TOOL_NAMES
        if name in BUILTIN_TOOL_NAMES
        and name not in excluded_set
        and name not in AUTO_MOUNTED_TOOLS
    ]


def admin_enabled_optional_tools() -> list[str]:
    """The admin's globally-enabled user-toggleable tools.

    Partners are admin-scoped artifacts (their config and workspace live under
    the admin workspace root), so a partner's tool surface mirrors the admin's
    Settings → Chat → Tools toggles — the very file that page writes. The
    partner runtime executes inside a *synthetic* partner scope, not the
    admin's, so reading the current-user path service there would resolve to
    the partner's own (empty) settings; this reader goes straight to the admin
    workspace's ``interface.json`` instead.

    This is the single source both the partner tool picker
    (``build_tool_options``) and the partner runtime
    (``_resolved_enabled_tools``) intersect against, keeping them in lock-step
    with the admin's global chat toggles: a tool the admin disabled globally
    can neither be picked for a partner nor run inside one, regardless of what
    a partner config saved. Fails open to the full toggleable set (mirroring
    ``DEFAULT_UI_SETTINGS``) so a missing or unreadable settings file never
    silently strips tools.
    """
    from deeptutor.multi_user.paths import get_admin_path_service

    try:
        path = get_admin_path_service().get_settings_file("interface")
        if not path.exists():
            return list(USER_TOGGLEABLE_TOOL_NAMES)
        with open(path, encoding="utf-8") as handle:
            data = json.load(handle)
    except Exception:
        return list(USER_TOGGLEABLE_TOOL_NAMES)

    value = data.get("enabled_optional_tools") if isinstance(data, dict) else None
    if not isinstance(value, list):
        return list(USER_TOGGLEABLE_TOOL_NAMES)
    allowed = set(USER_TOGGLEABLE_TOOL_NAMES)
    seen: set[str] = set()
    out: list[str] = []
    for name in value:
        if isinstance(name, str) and name in allowed and name not in seen:
            seen.add(name)
            out.append(name)
    return out


@dataclass(frozen=True)
class ToolMountFlags:
    """Per-turn flags that drive the auto-mount policy.

    Each capability resolves these from its own context (chat inspects
    ``UnifiedContext.knowledge_bases``, the source index, the memory
    service, the notebook manager; quiz reuses the same checks).
    """

    has_kb: bool = False
    has_sources: bool = False
    has_memory: bool = False
    has_notebooks: bool = False
    has_question_bank: bool = False
    has_skills: bool = False
    has_deferred_tools: bool = False
    has_scientific_research: bool = False
    has_exec: bool = False
    #: The learner has at least one mastery topic to be sent back to.
    has_mastery_nav: bool = False
    #: …and this turn is not itself a mastery turn. The tutoring surface has
    #: ``mastery_paths`` for reading the atlas, so listing topics twice with
    #: two differently-named tools only invites the model to pick the wrong
    #: one. The hand-off tools stay mounted there: sending the learner to
    #: another topic's own screen is safer mid-course than re-pointing the
    #: conversation under them.
    has_mastery_topics: bool = False


def compose_enabled_tools(
    *,
    registry: Any,
    requested_tools: list[str] | None,
    optional_whitelist: list[str],
    mount_flags: ToolMountFlags,
    capability_owned: Iterable[str] = (),
    exclusive: bool = False,
    builtin_whitelist: set[str] | None = None,
    forced: Iterable[str] = (),
    suppressed: Iterable[str] = (),
) -> list[str]:
    """Compose the per-turn enabled-tool list.

    Order:

    1. User-toggled tools (filtered through ``get_enabled`` so unknown tools
       never sneak in, intersected with ``optional_whitelist`` so only
       legitimate composer toggles are respected).
    2. Conditional auto-mounts (:data:`_CONDITIONAL_MOUNT_FLAGS`: ``rag`` if a
       KB is attached, ``read_source`` if a source index exists, …).
    3. Active loop capabilities' *owned* tools (``capability_owned``) — the
       capability's own tools, added on top.
    4. Always-on auto-mounts (``write_memory`` / ``learning_status`` / ``learning_update`` / ``web_fetch`` / ``github`` /
       ``ask_user`` / ``cron``).

    A loop capability (solve, mastery) reuses the *full* chat surface and only
    *adds* its owned tools — it never curates or suppresses the reused
    built-ins, so a capability turn respects the user's composer toggles
    exactly as a chat turn does.

    ``exclusive=True`` flips that for the *knowledge* category (an active
    :class:`~deeptutor.capabilities.protocol.KnowledgeCapability`): the turn
    runs on ``capability_owned`` plus the ``ask_user`` floor — no other
    built-ins, no composer toggles. The one exception is ``rag`` when
    ``mount_flags.has_kb`` is set: it serves co-selected KBs the capability does
    not own (e.g. LlamaIndex KBs alongside an Obsidian vault), so it coexists
    with the owned surface instead of being dropped (issue #650). The capability
    otherwise owns the surface.

    ``builtin_whitelist`` gates the *built-in* auto-mounts (steps 2 and 4 —
    the :data:`AUTO_MOUNTED_TOOLS` members). ``None`` (the product-chat default)
    means "no gating": every built-in mounts under its usual context condition,
    exactly as before. A set restricts which built-ins may mount — partners use
    this so an owner can deny e.g. ``read_memory`` to an IM-facing companion.
    It never *adds* tools (a built-in still needs its context gate); it only
    subtracts. User-toggled tools (step 1) and capability-owned tools (step 3)
    are unaffected — they have their own gates.

    ``forced`` tools are appended unconditionally — they bypass both the
    ``builtin_whitelist`` and the context gates (used by the partner runtime to
    mandate ``partner_read`` / ``partner_memorize`` / ``partner_search``).
    ``suppressed`` tools are removed from the final list regardless of how they
    got there (the partner runtime suppresses chat's ``read_memory`` /
    ``write_memory`` in favour of the partner variants). Both apply in the
    ``exclusive`` branch too.

    The result is ordered and deduplicated. ``optional_whitelist`` is still
    expected to exclude ``AUTO_MOUNTED_TOOLS`` via :func:`default_optional_tools`.
    """
    if exclusive:
        owned = [str(name) for name in capability_owned if str(name).strip()]
        # The KB built-ins are the ones that coexist with an exclusive knowledge
        # capability: they serve co-selected KBs the capability's own tools don't
        # touch (e.g. LlamaIndex KBs alongside an Obsidian vault). The caller
        # sets ``has_kb`` only for those coexisting KBs, so a pure-capability
        # turn still mounts nothing but ``owned`` + the ``ask_user`` floor (#650).
        extra = (
            [
                name
                for name in _KB_COEXISTING_TOOLS
                if builtin_whitelist is None or name in builtin_whitelist
            ]
            if mount_flags.has_kb
            else []
        )
        return _finalize(
            [*WORKSPACE_BASELINE_TOOLS, *owned, *extra, "ask_user"], forced, suppressed
        )

    def _builtin_allowed(name: str) -> bool:
        return builtin_whitelist is None or name in builtin_whitelist

    composed: list[str] = [
        tool.name
        for tool in registry.get_enabled(requested_tools or [])
        if tool.name in optional_whitelist
    ]
    for tool_name, flag in _CONDITIONAL_MOUNT_FLAGS.items():
        if getattr(mount_flags, flag) and _builtin_allowed(tool_name):
            composed.append(tool_name)
    composed.extend(str(name) for name in capability_owned if str(name).strip())
    for always_on in (
        "write_memory",
        "learning_status",
        "learning_update",
        "web_fetch",
        "github",
        "ask_user",
        "cron",
    ):
        if _builtin_allowed(always_on):
            composed.append(always_on)
    return _finalize([*WORKSPACE_BASELINE_TOOLS, *composed], forced, suppressed)


def _finalize(names: Iterable[str], forced: Iterable[str], suppressed: Iterable[str]) -> list[str]:
    """Append ``forced`` (bypassing all gates), dedupe, then drop ``suppressed``."""
    out = list(names)
    out.extend(str(name) for name in forced if str(name).strip())
    suppressed_set = {str(name) for name in suppressed}
    return [name for name in _ordered_unique(out) if name not in suppressed_set]


def _ordered_unique(names: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for name in names:
        if name in seen:
            continue
        seen.add(name)
        result.append(name)
    return result


def user_has_memory() -> bool:
    """Whether the active user has any L3 memory content.

    Drives the auto-mount of ``read_memory``. Per-user paths resolve via
    the multi-user ContextVars the runtime sets up. Fails closed (returns
    ``False``) on any error so a broken memory directory doesn't surface
    a tool with no payload to read.
    """
    try:
        from deeptutor.services.memory import get_memory_store

        store = get_memory_store()
        return any(
            store.read_raw("L3", slot).strip()
            for slot in ("recent", "profile", "scope", "preferences")
        )
    except Exception:
        return False


def user_has_notebooks() -> bool:
    """Whether the active user has at least one notebook.

    Auto-mount gate for ``list_notebook`` + ``write_note``. Same
    fail-closed posture as :func:`user_has_memory`.
    """
    try:
        from deeptutor.services.notebook import get_notebook_manager

        notebooks = get_notebook_manager().list_notebooks()
        return isinstance(notebooks, list) and any(
            nb for nb in notebooks if str(nb.get("id") or "").strip()
        )
    except Exception:
        return False


def user_has_mastery_topics() -> bool:
    """Whether the learner has any mastery topic worth navigating to.

    Auto-mount gate for the four ``mastery_*`` navigation tools. Same
    fail-closed posture as :func:`user_has_memory`; the probe itself avoids
    creating a store for a learner who has never opened one (see
    ``LearningStore.default_db_path``).
    """
    try:
        from deeptutor.learning.navigation import learner_has_topics

        return learner_has_topics()
    except Exception:
        return False


def user_has_question_bank() -> bool:
    """Whether the learner has any saved quiz questions.

    Auto-mount gate for ``question_bank``. Separate from
    :func:`user_has_notebooks` on purpose — the bank and the notebooks are
    different stores, and a learner routinely has one without the other.
    Same fail-closed posture as its siblings.
    """
    try:
        from deeptutor.services.session import get_sqlite_session_store

        return get_sqlite_session_store().has_question_bank_entries()
    except Exception:
        return False


def partner_can_record_questions() -> bool:
    """Whether this turn runs inside a partner conversation.

    Partner turns mount ``question_bank`` even when the bank is still empty:
    recording the first wrong question is exactly the point (#1244) — the
    tool's ``record`` action files the mistake the learner just owned up to
    into the bank their family reviews. The partner context is read lazily
    (import-time this would be a cycle through the partners package).
    """
    try:
        from deeptutor.services.partners.interaction import get_partner_turn_context

        return get_partner_turn_context() is not None
    except Exception:
        return False


__all__ = [
    "AUTO_MOUNTED_TOOLS",
    "ToolMountFlags",
    "WORKSPACE_BASELINE_TOOLS",
    "admin_enabled_optional_tools",
    "compose_enabled_tools",
    "default_optional_tools",
    "partner_can_record_questions",
    "user_has_mastery_topics",
    "user_has_memory",
    "user_has_notebooks",
    "user_has_question_bank",
]
