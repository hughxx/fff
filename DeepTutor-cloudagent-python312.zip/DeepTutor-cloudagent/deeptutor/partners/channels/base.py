"""Base channel interface for chat platforms."""

from __future__ import annotations

from abc import ABC, abstractmethod
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path
from typing import Any

from deeptutor.partners.bus.events import InboundMessage, OutboundMessage
from deeptutor.partners.bus.queue import MessageBus

#: Owning Partner of the channel currently being constructed. Channels that
#: resolve paths in ``__init__`` need the id *then*, but ``ChannelManager``
#: builds the instance before it can assign an attribute — and threading the
#: id through every subclass signature would break external plugins, which
#: are constructed the same way.
_constructing_for: ContextVar[str] = ContextVar("partner_channel_owner", default="")


@contextmanager
def constructing_for(partner_id: str):
    """Mark whose channel is being built, so ``__init__`` can resolve paths."""
    token = _constructing_for.set(str(partner_id or ""))
    try:
        yield
    finally:
        _constructing_for.reset(token)


def _logger():
    from loguru import logger as _log

    return _log


class BaseChannel(ABC):
    """
    Abstract base class for chat channel implementations.

    Each channel (Telegram, Discord, etc.) should implement this interface
    to integrate with the TutorBot message bus.
    """

    name: str = "base"
    display_name: str = "Base"
    transcription_api_key: str = ""
    # Effective delivery flags for this channel instance; the manager resolves
    # them from the channel's own config at init time.
    send_progress: bool = True
    send_tool_hints: bool = True
    partner_id: str = ""

    def __init__(self, config: Any, bus: MessageBus):
        """
        Initialize the channel.

        Args:
            config: Channel-specific configuration.
            bus: The message bus for communication.
        """
        self.config = config
        self.bus = bus
        self._running = False
        self.partner_id = _constructing_for.get()
        # User-actionable setup/runtime output belongs in the WebUI. Channels
        # may publish a small, deliberately non-secret status payload here
        # instead of printing QR codes, login URLs or setup instructions to
        # the backend terminal.
        self._setup_state: dict[str, str] = {}
        self._setup_revision = 0

    def set_setup_state(
        self,
        status: str,
        *,
        message: str = "",
        qr_payload: str = "",
    ) -> None:
        """Publish sanitized channel setup state for the Partner WebUI."""
        self._setup_revision += 1
        self._setup_state = {
            "status": str(status or ""),
            **({"message": str(message)} if message else {}),
            **({"qr_payload": str(qr_payload)} if qr_payload else {}),
        }

    @property
    def setup_state(self) -> dict[str, str]:
        """A copy of the current user-facing setup state (never credentials)."""
        return dict(self._setup_state)

    @property
    def setup_revision(self) -> int:
        """Monotonic marker used to detect channel-owned status updates."""
        return self._setup_revision

    def media_dir(self, channel: str | None = None) -> Path:
        """Download directory isolated to this channel's owning Partner."""
        from deeptutor.partners.config.paths import get_media_dir, get_partner_media_dir

        if self.partner_id:
            return get_partner_media_dir(self.partner_id, channel or self.name)
        # Plugin/tests may construct a channel outside PartnerManager. Preserve
        # the legacy location in that standalone case.
        return get_media_dir(channel or self.name)

    def state_dir(self) -> Path:
        """Runtime state directory isolated to this channel's owning Partner.

        Channel state is an *account identity* (bot tokens, poll cursors), so
        it must never be shared: two Partners on the same channel would read
        each other's credentials and overwrite each other's cursor. Resolve
        lazily — ``PartnerManager`` sets ``partner_id`` after construction.
        """
        from deeptutor.partners.config.paths import get_partner_channel_dir, get_runtime_subdir

        if self.partner_id:
            return get_partner_channel_dir(self.partner_id, self.name)
        # Standalone construction (plugins/tests): keep the legacy location.
        return get_runtime_subdir(self.name)

    async def transcribe_audio(self, file_path: str | Path) -> str:
        """Transcribe an audio file via Groq Whisper. Returns empty string on failure."""
        if not self.transcription_api_key:
            return ""
        try:
            from deeptutor.partners.transcription import GroqTranscriptionProvider

            provider = GroqTranscriptionProvider(api_key=self.transcription_api_key)
            return await provider.transcribe(file_path)
        except Exception as e:
            _logger().warning("{}: audio transcription failed: {}", self.name, e)
            return ""

    @abstractmethod
    async def start(self) -> None:
        """
        Start the channel and begin listening for messages.

        This should be a long-running async task that:
        1. Connects to the chat platform
        2. Listens for incoming messages
        3. Forwards messages to the bus via _handle_message()
        """
        pass

    @abstractmethod
    async def stop(self) -> None:
        """Stop the channel and clean up resources."""
        pass

    @abstractmethod
    async def send(self, msg: OutboundMessage) -> None:
        """
        Send a message through this channel.

        Args:
            msg: The message to send.

        Implementations should raise on delivery failure so the channel
        manager can apply the retry policy in one place.
        """
        pass

    async def send_delta(
        self, chat_id: str, delta: str, metadata: dict[str, Any] | None = None
    ) -> None:
        """Deliver a streaming text chunk.

        Override in subclasses to enable streaming (in-place message edits).
        Implementations should raise on delivery failure so the channel
        manager can retry.

        Streaming contract: ``_stream_delta`` marks a chunk, ``_stream_end``
        ends the current segment, and stateful implementations must key
        buffers by ``_stream_id`` rather than only by ``chat_id``.
        """
        pass

    @property
    def supports_streaming(self) -> bool:
        """True when config enables streaming AND this subclass implements send_delta."""
        cfg = self.config
        streaming = (
            cfg.get("streaming", False)
            if isinstance(cfg, dict)
            else getattr(cfg, "streaming", False)
        )
        return bool(streaming) and type(self).send_delta is not BaseChannel.send_delta

    def is_allowed(self, sender_id: str) -> bool:
        """Check if *sender_id* is permitted.  Empty list → deny all; ``"*"`` → allow all."""
        allow_list = getattr(self.config, "allow_from", [])
        if not allow_list:
            _logger().warning("{}: allow_from is empty — all access denied", self.name)
            return False
        if "*" in allow_list:
            return True
        return str(sender_id) in allow_list

    async def _handle_message(
        self,
        sender_id: str,
        chat_id: str,
        content: str,
        media: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        session_key: str | None = None,
    ) -> None:
        """
        Handle an incoming message from the chat platform.

        This method checks permissions and forwards to the bus.

        Args:
            sender_id: The sender's identifier.
            chat_id: The chat/channel identifier.
            content: Message text content.
            media: Optional list of media URLs.
            metadata: Optional channel-specific metadata.
            session_key: Optional session key override (e.g. thread-scoped sessions).
        """
        if not self.is_allowed(sender_id):
            _logger().warning(
                "Access denied for sender {} on channel {}. "
                "Add them to allowFrom list in config to grant access.",
                sender_id,
                self.name,
            )
            return

        meta = metadata or {}
        if self.supports_streaming and self.send_progress:
            # The runner streams reply text live only when asked to. Streaming
            # requires send_progress: narration rounds stream as they happen,
            # so with progress muted we fall back to buffered delivery.
            meta = {**meta, "_wants_stream": True}

        msg = InboundMessage(
            channel=self.name,
            sender_id=str(sender_id),
            chat_id=str(chat_id),
            content=content,
            media=media or [],
            metadata=meta,
            session_key_override=session_key,
        )

        await self.bus.publish_inbound(msg)

    @classmethod
    def default_config(cls) -> dict[str, Any]:
        """Return default config for onboard. Override in plugins to auto-populate config.json."""
        return {"enabled": False}

    @property
    def is_running(self) -> bool:
        """Check if the channel is running."""
        return self._running


async def deliver_outbound(channel: BaseChannel, msg: OutboundMessage) -> None:
    """Apply the shared stream/final delivery contract at either partner router."""
    metadata = msg.metadata or {}
    if metadata.get("_stream_delta") or metadata.get("_stream_end"):
        await channel.send_delta(msg.chat_id, msg.content, metadata)
    elif metadata.get("_streamed"):
        # A channel can confirm that its streamed final actually reached the
        # user. If it could not, give the ordinary final its own send attempt.
        consume = getattr(channel, "consume_stream_delivery", None)
        if callable(consume) and not consume(metadata):
            await channel.send(msg)
    else:
        await channel.send(msg)
