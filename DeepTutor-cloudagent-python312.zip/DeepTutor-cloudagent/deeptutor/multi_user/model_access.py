"""Server-side model grant resolution and redacted model views.

Grants carry LLM assignments only (grant v2): embedding and search always
resolve from the deployment's active profiles, so per-user grants for them
were never enforced and are not stored.

Two sources reach an ordinary user, and :func:`redacted_model_access` is the
one place both are resolved: ``admin`` models assigned through a grant, and
the ``personal`` owner-bound profiles the user signed in for themselves (see
:mod:`deeptutor.multi_user.personal_models`). Everything downstream — the
option list, the capability gate, and selection validation — reads that one
function, so the three can never disagree about what a user may use.
"""

from __future__ import annotations

from typing import Any

from deeptutor.services.config.model_catalog import ModelCatalogService
from deeptutor.services.config.provider_links import resolve_profile_provider
from deeptutor.services.model_selection import list_llm_options

from .context import get_current_user
from .grants import load_grant
from .paths import get_admin_path_service


def admin_catalog_service() -> ModelCatalogService:
    return ModelCatalogService(path=get_admin_path_service().get_settings_file("model_catalog"))


def admin_catalog() -> dict[str, Any]:
    return admin_catalog_service().load()


def _profile_by_id(catalog: dict[str, Any], service: str, profile_id: str) -> dict[str, Any] | None:
    for profile in catalog.get("services", {}).get(service, {}).get("profiles", []) or []:
        if str(profile.get("id") or "") == profile_id:
            return profile
    return None


def _model_by_id(profile: dict[str, Any], model_id: str) -> dict[str, Any] | None:
    for model in profile.get("models", []) or []:
        if str(model.get("id") or "") == model_id:
            return model
    return None


#: Bindings whose credential is one person's own subscription login rather than
#: a billable team key. Codex stamps ``owner_bound`` onto the managed profile it
#: publishes, but a profile can also be created by hand in the settings editor —
#: a CodeBuddy profile is, and it reads the operator's own IDE-plugin session —
#: and there is nowhere for such a profile to acquire the flag. Binding is the
#: durable fact, so it decides too.
OWNER_BOUND_BINDINGS = frozenset({"openai_codex", "codebuddy", "github_copilot"})


def is_owner_bound(profile: dict[str, Any]) -> bool:
    """Whether a profile is tied to the identity of the operator who set it up.

    OAuth providers such as Codex authenticate one individual's plan rather than
    a billable team key, so those profiles are never lent to other accounts
    through grants — each user signs in for themselves or goes without.
    """
    binding = str(profile.get("binding") or "").strip().lower().replace("-", "_")
    if binding in OWNER_BOUND_BINDINGS:
        return True
    return bool(profile.get("owner_bound"))


def redacted_model_access(user_id: str | None = None) -> dict[str, list[dict[str, Any]]]:
    user = get_current_user()
    if user_id is None:
        user_id = user.id
    grant = load_grant(user_id)
    catalog = admin_catalog()
    result: dict[str, list[dict[str, Any]]] = {"llm": []}
    for item in grant.get("models", {}).get("llm", []) or []:
        profile_id = str(item.get("profile_id") or item.get("id") or "")
        profile = _profile_by_id(catalog, "llm", profile_id)
        if profile is not None and is_owner_bound(profile):
            # A grant may predate the profile becoming owner-bound. Drop it here,
            # the one place every caller resolves grants through, so the option
            # list, the capability gate, and selection validation all agree.
            continue
        if not profile:
            result["llm"].append(
                {
                    "profile_id": profile_id,
                    "name": item.get("name") or profile_id or "Unavailable profile",
                    "source": "admin",
                    "available": False,
                }
            )
            continue
        for model_id in item.get("model_ids") or []:
            model = _model_by_id(profile, str(model_id))
            try:
                effective = resolve_profile_provider(catalog, "llm", profile, model)
            except ValueError:
                continue
            if is_owner_bound(effective):
                continue
            result["llm"].append(
                {
                    "profile_id": profile_id,
                    "model_id": str(model_id),
                    "name": (model or {}).get("name") or str(model_id),
                    "model": (model or {}).get("model") or "",
                    "provider": effective.get("binding") or "",
                    "profile_name": effective.get("name") or profile_id,
                    "reasoning_effort": (model or {}).get("reasoning_effort"),
                    "supported_reasoning_efforts": (model or {}).get(
                        "codex_supported_reasoning_levels"
                    ),
                    **{
                        f"declared_{key}": value
                        for key, value in ((model or {}).get("capabilities") or {}).items()
                        if key in {"reasoning", "vision"} and type(value) is bool
                    },
                    "source": "admin",
                    "available": model is not None,
                }
            )
    if user_id == user.id:
        # Only ever the caller's OWN personal models. An administrator
        # inspecting somebody's grants asks for that user's id, and their
        # personal sign-in is not the administrator's business — nor is it in
        # the grant editor's gift to assign.
        from .personal_models import personal_llm_rows

        result["llm"].extend(personal_llm_rows())
    return result


def allowed_llm_options() -> dict[str, Any]:
    user = get_current_user()
    if user.is_admin:
        return list_llm_options(admin_catalog())
    catalog = admin_catalog()
    llm_service = catalog.get("services", {}).get("llm", {})
    active_profile_id = str(llm_service.get("active_profile_id") or "")
    active_model_id = str(llm_service.get("active_model_id") or "")
    options = [
        {
            "profile_id": item.get("profile_id"),
            "model_id": item.get("model_id"),
            "profile_name": item.get("profile_name")
            or item.get("name")
            or item.get("profile_id")
            or "LLM",
            "model_name": item.get("name") or item.get("model") or item.get("model_id"),
            "label": item.get("name") or item.get("model") or item.get("model_id"),
            "model": item.get("model") or "",
            "provider": item.get("provider") or "",
            "reasoning_effort": item.get("reasoning_effort"),
            "supported_reasoning_efforts": item.get("supported_reasoning_efforts"),
            **{key: item[key] for key in ("declared_reasoning", "declared_vision") if key in item},
            "source": item.get("source") or "admin",
            "is_active_default": (
                item.get("profile_id") == active_profile_id
                and item.get("model_id") == active_model_id
            ),
        }
        for item in redacted_model_access(user.id).get("llm", [])
        if item.get("available")
    ]
    active = next(
        (
            {"profile_id": active_profile_id, "model_id": active_model_id}
            for option in options
            if option["is_active_default"]
        ),
        None,
    )
    return {"active": active, "options": options}


def has_capability_access(capability: str, user_id: str | None = None) -> bool:
    """Whether the user has at least one usable model for ``capability``.

    Admins are never gated — they manage the catalog directly. For ordinary
    users this mirrors exactly what ``redacted_model_access`` exposes to the
    frontend, so the server-side gate and the UI lock always agree.
    """
    user = get_current_user()
    if user.is_admin:
        return True
    if user_id is None:
        user_id = user.id
    items = redacted_model_access(user_id).get(capability, []) or []
    return any(item.get("available") for item in items)


def apply_allowed_llm_selection(selection: dict[str, Any] | None) -> dict[str, Any] | None:
    """Allow only admin-granted LLM profile/model selections for ordinary users."""
    user = get_current_user()
    if user.is_admin or not selection:
        return selection
    profile_id = str(selection.get("profile_id") or "")
    model_id = str(selection.get("model_id") or "")
    for item in redacted_model_access(user.id).get("llm", []):
        if item.get("profile_id") == profile_id and item.get("model_id") == model_id:
            return selection
    raise PermissionError("This model is not assigned to your account.")
