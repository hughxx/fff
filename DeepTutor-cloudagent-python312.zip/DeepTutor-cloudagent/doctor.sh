#!/usr/bin/env bash
# Explicit real cloud/embedding diagnostics. Never called by normal startup.
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
exec bash "$ROOT/deploy.sh" check
