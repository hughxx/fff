DeepTutor 内网适配包（无 Docker）
================================

此为精简部署包：省略 assets/figs 下的说明截图和架构插图，保留 Logo。
功能源码、测试、网页运行资源和部署文件均保留；仓库 README 的部分展示图片因此不会显示。
此 ZIP 是完整部署包，后续直接用完整包覆盖代码，不需要叠加补丁；运行数据不在包内。

部署：解压后进入目录，执行：
    bash deploy.sh

将 DeepTutor-cloudagent-python312.zip 上传到 /home/codeagent 后：
    cd /home/codeagent
    unzip -o DeepTutor-cloudagent-python312.zip
    cd DeepTutor-cloudagent
    bash deploy.sh

环境检查已合并到 bash deploy.sh：自动检查 Python/pip/Node、安装依赖、初始化配置、
检查真实模型/工具调用/向量服务，随后启动兼容网关和生产模式前后端。
默认页面：http://服务器IP:3782。首次前端编译需要时间，以终端 ready 提示为准。
前台运行，保持终端开启；Ctrl+C 停止全部本地服务。再次执行同一命令即可启动。
启动脚本不注册系统服务、不配置开机自启。需要长期运行可放在已有 tmux 会话里。
单独重跑真实服务检查：bash deploy.sh check
解压目录示例：/home/codeagent/DeepTutor-cloudagent。

机器与网络要求
--------------
Linux x86_64 或 ARM64；建议 Ubuntu 24.04 / Debian 12。
固定使用已有解释器：/home/codeagent/python312/bin/python3.12。
不使用 uv、sudo、apt 或虚拟环境，不另外安装 Python，不切换系统默认 Python。
依赖通过该解释器的 pip --user 安装，通常位于 ~/.local/lib/python3.12/site-packages。
所有启动命令使用同一解释器的 -m 模式，不依赖默认 python/pip/deeptutor 命令。
如果此解释器缺少 pip，会尝试自带的 ensurepip --user；缺少必要标准库时明确报错。
需要指定不同路径时：DEEPTUTOR_PYTHON=/完整路径/python3.12 bash deploy.sh。
旧包留下的 .venv/.runtime/uv 不会被使用或删除；配置和用户数据保留。
网页需要 Node.js 22+ 和 npm。
缺少 Node.js 时自动下载官方 22.22.0，校验 SHA256，安装在本目录 .runtime/。
需要能访问 PyPI、npm 和必要时 nodejs.org；这是在线安装包，不是离线依赖包。
前端默认使用 http://mirrors.tools.huawei.com/npm/，已写入 web/.npmrc 和部署命令。
锁文件的 5 个 npmmirror 直连地址已移除，依赖版本和完整性校验值保留。
要换前端源时：DEEPTUTOR_NPM_REGISTRY=https://其他源/ bash deploy.sh。
建议预留 4 核 / 8 GB 内存和 15 GB 可用磁盘（工程建议，并非已测最低配置）。无需 GPU。
Python 编译依赖报错时安装 build-essential / 对应 Python 开发头；FAISS 缺 libgomp.so.1 时安装 libgomp1。

固定服务：
  CloudAgent: http://10.90.113.228:8800
  Embedding: embed.txt 提供的 coreai 内网地址，默认 m3e / 768 维。
  也支持 paraphrase / 384 维，可在模型设置中选择。部署默认不使用 qwen3。
  如已运行旧包，已有模型配置会保留；需在设置中切换为 m3e、维度 768，并重建已有知识库索引。
部署机器须能直连上述地址，且能解析 service.coreai.rnd.huawei.com。
CloudAgent 需有在线节点和有效登录账号；工作区使用 Python 3.12。
内网服务请求不经过 HTTP_PROXY/HTTPS_PROXY。
部署前检查会实际生成少量向量并调用 3 次 Agent（文本、工具请求、工具结果回传）。
任何检查失败会停止部署，打印错误，不伪报成功。

实现与能力边界
--------------
127.0.0.1:8765 为本地兼容网关，不对外绑定。
模型地址 /v1/chat/completions；向量地址 /v1/embeddings。
模型配置自动写入 data/user/settings/model_catalog.json，只填充未配置的服务，不覆盖用户已有模型。
CloudAgent 地址写在 deployment/bridge.py；使用 cloudagent-default 时让云端选择账号默认模型。
可以在 DeepTutor 设置里把模型名改为该账号模型列表中的 value。

CloudAgent 文档没有原生 function calling：本包使用提示词 JSON 协议来请求宿主工具，
验证工具名称、JSON Schema、tool_choice 后再交给 DeepTutor 执行。
兼容云端偶发重复/残缺的 JSON 键前缀（例如 {"content{"content":...}）：
仅去除这类无有效值的前缀，提取其后的完整响应；恢复时会在终端打印说明。
不补造缺失参数、不选择多个答案中的某一个；工具参数仍需完整通过原有校验。
云端 Agent 并不直接执行 DeepTutor 工具。普通文本推理、结构化输出、知识库工具路径可经此协议接入。
这不是原生工具调用，可靠性取决于云端模型遵循协议；不合法输出会明确报错，不能保证全部复杂教学流程。
云端每次推理创建独立会话，完整消息/工具结果随请求传递，避免重复历史及并发串话；
推理成功后清理临时会话；失败会话保留以便查日志；每个安装目录保留一个隔离的云端工作区。
使用异步 tasks 接口，提交不自动重试；失败/中断时尝试取消仍在运行的任务，保留会话供排查。
默认串行推理，单次执行超时 600 秒（可通过 CLOUDAGENT_TIMEOUT 调整）。
兼容流会发送保活块，最终答案一次返回，不伪装成云端逐 token 实时流。
temperature/max_tokens 等参数无法通过提供的云端 API 强制控制；token 用量与费用未伪造。
输入总长度不能超过云端 100000 字符限制，超限报错，不静默截断。
图片/音频输入不支持；模型 vision 关闭。文本 PDF 解析可用；扫描件 OCR 需另外配置。
联网搜索、语音、图像/视频生成等外部服务没有自动配置。

数据、日志与端口
----------------
全部本地数据：data/（备份整个目录）。
环境检查、安装、云端检查、前端构建、服务输出和错误都会实时显示在终端。
完整输出同时追加保存到 data/deployment/deploy.log，无需自己接 tee。
网关输出也会显示在终端，并单独追加保存到 data/deployment/bridge.log。
部署失败时显示失败阶段、退出码和日志路径；服务非零退出也会明确显示。
启动前的模型检查尚未启动网关，该阶段错误在终端/deploy.log，不在 bridge.log。
云端失败详情（含云端实际返回的原因、会话/任务 ID）也直接显示在终端。
云端推理最近失败详情：data/cloudagent-bridge/last-error.json。
云端推理失败历史：data/cloudagent-bridge/errors.jsonl（每行一个 JSON）。
记录含工作区、会话、任务 ID，云端 error、结果错误及任务查询地址；不保存提交的完整提示词。
失败会话在云端保留，查询 task_url/session_url 可以继续排查；无需再次创建工作区。
云端工作区的执行诊断日志位于该工作区内的 .codeagent-logs/，与本机 data/ 不是同一路径。
云端工作区标识：data/cloudagent-bridge/workspace.json。
重复启动有目录锁；默认 3782/8001/8765 端口冲突会停止，不杀其他进程。
默认沿用 DeepTutor 单用户模式，仅用于受信任内网；需要公网访问时先配置登录和 HTTPS。
云端 API 按文档无需平台密钥；local-bridge 只是本地 SDK 占位值，不是云端凭证。

验证情况
--------
当前适配、启动检查、首次构建输入及终端日志共 46 项测试已通过，包括 OpenAI SDK 流式工具调用、
错误传播、云端失败原因输出、向量顺序/维度、会话保留/清理、配置保留及 stdout/stderr 日志镜像。
Bash 语法检查已通过；前端曾在本地完成生产构建，但这不代表目标 Linux 整机启动已验证。
开发环境访问真实 CloudAgent 和 Embedding 时连接被关闭，未完成真实云端端到端验证。
部署脚本强制在目标服务器执行真实检查后才启动；不代表所有业务能力均已验证。
开发环境为 Windows，Linux 安装流程仍需目标环境验证。
原生配置解析已验证；完整后端依赖安装未完成（开发环境下载受限），未做整机启动验证。
当前启动脚本针对指定 Python 3.12 路径做了 Bash 分支测试；尚未在目标 Linux 服务器执行。
