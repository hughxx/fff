#!/usr/bin/env bash
# Linux, no Docker. Run from anywhere: bash /path/to/DeepTutor/deploy.sh
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
export DEEPTUTOR_HOME="$ROOT"
export PYTHONUTF8=1
export PYTHONUNBUFFERED=1
export PIP_DEFAULT_TIMEOUT="${PIP_DEFAULT_TIMEOUT:-120}"
export PIP_RETRIES="${PIP_RETRIES:-5}"
export NEXT_TELEMETRY_DISABLED=1
export DEEPTUTOR_BACKEND_READY_TIMEOUT=180
export DEEPTUTOR_FRONTEND_READY_TIMEOUT=240
export NO_PROXY="${NO_PROXY:-},127.0.0.1,localhost,10.90.113.228,.rnd.huawei.com"
export no_proxy="$NO_PROXY"
export PATH="$ROOT/.runtime/node/bin:$PATH"
ACTION="${1:-start}"
mkdir -p data/deployment

fail() {
    echo "[ERROR] $*" >&2
    echo "[ERROR] Stage: ${DEPLOY_STAGE:-initialization}; output: ${DEPLOY_LOG:-terminal only}" >&2
    exit 1
}
DEPLOY_STAGE="initialization"
source "$ROOT/deployment/terminal_logging.sh"
trap 'report_deploy_error "$?" "$LINENO"' ERR
start_terminal_logging

[[ "$ACTION" == "start" || "$ACTION" == "check" || "$ACTION" == "doctor" ]] || fail "Usage: bash deploy.sh [start|check|doctor]"
[[ "$(uname -s)" == "Linux" ]] || fail "This Bash installer targets Linux (Ubuntu 22.04/24.04, Debian 12, or an existing Python 3.11-3.14 environment)."
command -v flock >/dev/null || fail "Install util-linux (flock) first."
exec 9>data/deployment/launcher.lock
flock -n 9 || fail "Another deploy.sh instance is already running for this directory."

source "$ROOT/deployment/bootstrap_python.sh"
DEPLOY_STAGE="Python/pip/Node environment check"
echo "[0/5] Checking Python, pip and Node.js environment..."
prepare_python
"$PYTHON" -m pip --version
if [[ "$ACTION" == "doctor" ]]; then
    if command -v node >/dev/null; then node --version; else echo "Node.js will be installed locally at startup."; fi
    exit 0
fi
if [[ "$ACTION" == "check" ]]; then
    "$PYTHON" -m deployment.check
    exit 0
fi

if ! command -v node >/dev/null || ! command -v npm >/dev/null || ! node -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 22 ? 0 : 1)'; then
    case "$(uname -m)" in x86_64) ARCH=x64;; aarch64|arm64) ARCH=arm64;; *) fail "Provide Node.js 22+ for this CPU architecture.";; esac
    NODE_VERSION=22.22.0
    mkdir -p .runtime
    # Python downloads and verifies the official SHA256 before extracting; local to this checkout.
    "$PYTHON" deployment/install_node.py "$NODE_VERSION" "$ARCH"
    export PATH="$ROOT/.runtime/node/bin:$PATH"
fi
node --version
npm --version
NPM_REGISTRY="${DEEPTUTOR_NPM_REGISTRY:-http://mirrors.tools.huawei.com/npm/}"
echo "Frontend registry: $NPM_REGISTRY"
DEPLOY_STAGE="Python dependency installation"
echo "[1/5] Installing Python dependencies (first run may take several minutes)..."
FINGERPRINT="$("$PYTHON" -c 'import hashlib,pathlib,site,sys; identity=f"direct-user-install-v1:{sys.executable}:{sys.version}:{site.getusersitepackages()}:{pathlib.Path.cwd()}"; print(hashlib.sha256(identity.encode()+pathlib.Path("pyproject.toml").read_bytes()+pathlib.Path("deployment/bridge.py").read_bytes()).hexdigest())')"
if [[ ! -f data/deployment/python-installed ]] || [[ "$(cat data/deployment/python-installed)" != "$FINGERPRINT" ]]; then
    "$PYTHON" -m pip install --user --upgrade pip
    "$PYTHON" -m pip install --user -e .
    printf '%s' "$FINGERPRINT" > data/deployment/python-installed
fi
DEPLOY_STAGE="frontend dependency installation"
echo "[2/5] Installing frontend dependencies..."
WEB_FINGERPRINT="$("$PYTHON" -c 'import hashlib,pathlib,sys; print(hashlib.sha256(pathlib.Path("web/package-lock.json").read_bytes()+pathlib.Path("web/.npmrc").read_bytes()+sys.argv[1].encode()).hexdigest())' "$NPM_REGISTRY")"
if [[ ! -d web/node_modules ]] || [[ ! -f data/deployment/web-installed ]] || [[ "$(cat data/deployment/web-installed)" != "$WEB_FINGERPRINT" ]]; then
    (cd web && npm ci --legacy-peer-deps --registry="$NPM_REGISTRY")
    printf '%s' "$WEB_FINGERPRINT" > data/deployment/web-installed
fi
DEPLOY_STAGE="configuration initialization"
echo "[3/5] Initializing configuration..."
"$PYTHON" -m deployment.configure
DEPLOY_STAGE="CloudAgent and embedding checks"
echo "[4/5] Checking cloud inference, tool round trip and embedding (real small model calls)..."
"$PYTHON" -m deployment.check
# Detect occupied ports before creating either process. Do not reuse unrelated listeners.
DEPLOY_STAGE="port availability check"
"$PYTHON" - <<'PY'
import json, socket
from pathlib import Path
s = json.loads(Path('data/user/settings/system.json').read_text())
for port in (8765, int(s.get('backend_port',8001)), int(s.get('frontend_port',3782))):
    with socket.socket() as sock:
        try: sock.bind(('0.0.0.0', port))
        except OSError: raise SystemExit(f'Port {port} is occupied. Stop the existing service before starting.')
PY
DEPLOY_STAGE="bridge startup"
echo "[5/5] Starting bridge and DeepTutor; first run builds the production frontend..."
BRIDGE_PID=""
APP_PID=""
cleanup() {
    trap - EXIT INT TERM
    [[ -z "$APP_PID" ]] || kill -TERM "$APP_PID" 2>/dev/null || true
    [[ -z "$APP_PID" ]] || wait "$APP_PID" 2>/dev/null || true
    [[ -z "$BRIDGE_PID" ]] || kill -TERM "$BRIDGE_PID" 2>/dev/null || true
    [[ -z "$BRIDGE_PID" ]] || wait "$BRIDGE_PID" 2>/dev/null || true
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
"$PYTHON" -m uvicorn deployment.bridge:app --host 127.0.0.1 --port 8765 9>&- > >(tee -a "$ROOT/data/deployment/bridge.log" 9>&-) 2>&1 &
BRIDGE_PID=$!
"$PYTHON" - <<'PY'
import time, urllib.request
opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
for _ in range(30):
    try:
        with opener.open('http://127.0.0.1:8765/health', timeout=1) as response:
            if response.status == 200: break
    except OSError: time.sleep(1)
else: raise SystemExit('Bridge failed to start. See data/deployment/bridge.log')
PY
DEPLOY_STAGE="DeepTutor startup and frontend production build"
"$PYTHON" -m deeptutor_cli start 9>&- &
APP_PID=$!
echo "Default web URL: http://<this-server-IP>:3782 (wait for DeepTutor's ready message)."
echo "Keep this terminal open. Ctrl+C stops all local services. Data stays in ./data/."
if wait -n "$APP_PID" "$BRIDGE_PID"; then
    STATUS=0
else
    STATUS=$?
fi
if ! kill -0 "$APP_PID" 2>/dev/null; then
    SERVICE="DeepTutor / frontend build"
else
    SERVICE="CloudAgent bridge"
fi
if [[ "$STATUS" -ne 0 ]]; then
    echo "[ERROR] $SERVICE exited with code $STATUS. Details are shown above." >&2
    echo "[ERROR] Complete output: $DEPLOY_LOG" >&2
else
    echo "[STOP] $SERVICE stopped; shutting down remaining local services."
fi
exit "$STATUS"
