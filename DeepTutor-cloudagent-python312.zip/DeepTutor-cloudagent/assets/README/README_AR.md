<div align="center">

<p align="center"><img src="../../assets/figs/logo/logo.png" alt="شعار DeepTutor" height="56" style="vertical-align: middle;">&nbsp;<img src="../../assets/figs/logo/banner.png" alt="DeepTutor" height="48" style="vertical-align: middle;"></p>

# DeepTutor: تدريس شخصي مدى الحياة

<p align="center">
  <a href="https://deeptutor.info" target="_blank"><img alt="الوثائق — deeptutor.info" src="https://img.shields.io/badge/Docs-deeptutor.info%20%E2%86%97-0A0A0A?style=for-the-badge&labelColor=F5F5F4" height="36"></a>&nbsp;
  <a href="https://deeptutor.info/collaborate/" target="_blank"><img alt="التعاون — اعمل معنا" src="https://img.shields.io/badge/Collaborate-work%20with%20us%20%E2%86%97-0A0A0A?style=for-the-badge&labelColor=F5F5F4" height="36"></a>
</p>

<p align="center">
<a href="https://www.star-history.com/hkuds/deeptutor"><picture><source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/badge?repo=HKUDS/DeepTutor&amp;type=trending&amp;theme=dark"><source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/badge?repo=HKUDS/DeepTutor&amp;type=trending"><img alt="مستودع GitHub الرائج لهذا اليوم" src="https://api.star-history.com/badge?repo=HKUDS/DeepTutor&amp;type=trending" height="55"></picture></a>&#32;<a href="https://trendshift.io/repositories/17099"><img src="https://trendshift.io/api/badge/trendshift/repositories/17099/daily" alt="HKUDS/DeepTutor | Trendshift" width="250" height="55"></a>&#32;<a href="https://www.star-history.com/hkuds/deeptutor"><picture><source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/badge?repo=HKUDS/DeepTutor&amp;theme=dark"><source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/badge?repo=HKUDS/DeepTutor"><img alt="ترتيب تاريخ النجوم" src="https://api.star-history.com/badge?repo=HKUDS/DeepTutor" width="185" height="55"></picture></a>
</p>

<p align="center">
  <a href="../../README.md"><img alt="English" height="40" src="https://img.shields.io/badge/English-CDCFD4"></a>&nbsp;
  <a href="README_CN.md"><img alt="简体中文" height="40" src="https://img.shields.io/badge/简体中文-CDCFD4"></a>&nbsp;
  <a href="README_TW.md"><img alt="繁體中文" height="40" src="https://img.shields.io/badge/繁體中文-CDCFD4"></a>&nbsp;
  <a href="README_JA.md"><img alt="日本語" height="40" src="https://img.shields.io/badge/日本語-CDCFD4"></a>&nbsp;
  <a href="README_ES.md"><img alt="Español" height="40" src="https://img.shields.io/badge/Español-CDCFD4"></a>&nbsp;
  <a href="README_FR.md"><img alt="Français" height="40" src="https://img.shields.io/badge/Français-CDCFD4"></a>&nbsp;
  <a href="README_AR.md"><img alt="Arabic" height="40" src="https://img.shields.io/badge/Arabic-BCDCF7"></a>&nbsp;
  <a href="README_RU.md"><img alt="Русский" height="40" src="https://img.shields.io/badge/Русский-CDCFD4"></a>&nbsp;
  <a href="README_HI.md"><img alt="Hindi" height="40" src="https://img.shields.io/badge/Hindi-CDCFD4"></a>&nbsp;
  <a href="README_PT.md"><img alt="Português" height="40" src="https://img.shields.io/badge/Português-CDCFD4"></a>&nbsp;
  <a href="README_TH.md"><img alt="Thai" height="40" src="https://img.shields.io/badge/Thai-CDCFD4"></a>&nbsp;
  <a href="README_PL.md"><img alt="Polski" height="40" src="https://img.shields.io/badge/Polski-CDCFD4"></a>
</p>

[![Python 3.11+](https://img.shields.io/badge/Python-3.11%2B-3776AB?style=flat-square&logo=python&logoColor=white)](https://www.python.org/downloads/)
[![Next.js 16](https://img.shields.io/badge/Next.js-16-000000?style=flat-square&logo=next.js&logoColor=white)](https://nextjs.org/)
[![License](https://img.shields.io/badge/License-Apache_2.0-blue?style=flat-square)](../../LICENSE)
[![GitHub release](https://img.shields.io/github/v/release/HKUDS/DeepTutor?style=flat-square&color=brightgreen)](https://github.com/HKUDS/DeepTutor/releases)
[![arXiv](https://img.shields.io/badge/arXiv-2604.26962-b31b1b?style=flat-square&logo=arxiv&logoColor=white)](https://arxiv.org/abs/2604.26962)

[![Discord](https://img.shields.io/badge/Discord-Community-5865F2?style=flat-square&logo=discord&logoColor=white)](https://discord.gg/eRsjPgMU4t)
[![Feishu](https://img.shields.io/badge/Feishu-Group-00D4AA?style=flat-square&logo=feishu&logoColor=white)](../../Communication.md)
[![WeChat](https://img.shields.io/badge/WeChat-Group-07C160?style=flat-square&logo=wechat&logoColor=white)](https://github.com/HKUDS/DeepTutor/issues/78)

[الميزات](#-الميزات-الرئيسية) · [البدء](#-البدء) · [الاستكشاف](#-استكشاف-deeptutor) · [واجهة CLI](#️-واجهة-سطر-أوامر-deeptutor--الواجهة-الأصيلة-للوكلاء) · [النظام البيئي](#-النظام-البيئي--eduhub-ومجتمع-المهارات) · [المجتمع](#-المجتمع)

</div>

---

> 🤝 **نرحب بجميع أنواع المساهمات!** صوّت على عناصر خارطة الطريق أو اقترح عناصر جديدة في [`Roadmap`](https://github.com/HKUDS/DeepTutor/issues/498)، وراجع [دليل المساهمة](../../CONTRIBUTING.md) لمعرفة استراتيجية الفروع ومعايير البرمجة وكيفية البدء.

### 📰 الأخبار

- **2026-09-20** 🎉 40 ألف نجمة في 9 أشهر! سنواصل توسيع منظومة التعلّم في DeepTutor.
- **2026-05-22** 🌐 موقع الوثائق الرسمي متاح على [**deeptutor.info**](https://deeptutor.info/) — الأدلة والمراجع وجولات القدرات كلها في مكان واحد.
- **2026-04-19** 🎉 20 ألف نجمة في 111 يومًا! شكراً على الدعم نحو تدريس شخصي وذكي حقيقي.
- **2026-04-10** 📄 ورقتنا البحثية متاحة على arXiv — اقرأ [النسخة الأولية](https://arxiv.org/abs/2604.26962) للتعرف على التصميم والأفكار وراء DeepTutor.
- **2026-02-06** 🚀 10 آلاف نجمة في 39 يومًا فقط! شكر جزيل لمجتمعنا الرائع.
- **2026-01-01** 🎊 كل عام وأنتم بخير! انضم إلى [Discord](https://discord.gg/eRsjPgMU4t) أو [WeChat](https://github.com/HKUDS/DeepTutor/issues/78) أو [النقاشات](https://github.com/HKUDS/DeepTutor/discussions) — لنشكّل معاً مستقبل DeepTutor.
- **2025-12-29** 🎓 تم إطلاق DeepTutor رسميًا!

## ✨ الميزات الرئيسية

DeepTutor هو بيئة تعلم أصيلة للوكلاء تربط التدريس وحل المشكلات وتوليد الاختبارات والبحث والتصور وممارسة الإتقان في نظام واحد قابل للتوسيع.

- **بيئة تشغيل واحدة لجميع الأوضاع** — تشترك Chat وAsk Questions وQuiz وResearch وVisualize وSolve وCourse Study وMastery Path وImmersive Reading وAudio Overview في بيئة تشغيل واحدة للقدرات وسياق الجلسة، مع احتفاظ كل منها بحلقات وخطوط أنابيب مصممة لغرضها.
- **Task Board** — تتبّع مهام الدراسة ضمن «للإنجاز» و«قيد التنفيذ» و«مكتمل»، مع ملاحظات وسحب وإفلات أو أزرار نقل يمكن استخدامها بلوحة المفاتيح، وأرشيف يمكنك الاستعادة منه. تبقى البطاقات في مساحة العمل الحالية وتتبع إعدادات المظهر واللغة القائمة؛ ولا يلزم تهيئة أي نموذج.
- **سياق تعلم متصل** — يمكن إعادة استخدام قواعد المعرفة والكتب ومسودات Co-Writer ودفاتر الملاحظات وبنوك الأسئلة والشخصيات والذاكرة عبر سير العمل التي تدعمها، وفقاً لمنح الحساب وسياسات التعلّم.
- **التعلّم الغامر بالفيديو** — أضف روابط YouTube أو Bilibili إلى Reading للتشغيل الأصلي والبحث في النصوص المفرّغة والتدريس المرتكز على الطوابع الزمنية والملاحظات المحفوظة والتقدّم القابل للاستئناف؛ ويمكن استخدام نسخة Invidious يهيئها المشرف لجلب ترجمات YouTube وتصفّحه.
- **الوكلاء الفرعيون والشركاء** — من داخل Chat، استشر مُشغِّل وكيل حيّاً (Claude Code أو Codex أو Grok CLI أو Antigravity أو Kimi أو opencode أو MiMo أو Hermes أو OpenClaw أو DeepSeek) أو Partner، واستورد المحادثات السابقة، وشغّل رفاق IM دائمين على نفس الدماغ.
- **معرفة متعددة المحركات** — مكتبات RAG مُصدَّرة عبر LlamaIndex وPageIndex وGraphRAG وLightRAG، أو LightRAG Server عن بُعد، أو قاعدة معرفة WeKnora ذاتية الاستضافة، أو مكتبة Tencent IMA أو MarginNote 4، أو أرشيف Kiwix ZIM متصل، أو مخزن Obsidian مرتبط، مع تحليل مستندات قابل للتوصيل. راجع [نماذج أدوار LightRAG الأصلية](../../deeptutor/services/rag/pipelines/lightrag/README.md) لإعدادات مستقلة للاستخراج والاستعلام والرؤية، والإنشاء بالنماذج الافتراضية فقط، وإعادة البناء بعد التأكيد.
- **أدوات ومهارات قابلة للتوسيع** — أدوات مدمجة وخوادم MCP وتطبيقات CLI ونماذج توليد الصور/الفيديو/الصوت ومهارات مجتمع قابلة للتثبيت من EduHub.
- **ذاكرة قابلة للتدقيق** — تجعل آثار L1 وملخصات أسطح L2 وتركيب L3 التخصيص مرئياً وقابلاً للتحرير؛ ويربط Memory Graph حقائق L2 بأدلة L1 وتركيب L3 بالأسطح المساهمة.

---

## 🚀 البدء

### دع وكيلك يُعِدّ DeepTutor

انسخ هذا الطلب إلى وكيل الذكاء الاصطناعي الذي يمكنه استخدام الطرفية (مثل Codex أو Claude Code):

```text
Help me install and configure DeepTutor locally from https://github.com/HKUDS/DeepTutor.
Clone the repository, or reuse my existing checkout, and read SKILL.md and
docs-for-user/AGENT_SETUP.md first. Follow that guide to prepare the environment,
configure my model provider, verify the setup, and start the Web app.
Ask me for any missing provider, model, or credential-source information;
do not print API keys. Preserve my existing files and settings, and finish
with the access URL and the results of your checks.
```

يغطي [دليل إعداد الوكيل](../../docs-for-user/AGENT_SETUP.md) التدفق كاملاً، بما فيه التهيئة غير التفاعلية عبر CLI. لتثبيته بنفسك، اختر أحد المسارات أدناه.

يأتي DeepTutor بأربعة مسارات تثبيت. وكلها تشترك في تخطيط واحد لمساحة عمل وقت التشغيل: تعيش الإعدادات الخاصة في `data/user/settings/` تحت الدليل الذي تُطلق منه التطبيق (أو تحت `DEEPTUTOR_HOME` / `deeptutor start --home` إذا حددت واحداً صراحةً). للتطبيق الكامل، التدفق الموصى به هو **اختر دليل مساحة عمل وقت التشغيل → تثبيت → `deeptutor init` → `deeptutor start`**.

### تجربة Docker بأمر واحد

إذا لم يكن Docker مثبتاً بعد، [ثبّت Docker](https://docs.docker.com/get-docker/) أولاً. ثم جرّب التطبيق الكامل دون إعداد Python أو Node.js:

```bash
docker run --rm --name deeptutor \
  -p 127.0.0.1:3782:3782 \
  -v deeptutor-data:/app/data \
  ghcr.io/hkuds/deeptutor:latest
```

افتح [http://127.0.0.1:3782](http://127.0.0.1:3782)، وهيّئ مزودي النماذج في **الإعدادات ← المزودون**، واضغط `Ctrl+C` عند الانتهاء. تحتفظ وحدة التخزين المسماة `deeptutor-data` بالإعدادات والبيانات المحلية للتشغيل التالي.

### مساحة عمل المحتوى

**مساحة عمل المحتوى** منفصلة عن مساحة عمل DeepTutor الخاصة لوقت التشغيل. إنها المجلد الذي يمكن للوكلاء قراءته، وتوضع الملفات المُولَّدة تحت `outputs/<capability>/<session>/<turn>/`. تعزل مساحات العمل المخصصة المحادثات والمواد التعليمية والتقدم والذاكرات المؤقتة في شجرة خاصة `.deeptutor/data/` لا تستطيع أدوات الملفات تصفحها. وتبقى الإعدادات وبيانات الاعتماد وMemory مشتركة على مستوى الحساب.

بدون تهيئة، تكون مساحة عمل المحتوى هي `<runtime-home>/data/user/workspace`. يمكن للتثبيتات المحلية من PyPI وCLI والمصدر اختيار المجلدات في **الإعدادات ← مساحات العمل**؛ واضبط المجلد الافتراضي باستخدام:

```bash
deeptutor workspace show
deeptutor workspace set /absolute/path/to/my-folder
deeptutor workspace reset
```

تفحص القدرات مساحة العمل المحددة لها من خلال أدوات مساحة العمل المدمجة. لا يتلقى النموذج سوى مسارات نسبية مثل `outputs/...`؛ وعندما يستخدم `workspace_present`، تُصيِّر الواجهة لقطة مصادَق عليها وقابلة للفتح. يعمل المسار النسبي الدقيق نفسه أيضاً في رابط أو صورة Markdown عادية. تغيير الملف المصدر لاحقاً لا يغيّر لقطة قُدِّمت مسبقاً.

يدير فضاء التعلم مكتبة الموارد. في **الإعدادات ← مساحات العمل**، عيّن المهارات وخدمات MCP وقواعد المعرفة لكل مساحة عمل، أو احتفظ بقواعد الوصول الحالية. تحتفظ مساحات العمل الموجودة بصلاحيات وصولها الحالية حتى يُحفظ الاختيار. تشير التعيينات إلى الموارد الأصلية دون نسخ بيانات الاعتماد أو فهارس المعرفة؛ ويمكن للمهارات الخاصة بمساحة عمل أن تتجاوز النسخ المشتركة. راجع [تعيين موارد مساحات العمل](../../docs-for-user/workspaces.md).

التنفيذ للقراءة فقط خارج `outputs/`. نسخ ملف مُولَّد إلى مكان آخر في مساحة عمل المحتوى يتطلب تأكيد **السماح مرة واحدة** الصريح لذلك المصدر والوجهة المحددين تماماً. يفرض صندوق أمان النظام أو مُشغِّل Docker هذا الحد عند توفره؛ ويظهر الرجوع إلى العملية الفرعية المقيَّدة محلياً كـ **أفضل جهد ممكن** في إعدادات مساحة العمل.

<details>
<summary><b>الخيار 1 — التثبيت من PyPI</b> · تطبيق ويب محلي كامل + CLI، لا يلزم الاستنساخ</summary>

تطبيق ويب محلي كامل + CLI، لا يلزم الاستنساخ. يحتاج **Python 3.11–3.14** وبيئة تشغيل **Node.js 20+** في PATH (يُشغَّل خادم Next.js المستقل المُحزَّم بواسطة `deeptutor start`).

```bash
mkdir -p my-deeptutor && cd my-deeptutor
pip install -U deeptutor
deeptutor init     # prompts for ports + LLM provider + optional embedding/search
deeptutor start    # starts backend + frontend; keep the terminal open
```

يطلب `deeptutor init` منفذ الخلفية (افتراضي `8001`)، ومنفذ الواجهة الأمامية (افتراضي `3782`)، ومزود LLM / عنوان URL الأساسي / مفتاح API / النموذج، ومزود تضمين اختياري لقاعدة المعرفة / RAG، ومزود بحث اختياري لـ Web Search.

بعد `deeptutor start`، افتح عنوان URL للواجهة الأمامية المطبوع في الطرفية — افتراضياً [http://127.0.0.1:3782](http://127.0.0.1:3782). اضغط `Ctrl+C` في تلك الطرفية لإيقاف الخلفية والواجهة الأمامية معاً. تخطي `deeptutor init` لا بأس به للتجربة السريعة؛ يُقلع التطبيق بالمنافذ الافتراضية وإعدادات نموذج فارغة، قم بتهيئتها لاحقاً في **الإعدادات ← المزودون** و**نماذج اللغة**.

**تفريغ صوت ميكروفون المتصفح:** ترسل موائمات STT المتوافقة مع OpenAI صوت المتصفح إلى المزود دون تحويل محلي. تحوّل موائمات STT الأصلية لـ DashScope وVolcengine صوت المتصفح من WebM/Opus إلى WAV بتردد 16 kHz، وتتطلب ملفاً تنفيذياً لـ `ffmpeg` على `PATH` الخاص بـ DeepTutor. يتجاوز ملف WAV القياسي أحادي القناة بترميز PCM وتردد 16 kHz هذا التحويل. عند تثبيت إصدار PyPI على Windows واستخدام أيٍّ من الموائمين الأصليين، ثبّت FFmpeg، وأضف دليل `bin` الخاص به إلى `PATH` للخدمة، ثم أعد تشغيل DeepTutor. تظهر حالات فشل التحويل أسفل حقل إدخال المحادثة.

</details>

<details>
<summary><b>الخيار 2 — التثبيت من المصدر</b> · للتطوير مقابل نسخة مسحوبة</summary>

للتطوير مقابل نسخة مسحوبة. استخدم **Python 3.11–3.14** و**Node.js 22 LTS** لمطابقة CI وDocker.

```bash
git clone https://github.com/HKUDS/DeepTutor.git
cd DeepTutor

# Create a venv (macOS/Linux). Windows PowerShell:
#   py -3.11 -m venv .venv ; .\.venv\Scripts\Activate.ps1
python3 -m venv .venv && source .venv/bin/activate
python -m pip install --upgrade pip

# Install backend + frontend deps
python -m pip install -e .
( cd web && npm ci --legacy-peer-deps )

deeptutor init
deeptutor start --dev
```

يبني أمر `deeptutor start` واجهة `web/` المحلية للإنتاج مرة واحدة ويعيد استخدامها؛ بينما يشغّل `--dev` تطبيق Next.js مع إعادة التحميل الفوري للوحدات (HMR). تخطيط التهيئة، والمنافذ، والإيقاف بـ `Ctrl+C` يطابق الخيار 1.

<details>
<summary><b>بيئة Conda</b> (بديلاً عن <code>venv</code>)</summary>

```bash
conda create -n deeptutor python=3.11
conda activate deeptutor
python -m pip install --upgrade pip
```

</details>

<details>
<summary><b>إضافات التثبيت الاختيارية</b> — محركات RAG / dev / partners / matrix / math-animator</summary>

```bash
pip install -e ".[rag-lightrag]"    # Built-in LightRAG engine (exact supported SDK)
pip install -e ".[graphrag]"        # Microsoft GraphRAG engine (Python 3.11–3.13)
pip install -e ".[dev]"             # tests/lint tools
pip install -e ".[partners]"        # Partner IM channel SDKs
pip install -e ".[video-learning]"  # compatibility extra; captions ship in the full/CLI installs
pip install -e ".[matrix]"          # Matrix channel without E2EE/libolm
pip install -e ".[matrix-e2e]"      # Matrix E2EE; requires libolm
pip install -e ".[math-animator]"   # Manim addon; requires LaTeX/ffmpeg/system libs
```

</details>

<details>
<summary><b>تعديلات تبعيات الواجهة الأمامية وحل مشاكل خادم التطوير</b></summary>

**تغيير تبعيات الواجهة الأمامية:** شغّل `npm install --legacy-peer-deps` لتحديث `web/package-lock.json`، ثم ارفع كلاً من `web/package.json` و`web/package-lock.json`.

**خادم تطوير متوقف:** إذا أبلغ `deeptutor start --dev` عن واجهة أمامية موجودة لا تستجيب، أوقف الـ PID الذي يطبعه. إذا لم يكن هناك أي عملية Next.js تعمل فعلياً، فملفات القفل قديمة — احذفها وأعد المحاولة:

```bash
rm -f web/.next/dev/lock web/.next/lock
deeptutor start --dev
```

</details>

</details>

<details>
<summary><b>الخيار 3 — Docker</b> · حاوية واحدة مكتفية بذاتها</summary>

حاوية واحدة لتطبيق الويب الكامل. الصور على GitHub Container Registry:

- `ghcr.io/hkuds/deeptutor:latest` — أحدث إصدار مستقر
- `ghcr.io/hkuds/deeptutor:<version>` — الإصدار المحدد بدقة من دون `v` في البداية (مثلاً `:1.6.3`)؛ لا تحصل الإصدارات الأولية إلا على وسم إصدارها

> راجع [CONTAINERIZATION.md](../../docs-for-user/CONTAINERIZATION.md) لعمليات نشر podman/rootless/read-only-rootfs والدليل الكامل لكل تثبيت.

```bash
docker run --rm --name deeptutor \
  -p 127.0.0.1:3782:3782 \
  -v deeptutor-data:/app/data \
  ghcr.io/hkuds/deeptutor:latest
```

لاختيار مجلد محتوى مضيف عند بدء تشغيل الحاوية، ثبّته على مسار الحاوية الثابت واحبس DeepTutor على ذلك المسار:

```bash
mkdir -p "$PWD/deeptutor-workspace/outputs"
docker run --rm --name deeptutor \
  -p 127.0.0.1:3782:3782 \
  -v deeptutor-data:/app/data \
  -v "$PWD/deeptutor-workspace:/workspace" \
  -e DEEPTUTOR_WORKSPACE_ROOT=/workspace \
  -e DEEPTUTOR_WORKSPACE_ALLOWED_ROOTS=/workspace \
  ghcr.io/hkuds/deeptutor:latest
```

بالنسبة إلى Compose، اضبط `DEEPTUTOR_WORKSPACE_HOST=/absolute/host/folder` قبل تشغيل `python scripts/docker_compose.py up -d`. وعند إغفاله يُستخدَم `./data/user/workspace`. تُختار مسارات Docker عند بدء التشغيل، ولذلك تظهر مقفلة في صفحة إعدادات الويب.

> **يكفي نشر `3782` فقط.** يتحدث المتصفح حصرياً إلى أصل الواجهة الأمامية؛ يقوم وسيط Next.js (`web/proxy.ts`) بإعادة توجيه `/api/*` و`/ws/*` إلى خلفية FastAPI **داخل الحاوية**. نشر `8001` (`-p 127.0.0.1:8001:8001`) اختياري — مفيد فقط لاستدعاء واجهة برمجة التطبيقات مباشرةً باستخدام curl أو نصوص.

افتح [http://127.0.0.1:3782](http://127.0.0.1:3782). تُنشئ الحاوية `/app/data/user/settings/*.json` عند الإقلاع الأول؛ قم بتهيئة مزودي النماذج من صفحة إعدادات الويب. تبقى التهيئة ومفاتيح API والسجلات ومساحة عمل المحتوى الافتراضية والذاكرة وقواعد المعرفة في وحدة تخزين `deeptutor-data`. أما مساحة عمل المحتوى المثبَّتة بشكل منفصل فتستمر في مسار مضيفها بدلاً من ذلك. الإضافات الاختيارية تنتمي إلى بيئة النشر، لا إلى جلسة طرفية عابرة: اضبط `DEEPTUTOR_EXTRAS` (و`DEEPTUTOR_APT_PACKAGES` لمكتبات النظام) وستعيد كل حاوية تُشغَّل انطلاقاً منها تطبيقها تلقائياً، في حين أن أمر `docker exec … pip install` سيُفقَد عند `compose down` التالي.

- **منافذ مضيف مختلفة:** غيّر الجانب الأيسر من كل تعيين `-p host:container` (مثلاً `-p 127.0.0.1:8088:3782`). إذا غيّرت المنافذ على جانب الحاوية في `/app/data/user/settings/system.json`، أعد التشغيل وحدّث الجانب الأيمن من كل تعيين ليطابق ذلك.
- **وضع المنفصل:** أضف `-d`، ثم `docker logs -f deeptutor` للمتابعة، و`docker stop deeptutor` للإيقاف، و`docker rm deeptutor` قبل إعادة استخدام الاسم. تحتفظ وحدة تخزين `deeptutor-data` ببيانات وقت التشغيل الخاصة ومساحة عمل المحتوى الافتراضية عبر عمليات إعادة التشغيل؛ أما مساحة عمل المحتوى المثبَّتة بشكل منفصل فتستمر في مسار مضيفها.

**Docker عن بُعد / وكيل عكسي:** يتحدث المتصفح فقط إلى أصل الواجهة الأمامية (`:3782`)؛ يقوم وسيط Next.js داخل الحاوية بإعادة توجيه `/api/*` و`/ws/*` إلى خادم الخلفية من جانب الخادم. في حالة الحاوية الواحدة الشائعة لا تهيّئ قاعدة API على الإطلاق — فقط وجّه وكيلك العكسي / منهي TLS إلى `:3782`. تحتاج قاعدة API فقط لـ **النشر المنفصل** (الخلفية في حاوية/مضيف منفصل): اضبط `next_public_api_base` في `data/user/settings/system.json` على عنوان الشبكة الداخلية الذي يستخدمه خادم الواجهة الأمامية للوصول إلى الخلفية (يُقرأ من جانب الخادم، ولا يُرسَل أبداً إلى المتصفح).

```json
{
  "next_public_api_base": "http://backend:8001"
}
```

يُقبَل `next_public_api_base_external` (واسمه المستعار `public_api_base`) كبدائل ذات أولوية أقل. يستخدم CORS **منشآت** الواجهة الأمامية، وليس عناوين URL لواجهة برمجة التطبيقات. مع تعطيل المصادقة، يسمح DeepTutor بمنشآت متصفح HTTP/HTTPS العادية افتراضياً. مع تفعيل المصادقة، أضف منشآت الواجهة الأمامية الدقيقة:

```json
{
  "cors_origins": ["https://deeptutor.example.com"]
}
```

<details>
<summary><b>الاتصال بـ Ollama / LM Studio / llama.cpp / vLLM / Lemonade على المضيف</b></summary>

داخل Docker، يشير `localhost` إلى الحاوية نفسها، وليس جهازك المضيف. للوصول إلى خدمة نموذج تعمل على المضيف، استخدم بوابة المضيف (موصى بها):

```bash
docker run --rm --name deeptutor \
  -p 127.0.0.1:3782:3782 -p 127.0.0.1:8001:8001 \
  --add-host=host.docker.internal:host-gateway \
  -v deeptutor-data:/app/data \
  ghcr.io/hkuds/deeptutor:latest
```

ثم في **الإعدادات ← المزودون**، وجّه عنوان URL الأساسي للمزود إلى `host.docker.internal`:

- Ollama LLM: `http://host.docker.internal:11434/v1`
- Ollama embedding: `http://host.docker.internal:11434/api/embed`
- LM Studio: `http://host.docker.internal:1234/v1`
- llama.cpp: `http://host.docker.internal:8080/v1`
- Lemonade: `http://host.docker.internal:13305/api/v1`

عادةً ما يحل Docker Desktop (macOS/Windows) `host.docker.internal` بدون `--add-host`. على Linux، يُعدّ هذا العلم الطريقة المحمولة لإنشاء هذا الاسم المضيف على Docker Engine الحديث.

**بديل Linux — شبكة المضيف:** أضف `--network=host` وأزل علامات `-p`. تشارك الحاوية شبكة المضيف مباشرةً، لذا افتح [http://127.0.0.1:3782](http://127.0.0.1:3782) (أو `frontend_port` في `system.json`)، ويمكن الوصول إلى خدمات المضيف بعناوين URL العادية لـ localhost مثل `http://127.0.0.1:11434/v1`. لاحظ أن شبكة المضيف تكشف منافذ الحاوية مباشرةً على المضيف وقد تتعارض مع الخدمات الموجودة — للإبقاء عليها على loopback، اضبط `BACKEND_HOST=127.0.0.1` و`FRONTEND_HOST=127.0.0.1` (راجع [CONTAINERIZATION.md](../../docs-for-user/CONTAINERIZATION.md)).

</details>

</details>

<details>
<summary><b>الخيار 4 — واجهة سطر الأوامر فقط</b> · بدون واجهة ويب، من نسخة مسحوبة</summary>

عندما لا تحتاج إلى واجهة مستخدم الويب. يُثبَّت حزمة CLI فقط من نسخة مسحوبة من المصدر، وليس من PyPI.

```bash
git clone https://github.com/HKUDS/DeepTutor.git
cd DeepTutor

# Create a venv (macOS/Linux). Windows PowerShell:
#   py -3.11 -m venv .venv-cli ; .\.venv-cli\Scripts\Activate.ps1
python3 -m venv .venv-cli && source .venv-cli/bin/activate
python -m pip install --upgrade pip

python -m pip install -e ./packaging/deeptutor-cli
deeptutor init --cli
deeptutor chat
```

يشارك `deeptutor init --cli` نفس تخطيط `data/user/settings/` مع التطبيق الكامل، لكنه يتخطى موجهات منفذ الخلفية/الواجهة الأمامية. ولا يزال يتيح محددي Embedding وSearch (اختر **Skip** عندما لا تحتاج إليهما)، ويكتب ملفات وقت التشغيل الأساسية (`system.json`، `auth.json`، `integrations.json`، `interface.json`، `model_catalog.json`، `main.yaml`، `agents.yaml`)، ويطلب مزود LLM النشط والنموذج.

<details>
<summary><b>الأوامر الشائعة</b></summary>

```bash
deeptutor chat                                          # interactive REPL
deeptutor chat --capability deep_solve --tool rag --kb my-kb
deeptutor run chat "Explain Fourier transform"
deeptutor run deep_solve "Solve x^2 = 4" --tool rag --kb my-kb
deeptutor kb create my-kb --doc textbook.pdf
deeptutor memory show
deeptutor config show
```

</details>

لا يشحن تثبيت `deeptutor-cli` المحلي بأصول الويب أو تبعيات الخادم. احتفظ بالنسخة المسحوبة من المصدر — يشير التثبيت القابل للتحرير إليها. لإضافة تطبيق الويب لاحقاً، ثبّت حزمة PyPI (الخيار 1) وشغّل `deeptutor init` + `deeptutor start` من نفس مساحة العمل.

</details>

<details>
<summary><b>صندوق أمان تنفيذ الرمز (مهارات المكتب)</b> · تشغيل الرمز المُولَّد بالنموذج لـ docx / pdf / pptx / xlsx</summary>

مهارات المكتب المدمجة — **docx / pdf / pptx / xlsx** — تعمل عن طريق جعل النموذج يكتب برنامج Python قصير (`python-docx`، `reportlab`، `openpyxl`، ...)، وتشغيله عبر أداة `exec` الوحيدة، وتقديم الملف المحفوظ في مساحة العمل. تُثبَّت هذه الأدوات عندما تكون خلفية صندوق الأمان نشطة. ويختار DeepTutor أقوى خلفية مهيأة بالترتيب التالي:

- **Runner sidecar:** يوجّه `DEEPTUTOR_SANDBOX_RUNNER_URL` التنفيذ إلى الخدمة المحصنة والأدنى امتيازاً التي يوفرها `Dockerfile.runner`.
- **Linux bubblewrap:** عند توفر `bwrap`، فإنه يعزل العملية والملفات.
- **الرجوع إلى عملية فرعية مقيّدة:** لا تستخدم التثبيتات المحلية وتثبيتات الحاوية الواحدة هذا الخيار إلا عند السماح به؛ وتظل الحاوية تحت Docker حد عزل إضافياً.

يتحكم إعداد `sandbox_allow_subprocess` في `data/user/settings/system.json` (افتراضي `true`) في خيار الرجوع الأخير فقط. اضبطه على `false` (أو صدّر `DEEPTUTOR_SANDBOX_ALLOW_SUBPROCESS=0`) لرفض تنفيذ العمليات الفرعية عند عدم توفر خلفية runner أو `bwrap`؛ ولا يؤدي ذلك إلى تعطيل الخلفيات الأقوى.

</details>

<details>
<summary><b>مرجع التهيئة</b> — ملفات التهيئة تحت <code>data/user/settings/</code> (JSON/YAML)</summary>

كل شيء تحت `data/user/settings/` هو JSON/YAML عادي. صفحة **الإعدادات** هي المحرر الموصى به؛ وتُحفظ تسجيلات مساحات العمل بشكل منفصل في `data/user/.runtime/workspaces.sqlite3`.

| الملف | الغرض |
|:---|:---|
| `model_catalog.json` | اتصالات المزودين، إضافة إلى ملفات تعريف LLM والمهام والتضمين والبحث وTTS وSTT والصور والفيديو، وبيانات الاعتماد والاختيارات النشطة |
| `system.json` | منافذ الخلفية/الواجهة الأمامية، وقاعدة API العامة، وCORS، والتحقق من SSL، ودليل المرفقات وحدود الرفع/الاستخراج |
| `auth.json` | تبديل مصادقة اختياري، واسم مستخدم، وتجزئة كلمة مرور، وإعدادات الرمز/الكوكي |
| `integrations.json` | إعدادات تكامل PocketBase والمرافق الاختيارية |
| `interface.json` | تفضيلات لغة واجهة المستخدم ولغة مخرجات النموذج / الثيمة / الشريط الجانبي |
| `document_parsing.json` | اختيار محرك التحليل ونموذج وصف الصور ونقاط النهاية البعيدة والخيارات الخاصة بكل محرك |
| `video_learning.json` | مزود ترجمات YouTube، وأصول Invidious والوصول إلى الحساب، وإعدادات النصوص المفرّغة |
| `main.yaml` | افتراضيات سلوك وقت التشغيل وحقن المسار |
| `agents.yaml` | إعدادات درجة حرارة القدرة/الأداة والرمز |

تُرشَّح مراجع Web Search افتراضياً: لا تظهر سوى عناوين URL عامة من `http`/`https` لا تتضمن بيانات اعتماد مضمنة أو منافذ غير معتادة. ويمكن لعمليات النشر إضافة سياسة نطاقات تركّز على التعليم في `data/user/settings/system.json`:

```json
{
  "web_search_source_filtering": {
    "enabled": true,
    "blocked_domains": ["spam.example"],
    "trusted_domains": ["edu.cn", "arxiv.org"]
  }
}
```

عندما لا تكون `trusted_domains` فارغة، تقتصر المراجع على تلك النطاقات ونطاقاتها الفرعية؛ وتكون الأولوية دائماً لـ `blocked_domains`.

ملف `.env` في جذر المشروع **لا يُقرأ** كملف تهيئة للتطبيق. للإعداد الأدنى للنموذج، احفظ عنوان URL أساسياً ومفتاح API في **الإعدادات ← المزودون**، ثم أضف نموذج LLM وحدّده في **نماذج اللغة**. أضف ملف تعريف التضمين فقط إذا كنت تخطط لاستخدام ميزات قاعدة المعرفة / RAG.

لاستخدام API Route، اختر **API Route** في **الإعدادات ← المزودون** وأدخل مفتاح API Route. يستخدم الإعداد المسبق `https://global.api-route.com/v1`؛ ثم أضف نموذجاً باستخدام معرّف نموذج API Route الخاص به في **نماذج اللغة**. راجع [دليل البدء السريع لـ API Route](https://www.api-route.com/docs/quickstart) لإعداد المفتاح والنموذج.

تعرض ملفات تعريف LLM وملفات تعريف نماذج المهام إعداد **تنسيق API** عندما يدعم مزودها الاختيار. أبقِ `Auto` للتوجيه والرجوع العاديين، أو اختر `OpenAI Chat Completions` أو `OpenAI Responses` أو `Anthropic Messages`؛ ويظل وضع Responses الإجباري مغلقاً عند الفشل. الحقل المحفوظ هو `api_format` (`auto` أو `openai_chat` أو `openai_responses` أو `anthropic`)؛ و`wire_api` حالة توافق مشتقة. وتغطي إعدادات التجاوز `Auto` / `Supported` / `Not supported` الخاصة بكل نموذج استدعاء الأدوات وإدخال الصور وإخراج JSON وعناصر التحكم في الاستدلال.

</details>

<details>
<summary><b>إلغاء التثبيت والتنظيف</b></summary>

يفصل DeepTutor بين شيفرته المثبَّتة، ومساحة عمله الخاصة لوقت التشغيل، ومساحة عمل المحتوى الاختيارية. افتراضياً، تكون مساحة عمل وقت التشغيل هي الدليل الذي تشغّل فيه `deeptutor init` / `deeptutor start`؛ ويمكن لـ `--home PATH` أو `DEEPTUTOR_HOME` تجاوز ذلك. حالة التطبيق الخاصة هي دليل `data` داخل تلك المساحة، ولذلك يحدد سطر لافتة بدء التشغيل الذي يبدأ بـ `Workspace:` ذلك الموقع الخاص بوقت التشغيل. إذا كانت **الإعدادات ← مساحة العمل** تشير إلى مجلد آخر، فانسخ احتياطياً أو أزل ذلك المجلد المحتوى بشكل منفصل؛ فهو لا يُمحى عمداً عند إلغاء تثبيت DeepTutor.

1. أوقف التطبيق. اضغط `Ctrl+C` في الطرفية التي تشغّل `deeptutor start`، أو شغّل `deeptutor stop [--home PATH]` إذا بدأ المُشغِّل باستخدام `--detach`؛ وأوقف أي Partner قيد التشغيل وأي حاويات Docker منفصلة قبل حذف البيانات.
2. أزل بيانات وقت التشغيل فقط إذا كنت تريد أيضاً محو كل الحالة المحلية. يشمل ذلك الإعدادات ومفاتيح API، وتاريخ المحادثة، والجلسات، وMemory، وNotebooks، وBooks، وحالة Reading، وSkills، وحالة Partners، والسجلات، وKnowledge Bases، وذاكرات التحليل المؤقتة، والمخرجات المُولَّدة، وذاكرة وقت تشغيل الواجهة الأمامية المحزّمة.

   انسخ أولاً مسار `Workspace:` الدقيق من لافتة بدء التشغيل وتحقق من أن مجلد `data` التابع له هو دليل بيانات DeepTutor المقصود. أنشئ نسخة احتياطية إذا كان من المحتمل أن تحتاج إلى أي شيء لاحقاً، ثم انقل ذلك الدليل المحدد إلى سلة المهملات/المحذوفات في نظام التشغيل. لا تشغّل أمراً للحذف التكراري على مسار نسبي أو متغير بيئة غير محلول.

3. أزل الحزمة المثبَّتة. استخدم الأمر المطابق للتوزيع:

   ```bash
   python -m pip uninstall deeptutor
   python -m pip uninstall deeptutor-cli
   ```

   إذا أُنشئت البيئة الافتراضية لـ DeepTutor وحده، فأزلها عبر مدير البيئات. في التثبيت من المصدر، عطّل البيئة، وغادر دليل المصدر، وشغّل `git status --short` داخل تلك النسخة المحددة. لا تنقل النسخة إلى سلة المهملات/المحذوفات إلا بعد التأكد من أنها لا تحتوي عملاً غير ذي صلة أو غير ملتزم به.

4. بالنسبة إلى مسار Docker، افحص الحاوية الدقيقة ووحدة التخزين المسماة قبل إزالتهما. تؤدي إزالة وحدة التخزين إلى محو البيانات التي يديرها Docker نهائياً:

   ```bash
   docker ps -a --filter name=^/deeptutor$
   docker volume inspect deeptutor-data
   docker rm -f deeptutor
   docker volume rm deeptutor-data
   ```

</details>

## 📖 استكشاف DeepTutor

ابدأ بالأسطح الرئيسية التي ستستخدمها يومياً: Chat وPartners وMy Agents وCo-Writer وBook ومركز المعرفة وفضاء التعلم والذاكرة والإعدادات. ثم تغطي الجولة عمليات النشر متعددة المستخدمين لمساحات العمل المشتركة المعزولة.

إذا فقدت إجابة قيداً سابقاً، أو استشهدت بدليل ضعيف، أو خالفت المادة المحددة، فاجمع بيانات التشخيص في [`REASONING_SAFETY_CHECKLIST.md`](../../docs-for-user/REASONING_SAFETY_CHECKLIST.md) قبل فتح مشكلة.

<div align="center">
<img src="../../assets/figs/web-1.6.5/OVERVIEW.png" alt="الصفحة الرئيسية لـ DeepTutor — مساحة عمل Chat مع كل الأسطح في الشريط الجانبي" width="900">
</div>

> **حالة لقطات الشاشة:** الصورة العامة محدثة لـ v1.6.5. لقطات الواجهات أدناه لا تزال مراجع من v1.4.6 أثناء تحديثها. استخدمها لفهم سير العمل، لا كملاحة دقيقة للواجهة الحالية.

<details>
<summary><b>🏗️ معمارية النظام</b></summary>

<div align="center">
<img src="../../assets/figs/system/system%20architecture.png" alt="معمارية نظام DeepTutor" width="900">
</div>

</details>

<details>
<summary><b>💬 Chat — حلقة الوكيل التي تستخدمها فعلاً</b></summary>

Chat هي القدرة الافتراضية والمكان الذي يبدأ فيه معظم العمل. يمكن لخيط واحد أن يتحدث عادياً، ويستدعي الأدوات، ويرتكز على قواعد المعرفة المحددة، ويقرأ المرفقات، ويولّد الصور، ويستشير الوكلاء الفرعيين، ويكتب سجلات دفتر الملاحظات، ويستمر بنفس السياق عبر الأدوار.

<div align="center">
<img src="../../assets/figs/web-1.4.6+/home/00-overview.png" alt="مساحة عمل محادثة DeepTutor" width="900">
</div>

الحلقة بسيطة عمداً: يفكر النموذج في جولات، ويستدعي الأدوات عند الحاجة، ويلاحظ النتائج، وينتهي برسالة خالية من الأدوات. `ask_user` خاص — بدلاً من التخمين، يمكن للوكيل إيقاف الدور مؤقتاً، وطرح سؤال توضيحي منظَّم، والاستئناف بمجرد إجابتك.

<div align="center">
<img src="../../assets/figs/system/chat-agent-loop.png" alt="حلقة وكيل محادثة DeepTutor" width="900">
</div>

الأدوات القابلة للتبديل من قِبَل المستخدم هي `brainstorm` و`web_search` و`paper_search` و`zotero_search` و`reason` و`geogebra_analysis` — بالإضافة إلى `imagegen` و`videogen` بمجرد تهيئة نموذج التوليد المطابق. الأدوات السياقية مثل `rag` و`kb_files` و`knowledge_frontier` و`read_source` و`read_memory` و`write_memory` و`read_skill` و`load_tools` و`exec` و`web_fetch` و`ask_user` و`list_notebook` و`write_note` و`question_bank` و`github` و`consult_subagent` و`workspace_list` و`workspace_read` و`workspace_search` و`workspace_present` و`workspace_export` تُثبَّت تلقائياً عندما يكون للدور السياق الصحيح.

يأتي السياق في نوعين: يستمر **السياق الثابت للجلسة** (القدرة، ومساحة العمل أو الدورة، والأدوات، وقواعد المعرفة، والشخصية، والنموذج، وحالة Reading / Mastery) عبر الأدوار؛ وتأتي **المراجع لمرة واحدة** (الملفات وتاريخ المحادثة والكتب وأقسام القراءة ودفاتر الملاحظات ومدخلات بنك الأسئلة المحددة والوكلاء المستوردون) من قائمة `+` لدور واحد. ولا يفعل زر الصوت سوى تفريغ الرسالة الحالية نصياً.

تُبقي الصفحة الرئيسية **Chat** و**Ask Questions** و**Quiz** و**Visualize** على بُعد نقرة واحدة؛ وتقع **Research** للتقارير المستشهَد بها و**Solve** للاستدلال المشروح تحت *المزيد من القدرات*. يجمع **التعلم المخصص** كلاً من Book و**Mastery Path** و**Immersive Reading** و**التدريب**؛ وتجمع Reading المستندات والفيديو والصوت مع استشهادات موثَّقة وملاحظات محفوظة وقراءة طبيعية بصوت عالٍ من مقاطع المصدر / إجراءات الإرشاد الدراسي / المفردات / الاختبار / الترجمة، والتقاط إلى دفتر الملاحظات، بينما يحتفظ Course Study بسياقه المرتبط بالدورة.

</details>

<details>
<summary><b>🤝 Partner — رفاق دائمون على نفس الدماغ</b></summary>

<div align="center">
<img src="../../assets/figs/web-1.4.6+/partners/00-partners%20overview.png" alt="مساحة عمل شركاء DeepTutor" width="900">
</div>

الشركاء هم رفاق دائمون بروحهم الخاصة وسياسة النموذج ومكتبتهم وذاكرتهم وقنواتهم. إنهم ليسوا محرك بوت منفصلاً: كل رسالة ويب أو IM واردة تصبح دوراً عادياً لـ `ChatOrchestrator` داخل مساحة عمل محدودة بنطاق الشريك. الشريك هو "محادثة لها شخصية ورقم هاتف".

<div align="center">
<img src="../../assets/figs/system/partners-architecture.png" alt="معمارية شركاء DeepTutor" width="900">
</div>

لكل شريك `SOUL.md` واختيار نموذج وقنوات وسياسة أدوات ومكتبة مخصصة. تنسخ مكتبته قواعد المعرفة والمهارات ودفاتر الملاحظات إلى `data/partners/<id>/workspace/`، أو تبقى مرتبطة بملفات مساحة عمل موجودة ومواردها؛ وتظل هوية الشريك ومحادثاته وذاكرة Partner منفصلة. يحتفظ المستخدمون غير المشرفين الذين تمت مصادقتهم بجلسات Partner وذاكرة علاقة خاصة، بينما يقرأ Partner ذاكرتهم الشخصية للقراءة فقط؛ وتستخدم حركة مرور المشرفين والمجموعات وغير المرتبطة نطاق Partner المشترك.

<div align="center">
<img src="../../assets/figs/web-1.4.6+/partners/02-IM%20config%20for%20each%20partner.png" alt="إعداد قناة IM لكل شريك" width="900">
</div>

طبقة القناة مدفوعة بالمخطط ويمكنها الاتصال بمنصات IM مثل Feishu وTelegram وSlack وDiscord وDingTalk وQQ/NapCat وWeCom وWhatsApp وZulip وMattermost وMatrix وMochat وMicrosoft Teams بناءً على الإضافات المثبتة والبيانات الاعتمادية المهيأة. يمكن أيضاً توصيل الشريك كوكيل فرعي واستشارته من دور محادثة عادي — راجع **My Agents** أدناه.

لإعداد أسرع، يمكن لصفحة قناة الشريك إنشاء تطبيق Feishu/Lark أو بوت WeCom AI، أو تسجيل دخول حساب WeChat شخصي، من خلال مسح رمز QR يُرسَم في المتصفح بدلاً من سجل الخادم. يكتشف Feishu/Lark نطاق الحساب ويحفظ المستخدم الذي أجرى المسح كمُرسِل مسموح به أولي. يحتفظ WeCom بقائمة سماح موجودة، وإلا فإنه يفترض افتراضياً جميع المستخدمين القادرين على الوصول إلى البوت، مع تحذير وصول مفتوح ظاهر؛ وتبقى استمارات القناة اليدوية متاحة إذا تغيّر بروتوكول المسح الخاص بأحد المزودين.

</details>

<details>
<summary><b>🧑‍🚀 My Agents — استشارة واستيراد الوكلاء الآخرين</b></summary>

<div align="center">
<img src="../../assets/figs/web-1.4.6+/myagents/00-overview.png" alt="مساحة عمل My Agents في DeepTutor" width="900">
</div>

يحوّل My Agents الوكلاء الآخرين إلى سياق لـ DeepTutor، ويقوم بشيئين متمايزين. **توصيل وكيل مباشر** — Claude Code أو Codex أو Grok CLI أو Antigravity أو Kimi أو opencode أو MiMo Code أو Hermes Agent أو OpenClaw أو DeepSeek Harness على جهازك، أو بوابة Hermes بعيدة، أو أحد Partners لديك — واستشارته من داخل دور محادثة: DeepTutor *يشغّل* الوكيل الآخر فعلاً ويبث عمله إلى لوحة Activity عبر أداة `consult_subagent`. اختره وحدّد له الحد الأقصى للجولات باستخدام شريحة Agent، أو صفِّ قائمة الوكلاء المتصلين نفسها باستخدام `@`؛ ويبقى اختيارك مرتبطاً بالجلسة.

**توصيل Grok CLI.** ثبّت Grok CLI الخاص بـ xAI على الجهاز الذي يشغّل خلفية DeepTutor، وشغّل `grok login` هناك، وتحقق من أن `grok --help` يسرد `--output-format streaming-json`. ثم افتح **My Agents ← Connect**، واختر **Grok CLI**، وحدّد دليل عمل. يفحص الاكتشاف دعم البروتوكول في الملف التنفيذي؛ ولا يتحقق من تسجيل الدخول أو الوصول إلى النموذج. جُرِّب الموصِّل مع Grok CLI الإصدار 1.0.3؛ والأوامر الأخرى من جهات خارجية غير ذات صلة والمسماة أيضاً `grok` غير مدعومة.

في **الإعدادات ← الشركاء والوكلاء ← Grok CLI**، اترك النموذج وجهد الاستدلال فارغين لاستخدام افتراضيات CLI، أو أدخل قيماً يدعمها ناتج `grok models` الخاص بحسابك. تُمرَّر تعليمات النظام عبر `--rules`. وضع الصلاحيات الافتراضي هو `dontAsk`: يستخدم Grok قواعده الحالية ومعالجته المدمجة للقراءة فقط، ويرفض العمليات التي تحتاج موافقة. هذه سياسة صلاحيات لـ CLI، وليست صندوق أمان لنظام الملفات. يمكن اختيار أوضاع أوسع صراحةً في الإعدادات؛ وتبقى أعلام CLI المتقدمة متاحة عبر `backends.grok.extra_args` في واجهة برمجة إعدادات الوكيل الفرعي.

يستخدم Grok مصادقته وتخزين جلسته الخاصين؛ ولا ينسخ DeepTutor بيانات اعتماده. تستأنف الاستشارات اللاحقة جلسة الاتصال نفسها في دليل العمل نفسه. يُبث النص ونشاط الأدوات مباشرة؛ وتُحذَف حمولات التفكير الخاصة. تُعطَّل ذاكرة Grok عبر الجلسات افتراضياً. يدعم هذا الموصِّل الأسئلة النصية وأدوات CLI، لا إعادة توجيه الصور أو استيراد محادثات Grok السابقة. في Docker، ثبّت Grok وصادِق عليه داخل حاوية الخلفية؛ فـ CLI المثبَّت فقط على جهاز المتصفح لا يمكن الوصول إليه.

<div align="center">
<img src="../../assets/figs/web-1.4.6+/home/08-subagent%20demo%20with%20claude%20code.png" alt="استشارة وكيل Claude Code الفرعي مباشرةً" width="900">
</div>

**استيراد المحادثات السابقة** — أحضر تاريخ ChatGPT وClaude Code وCodex الموجود لديك كمحادثات قابلة للبحث والاستئناف. اختر ملف `conversations.json` من تصدير بيانات ChatGPT رسمي لاستيراد لقطة آمنة ومتكافئة القوة (idempotent)، أو اختر تاريخ Claude حسب المشروع / دليل العمل، أو اختر تاريخ Codex حسب تاريخ التقويم. يبقى الوكلاء المستندون إلى مجلد قابلين للتحديث بحيث يمكن للنطاق المحدد أن يسحب محادثات جديدة. ارجع إلى إحداها من دور Chat عبر `+` ← My Agents، وسيقرأها DeepTutor كنصوص محادثة لطرف ثالث — تبقى *محادثتهم*، وليس صوت DeepTutor الخاص.

</details>

<details>
<summary><b>✍️ Co-Writer — صياغة Markdown واعية بالتحديد</b></summary>

<div align="center">
<img src="../../assets/figs/web-1.4.6+/co-writer/00-overview.png" alt="مساحة عمل Co-Writer في DeepTutor" width="900">
</div>

Co-Writer هو مساحة عمل Markdown ذات عرض مقسَّم للتقارير والدروس التعليمية والملاحظات والقطع التعليمية الطويلة. تحفظ المستندات تلقائياً وتُظهر معاينة مباشرة (رياضيات KaTeX وأسوار الرسم البياني)، ويمكن حفظها مرة أخرى في دفاتر الملاحظات عندما تصبح المسودة سياقاً قابلاً لإعادة الاستخدام. استورد ملف `.docx` لبدء مسودة جديدة، وصَدِّر المحرر الحالي كـ Markdown أو Word.

<div align="center">
<img src="../../assets/figs/web-1.4.6+/co-writer/01-edit%20panel.png" alt="محرر Co-Writer مع معاينة مباشرة" width="900">
</div>

الفكرة المحورية هي **التحرير الجراحي**: حدد نطاقاً واطلب من DeepTutor إعادة كتابته أو توسيعه أو تقصيره. اختر نموذج التحرير؛ ويمكنه استخدام قاعدة معرفة أو أدلة من الويب، ويحتفظ بأثر استدعاءات أدواته. وإذا لم تتغير المسودة أثناء عمله، تستبدل النتيجة النص المحدد مباشرةً وتظل قابلة للعكس باستخدام **Undo**.

</details>

<details>
<summary><b>📖 Book — كتب حية من موادك</b></summary>

<div align="center">
<img src="../../assets/figs/web-1.4.6+/book/00-book_overview.png" alt="مكتبة كتب DeepTutor" width="900">
</div>

يحوّل Book المصادر المحددة إلى **كتاب حي** تفاعلي — ليس PDF ثابتاً، بل بيئة قراءة مبنية من كتل مكتوبة. يمكن أن يبدأ الكتاب من قواعد المعرفة أو دفاتر الملاحظات أو بنوك الأسئلة أو تاريخ المحادثة؛ يقترح تدفق الإنشاء هيكل فصل قبل توليد المحتوى، لذا تراجع الشكل بدلاً من قبول مخرجات عشوائية.

<p align="center">
<img src="../../assets/figs/web-1.4.6+/book/01-book-demo-quiz%20card.png" alt="كتلة اختبار في الكتاب" width="31%">
&nbsp;
<img src="../../assets/figs/web-1.4.6+/book/02-book-demo-manim%20video.png" alt="كتلة رسوم متحركة Manim في الكتاب" width="31%">
&nbsp;
<img src="../../assets/figs/web-1.4.6+/book/03-book-demo%20interactive%20module.png" alt="كتلة ودجت تفاعلية في الكتاب" width="31%">
</p>

يُجمِّع كل فصل إلى كتل ذات أنواع محددة وقابلة للتحرير — نصوص وتنبيهات واختبارات وبطاقات فلاش وجداول زمنية ورمز وأشكال وHTML تفاعلية ورسوم متحركة وأشكال مفاهيم وغوص عميق وملاحظات مستخدم — وله Page Chat الخاصة به. أدرج كتلة أو حرّكها أو أعد توليدها أو كتابتها أو غيّر نوعها؛ وتدخل المقاطع المحددة إلى صندوق وارد لمقتطفات التعلّم يمكن مراجعته. يبقى التقدّم والإشارات المرجعية ومحاولات الاختبار ومقتطفات التعلّم وPage Chat خاصاً بكل قارئ، حتى عندما يشارك المشرف كتاباً للقراءة فقط أو للتحرير التعاوني؛ ويظل حذف الكتب المشتركة مقصوراً على المشرف. يمكن تصدير أي كتاب إلى Markdown، وتتوقف عمليات التجميع الطويلة مؤقتاً وتُستأنف، ويكشف `deeptutor book health` / `refresh-fingerprints` عن انجراف المصادر.

</details>

<details>
<summary><b>📚 مركز المعرفة — مكتبات RAG متعددة المحركات</b></summary>

<div align="center">
<img src="../../assets/figs/web-1.4.6+/knowledge/00-overview.png" alt="مركز المعرفة في DeepTutor" width="900">
</div>

قواعد المعرفة هي مجموعات المستندات وراء RAG — إنها ترسّخ أدوار Chat وتحرير Co-Writer وتوليد Book ومحادثات Partner. ما يميزها هو **اختيار محرك الاسترجاع**: **LlamaIndex** (الافتراضي، مزيج من المتجهات + BM25 مع إعادة ترتيب اختيارية بمرمّز متقاطع وفهارس FAISS من نوع exact-flat أو HNSW)، **PageIndex** (استرجاع تفكيري مع استشهادات على مستوى الصفحة، مستضاف أو مفتوح المصدر ذاتي الاستضافة)، **GraphRAG** و**LightRAG** (استرجاع قائم على الرسم البياني المعرفي)، **LightRAG Server** (استرجاع مُحال إلى نسخة LightRAG خارجية تتصل بها عبر HTTP)، **WeKnora** (استرجاع من قاعدة معرفة في نشرك ذاتي الاستضافة، بلا فهرس محلي أو نسخة من المستند)، **Tencent IMA** (مكتبة تنظّمها ضمن IMA — يُبحث فيها ويُتصفَّح ويُكتَب إليها عبر OpenAPI الخاصة بها)، **MarginNote 4** (بيانات دراستك في MN4 — المستندات والمقتطفات وبطاقات الخريطة الذهنية والروابط بينها — التي تدفعها إضافة (Add-on) التطبيق ويتم التنقل فيها بأدوات مخصصة)، **Kiwix** (أرشيف ZIM قابل للبحث يُقدَّم عبر HTTP دون فهرسة محلية)، أو مخزن **Obsidian** مرتبط يقرأ المدرس ويكتب فيه في مكانه. كل قاعدة معرفة مرتبطة بمحرك واحد.

<div align="center">
<img src="../../assets/figs/web-1.4.6+/knowledge/01-create%20knowledge%20base.png" alt="إنشاء قاعدة معرفة" width="900">
</div>

هل تنقل مكتبة Obsidian أو Hermes أو Markdown موجودة؟ راجع [دليل نقل المعرفة](../../docs-for-user/KNOWLEDGE_MIGRATION.md) لمساري المخزن المتصل والنسخة المفهرسة.

عند إنشاء قاعدة معرفة، يمكنك **إنشاء جديدة** (تحميل المستندات وفهرستها)، أو **ربط موجودة** (إعادة استخدام فهرس في مكانه)، أو **توصيل Kiwix** (البحث عند الطلب في أرشيف ZIM واحد يقدّمه خادم). اختر مساحة عمل التخزين عند الإنشاء؛ ويمكن نقل قاعدة معرفة موجودة بين مساحات العمل بعد معاينة، مع الاحتفاظ بالتعيينات والمراجع المحفوظة. يمكن لقاعدة المعرفة أيضاً تتبُّع **مستودعات GitHub** (المستودع والفرع ونمط glob) أو **عناوين URL لمواقع التوثيق** (مع حدود لعمق الزحف وعدد الصفحات، وتُعاد مزامنتها كل 24 ساعة افتراضياً)؛ تقارن المزامنة تجزئات المحتوى لتحديد ما أُضيف أو تغيّر أو أُزيل، كي تبقى الوثائق التي تتابعها محدَّثة دون إعادة رفع، وتلتقط **المجلدات المرتبطة** الملفات المحلية الجديدة أو المتغيرة عند المزامنة. تكتب إعادة الفهرسة دليل `version-N` مسطحاً جديداً وتحتفظ بالسابقة، لذا لا يُدمَّر فهرس عامل أبداً أثناء إعادة البناء. يمكن إزالة مستند واحد حتى من قاعدة في حالة **خطأ** — إسقاط ملف فشل تحليله بدون حذف وإعادة بناء كاملين. يُختار تحليل المستندات — نص فقط أو MinerU أو Docling أو Tika أو markitdown أو PyMuPDF4LLM أو LiteParse — ونموذج اختياري لوصف الصور في **الإعدادات ← المعرفة والمستندات**، مع إيقاف تنزيلات النماذج المحلية افتراضياً. يمكن لـ Docling أيضاً العمل في وضع **بعيد** مقابل خادم Docling Serve (بلا حاجة إلى تثبيت محلي أو نماذج)، يُهيَّأ في الصفحة نفسها (`mode=remote`، وعنوان URL أساسي للخادم، ومفتاح API اختياري) أو متغيرات البيئة `DOCLING_MODE` / `DOCLING_API_BASE_URL` / `DOCLING_API_TOKEN`. أما Tika فهو بعيد فقط ويشير إلى خادم Apache Tika المهيَّأ في تلك الصفحة. تعكس واجهة CLI دورة الحياة عبر `list/info/create/connect-kiwix/add/search/eval/eval-diff/set-default/delete`، وأوامر إضافة المصادر وإزالتها، و`list-sources`، و`sync`.

يُثبَّت محرك LightRAG المدمج عبر `pip install 'deeptutor[rag-lightrag]'`. تحتوي هذه الإضافة على SDK الخاص بـ LightRAG المدعوم لكنها لا تُثبِّت MinerU. اختر MinerU بشكل مستقل في تحليل المستندات، وإما هيّئ وضعه السحابي أو ثبّت واجهة سطر أوامره المحلية الحالية عندما تحتاج إلى تحليل منظَّم. يقبل MinerU ملفات PDF والصور النقطية الشائعة وDOCX وPPTX وXLSX؛ ويظل الأمر القديم `magic-pdf` مقصوراً على PDF. لا يتطلب وضع النص فقط ومحركات التحليل الأخرى MinerU.

يتطلب استعلام LightRAG الأصلي والفهرسة التزايدية تهيئة التضمين المسجَّلة في الفهرس المنشور، بما يشمل النموذج والبُعد وهوية نقطة النهاية. إذا تغيّرت، فاستعد التهيئة الأصلية أو أعد البناء باستخدام التضمين الحالي؛ والفهارس التي لا تحمل هوية تضمين مسجَّلة تتطلب إعادة البناء. تعرض صفحات تفاصيل قاعدة المعرفة وإصدارات الفهرس إرشادات التعافي، بينما تبقى الملفات متاحة للعرض والتنزيل.

**تقييم قاعدة المعرفة.** مع توفر عدة محركات، يصبح سؤال «أيها يسترجع أفضل النتائج هنا؟» سؤالاً تجريبياً — ولذلك يجيب عنه `deeptutor kb eval`. اكتب مجموعة أسئلة وأجوبة (كائن JSON واحد في كل سطر: `query` مع مقاطع `gold` التي ينبغي أن يُرجعها الاسترجاع المثالي)، ثم قيّم قاعدة المعرفة باستخدام `deeptutor kb eval <name> --dataset qa.jsonl --top-k 5 [--mode hybrid] [--save baseline.json]`. يُجرى الاسترجاع لكل حالة عبر المسار نفسه الذي يستخدمه دور المحادثة، وتُطابَق استشهاداتها المرتّبة مع المقاطع المرجعية باستخدام النص المطابق تماماً أو التداخل اللفظي (يمكن ضبط العتبات عبر `--min-ratio`؛ ولا يُقيَّم التكافؤ الدلالي)، ويُبلّغ التشغيل عن **Recall@k / Precision@k / nDCG@k / MRR / MAP / Hit@k**. المقاييس دوال خالصة على الترتيب؛ ولا يحكم أي نموذج على المخرجات. قارن التقارير المحفوظة باستخدام `deeptutor kb eval-diff baseline.json candidate.json` لمعرفة التغيّرات لكل مقياس ولكل حالة. استخدم `--rewrite off` أو `--rewrite standalone` مع `kb eval` لمقارنة الاستعلامات الأصلية والمعاد صياغتها؛ وتحتفظ التقارير بسجلّ إعادة الصياغة. الحالات التي يفشل بحثها (فهرس مفقود أو بيانات اعتماد غير صالحة) لا تحصل على درجة وتُعرض منفصلة بدلاً من خفض المتوسطات. يستخدم PageIndex الاستدلال للاسترجاع ولا يُرجع مقاطع مرتّبة، ولذلك يُستثنى.

```jsonl
{"query": "Why do transformers scale attention?", "gold": ["Scaling keeps the dot products from growing with the dimension."]}
```

</details>

<details>
<summary><b>🌐 فضاء التعلم — المهارات والشخصيات والسياق القابل لإعادة الاستخدام</b></summary>

<div align="center">
<img src="../../assets/figs/web-1.4.6+/learning-space/00-overview.png" alt="مركز فضاء التعلم في DeepTutor" width="900">
</div>

فضاء التعلم هو طبقة المكتبة والتنظيم والتخصيص. تضم **المحادثات والمواد** سجل Chat ودفاتر الملاحظات بسجلات قابلة للنقل وتصدير إلى Markdown، وبنك أسئلة مع الإجابات والشروح. ابدأ **التدريب** من مجموعة أسئلة محددة في بنك الأسئلة أو من التعلم المخصص لجلسات المراجعة وتتبع الأخطاء والتكرار المجدول. أما **التخصيص** فيضم الشخصيات والمهارات (أدلة `SKILL.md`) و**خدمات MCP** التي تُثبَّت بنقرة واحدة و**تطبيقات CLI** من كتالوج [CLI-Anything](https://github.com/HKUDS/CLI-Anything)، ولكل تطبيق دليل استخدام يُحمَّل عند الطلب. وتجمع مساحة **دوراتي** المنفصلة محادثات المواد ومحادثات المدرّسين؛ ولا يُتاح كل أصل إلا في سير العمل التي تدعمه.

<div align="center">
<img src="../../assets/figs/web-1.4.6+/learning-space/07-%20download%20skills%20from%20eduhub.png" alt="استيراد مهارات من EduHub" width="900">
</div>

لا يجب عليك كتابة كل مهارة بنفسك — **الاستيراد من EduHub** يتصفح الكتالوج المجتمعي ويُنزّل المهارة مباشرةً إلى مكتبتك من خلال بوابة أمان (راجع [النظام البيئي](#-النظام-البيئي--eduhub-ومجتمع-المهارات)).

</details>

<details>
<summary><b>🧠 Memory — تخصيص قابل للتدقيق</b></summary>

<div align="center">
<img src="../../assets/figs/web-1.4.6+/memory/00-overview.png" alt="نظرة عامة على ذاكرة DeepTutor" width="900">
</div>

الذاكرة نظام ثلاثي الطبقات مدعوم بالملفات يمكنك قراءته وتنظيمه ومراجعته — وهو عمداً *ليس* مخزناً مخفياً للمتجهات. **L1** هو مرآة مساحة العمل بالإضافة إلى آثار أحداث تراكمية فقط (`trace/<surface>/<date>.jsonl`)؛ **L2** هو حقائق منظَّمة لكل سطح (`L2/<surface>.md`) مع مراجع إلى كيانات L1؛ و**L3** هو تركيب عبر الأسطح (`L3/<profile|recent|scope|preferences>.md`) يسجل أسطح L2 المساهمة فيه.

<div align="center">
<img src="../../assets/figs/web-1.4.6+/memory/01-3%20layer%20memory%20graph.png" alt="رسم بياني لذاكرة DeepTutor" width="900">
</div>

يُظهر Memory Graph الهرم بأكمله — تركيب L3 في المركز وL2 في الحلقة الوسطى وآثار L1 في الخارج — مع حواف أدلة دقيقة تربط حقائق L2 بأدلة L1، وروابط تصل تركيب L3 بالأسطح المساهمة. تُتتبع الذاكرة عبر أسطح `chat` و`notebook` و`quiz` و`kb` و`book` والشريك و`cowriter`؛ وتُضبط ميزانيات تحديث الموحّد / تدقيقه / إلغاء تكراره في **الإعدادات ← الذاكرة**.

</details>

<details>
<summary><b>⚙️ الإعدادات — لوحة تحكم واحدة</b></summary>

<div align="center">
<img src="../../assets/figs/web-1.4.6+/settings/00-setting%20overview.png" alt="مركز إعدادات DeepTutor" width="900">
</div>

الإعدادات هي لوحة التحكم التشغيلية، وتُفتح على صفحة **عام** لضبط لغة الواجهة ومخرجات النموذج. يربط شريط التنقل القابل للبحث صفحات مستقلة: تضم **شخصي** مساحات العمل ونقل البيانات والمظهر وإحصاءات الاستخدام؛ وتضم **التعلم والمحادثة** نقاط الانطلاق والمرفقات وVideo Learning وعناصر تحكم المتعلم وولي الأمر وتقدّم التعلّم والذاكرة؛ وتضم **النماذج والخدمات** المزودين ونماذج اللغة ونماذج المهام والتضمين والبحث والصوت والتوليد متعدد الوسائط؛ وتضم **الميزات والتكاملات** الأدوات ومعاملات القدرات والشركاء والوكلاء والمعرفة والمستندات. يضم **النظام** الشبكة وحالة التشغيل وحول؛ وتتيح **المحادثات المؤرشفة** البحث في المحادثات المؤرشفة واستعادتها أو حذفها نهائياً. تحتوي حالة التشغيل على سلامة الخلفية والذاكرة المقيمة ومصفوفة **جاهزية** (Readiness) التي تقيّم عوائق القدرات وتحذيراتها واقتراحاتها. تفصل مساحات العمل ملفات المواضيع وحالة التعلم، مع نقل موثَّق وتصدير ضمن نقل البيانات. يحتفظ **المزود** بعنوان مقدم الخدمة وبيانات اعتماده لتعيد نماذج خدماته استخدامها؛ وتختار صفحات النماذج مزودين محفوظين وتضبط أسماء النماذج وقدراتها. تُثبّت **نماذج المهام** نموذجاً صغيراً وسريعاً للأعمال الخلفية — تسمية المحادثات وكتابة نقاط الانطلاق — وتستخدم النموذج الافتراضي النشط عند تركها فارغة. يجمع الصوت توليد الكلام وتفريغه؛ ويجمع التوليد متعدد الوسائط نماذج الصور والفيديو. تضبط صفحة الشركاء والوكلاء المُشغِّلات المحلية وبوابة Hermes بعيدة.

**الكلام عبر Xiaomi MiMo.** أضف مزود Xiaomi MiMo بعنوان `https://api.xiaomimimo.com/v1` ومفتاح API الخاص به، ثم أضف `mimo-v2.5-tts` ضمن الإعدادات ← الصوت. اختر صوتاً مسبقاً مثل `mimo_default` أو `冰糖` أو `苏打`، واستخدم إخراج `wav` أو `pcm16`، وجرّبه قبل تطبيقه. تتحكم تعليمات الصوت في الأسلوب وسرعة الكلام. يدعم هذا الموائم الكلام بالأصوات المسبقة فقط؛ ويتطلب تصميم الأصوات واستنساخها نماذج منفصلة ولا يدعمهما. إذا كان نموذج MiMo صوتي قديم مهيّأً عبر الموائم العام المتوافق مع OpenAI، فأعد إنشاء مدخل الكلام باستخدام مزود Xiaomi MiMo كي يستخدم بروتوكول chat-completions. راجع [دليل MiMo الرسمي لتوليد الكلام](https://mimo.mi.com/docs/zh-CN/quick-start/usage-guide/audio/speech-synthesis-v2.5).

**الكلام عبر MiniMax** — في الإعدادات ← الصوت، اختر MiniMax لتحويل النص إلى كلام وحدّد `speech-2.8-hd`. هيّئ مفتاح API لـ MiniMax واختر صراحةً صوتاً من أصوات النظام أو أدخل معرّف صوت مخصص. عنوان API الأساسي الافتراضي هو `https://api.minimax.io/v1`؛ ولمنطقة الصين استخدم `https://api.minimaxi.com/v1`. تستخدم القراءة بصوت عالٍ ومعاينات الصوت نقطة نهاية الكلام الأصلية، مع إخراج MP3 أو WAV أو FLAC أو PCM، وعناصر تحكم في معدل أخذ العينات والسرعة واللغة. راجع [واجهة API للكلام في MiniMax](https://platform.minimax.io/docs/api-reference/speech-t2a-http) لمعرّفات الأصوات وتوفرها للحساب.


**Video Learning** ضمن الإعدادات ← التعلم والمحادثة يهيّئ ترجمات YouTube والوصول إلى Invidious لاستخدامهما في Reading. لاستخدام Invidious، اضبط أصل API الخلفية الذي يديره المشرف (مثلاً `http://127.0.0.1:3000`) والأصل العام الذي يمكن للمتصفح الوصول إليه، واختبر الاتصال، واختر Invidious، ثم احفظ. يبحث **تصفّح Invidious** في مربع حوار إضافة المواد في Reading عن مقاطع الفيديو ويتيح الوصول إلى الاشتراكات وقوائم التشغيل المتصلة. يستخدم تشغيل YouTube المشغّل الرسمي المعزَّز للخصوصية؛ ويظل غياب الترجمات ظاهراً ويحدّ من الأدلة المتاحة للمدرّس دون تعطيل التشغيل الأصلي. ثبّت `.[video-learning]` لاستخدام مُحمِّل ترجمات YouTube الافتراضي. تنتقل روابط Watching الموجودة إلى Reading مع الحفاظ على سجل المحادثة والنصوص المفرّغة المتوافقة والملاحظات والتقدّم؛ وتصبح الملاحظات الزمنية الجديدة تعليقات Reading التوضيحية. يستخدم Bilibili مساره الخاص للتشغيل والترجمات.

<div align="center">
<img src="../../assets/figs/web-1.4.6+/settings/01-appearance%20settings.png" alt="إعدادات المظهر والثيمات في DeepTutor" width="900">
</div>

تستخدم معظم الأقسام تدفق صياغة-وتطبيق، لذا يمكنك اختبار مزود قبل الالتزام به. يمكنك أيضاً أن تطلب ذلك ببساطة في Chat: يقرأ المساعد التهيئة الحالية، ويطبّق التغيير، ويخبرك إن كان يحتاج إلى إعادة تشغيل أو إعادة فهرسة — مع اختبار النموذج الجديد قبل الالتزام به، بحيث لا يمكنه تبديل نفسه إلى شيء يتعذّر الوصول إليه. مفاتيح API لا تمرّ أبداً عبر النموذج، الذي يفتح لك بدلاً من ذلك الاستمارة المطابقة. تشحن أربع ثيمات في الصندوق — Default وCream وDark وGlass. ملفات `.env` في جذر المشروع تُتجاهل عمداً؛ تعيش تهيئة وقت التشغيل تحت `data/user/settings/*.json` إلا إذا وجّه `DEEPTUTOR_HOME` أو `deeptutor start --home` التطبيق في مكان آخر.

**OpenAI Codex OAuth (تجريبي).** إضافة **OpenAI Codex** ضمن **الإعدادات ← المزودون** تفتح تسجيل دخول عبر المتصفح يعمل مقابل خطة ChatGPT الخاصة بك، لذا لا حاجة إلى `OPENAI_API_KEY`. تعيش الرموز (tokens) فقط في `data/system/user-secrets/<owner>/private/openai-codex/` — في نشر Compose متعدد الحاويات، خارج كل شجرة يمكن لصندوق أمان التنفيذ الوصول إليها — ولا يقرأ DeepTutor أو يعدّل أبداً تسجيل دخولك إلى CLI في `~/.codex`. تأتي قائمة النماذج من الكتالوج الحي لذلك الحساب؛ تسجيل الدخول ينشر الملف الشخصي لكنه لا يصبح النموذج النشط إلا عندما لا يكون هناك LLM مهيأ بعد. ولأن الرمز يخوّل خطة شخص واحد فقط، فالملف الشخصي غير قابل للمشاركة عبر منح المستخدمين — كل حساب يسجّل دخوله بنفسه، بما في ذلك المستخدمون العاديون: تظهر بطاقة تسجيل دخولهم ضمن **المزودون**، وتبقى النماذج الناتجة والكتالوج وتسجيل الخروج خاصة بذلك الحساب.

عند تسجيل الدخول وعند **تحديث النماذج**، يقرأ DeepTutor أحدث إصدار مستقر من `@openai/codex` من سجل npm الرسمي ويستخدمه كـ `client_version` في طلب الكتالوج. هذا بيانات وصفية فقط: لا يُثبِّت ولا يُنزِّل ولا يُحدِّث CLI الخاص بـ Codex، ولا يحمل طلب npm أي بيانات اعتماد OAuth. للاكتشاف حد زمني ثلاث ثوانٍ وحد أقصى لحجم الاستجابة 64 كيلوبايت. وإذا فشل، يستخدم DeepTutor آخر إصدار ناجح لذلك الحساب، أو خياره الاحتياطي المدمج عندما لا يوجد شيء مخزَّن مؤقتاً. لا يُحفَظ إصدار جديد إلا عند تحليل كتالوج حي بنجاح؛ ولا تُعاد أبداً استخدام أدوات التحقق عبر الإصدارات أو أجيال بيانات الاعتماد. يسمح رفض إصدار أو بنية كتالوج غير متوافقة بإعادة محاولة واحدة بالإصدار السابق؛ ولا تُعاد محاولة أعطال المصادقة أو حدود المعدل أو TLS باعتبارها مشاكل إصدار. يُبلِّغ التحديث اليدوي الفاشل عن خطأ بدلاً من تقديم كتالوج قديم مخزَّن مؤقتاً كأنه مُحدَّث.

يبقى سجل الإصدارات الناجحة قائماً عبر تجديد الرمز لنفس الحساب وأخطاء مصادقة الكتالوج، دون أن يعيد ذلك صلاحية بيانات نماذج أو ETags أُلغيت صلاحيتها. يمسح تسجيل الخروج الذاكرة المؤقتة المحلية لذلك الحساب، بما يشمل سجل الإصدارات. لا تستعلم قراءات الحالة العادية والاستدلال npm. لا تستبدل إدخالات الكتالوج الجديدة نموذجاً اخترته مسبقاً ولا تُعيد تشغيل جلسات التعلّم؛ وظهور نموذج في الكتالوج لا يثبت توافقاً كاملاً مع بروتوكول الاستدلال. لا يوجد مُحدِّث إصدار في الخلفية ولا إعداد إصدار يتحكم فيه المستخدم.

تستخدم عمليات نشر Docker وPodman المحلية الافتراضية شبكات loopback منفصلة وتحتاج إلى جسر مؤقت أثناء تسجيل الدخول. اتبع [دليل جسر OAuth المؤقت المحلي لـ Codex](../../docs-for-user/CONTAINERIZATION.md#temporary-local-codex-oauth-bridge) للاطلاع على أوامر Docker وCompose وPodman والإزالة الدقيقة.

في حالة النشر عن بُعد، يكون `localhost` الخاص بالمتصفح و`localhost` الخاص بالخادم جهازين مختلفين، لذا لا يستطيع وكيل عكسي عادي وحده نقل استدعاء (callback) localhost من المتصفح إلى الخادم. استخدم نفق SSH كجسر للاستدعاء. يصل النفق إلى منفذ الويب المنشور بالفعل؛ يعيد Next.js توجيه مسار الاستدعاء الدقيق فقط إلى وسيط الاستدعاء العام، ويتحقق الوسيط من `state` قبل التوجيه إلى عملية OAuth الأصلية. يبقى مستمع الاستدعاء على loopback الخلفية، والمنفذان `1455` و`1457` غير منشورين، ويدعم هذا المسار شبكة جسر Docker الافتراضية.

```bash
ssh -N -L 1455:127.0.0.1:3782 <ssh-user>@<server-host>
```

إذا أبلغ DeepTutor عن منفذ استدعاء احتياطي (fallback) `1457`، استخدم:

```bash
ssh -N -L 1457:127.0.0.1:3782 <ssh-user>@<server-host>
```

نفّذ الأمر الواحد المطابق لمنفذ الاستدعاء الفعلي فقط؛ لا تُشغّل كليهما أبداً. `3782` هو فقط منفذ الويب المثال: إنه منفذ الواجهة الأمامية/الحاوية المهيأ والمُبلَّغ عنه كـ `callback_forward_port`. لا تضمن هذه القيمة أن المنفذ نفسه يستمع على `127.0.0.1` الخاص بمضيف SSH. إذا نشر Docker أو Podman منفذ مضيف مختلفاً، أو استمع وكيل عكسي على منفذ مختلف، استبدل فقط منفذ الهدف الظاهر في الجهة اليمنى من الأمر (`3782` أعلاه) بمنفذ الويب الذي يستمع فعلياً على `127.0.0.1` الخاص بمضيف SSH؛ أبقِ منفذ الاستدعاء الظاهر في الجهة اليسرى كما هو، أي `1455` أو `1457`. `<server-host>` هو مضيف SSH الذي يملك loopback الذي يستضيف ذلك المنفذ المستمع. إذا كان عنوان URL في المتصفح يشير إلى وكيل عكسي أو موازن تحميل، استبدله بمضيف SSH الأمامي الصحيح.

تطبع واجهة سطر الأوامر (CLI) أمر النفق ثم تحاول فوراً فتح المتصفح. في حالة النشر عن بُعد، أبقِ صفحة التفويض مفتوحة دون إتمامها، أنشئ النفق المطبوع في طرفية أخرى، ثم تابع عملية التفويض بعد ذلك فقط.

لاكتشاف الطوبولوجيا عن بُعد حدٌّ يتعلق بـ localhost. إذا كان الوصول إلى الويب نفسه يتم عبر إعادة توجيه localhost من SSH أو من بيئة تطوير (IDE)، فلا يستطيع المتصفح معرفة أن الخادم بعيد. بالنسبة لعملية الويب الحالية، اترك صفحة تفويضها دون إنهاء، واقرأ `redirect_uri` في عنوان URL الخاص بالتفويض لتلك العملية لتحديد منفذ الاستدعاء `1455` أو `1457`، وأنشئ النفق الثاني من ذلك المنفذ المحلي إلى منفذ الويب الفعلي. بدلاً من ذلك، ألغِ عملية الويب تلك وابدأ عملية جديدة عبر CLI؛ إذ يخص ناتج CLI العملية الجديدة ويجب ألا يُستخدم لعملية الويب القائمة. تُبلَّغ أخطاء الحصة وفشل الكتالوج كما هي ولا تتراجع أبداً إلى مزود مدفوع. مسار التوافق هذا تجريبي: قد تتغيّر واجهة المصدر الأعلى (upstream).

</details>

<details>
<summary><b>👥 متعدد المستخدمين — النشر المشترك</b> · مصادقة اختيارية، مساحات عمل معزولة لكل مستخدم</summary>

المصادقة **معطلة افتراضياً** — يعمل DeepTutor لمستخدم واحد. فعّلها وشجرة `data/` واحدة تستضيف مساحة عمل المشرف ومساحات عمل معزولة لكل مستخدم ومساحات عمل الشريك جنباً إلى جنب:

```text
data/
├── user/                    # Admin workspace + global settings
├── users/<uid>/             # Per-user scope: chat history, memory, notebooks, KBs
├── partners/<id>/workspace/ # Partner (synthetic-user) scope
├── cli-apps/                # Installed CLI apps, mounted read-only into the sandbox
└── system/                  # auth · grants · audit · user-secrets/<owner> (OAuth tokens)
```

**أول مستخدم مسجَّل يصبح مشرفاً** ويمتلك كتالوجات النماذج وبيانات اعتماد المزود وقواعد المعرفة المشتركة والمهارات والكتب المشتركة المرجعية والمنح لكل مستخدم. يختار المستخدمون المحليون الذين ينشئهم المشرف Standard أو Learner أو Custom. يقيّد Learner قدرات التعلم وسياسة المواد، ويضيف ملفاً تكيفياً، ويدعم بيانات اعتماد أجهزة قابلة للإلغاء مع انتهاء صلاحية وحدود يومية؛ ويمكن لأولياء الأمور المصرَّح لهم عرض التقارير والموافقة على المواد وإعادة ضبط بيانات الاعتماد. يحصل المستخدمون الآخرون على مساحات عمل معزولة، إضافةً إلى نماذج وقواعد معرفة ومهارات وPartners ووصول إلى الكتب المشتركة ضمن نطاق محدد، من دون الحصول على مفاتيح API الخام. إذا كان `auth.json` يحتوي مسبقاً على `username` + `password_hash`، فإن ذلك الحساب هو المشرف: يظل `/register` مغلقاً، وتكون الحسابات المنشأة من `/admin/users` دائماً `role=user` إلى أن ترفع صلاحياتها.

**تفعيله:** فعّل المصادقة في `data/user/settings/auth.json`، وأعد تشغيل `deeptutor start`، وسجّل أول مشرف على `/register`، ثم أضف المستخدمين من `/admin/users` وعيّن النماذج وقواعد المعرفة والمهارات والـ Partners وسياسة الأداة/MCP/تطبيق CLI ووصول تنفيذ الرمز من خلال المنح؛ وهيّئ الكتب المشتركة من لوحة **الوصول إلى الكتب** لكل مستخدم.

بالنسبة إلى الأصول (origins) الخاصة/العامة المنفصلة، اضبط `auth.private_login_hosts` (أو `AUTH_PRIVATE_LOGIN_HOSTS`) على مضيفات الواجهة الأمامية الخاصة التي يجوز لها إظهار تسجيل الدخول بكلمة مرور والتسجيل. تُمرِّر الواجهة الأمامية رأس `Host` الوارد عبر HTTP إلى الخلفية كتأكيد لمضيف الواجهة الأمامية. حافظ على `Host` الخاص بالمتصفح عبر وكيلك العكسي، واجعل مدخل الشبكة العام يرفض الطلبات التي تسمّي مضيفاً خاصاً؛ ولا تكشف منفذ Next.js الخام الذي يقبل أي قيمة لـ `Host`. يمكن تزوير `Host` عبر HTTP من قِبَل عميل مباشر، فتفويض المضيف الخاص يعتمد على تلك الحدود عند المدخل. تقبل الخلفية تأكيدات مضيف الواجهة الأمامية فقط من loopback افتراضياً. إذا كانت الواجهة الأمامية للويب تتصل من حاوية أو مضيف آخر، اضبط `AUTH_TRUSTED_FRONTEND_PROXY_IPS` على عنوان IP الدقيق لوكيل الواجهة الأمامية ذلك في عملية الخلفية (مفصولة بفواصل لأكثر من عنوان واحد). أبقِ واجهة برمجة تطبيقات الخلفية خاصة بوكيل الواجهة الأمامية ولا تُضمِّن شبكات العملاء العامة في هذه القائمة. يُسمح بـ loopback دائماً؛ وعندما تكون القائمة غير فارغة، يمكن لمستخدم مصادَق عليه على أصل خاص أن يفتح **الملف الشخصي ← تسجيل دخول جهاز عام** وينشئ رابط إقران قصير العمر ومرتبط بالمضيف لأصل عام عبر HTTPS. تستبدل صفحة `/handoff` العامة الرمز التسجيلي لمرة واحدة بتذكرة JWE قصيرة العمر أيضاً في نص طلب POST، وتستهلك التذكرة مرة واحدة، وتستلم كوكي الجلسة العادي HttpOnly.

> يبقى PocketBase تكاملاً لمستخدم واحد — أبقِ `integrations.pocketbase_url` فارغاً لعمليات النشر متعددة المستخدمين إلا إذا وصلت مخزن مستخدم خارجي.

</details>

## ⌨️ واجهة سطر أوامر DeepTutor — الواجهة الأصيلة للوكلاء

ثنائي `deeptutor` واحد، طريقتان للدخول: **REPL** تفاعلي للأشخاص الذين يعيشون في الطرفية، و**JSON** منظَّم للوكلاء الأخرى التي تقود DeepTutor كأداة. نفس القدرات والأدوات وقواعد المعرفة في كلتا الحالتين.

<details>
<summary><b>قدّها بنفسك</b></summary>

يفتح `deeptutor chat` واجهة REPL تفاعلية ويختار وضعاً باستخدام `--capability`؛ بينما يأخذ `deeptutor run <capability> "<message>"` تلك القدرة كأول وسيطة موضعية ويخرج بعد دور واحد. ويقبل كلاهما `--tool` و`--kb` و`--config` و`--workspace` لاختيار مساحة عمل مسجلة.

```bash
deeptutor chat                                              # interactive REPL
deeptutor chat --capability deep_solve --kb my-kb --tool rag
deeptutor run chat "Explain the Fourier transform" --tool rag --kb textbook
deeptutor run chat "Find recent work beyond this material" --kb textbook --tool knowledge_frontier
deeptutor run deep_research "Survey 2026 papers on RAG" \
  --config mode=report --config depth=standard
```

تتوفر هنا أيضاً إدارة مساحة العمل الأساسية — قواعد المعرفة (`kb`)، والجلسات (`session`)، والشركاء (`partner`)، والمهارات (`skill`)، ودفاتر الملاحظات، والذاكرة، والتهيئة؛ بينما يظل تنظيم الدورات والجلسات في تطبيق الويب. القائمة الكاملة أدناه.

</details>

<details>
<summary><b>دع وكيلاً يقودها</b></summary>

DeepTutor مبنية لتكون *مُشغَّلة بواسطة وكيل آخر*. أضف `--format json` إلى أي `run` وكل دور يبث **NDJSON — حدث واحد في كل سطر** (`content` و`tool_call` و`tool_result` و`done` و...)، وكل سطر مُعنوَن بـ `session_id` الخاص به. التشغيلات آمنة بدون TTY: توقف `ask_user` بدون TTY يحل تلقائياً برد فارغ بدلاً من التعليق.

```bash
# One shot, machine-readable
deeptutor run deep_solve "Find d/dx[sin(x^2)]" --tool reason --format json

# Chain turns in one stateful session — capture the id, reuse it
SID=$(deeptutor run deep_research "Survey 2026 papers on RAG" \
  --config mode=report --config depth=standard --format json \
  | jq -r 'select(.type=="done").session_id')
deeptutor run deep_question "Quiz me on that survey" --session "$SID" --format json
```

يأتي المستودع بملف [`SKILL.md`](../../SKILL.md) في الجذر — وثيقة تسليم موجزة لواجهة CLI. اطلب من وكيلك قراءته صراحةً؛ ويغطي [دليل إعداد الوكيل](../../docs-for-user/AGENT_SETUP.md) التثبيت والتهيئة. يمكنك أيضاً تغليف `deeptutor run` كأداة في حلقة LangChain / AutoGen. الوصفات الكاملة: [Agent Handoff](https://deeptutor.info/docs/cli/agent-handoff/).

</details>

<details>
<summary><b>مرجع الأوامر</b></summary>

| الأمر | الوصف |
|:---|:---|
| `deeptutor init [--non-interactive] [--home PATH]` | تشغيل معالج الإعداد، أو إنشاء القيم الافتراضية الناقصة دون مطالبات |
| `deeptutor doctor [--online]` | التحقق مما إذا كان وقت التشغيل جاهزاً لبدء جلسة؛ `--online` يفحص أيضاً مزود النموذج المهيَّأ، و`--format json` يطبع التقرير |
| `deeptutor start [--home PATH] [--dev] [--detach] [--no-browser]` | تشغيل الخلفية + الواجهة الأمامية معاً؛ مع خيار العمل منفصلاً أو منع فتح المتصفح |
| `deeptutor stop [--home PATH]` | إيقاف مُشغِّل بدأ باستخدام `--detach` |
| `deeptutor serve [--port PORT]` | تشغيل خلفية FastAPI فقط |
| `deeptutor workspace show/set/reset` | فحص مساحة عمل المحتوى الخاصة بالمستخدم، أو اختيارها، أو استعادتها |
| `deeptutor run <capability> <message>` | تشغيل دور قدرة واحدة (`chat` و`ask_questions` و`deep_solve` و`deep_question` و`deep_research` و`visualize` و`math_animator` و`mastery_path` و`immersive_reading` و`course_study` و`audio_overview`)؛ أضف `--format json` لإخراج NDJSON |
| `deeptutor chat` | REPL تفاعلي مع تحكمات القدرة والأداة وقاعدة المعرفة ودفتر الملاحظات والتاريخ |
| `deeptutor partner list/create/start/stop` | إدارة الشركاء المتصلين بـ IM |
| `deeptutor kb list/info/create/connect-kiwix/add/search/eval/eval-diff/set-default/delete/list-sources/sync` | إدارة قواعد المعرفة، وتوصيل أرشيفات Kiwix، وتقييم عمليات الاسترجاع ومقارنتها، ومزامنة مصادر GitHub/الويب المسجَّلة (مع أوامر إضافة المصادر وإزالتها) |
| `deeptutor skill search/install/list/remove/login/logout/publish/update` | إدارة المهارات، التثبيت من المراكز، ونشر مهاراتك الخاصة (`eduhub:<slug>` افتراضياً، راجع النظام البيئي) |
| `deeptutor memory show/clear` | فحص مستندات الذاكرة L2/L3 أو مسح ذاكرة L1/الكل |
| `deeptutor session list/show/open/rename/delete` | إدارة الجلسات المشتركة |
| `deeptutor notebook list/create/show/add-md/replace-md/remove-record` | إدارة دفاتر الملاحظات من ملفات Markdown |
| `deeptutor book list/health/refresh-fingerprints` | فحص الكتب وتحديث بصمات المصادر |
| `deeptutor plugin list/info/state/search/show/install/approve/enable/disable/rollback/uninstall` | فحص الأدوات والقدرات؛ وإدارة حزم الإضافات التي خضعت للمراجعة والموافقات على أذوناتها |
| `deeptutor config show [--home PATH]` | عرض تهيئة وقت التشغيل الفعلية مع حجب بيانات الاعتماد |
| `deeptutor config providers` | سرد مزودي الإعداد المدعومين وقيمهم الافتراضية بصيغة JSON |
| `deeptutor config apply FILE [--check] [--home PATH]` | تطبيق إعداد JSON دون مطالبات، أو التحقق منه دون كتابة الإعدادات |
| `deeptutor provider login <provider>` | مصادقة المزود (`openai-codex` تسجيل دخول OAuth؛ `github-copilot` تسجيل دخول GitHub عبر الجهاز؛ `codebuddy` يتحقق من مصادقة CodeBuddy SDK ويبدأ تسجيل الدخول عند الحاجة) |

تخص بيانات اعتماد GitHub Copilot مالك DeepTutor المسجَّل دخوله، وتُحفَظ فقط في
`<runtime-home>/data/system/user-secrets/<owner-id>/private/github-copilot/credentials.v1.json`،
خارج مساحات عمل صندوق الأمان. يستخدم الشركاء العاملون عبر CLI أو بحساب المشرف بيانات اعتماد المشرف؛ ويسجّل المستخدمون الآخرون دخولهم بصورة منفصلة، ولا يمكن مشاركة ملفات تعريف Copilot عبر منح النماذج.
لا تُستورد ملفات رموز nanobot/Copilot الخارجية أبداً: بعد الترقية، شغّل
`deeptutor provider login github-copilot` مجدداً.

يتحقق تسجيل الدخول من الاستدلال باستخدام نموذج مكتشَف حالياً؛ ويتحقق `init` من النموذج المحدد ويتوقف عند الفشل دون حفظ مسودة التهيئة. نجاح مصادقة GitHub وحده لا يثبت إمكانية الوصول إلى نماذج Copilot (يُحتفَظ بتسجيل الدخول المحفوظ إذا فشل التحقق). تتبع طلبات وقت التشغيل نقطة نهاية API التي تعيدها عملية تبادل الرموز، بما في ذلك التجديدات، وتحترم بيانات نقطة النهاية الوصفية الخاصة بـ Responses/Chat Completions لكل نموذج.

يُطبَّق توافق Responses الخاص بـ Copilot عند إرسال الطلب دون إعادة كتابة السجل المحفوظ.

</details>

<details>
<summary><b>توزيع CLI فقط</b></summary>

حزمة CLI فقط تعيش في `packaging/deeptutor-cli`. في هذه النسخة، ثبّتها من المصدر:

```bash
python -m pip install -e ./packaging/deeptutor-cli
```

لم تُنشر على PyPI بعد، لذا يحتفظ قسم [البدء](#-البدء) الرئيسي بمسار التثبيت من المصدر.

</details>

## 🧩 النظام البيئي — EduHub ومجتمع المهارات

تستخدم مهارات DeepTutor تنسيق **Agent-Skills** المفتوح — مجلد يحتوي دليل `SKILL.md` (YAML frontmatter + Markdown) وملفات مرجعية اختيارية. لا شيء في ذلك خاص بـ DeepTutor، لذا أي سجل يتحدث التنسيق يصبح مصدراً لمكتبتك. يشحن DeepTutor مع **[EduHub](https://eduhub.deeptutor.info/)** — سجل المهارات المركّز على التعليم الخاص بنا — مُوصَّلاً كمركز افتراضي.

<details>
<summary><b>EduHub — النظام البيئي للمهارات في DeepTutor</b></summary>

[**EduHub**](https://eduhub.deeptutor.info/) هو المركز المجتمعي الذي أطلقه DeepTutor لمشاركة مهارات الوكيل الموجهة نحو التعليم — موجهو سقراط وبناة بطاقات الفلاش وتغذية راجعة للمقالات وخطط الامتحانات وشارحو المفاهيم وغيرها. مُدمَج في DeepTutor، لذا لا شيء يجب تهيئته: slug مجرد أو بادئة `eduhub:` تحل إليه.

**البحث والتثبيت** — في المتصفح، افتح **فضاء التعلم ← المهارات ← الاستيراد من EduHub** لتصفح الكتالوج وتنزيل مهارة مباشرةً إلى مكتبتك. من الطرفية:

```bash
deeptutor skill search "socratic tutor"               # search EduHub (the default hub)
deeptutor skill install socratic-tutor                # fetch → verify → register
deeptutor skill install eduhub:socratic-tutor@1.2.0   # pin a hub and a version
deeptutor skill list                                  # local skills with their hub provenance
```

**انشر مهارتك الخاصة** — حزّم `SKILL.md` وشاركها مع المجتمع:

```bash
deeptutor skill login                                 # browser sign-in to EduHub
deeptutor skill publish ./my-skill                    # interactive: pick a track + tags, then upload
deeptutor skill update                                # roll back or release a new version
```

EduHub هو أيضاً سجل مستقل متوافق مع ClawHub، لذا الوكلاء الذين ليسوا DeepTutor (Claude Code وCodex و...) يمكنهم استخدامه مباشرةً من خلال واجهة `eduhub` — `npx eduhub install socratic-tutor`.

</details>

<details>
<summary><b>بوابة أمان الاستيراد</b></summary>

مهما كان المصدر، كل استيراد يمر من **نفس بوابة الأمان** قبل أن يلمس أي شيء مساحة عملك:

- يُفحَص **حكم الأمان** للسجل أولاً — الحزم الموسومة ترفض إلا إذا مررت `--allow-unverified`؛
- تُستخرَج الأرشيفات بشكل دفاعي مع فحوص اجتياز المسار وعدد الإدخالات والحجم ونسبة الضغط واللاحقة والروابط الرمزية؛ وتُزال بتات التنفيذ، بينما تبقى الملفات بلا امتداد مسموحاً بها؛
- تُعيَّر الـ frontmatter إلى مخطط DeepTutor و`always:` **تُزال**، لذا مهارة محملة لا يمكنها أبداً إجبار نفسها في كل مطالبة نظام؛
- المصدر — المركز والإصدار والحكم ووقت التثبيت — يُكتب إلى `.hub-lock.json` للمراجعات والتحديثات.

في عمليات النشر متعددة المستخدمين، تصل عمليات الاستيراد من المتصفح إلى طبقة مهارات المستدعي المصادَق عليه، بينما تستهدف عمليات التثبيت من CLI ووحدة تحكم المشرف مساحة عمل المالك/المشرف؛ وتبقى مهارات المشرف مخفية وللقراءة فقط للمستخدمين العاديين إلى أن تُمنح لهم.

</details>

<details>
<summary><b>متوافق أيضاً مع ClawHub</b></summary>

لأن DeepTutor يتحدث تنسيق Agent-Skills المفتوح، **[ClawHub](https://clawhub.ai/)** يعمل كمصدر من الدرجة الأولى أيضاً — مُدمَج جنباً إلى جنب مع EduHub. اختره ببادئة المركز:

```bash
deeptutor skill search "git release notes" --hub clawhub
deeptutor skill install clawhub:git-release-notes@1.0.1
deeptutor skill install clawhub:udiedrichsen/stock-analysis
```

عندما يشترك عدة ناشرين في نفس الـ slug، يعرض البحث كل ناشر ومرجع تثبيت كامل النطاق (`clawhub:<ownerHandle>/<slug>`).

أضف المزيد من السجلات في `data/user/settings/skill_hubs.json`: إدخال `type: "clawhub"` يشير إلى أي HTTP API متوافق (EduHub وClawHub يتحدثانه كلاهما)، `type: "command"` يلفّ أي CLI جلب يشحنه السجل، و`"default"` يختار المركز المستخدم للـ slugs المجردة. كلها تُغذّي نفس بوابة الاستيراد.

</details>

## 🤝 شركاء المصادر المفتوحة

<p align="center">
  <a href="https://github.com/VectifyAI/PageIndex" target="_blank">
    <picture>
      <source media="(prefers-color-scheme: dark)" srcset="../../assets/figs/partners/pageindex-mark-dark.svg">
      <source media="(prefers-color-scheme: light)" srcset="../../assets/figs/partners/pageindex-mark.svg">
      <img src="../../assets/figs/partners/pageindex-mark.svg" alt="PageIndex" height="38">
    </picture>
  </a>
</p>

<p align="center">
  باستخدام الرمز: <b><code>DEEPTUTOR20</code></b> — احصل على خصم 20 دولاراً على أول <a href="https://developer.pageindex.ai/">اشتراك في PageIndex</a>!
</p>

## 🌐 المجتمع

### 🔗 المشرفون

<table>
  <tr>
    <td align="center"><a href="https://github.com/pancacake"><img src="https://avatars.githubusercontent.com/u/150592536?v=4&s=80" width="80" height="80" alt="Bingxi Zhao"><br><strong>Bingxi Zhao</strong></a></td>
    <td align="center"><a href="https://github.com/TyrionH-is-coding"><img src="https://avatars.githubusercontent.com/u/275607548?v=4&s=80" width="80" height="80" alt="Xingyu Hou"><br><strong>Xingyu Hou</strong></a></td>
    <td align="center"><a href="https://github.com/zzhtx258"><img src="https://avatars.githubusercontent.com/u/175302980?v=4&s=80" width="80" height="80" alt="Jiahao Zhang"><br><strong>Jiahao Zhang</strong></a></td>
  </tr>
</table>

### 📮 التواصل

DeepTutor هو مشروع مفتوح المصدر تقوده [Bingxi Zhao](https://github.com/pancacake) ضمن مجموعة [HKUDS](https://github.com/HKUDS)، ويتطور بشكل **مفتوح المصدر بالكامل**، مبني مع المجتمع. حتى الآن، **لا يوجد** لدينا أي منتجات مدفوعة عبر الإنترنت من أي شكل. تفضّل بالتواصل على **bingxizhao39@gmail.com** للنقاشات والأفكار والتعاون.

### 🙏 التقدير

خالص الشكر لـ [**Chao Huang**](https://sites.google.com/view/chaoh)، مدير مختبر ذكاء البيانات @ HKU، ولزملائنا في HKUDS على دعمهم الحار — وخاصةً [**Jiahao Zhang**](https://github.com/zzhtx258)، و[**Zirui Guo**](https://github.com/LarFii)، و[**Xubin Ren**](https://github.com/Re-bin). ونحن ممتنون عميقاً أيضاً لـ **مجتمع المصادر المفتوحة**: نجومكم والمشكلات التي تبلّغون عنها وطلبات السحب والنقاشات تشكّل DeepTutor كل يوم.

يقف DeepTutor أيضاً على أكتاف مشاريع مفتوحة المصدر متميزة أعطتنا أدوات وإلهاماً:

| المشروع | الدور / الإلهام |
|:---|:---|
| [**LlamaIndex**](https://github.com/run-llama/llama_index) | العمود الفقري لخط أنابيب RAG وفهرسة المستندات |
| [**nanobot**](https://github.com/HKUDS/nanobot) | محرك وكيل خفيف الوزن للغاية مكّن TutorBot الأصلي *(HKUDS)* |
| [**LightRAG**](https://github.com/HKUDS/LightRAG) | RAG بسيط وسريع *(HKUDS)* |
| [**AutoAgent**](https://github.com/HKUDS/AutoAgent) | إطار وكيل بدون رمز *(HKUDS)* |
| [**AI-Researcher**](https://github.com/HKUDS/AI-Researcher) | خط أنابيب بحث آلي *(HKUDS)* |
| [**OpenClaw**](https://github.com/openclaw/openclaw) | بوابة وكيل مفتوحة ونظام مهارات وراء ClawHub |
| [**Codex**](https://github.com/openai/codex) | واجهة برمجة أصيلة للوكلاء ألهمت سير عمل CLI لدينا |
| [**Claude Code**](https://github.com/anthropics/claude-code) | واجهة برمجة للوكلاء ألهمت حلقة وكيل DeepTutor |
| [**ManimCat**](https://github.com/Wing900/ManimCat) | توليد رسوم متحركة رياضية مدفوع بالذكاء الاصطناعي لـ Math Animator |

### 🗺️ خارطة الطريق والمساهمة

نريد لـ DeepTutor أن يستمر في التطور والتحسين — وفي نهاية المطاف أن يصبح هدية نقدمها للمجتمع مفتوح المصدر. يُحدَّث [**خارطة طريقنا**](https://github.com/HKUDS/DeepTutor/issues/498) باستمرار؛ صوّت على العناصر هناك أو اقترح عناصر جديدة. إذا كنت ترغب في المساهمة، راجع [**دليل المساهمة**](../../CONTRIBUTING.md) لمعرفة استراتيجية الفروع ومعايير البرمجة وكيفية البدء.

<div align="center">

نأمل أن يصبح DeepTutor هدية للمجتمع. 🎁

<a href="https://github.com/HKUDS/DeepTutor/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=HKUDS/DeepTutor&max=999" alt="المساهمون" />
</a>

</div>

<p align="center">
 <a href="https://www.star-history.com/hkuds/deeptutor">
  <picture>
   <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/badge?repo=HKUDS/DeepTutor&theme=dark" />
   <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/badge?repo=HKUDS/DeepTutor" />
   <img alt="ترتيب تاريخ النجوم" src="https://api.star-history.com/badge?repo=HKUDS/DeepTutor" />
  </picture>
 </a>
</p>

<div align="center">

مرخّص بموجب [رخصة Apache 2.0](../../LICENSE).

<p>
  <img src="https://visitor-badge.laobi.icu/badge?page_id=HKUDS.DeepTutor&style=for-the-badge&color=00d4ff" alt="المشاهدات">
</p>

</div>

### إسناد أدوار الإتقان إلى حالة المسار

تقرأ أدوار Mastery حالة المسار النشط قبل الطلب الأول إلى النموذج، باستخدام أداة الحالة نفسها وبوابات الإتقان نفسها المستخدمة عند استدعاء الأداة صراحةً. تكون هذه اللقطة حديثة لكل دور، وتتضمن وضع الجلسة النشط، ولا تُخزَّن مؤقتاً عبر الأدوار. عند فشل القراءة، يُرجَع إلى `mastery_status`؛ وبعد تغيير المسار أو الوضع أو المخطط أو التقدّم، يستطيع المدرّس تحديث الحالة عبر تلك الأداة. يظل تقييم البطاقات وآلية التسليم الحالية دون تغيير.

### مرفقات الصور المتكررة

ترسل حلقة الوكيل صور المستخدم المضمنة المتطابقة مرة واحدة لكل طلب، وتستبدل النسخ اللاحقة بمراجع إلى الصورة المحتفَظ بها. تحدد تسميات ثابتة خاصة بالطلب الصور المضمنة المحتفَظ بها عبر تحويلات المزودين والأدوار المُلحقة. تبقى كتل الصور الفريدة وعناوين URL البعيدة وخيارات الصور المختلفة ورسائل المساعد ونتائج الأدوات كاملة. يحتفظ السجل المحفوظ بكل مرفق أصلي؛ وتُعاد صياغة المراجع بعد تقليص السجل. يقلل ذلك حمولات الصور المتكررة، لكن الاستخدام الذي يبلّغ عنه المزود يظل مصدر الحقيقة للفوترة وإصابات الذاكرة المؤقتة.
