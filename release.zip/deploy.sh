#!/usr/bin/env bash
set -Eeuo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"

requested_port=''
requested_candidates=''
while [[ $# -gt 0 ]]; do
  case "$1" in
    --port) [[ $# -ge 2 ]] || { printf '%s\n' 'Missing --port value' >&2; exit 2; }; requested_port="$2"; shift 2 ;;
    --ports) [[ $# -ge 2 ]] || { printf '%s\n' 'Missing --ports value' >&2; exit 2; }; requested_candidates="$2"; shift 2 ;;
    --help) printf '%s\n' 'Usage: bash deploy.sh [--port 28743 | --ports 18743,18744,28743]'; exit 0 ;;
    *) printf 'Unknown option: %s\n' "$1" >&2; exit 2 ;;
  esac
done
if [[ -n "$requested_port" && -n "$requested_candidates" ]]; then
  printf '%s\n' 'Use either --port or --ports.' >&2
  exit 2
fi

if ! command -v docker >/dev/null 2>&1; then
  printf '%s\n' 'Docker is required. Install Docker Engine and the Compose plugin, then run bash deploy.sh again.' >&2
  exit 1
fi
if ! docker compose version >/dev/null 2>&1; then
  printf '%s\n' 'The Docker Compose plugin is required (docker compose).' >&2
  exit 1
fi
if ! docker info >/dev/null 2>&1; then
  printf '%s\n' 'Cannot connect to Docker. Start the daemon and check your Docker permissions.' >&2
  exit 1
fi
umask 077
if [[ ! -f .env ]]; then
  password="$(od -An -N24 -tx1 /dev/urandom | tr -d ' \n')"
  if [[ ${#password} -ne 48 ]]; then
    printf '%s\n' 'Could not generate an administrator password.' >&2
    exit 1
  fi
  {
    printf 'OIO_ADMIN_PASSWORD=%s\n' "$password"
    printf 'OIO_PORT=18743\nOIO_PORT_CANDIDATES=18744,28743\nOIO_BIND=0.0.0.0\nOIO_SECURE_COOKIE=false\nOIO_PUBLIC_URL=\n'
    printf 'CLOUDAGENT_URL=\nCLOUDAGENT_TOKEN=\nCLOUDAGENT_ACCOUNT_ID=\nCLOUDAGENT_MODEL=\n'
    printf 'OIO_PYTHON_RUNTIME=true\nOIO_RUNTIME_MEMORY=512m\n'
  } > .env
  unset password
  printf '%s\n' 'Created .env with a random administrator password. Read it locally to log in.'
fi
chmod 600 .env
read_setting() { sed -n "s/^$1=//p" .env | tail -n 1 | tr -d '\r"'; }
write_setting() {
  local temporary
  temporary="$(mktemp .env.XXXXXX)"
  awk -v key="$1" -v value="$2" 'BEGIN{found=0} index($0,key"=")==1 {if(!found)print key"="value;found=1;next} {print} END{if(!found)print key"="value}' .env > "$temporary"
  chmod 600 "$temporary"
  mv -- "$temporary" .env
}
socket_group="$(stat -c '%g' /var/run/docker.sock 2>/dev/null || printf '0')"
write_setting DOCKER_GID "$socket_group"
preferred="${OIO_PORT:-$(read_setting OIO_PORT)}"
fallbacks="${OIO_PORT_CANDIDATES:-$(read_setting OIO_PORT_CANDIDATES)}"
candidate_list="${requested_candidates:-${preferred:-18743},${fallbacks:-18744,28743}}"
if [[ -n "$requested_port" ]]; then candidate_list="$requested_port"; fi
IFS=',' read -r -a candidates <<< "$candidate_list"
for candidate in "${candidates[@]}"; do
  if [[ ! "$candidate" =~ ^[1-9][0-9]{0,4}$ ]] || (( candidate > 65535 )); then
    printf 'Invalid TCP port: %s\n' "$candidate" >&2
    exit 2
  fi
done
OIO_PORT="${candidates[0]}" docker compose config --quiet
docker compose build
deploy_log="$(mktemp)"
trap 'rm -f -- "$deploy_log"' EXIT
selected=''
for candidate in "${candidates[@]}"; do
  printf 'Starting OIO on port %s...\n' "$candidate"
  if OIO_PORT="$candidate" docker compose up -d --wait --wait-timeout 180 > "$deploy_log" 2>&1; then
    selected="$candidate"
    cat "$deploy_log"
    break
  fi
  cat "$deploy_log" >&2
  if ! grep -Eiq 'address already in use|port is already allocated|bind:.*(address|port)|failed to bind host port' "$deploy_log"; then
    printf '%s\n' 'Startup failed for a reason other than a port conflict; stopping here.' >&2
    exit 1
  fi
done
if [[ -z "$selected" ]]; then
  printf '%s\n' 'All selected ports are occupied. Run bash deploy.sh --port ANOTHER_PORT.' >&2
  exit 1
fi
write_setting OIO_PORT "$selected"
printf '\nOIO is ready. Home: http://YOUR_SERVER:%s/\n' "$selected"
printf '%s\n' 'Administrator password: OIO_ADMIN_PASSWORD in .env.'
printf '%s\n' 'Configure your CodeAgent API address in Platform Settings to enable AI building.'
printf '%s\n' 'Platform data: oio-data. Python websites use independent beta and production data volumes.'
