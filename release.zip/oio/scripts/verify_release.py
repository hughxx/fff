"""Verify packaging and run the extracted release with a fresh, temporary data directory."""
import hashlib
import http.cookiejar
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    release = ROOT / 'release.zip'
    digest = hashlib.sha256(release.read_bytes()).hexdigest()
    assert (ROOT / 'release.zip.sha256').read_text().split()[0] == digest
    with tempfile.TemporaryDirectory(prefix='oio-release-') as directory:
        with zipfile.ZipFile(release) as archive:
            assert archive.testzip() is None
            entries = archive.namelist()
            assert all(name.startswith('oio/') for name in entries)
            names = [name.removeprefix('oio/') for name in entries]
            assert all(not name.startswith(('.git/', '.venv/', 'data/', 'artifacts/', 'backups/')) for name in names)
            assert '.env' not in names
            assert 'backend/app.py' in names and 'frontend/chat.js' in names
            assert 'start.sh' in names and 'scripts/serve.py' in names
            assert 'Dockerfile' not in names and 'compose.yaml' not in names
            for name in names:
                assert '..' not in Path(name).parts and not Path(name).is_absolute()
                if name.endswith('.sh'):
                    assert b'\r' not in archive.read('oio/' + name)
                    assert archive.getinfo('oio/' + name).external_attr >> 16 & 0o111
            metadata = json.loads(archive.read('oio/release.json'))
            assert metadata['commit'] and not metadata['dirty'], metadata
            archive.extractall(directory)
        extracted = Path(directory)/'oio'
        assert {path.name for path in Path(directory).iterdir()} == {'oio'}
        env = {**os.environ, 'OIO_DATA_DIR':str(Path(directory)/'runtime-data'),
               'CLOUDAGENT_URL':'', 'OIO_PUBLIC_URL':'', 'PYTHONPATH':str(extracted)}
        env.pop('OIO_ADMIN_PASSWORD', None)
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 0))
            port = sock.getsockname()[1]
        with tempfile.TemporaryFile() as log:
            env['OIO_BIND'] = '127.0.0.1'
            process = subprocess.Popen([sys.executable, 'scripts/serve.py', '--port',str(port)],
                                       cwd=extracted, env=env, stdout=log, stderr=log)
            base = f'http://127.0.0.1:{port}'
            opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))

            def call(path, data=None, method=None):
                request = urllib.request.Request(base + path, data=json.dumps(data).encode() if data is not None else None,
                                                 headers={'Content-Type':'application/json','X-OIO-Request':'1'}, method=method)
                return opener.open(request, timeout=5)

            try:
                deadline = time.monotonic() + 15
                while True:
                    try:
                        assert json.load(call('/api/health'))['status'] == 'ok'
                        break
                    except (OSError, urllib.error.URLError):
                        if process.poll() is not None or time.monotonic() > deadline:
                            log.seek(0)
                            raise RuntimeError(log.read().decode(errors='replace'))
                        time.sleep(.1)
                assert b'InstaSite' in call('/').read()
                assert b'boot()' in call('/_console/chat.js').read()
                site = json.load(call('/api/sites', {'name':'Release smoke', 'slug':'release-smoke'}))
                assert b'Release smoke' in call('/release-smoke-beta/').read()
                assert json.load(call(f"/api/sites/{site['id']}/publish", {'version_id':site['beta_version']}))['success']
                assert b'Release smoke' in call('/release-smoke/nested/path').read()
            finally:
                process.terminate()
                try:
                    process.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
    print('Release verified: SHA256, archive contents, executable LF scripts, password-free startup, create, publish and routes.')


if __name__ == '__main__':
    main()
