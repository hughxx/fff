from tests.test_platform import create, submit, wait_job


def delete(client, site, **overrides):
    return client.request('DELETE', '/api/sites/'+site['id'], json={
        'confirmed': True, 'confirm_slug': site['slug'], **overrides})


def test_delete_requires_explicit_confirmation(harness):
    client, app, agent = harness
    site = create(client)
    assert delete(client, site, confirmed=False).status_code == 400
    assert delete(client, site, confirmed=1).status_code == 422
    assert delete(client, site, confirm_slug='another').status_code == 400
    assert client.get('/api/sites/'+site['id']).status_code == 200
    assert delete(client, site).status_code == 200
    assert client.get('/studio-beta/').status_code == 404
    create(client)


def test_delete_cleans_workspace_versions_and_conversation(harness):
    client, app, agent = harness
    site = create(client)
    submit(client, site)
    site = wait_job(client, site['id'])
    other = create(client, 'another')
    other['workspace_id'] = 'other-workspace'
    agent.workspaces['other-workspace'] = {'id':'other-workspace'}
    app.state.store.execute('UPDATE sites SET workspace_id=? WHERE id=?', ('other-workspace',other['id']))
    thread = client.post('/api/sites/'+site['id']+'/conversation').json()
    assert client.post('/api/sites/'+site['id']+'/publish', json={'version_id':site['beta_version']}).status_code == 200
    assert delete(client, site).status_code == 200
    assert site['workspace_id'] not in agent.workspaces
    assert other['workspace_id'] in agent.workspaces
    assert client.get('/api/conversations/'+thread['id']).status_code == 404
    for table in ('sites','jobs','versions','messages','events','site_tags','site_deletions'):
        column = 'id' if table == 'sites' else 'site_id'
        assert not app.state.store.all(f'SELECT * FROM {table} WHERE {column}=?', (site['id'],))
    for version in site['versions']:
        assert not (app.state.config.data_dir/'versions'/version['id']).exists()
    assert client.get('/studio/').status_code == 404
    assert client.get('/another-beta/').status_code == 200


def test_remote_failure_can_retry_but_cannot_restore(harness):
    client, app, agent = harness
    site = create(client)
    submit(client, site)
    site = wait_job(client, site['id'])
    agent.fail_workspace_delete = True
    assert delete(client, site).status_code == 503
    assert client.get('/api/sites/'+site['id']).json()['archived']
    assert client.patch('/api/sites/'+site['id']+'/archive', json={'archived':False}).status_code == 409
    agent.fail_workspace_delete = False
    assert delete(client, site).status_code == 200


def test_running_job_blocks_delete(harness):
    client, app, agent = harness
    site = create(client)
    agent.hold = True
    submit(client, site)
    assert delete(client, site).status_code == 409
    assert not client.get('/api/sites/'+site['id']).json()['archived']


def test_stop_failure_keeps_workspace(harness):
    client, app, agent = harness
    site = create(client)
    submit(client, site)
    site = wait_job(client, site['id'])
    async def fail(*args, **kwargs):
        raise RuntimeError('unreachable')
    app.state.runtime.stop_others = fail
    assert delete(client, site).status_code == 503
    assert site['workspace_id'] in agent.workspaces
