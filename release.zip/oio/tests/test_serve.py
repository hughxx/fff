import importlib.util
import socket

from backend.config import ROOT

spec=importlib.util.spec_from_file_location('oio_serve',ROOT/'scripts/serve.py')
serve=importlib.util.module_from_spec(spec);spec.loader.exec_module(serve)


def test_real_port_conflict_falls_back_and_explicit_port_fails():
    occupied=socket.socket();occupied.bind(('127.0.0.1',0));occupied.listen()
    free=socket.socket();free.bind(('127.0.0.1',0));alternative=free.getsockname()[1];free.close()
    try:
        selected=serve.bind_port('127.0.0.1',[occupied.getsockname()[1],alternative])
        assert selected.getsockname()[1]==alternative;selected.close()
        import pytest
        with pytest.raises(OSError):serve.bind_port('127.0.0.1',[occupied.getsockname()[1]])
    finally:
        occupied.close()


def test_env_is_not_executed_and_existing_settings_are_preserved(tmp_path,monkeypatch):
    monkeypatch.delenv('OIO_PORT',raising=False)
    monkeypatch.delenv('OIO_TEST_VALUE',raising=False)
    (tmp_path/'.env').write_text('OIO_PORT=28743\nOIO_TEST_VALUE=$(touch nope)\n')
    serve.load_environment(tmp_path)
    import os
    assert os.environ['OIO_PORT']=='28743'
    assert os.environ['OIO_TEST_VALUE']=='$(touch nope)'
    assert not (tmp_path/'nope').exists()
    monkeypatch.delenv('OIO_PORT');monkeypatch.delenv('OIO_TEST_VALUE')
