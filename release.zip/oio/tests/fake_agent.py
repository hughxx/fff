"""A deterministic protocol stub used only in tests; never a production AI provider."""
import json
from pathlib import PurePosixPath

import httpx

from backend.agent import CloudAgent


class FakeAgent:
    def __init__(self):
        self.workspaces = {}
        self.sessions = {}
        self.tasks = {}
        self.posts = []
        self.source_files = {}
        self.files = {
            'index.html': b'<!doctype html><html><head><title>Generated</title><link rel="stylesheet" href="assets/style.css"></head><body><h1>Generated website</h1><a href="about/">About</a><script type="module" src="assets/app.js"></script></body></html>',
            'about/index.html': b'<!doctype html><html><head><title>About</title></head><body><h1>About this site</h1></body></html>',
            'assets/style.css': b'body{background:#eef4e5;font-family:system-ui;padding:48px;color:#3e5536}h1{font-size:44px}',
            'assets/app.js': b'document.body.dataset.moduleLoaded="yes";',
            'assets/logo.png': b'\x89PNG\r\n\x1a\n',
        }
        self.hold = False
        self.fail_workspace_delete = False
        self.result_error = False
        self.fail_download = False
        self.ambiguous_submit = False
        self.symlink = False

    def factory(self):
        return CloudAgent('http://agent.test/api', transport=httpx.MockTransport(self.handle))

    async def handle(self, request):
        path = request.url.path.removeprefix('/api/').split('/')
        method = request.method
        body = json.loads(request.content) if request.content and 'application/json' in request.headers.get('content-type','') else {}
        if method == 'POST':
            self.posts.append(('/'.join(path), body))
        if path == ['workspaces']:
            if method == 'GET':
                return httpx.Response(200, json={'items': list(self.workspaces.values()), 'total':len(self.workspaces)})
            self.workspaces[body['name']] = {'id':body['name'], 'status':'ready'}
            return httpx.Response(201, json=self.workspaces[body['name']])
        if path[0] == 'workspaces' and len(path) == 2:
            if path[1] not in self.workspaces:
                return httpx.Response(404, json={'detail':'not found'})
            if method == 'DELETE':
                if self.fail_workspace_delete:
                    return httpx.Response(503)
                assert not any(s['workspace_id'] == path[1] for s in self.sessions.values())
                del self.workspaces[path[1]]
                return httpx.Response(200, json={'success':True})
            return httpx.Response(200, json=self.workspaces[path[1]])
        if path[0] == 'workspaces' and len(path) >= 3 and path[2] == 'files':
            remote = request.url.params.get('path', 'dist')
            if len(path) == 4 and path[3] == 'content':
                if remote not in self.source_files:
                    return httpx.Response(404, json={'detail':'not found'})
                return httpx.Response(200, json={'content':self.source_files[remote].decode()})
            if len(path) == 4 and path[3] == 'upload':
                self.source_files[remote] = request.content
                return httpx.Response(201, json={'path':remote})
            if len(path) == 4 and path[3] == 'download':
                if self.fail_download:
                    return httpx.Response(503, json={'detail':'unavailable'})
                return httpx.Response(200, content=self.files[remote.removeprefix('dist/')])
            prefix = remote + '/'
            items = {}
            for name, content in self.files.items():
                full = name if name.startswith('backend/') else 'dist/' + name
                if full.startswith(prefix):
                    remainder = full[len(prefix):]
                    first = remainder.split('/')[0]
                    items[first] = {'name':first, 'path':prefix+first, 'type':'directory' if '/' in remainder else 'file', 'size':len(content)}
            if self.symlink:
                items['escape'] = {'name':'escape', 'path':'dist/escape', 'type':'symlink', 'size':0}
            return httpx.Response(200, json={'path':remote, 'items':list(items.values())})
        if path == ['sessions']:
            if method == 'GET':
                return httpx.Response(200, json={'items':[s for s in self.sessions.values() if s['workspace_id'] == request.url.params['workspace_id']]})
            session_id = 'sess_' + str(len(self.sessions) + 1)
            self.sessions[session_id] = {'session_id':session_id, **body}
            return httpx.Response(201, json=self.sessions[session_id])
        if path[0] == 'sessions' and len(path) == 2 and method == 'DELETE':
            self.sessions.pop(path[1], None)
            return httpx.Response(200, json={'success':True})
        if path[0] == 'sessions' and len(path) == 3 and path[2] == 'tasks':
            task_id = 'task_' + str(len(self.tasks) + 1)
            self.tasks[task_id] = {'task_id':task_id, 'session_id':path[1], 'status':'running', 'result':None}
            if self.ambiguous_submit:
                raise httpx.ReadTimeout('response lost', request=request)
            return httpx.Response(202, json=self.tasks[task_id])
        if path[0] == 'sessions' and len(path) >= 4:
            task = self.tasks[path[3]]
            if len(path) == 5 and path[4] == 'cancel':
                task['status'] = 'cancelled'
                return httpx.Response(200, json={'success':True, 'status':'cancelled'})
            if not self.hold and task['status'] == 'running':
                task.update(status='success', result={'type':'result', 'is_error':self.result_error, 'result':'已生成网站，完成构建检查。'})
            return httpx.Response(200, json=task)
        raise AssertionError(f'Unexpected request: {method} {request.url}')
