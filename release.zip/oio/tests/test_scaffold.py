import importlib.util
import shutil
from backend.config import ROOT


def test_enable_backend_preserves_business_code(tmp_path):
    source = ROOT/'templates/react/scripts/enable_backend.py'
    spec = importlib.util.spec_from_file_location('enable_backend', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    shutil.copytree(ROOT/'templates/python', tmp_path/'python-example')
    module.enable(tmp_path)
    assert (tmp_path/'oio-runtime.json').is_file()
    assert (tmp_path/'backend/requirements.txt').is_file()
    main = tmp_path/'backend/main.py'
    main.write_text('# existing business code', encoding='utf-8')
    module.enable(tmp_path)
    assert main.read_text(encoding='utf-8') == '# existing business code'
