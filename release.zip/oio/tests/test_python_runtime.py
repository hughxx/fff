import json
import io
import zipfile

import httpx
import pytest
from fastapi.testclient import TestClient

from backend.app import create_app
from backend.config import Config
from backend.runtime import MANIFEST, manifest_at, parse_manifest, RuntimeError
from tests.conftest import HEADERS
from tests.fake_agent import FakeAgent
from tests.test_platform import create, submit, wait_job


class FakeRuntime:
    def __init__(self, store, config):
        self.store,self.config=store,config
        self.calls=[]
        self.fail=False

    async def prepare(self, site, environment, version):
        if not manifest_at(self.config.data_dir/'versions'/version):return None
        self.calls.append((environment,version))
        if self.fail:raise RuntimeError('Python 健康检查未通过')
        return f'http://runtime.test/{environment}/{version}'

    async def stop_others(self,*args):pass

    async def target(self,site,environment):
        version=site['beta_version' if environment=='beta' else 'production_version']
        return await self.prepare(site,environment,version) if version else None


@pytest.fixture
def fullstack(tmp_path):
    agent=FakeAgent()
    agent.source_files[MANIFEST]=json.dumps({'python':{'command':['python','main.py'],'health_path':'/api/health'}}).encode()
    agent.files['backend/main.py']=b'print("private python source")'
    agent.files['backend/requirements.txt']=b'fastapi==0.161.1'
    app=create_app(Config(data_dir=tmp_path,agent_url='http://agent/api',poll_seconds=.01),agent.factory,FakeRuntime)
    async def upstream(request):
        payload=await request.aread()
        return httpx.Response(200,json={'path':request.url.path,'body':payload.decode(),'authorization':request.headers.get('authorization'),'cookie':request.headers.get('cookie')})
    app.state.proxy_transport=httpx.MockTransport(upstream)
    with TestClient(app) as client:
        client.headers.update(HEADERS)
        yield client,app,agent


def test_fullstack_versions_health_and_private_sources(fullstack):
    client,app,agent=fullstack
    site=create(client);submit(client,site);built=wait_job(client,site['id'])
    first=built['beta_version']
    assert ('beta',first) in app.state.runtime.calls
    package=client.get(f"/api/sites/{site['id']}/versions/{first}/download")
    with zipfile.ZipFile(io.BytesIO(package.content)) as archive:
        assert 'backend/main.py' in archive.namelist()
        assert 'dist/index.html' in archive.namelist()
        assert MANIFEST in archive.namelist()
    assert client.get('/studio/backend/main.py').status_code==404
    assert client.get('/studio-beta/backend/main.py').status_code==404
    assert client.get('/studio-beta/oio-runtime.json/').status_code==404
    response=client.post('/studio-beta/api/echo?x=1',content='hello',headers={'Authorization':'Bearer website-token','Cookie':'private-cookie=secret'})
    assert response.status_code==200,response.text
    assert response.json()['path']==f'/beta/{first}/api/echo'
    assert response.json()['body']=='hello'
    assert response.json()['authorization']=='Bearer website-token'
    assert response.json()['cookie'] is None
    assert response.headers['access-control-allow-origin']=='*'
    client.post(f"/api/sites/{site['id']}/publish",json={'version_id':first})
    assert client.get('/studio/api/echo').json()['path']==f'/production/{first}/api/echo'
    submit(client,site);second=wait_job(client,site['id'])['beta_version']
    app.state.runtime.fail=True
    assert client.post(f"/api/sites/{site['id']}/publish",json={'version_id':second}).status_code==503
    assert client.get('/api/sites/'+site['id']).json()['production_version']==first
    app.state.runtime.fail=False
    client.post(f"/api/sites/{site['id']}/publish",json={'version_id':second})
    client.post(f"/api/sites/{site['id']}/rollback",json={'version_id':first})
    assert client.get('/studio/api/echo').json()['path']==f'/production/{first}/api/echo'
    assert client.get('/studio-beta/api/echo').json()['path']==f'/beta/{second}/api/echo'


def test_failed_backend_keeps_previous_beta_and_retry_uses_same_version(fullstack):
    client,app,_=fullstack
    site=create(client);app.state.runtime.fail=True
    job=submit(client,site);failed=wait_job(client,site['id'],'failed')
    assert failed['beta_version']==site['beta_version']
    candidate=failed['jobs'][0]['version_id']
    app.state.runtime.fail=False
    assert client.post(f"/api/sites/{site['id']}/jobs/{job['id']}/retry-sync").status_code==200
    assert wait_job(client,site['id'])['beta_version']==candidate


@pytest.mark.parametrize('value',[{}, {'python':{'command':'python main.py'}},{'python':{'command':[]}}, {'python':{'command':['python'],'health_path':'//outside'}}, {'python':{'command':['python'],'privileged':True}}])
def test_runtime_manifest_rejects_unsafe_or_invalid_options(value):
    with pytest.raises(ValueError):parse_manifest(json.dumps(value))
