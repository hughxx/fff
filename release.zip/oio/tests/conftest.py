import pytest
from fastapi.testclient import TestClient

from backend.app import create_app
from backend.config import Config
from tests.fake_agent import FakeAgent

HEADERS = {'X-OIO-Request':'1'}


@pytest.fixture
def harness(tmp_path):
    agent = FakeAgent()
    config = Config(data_dir=tmp_path, agent_url='http://agent.test/api', poll_seconds=.02)
    app = create_app(config, agent.factory)
    with TestClient(app) as client:
        client.headers.update(HEADERS)
        yield client, app, agent
