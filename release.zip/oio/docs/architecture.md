# CloudAgent 工作区架构

InstaSite 是一个 FastAPI 网关，管理前端不需要 Node 编译。默认生成的微网站使用 React / TypeScript / Vite / React Router。AI 开发、npm 构建、Python 依赖安装与业务运行都由 CloudAgent 工作区承载。InstaSite 保存 SQLite、对话和不可变版本快照，并提供静态前端和后端反向代理。

## 文件与进程

前端采用两级视图：/ 为网站卡片目录，/#/sites/<site_id> 为单站对话页，包含测试与生产链接，不嵌入业务页面。site_threads 将站点绑定到持久对话，防止跨站历史混在一起；旧站点首次打开时接续已有对话。主页对所有人展示全部网站和下线卡片；保留的 /api/catalog 只是筛选已发布网站的接口，不是权限边界。所有接口均不要求用户登录，每个网站仍对应独立 CloudAgent workspace。

每站使用独立工作区，工作区内：

```text
src/、dist/、backend/        AI 编写的工程
.oio/services/beta/
  data/                     测试业务数据
  versions/ver_xxx/
    backend/                不可变后端快照
    venv/                   本版本依赖
    controller.py           平台上传的进程控制器
    config.json             启动参数与环境变量
    state.json              PID、启动标识、端口、就绪状态
    service.log             业务日志
    supervisor.log          守护进程日志
.oio/services/production/    同结构，独立生产数据
```

创建异步 command-task 后保存 task_id，轮询任务到终态。安装依赖受底座 1800 秒任务上限约束。控制器通过 start_new_session、DEVNULL、文件日志和 SIGHUP 忽略方式启动守护进程，达到 nohup 后台常驻的目的；子进程有自己的进程组。

部署锁和守护进程锁防止重复启动。停止标记阻止延迟部署在下线后拉起服务。守护进程记录 Linux /proc 中的启动时间，与 PID 一起验证身份；停止请求通过站点版本目录的标记由该守护进程处理，只终止它创建的业务进程组。

平台 workspace_runtimes 表保存 workspace_id、task_id、directory、supervisor_pid、service_pid、start_time、port、url、status。无需登录的站点详情 API 返回这些记录，卡片目录不返回。下线关闭 InstaSite 地址，再尝试停止两个环境的全部历史运行实例；失败标记 stop_failed，并向对话报告，可重试。

底座机器重启后进程会消失，保存的数据不会消失。后续 API 访问或恢复操作会核对并重建运行服务；没有独立的节点开机自启服务。InstaSite 重启后第一次 API 请求核对远程状态，短期缓存十秒，因此业务异常后可能有短暂 502。守护进程异常退出不保证立即恢复；后续访问触发恢复。

## Python 交付契约

工作区根目录 oio-runtime.json：

```json
{"python":{"command":["uvicorn","main:app","--host","0.0.0.0","--port","{port}"],"health_path":"/api/health"}}
```

Python 源码与 requirements.txt 放 backend/；前端交付 dist/index.html 和相对资源。启动命令按数组执行，不经 shell。使用 {port} 或环境变量 PORT，不硬编码端口；兼容旧清单的 8080 参数。服务监听 0.0.0.0，通过健康检查后才切换版本。支持 FastAPI、Flask、Django 等符合此 HTTP 契约的 Python 服务；Flask 可用 gunicorn 的 --bind 0.0.0.0:{port}。

环境变量：PORT、OIO_DATA_DIR、OIO_BASE_PATH、OIO_API_BASE、OIO_ENVIRONMENT。持久数据只能依赖 OIO_DATA_DIR，不假定为 /data。平台数据目录 runtime-env/<slug>.json 可分别配置 beta、production 的业务变量，在服务端维护，配置随版本写入工作区，切勿写入前端。已有版本配置保持不变，更新密钥应生成新版本。

发布先启动对应生产版本并检查 InstaSite 到节点的连通性，再切换版本指针；失败保留原生产。Beta 同样在成功启动后切换。回滚采用相同过程，允许已发布版本。版本间共用本环境数据，迁移必须向后兼容；回滚代码不会回滚数据库。

## 网络与前端

浏览器 /demo/api/* 转发到节点动态端口 /api/*，/demo-beta/api/* 对应测试服务。支持 HTTP、流式上传、SSE、WebSocket。节点默认选择 22000–22999 的可用端口；只向 InstaSite 主机开放该内部端口范围，避免用户绕过平台入口。多节点映射 CLOUDAGENT_RUNTIME_HOSTS 按 node_id 指定 InstaSite 可达的节点地址，不能把无法访问的内部地址假称为已部署成功。

同一个构建产物用于生产与 Beta。Vite base 使用 ./，React Router basename 使用 window.OIO_BASE_PATH。业务网站没有平台返回链接。网页 CSP sandbox 不授予 allow-same-origin，不能使用平台 cookies、localStorage 或 service worker。转发剔除平台 cookie 和 Set-Cookie，业务登录需设计 token/API 方式。

## 隔离和备份范围

工作区与虚拟环境提供工程、依赖分离，但命令继承节点服务用户权限，并非安全沙箱；没有 Docker 的 CPU、内存和文件系统隔离。平台不承诺阻止恶意代码访问节点其他目录。控制器只向业务进程传递少量基本环境及服务端配置的业务变量。

InstaSite 备份包含平台数据库、快照和 .env；CloudAgent 的源码、.oio 数据目录与进程日志须在节点另行备份。依赖虚拟环境可重建。前端源代码留在底座，版本 ZIP 包含前端构建产物及 Python 源码。旧版本目录与日志目前不自动清理。

仅支持一个 InstaSite worker。SQLite 和任务锁不支持多副本横向扩展。
