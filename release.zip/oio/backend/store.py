import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from uuid import uuid4


def now():
    return datetime.now(timezone.utc).isoformat()


def uid(prefix):
    return prefix + '_' + uuid4().hex


SCHEMA = '''
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sites (
 id TEXT PRIMARY KEY, slug TEXT UNIQUE NOT NULL COLLATE NOCASE,
 name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
 workspace_id TEXT, session_id TEXT, beta_version TEXT, production_version TEXT,
 archived INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS versions (
 id TEXT PRIMARY KEY, site_id TEXT NOT NULL REFERENCES sites(id),
 number INTEGER NOT NULL, summary TEXT NOT NULL, file_count INTEGER NOT NULL,
 size INTEGER NOT NULL, digest TEXT NOT NULL, created_at TEXT NOT NULL,
 UNIQUE(site_id, number)
);
CREATE TABLE IF NOT EXISTS jobs (
 id TEXT PRIMARY KEY, site_id TEXT NOT NULL REFERENCES sites(id),
 prompt TEXT NOT NULL, status TEXT NOT NULL, stage TEXT NOT NULL,
 remote_task_id TEXT, result TEXT, error TEXT, version_id TEXT,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS one_active_job ON jobs(site_id)
 WHERE status IN ('queued','running');
CREATE TABLE IF NOT EXISTS messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT, site_id TEXT NOT NULL REFERENCES sites(id),
 job_id TEXT, role TEXT NOT NULL, content TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS events (
 id INTEGER PRIMARY KEY AUTOINCREMENT, site_id TEXT NOT NULL REFERENCES sites(id),
 action TEXT NOT NULL, version_id TEXT, note TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS conversations (
 id TEXT PRIMARY KEY, site_id TEXT REFERENCES sites(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chat_messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT, conversation_id TEXT NOT NULL REFERENCES conversations(id),
 role TEXT NOT NULL, content TEXT NOT NULL, links TEXT NOT NULL DEFAULT '[]',
 job_id TEXT REFERENCES jobs(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS site_threads (
 site_id TEXT PRIMARY KEY REFERENCES sites(id),
 conversation_id TEXT UNIQUE NOT NULL REFERENCES conversations(id)
);
CREATE TABLE IF NOT EXISTS chat_turns (
 conversation_id TEXT NOT NULL REFERENCES conversations(id), request_id TEXT NOT NULL,
 response TEXT, PRIMARY KEY(conversation_id, request_id)
);
CREATE TABLE IF NOT EXISTS site_tags (
 site_id TEXT NOT NULL REFERENCES sites(id), tag TEXT NOT NULL COLLATE NOCASE,
 PRIMARY KEY(site_id,tag)
);
CREATE TABLE IF NOT EXISTS site_deletions (
 site_id TEXT PRIMARY KEY REFERENCES sites(id), started_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS runtimes (
 site_id TEXT NOT NULL REFERENCES sites(id), environment TEXT NOT NULL, version_id TEXT NOT NULL,
 container_id TEXT NOT NULL, url TEXT NOT NULL, PRIMARY KEY(site_id,environment,version_id)
);
CREATE TABLE IF NOT EXISTS workspace_runtimes (
 site_id TEXT NOT NULL REFERENCES sites(id), environment TEXT NOT NULL, version_id TEXT NOT NULL,
 workspace_id TEXT NOT NULL, directory TEXT NOT NULL, task_id TEXT,
 supervisor_pid INTEGER, service_pid INTEGER, start_time TEXT, port INTEGER, url TEXT,
 status TEXT NOT NULL DEFAULT 'preparing', updated_at TEXT NOT NULL,
 PRIMARY KEY(site_id,environment,version_id)
);
'''


class Store:
    def __init__(self, directory):
        directory.mkdir(parents=True, exist_ok=True)
        self.path = directory / 'oio.sqlite3'
        with self.connect() as db:
            db.executescript(SCHEMA)
            if 'visits' not in {row['name'] for row in db.execute('PRAGMA table_info(sites)')}:
                db.execute('ALTER TABLE sites ADD COLUMN visits INTEGER NOT NULL DEFAULT 0')
            db.execute('PRAGMA user_version=3')

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        try:
            with db:
                yield db
        finally:
            db.close()

    def all(self, sql, args=()):
        with self.connect() as db:
            return [dict(r) for r in db.execute(sql, args).fetchall()]

    def one(self, sql, args=()):
        rows = self.all(sql, args)
        return rows[0] if rows else None

    def execute(self, sql, args=()):
        with self.connect() as db:
            db.execute(sql, args)

    def setting(self, key, default=None):
        row = self.one('SELECT value FROM settings WHERE key=?', (key,))
        return json.loads(row['value']) if row else default

    def set_setting(self, key, value):
        self.execute('INSERT OR REPLACE INTO settings VALUES (?,?)', (key, json.dumps(value)))
