"""Conversational control plane. Explicit lifecycle intents never go to a coding agent."""
import asyncio
import json
import re

from fastapi import HTTPException

from .store import now, uid


def intent(text):
    value = re.sub(r'[\s，。！？,.!？]+', '', text.lower())
    value = re.sub(r'^(?:请|麻烦|帮我|请帮我)', '', value)
    patterns = {
        'home': r'(?:返回主页|回到主页|主页|换个网站|结束当前对话|先不改了)',
        'new': r'(?:新建网站|创建网站|做个新网站|新的网站|重新开始)',
        'help': r'(?:帮助|怎么用|你能做什么|help)',
        'preview': r'(?:预览|看看效果|看下效果|打开测试(?:地址|环境)?|测试地址|生产地址|网站地址|地址|看看网站|查看网站)',
        'publish': r'(?:发布|上线|发布上线|发布到生产|发布网站|可以发布了|可以上线了|把它上线|确认发布|确认上线|这个可以了(?:帮我)?上线)',
        'archive': r'(?:归档|归档网站|把网站归档|下线|下线网站|把它下线)',
        'delete': r'(?:删除网站|永久删除网站|删除这个网站|删除站点|我已确认删除)',
        'restore': r'(?:恢复|恢复网站|取消归档|重新开放)',
        'history': r'(?:历史|版本|版本记录|历史版本|查看版本|看看历史版本)',
        'cancel': r'(?:停止|取消任务|停止生成|停止修改|取消生成)',
        'sync': r'(?:重新同步|重试同步|同步产物|重新同步构建产物)',
        'keep': r'(?:不要发布|先不发布|暂不发布|不要上线|先不归档|不要归档|不要回滚|先不回滚)',
    }
    for action, pattern in patterns.items():
        if re.fullmatch(pattern, value):
            return action, None
    rollback = re.fullmatch(r'(?:回滚|恢复)(?:到|至)?(?:版本)?v?(\d+)', value)
    if rollback:
        return 'rollback', int(rollback[1])
    if value in ('回滚', '回到上个版本', '回滚到上一版', '撤回这次发布', '退回上个版本'):
        return 'rollback', None
    if value in ('下载版本', '下载归档', '导出网站'):
        return 'download', None
    if re.search(r'(发布|上线|归档|回滚|下线)', value) and not re.search(r'(按钮|文案|文字|功能|页面|组件|样式|颜色|菜单)', value):
        return 'clarify', None
    return 'build', None


class ConversationService:
    def __init__(self, store, operations):
        self.store, self.operations = store, operations
        self.lock = asyncio.Lock()  # short control-plane operations, one administrator

    def create(self, site_id=None):
        identifier = uid('chat')
        self.store.execute('INSERT INTO conversations VALUES (?,?,?)', (identifier, site_id, now()))
        return identifier

    def message(self, identifier, role, content, links=None, job_id=None):
        self.store.execute('INSERT INTO chat_messages(conversation_id,role,content,links,job_id,created_at) VALUES (?,?,?,?,?,?)',
                           (identifier, role, content, json.dumps(links or [], ensure_ascii=False), job_id, now()))

    def links(self, site):
        if site['archived']:
            return []
        return [{'label':'生产地址' if site['production_version'] else '生产地址（待发布）', 'url':f"/{site['slug']}/"},
                {'label':'测试地址', 'url':f"/{site['slug']}-beta/"}]

    def read(self, identifier):
        conversation = self.store.one('SELECT * FROM conversations WHERE id=?', (identifier,))
        if not conversation:
            raise HTTPException(404, '对话不存在')
        messages = self.store.all('SELECT * FROM chat_messages WHERE conversation_id=? ORDER BY id DESC LIMIT 150', (identifier,))[::-1]
        for message in messages:
            message['links'] = json.loads(message['links'])
            if message['job_id']:
                job = self.store.one('SELECT * FROM jobs WHERE id=?', (message['job_id'],))
                message['job'] = {key:job[key] for key in ('id', 'status', 'stage', 'result', 'error', 'version_id')}
                if job['status'] == 'success':
                    message['job']['result'] = (job['result'] or '修改完成。') + '\n测试地址已更新，满意后直接告诉我“发布”。'
        site = self.store.one('SELECT * FROM sites WHERE id=?', (conversation['site_id'],)) if conversation['site_id'] else None
        if site:
            site['tags'] = [row['tag'] for row in self.store.all('SELECT tag FROM site_tags WHERE site_id=? ORDER BY tag', (site['id'],))]
        return {'id':identifier, 'messages':messages, 'site':site, 'links':self.links(site) if site else []}

    async def send(self, identifier, request_id, text, expected_beta=None):
        async with self.lock:
            context = self.read(identifier)
            old = self.store.one('SELECT response FROM chat_turns WHERE conversation_id=? AND request_id=?', (identifier, request_id))
            if old:
                if old['response']:
                    return self.read(identifier)
                raise HTTPException(409, '上一条消息的执行结果尚未确认。请查看当前对话和任务状态，不会重复执行。')
            self.store.execute('INSERT INTO chat_turns VALUES (?,?,NULL)', (identifier, request_id))
            self.message(identifier, 'user', text)
            try:
                reply, links, job_id = await self.respond(identifier, context['site'], text, expected_beta)
            except HTTPException as error:
                reply, links, job_id = str(error.detail), [], None
            except ValueError as error:
                reply, links, job_id = str(error), [], None
            except Exception as error:
                from .runtime import RuntimeError as PythonRuntimeError
                reply = str(error) if isinstance(error, PythonRuntimeError) else '这次操作没有完成，请检查服务状态后再试。'
                links, job_id = [], None
            self.message(identifier, 'assistant', reply, links, job_id)
            self.store.execute('UPDATE chat_turns SET response=? WHERE conversation_id=? AND request_id=?',
                               (json.dumps({'complete':True}), identifier, request_id))
            return self.read(identifier)

    async def respond(self, identifier, site, text, expected_beta):
        # Explicit @slug or /slug selects a website. Names are never guessed for destructive actions.
        match = re.search(r'(?<![a-z0-9])(?:@|/)([a-z][a-z0-9]*(?:-[a-z0-9]+)*)/?', text, re.I)
        pinned = self.store.one('SELECT site_id FROM site_threads WHERE conversation_id=?', (identifier,))
        if pinned:
            # Paths inside a page requirement (e.g. /about) belong to this site, not a global site selector.
            match = re.fullmatch(r'(?:修改|打开|管理|选择)?\s*(?:@|/)([a-z][a-z0-9]*(?:-[a-z0-9]+)*)/?', text.strip(), re.I)
            if match and site and match[1].lower().removesuffix('-beta') != site['slug']:
                return '每个网站有独立对话。请返回主页，点击对应网站卡片后继续。', [], None
        remainder = text
        if match:
            slug = match[1].lower().removesuffix('-beta')
            selected = self.store.one('SELECT * FROM sites WHERE slug=?', (slug,))
            if not selected:
                return f'没有找到 /{slug}/。请在主页点击“新建网站”，填写网站名称和英文网址名称。', [], None
            site = selected
            self.store.execute('UPDATE conversations SET site_id=? WHERE id=?', (site['id'], identifier))
            remainder = (text[:match.start()] + text[match.end():]).strip()
            if remainder in ('', '修改', '打开', '管理', '看看', '选择'):
                return f'现在聊的是「{site["name"]}」。告诉我哪里需要修改，也可以说“发布”“回到上个版本”或“归档”。', self.links(site), None
        tag_match = re.fullmatch(r'(打标签|添加标签|加标签|删除标签|移除标签|设置标签)\s*[:：]?\s*(.+)', remainder.strip())
        if tag_match:
            if not site:
                return '先告诉我是哪个网站，例如“修改 /coffee”，再说“打标签 张三，设计组”。', [], None
            tags = [item for item in re.split(r'[，,、\s#]+', tag_match[2]) if item]
            existing = [row['tag'] for row in self.store.all('SELECT tag FROM site_tags WHERE site_id=?', (site['id'],))]
            if tag_match[1] in ('删除标签', '移除标签'):
                tags = [tag for tag in existing if tag.casefold() not in {t.casefold() for t in tags}]
            elif tag_match[1] != '设置标签':
                tags = existing + tags
            updated = await self.operations['tags'](site['id'], tags)
            return '标签已更新：' + ('、'.join('#'+tag for tag in updated['tags']) or '暂无标签') + '。在主页搜索标签即可找到这个网站。', [], None
        if remainder.strip() in ('标签','查看标签') and site:
            tags = [row['tag'] for row in self.store.all('SELECT tag FROM site_tags WHERE site_id=?', (site['id'],))]
            return '当前标签：' + ('、'.join(tags) or '暂无。可以说“打标签 张三，设计组”。'), [], None
        action, number = intent(remainder)
        if action == 'delete':
            return '永久删除需要二次确认。请在网站页点击“删除网站”，核对网站与数据范围，再勾选“我已确认删除”。仅发送对话不会执行删除。', [], None
        if action in ('home', 'new'):
            if pinned:
                return '请点击“所有网站”返回主页，或使用主页的“新建网站”按钮。这段对话会保留在当前网站里。', [], None
            self.store.execute('UPDATE conversations SET site_id=NULL WHERE id=?', (identifier,))
            return '好，直接描述你想创建的网站。也可以说“修改 /英文地址”继续一个已有网站。', [], None
        if action == 'help':
            return '描述需求即可创建网站。修改已有网站时说“修改 /英文地址”。\n在网站对话里，可以直接说“预览”“发布”“回到上个版本”“回滚到 v2”“归档”“恢复网站”“历史版本”或“下载版本”。', [], None
        if action == 'keep':
            return '好的，不执行发布、回滚或归档。你可以继续描述修改需求。', self.links(site) if site else [], None
        if action == 'clarify':
            return '这句话可能是在讨论功能，也可能是操作网站。若要执行操作，请直接说“发布”“归档”或“回滚到 v2”；若要改页面，请描述具体页面和改动。', [], None
        if not site:
            if action != 'build':
                return '先告诉我是哪个网站，例如“修改 /coffee”，再说你要做什么。', [], None
            slug_match = re.search(r'英文(?:网址名称|名称|名|地址)\s*(?:是|为|叫|[:：])?\s*[「“"]?([a-zA-Z][a-zA-Z0-9-]*)(?=$|[\s，。；」”",])', text)
            if not slug_match:
                return '请在主页点击“新建网站”并填写英文网址名称，例如 coffee。也可以在完整需求中注明“英文名 coffee”；不会再自动分配随机地址。', [], None
            slug = slug_match[1].lower()
            name_match = re.search(r'(?:名字叫|命名为|叫做|叫)[「“"\s]*([^，。；\n」”"]{1,30})', text)
            name = name_match[1].strip() if name_match else text.strip()[:24]
            site = await self.operations['create'](name, slug, text[:1000])
            self.store.execute('UPDATE conversations SET site_id=? WHERE id=?', (site['id'], identifier))
            try:
                job = await self.operations['build'](site['id'], text)
            except HTTPException as error:
                return f'已为你创建「{name}」。{error.detail}；连接好后把需求发给我即可开始。', self.links(site), None
            return f'已创建「{name}」，正在构建。你只需要记住下面两个地址。', self.links(site), job['id']
        if action == 'preview':
            return f'「{site["name"]}」的地址在这里。测试修改不会自动覆盖生产。' if not site['archived'] else '网站已归档。说“恢复网站”后两个地址会重新可用。', self.links(site), None
        if action == 'publish':
            if expected_beta is not None and expected_beta != site['beta_version']:
                raise HTTPException(409, '测试版本刚刚有更新。请先打开测试地址检查，再说“发布”。')
            await self.operations['publish'](site['id'], site['beta_version'])
            site['production_version'] = site['beta_version']
            return f'「{site["name"]}」已发布，生产地址现在就是刚才的测试版本。', self.links(site), None
        if action in ('archive', 'restore'):
            await self.operations['archive'](site['id'], action == 'archive')
            site['archived'] = action == 'archive'
            return ('网站已归档，两个地址暂时停止访问。对话与版本保留，随时可以说“恢复网站”。' if site['archived'] else '网站已恢复，原来的地址继续使用。'), self.links(site), None
        if action in ('history', 'rollback', 'download'):
            versions = self.store.all('SELECT * FROM versions WHERE site_id=? ORDER BY number DESC', (site['id'],))
            events = self.store.all("SELECT version_id FROM events WHERE site_id=? AND action IN ('publish','rollback') ORDER BY id DESC", (site['id'],))
            published = {event['version_id'] for event in events}
            if action == 'history':
                return '\n'.join(f"v{v['number']} · {'当前生产' if v['id']==site['production_version'] else '已发布过' if v['id'] in published else '测试版本'} · {v['created_at'][:16]}\n{v['summary'][:160]}" for v in versions[:20]), [], None
            if action == 'download':
                version = next(v for v in versions if v['id'] == (site['production_version'] or site['beta_version']))
                return f"这是 v{version['number']} 的网站产物归档。", [{'label':'下载 ZIP', 'url':f"/api/sites/{site['id']}/versions/{version['id']}/download"}], None
            previous = next((event['version_id'] for event in events if event['version_id'] != site['production_version']), None)
            target = next((v for v in versions if (v['number'] == number if number is not None else v['id'] == previous)), None)
            if not target:
                return '没有找到可回滚的版本。说“历史版本”可以查看已有版本。', [], None
            await self.operations['rollback'](site['id'], target['id'])
            return f"生产环境已回滚到 v{target['number']}，测试环境不受影响。", self.links(site), None
        if action in ('cancel', 'sync'):
            job = self.store.one('SELECT * FROM jobs WHERE site_id=? ORDER BY created_at DESC LIMIT 1', (site['id'],))
            if not job:
                return '这个网站还没有构建任务。', [], None
            await self.operations[action](site['id'], job['id'])
            return '已处理，任务状态会继续显示在对话里。', [], None
        job = await self.operations['build'](site['id'], text)
        return '收到，正在修改。完成后测试地址会自动更新，生产版本保持不变。', self.links(site), job['id']
