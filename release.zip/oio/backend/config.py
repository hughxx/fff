import os
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


@dataclass
class Config:
    data_dir: Path = field(default_factory=lambda: Path(os.getenv('OIO_DATA_DIR', ROOT / 'data')))
    agent_url: str = field(default_factory=lambda: os.getenv('CLOUDAGENT_URL', 'http://10.90.113.228:8800/api').rstrip('/'))
    agent_token: str = field(default_factory=lambda: os.getenv('CLOUDAGENT_TOKEN', ''))
    agent_account: str = field(default_factory=lambda: os.getenv('CLOUDAGENT_ACCOUNT_ID', ''))
    agent_model: str = field(default_factory=lambda: os.getenv('CLOUDAGENT_MODEL', ''))
    public_url: str = field(default_factory=lambda: os.getenv('OIO_PUBLIC_URL', '').rstrip('/'))
    poll_seconds: float = 3
    max_files: int = 1000
    max_bytes: int = 64 * 1024 * 1024
    python_runtime: bool = field(default_factory=lambda: os.getenv('OIO_PYTHON_RUNTIME', 'true').lower() == 'true')
    runtime_hosts: str = field(default_factory=lambda: os.getenv('CLOUDAGENT_RUNTIME_HOSTS', '{}'))
    runtime_port_min: int = field(default_factory=lambda: int(os.getenv('OIO_RUNTIME_PORT_MIN', '22000')))
    runtime_port_max: int = field(default_factory=lambda: int(os.getenv('OIO_RUNTIME_PORT_MAX', '22999')))
    runtime_start_timeout: float = 60
