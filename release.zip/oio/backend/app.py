import asyncio
import html
import mimetypes
import re
import sqlite3
import shutil
from collections import defaultdict
from contextlib import asynccontextmanager
from urllib.parse import urlsplit, quote
from typing import Literal

from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse, Response, StreamingResponse
from starlette.background import BackgroundTask
import httpx
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, StrictBool, field_validator

from .agent import AgentError, JobRunner
from .artifacts import inject_base, safe_path, save_version, version_zip
from .config import Config, ROOT
from .conversation import ConversationService
from .runtime import PythonRuntime, RuntimeError as PythonRuntimeError, MANIFEST
from .store import Store, now, uid

RESERVED = {'api', 'assets', 'static', 'admin', 'login', 'logout', 'health', 'docs', 'redoc',
            'openapi', 'favicon', 'robots', 'console', 'settings', 'websites'}
ACTIVE = "status IN ('queued','running')"


class SiteInput(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    slug: str = Field(min_length=2, max_length=48)
    description: str = Field(default='', max_length=1000)

    @field_validator('name')
    @classmethod
    def name_nonempty(cls, value):
        if not value.strip():
            raise ValueError('名称不能为空')
        return value.strip()

    @field_validator('slug')
    @classmethod
    def valid_slug(cls, value):
        value = value.lower().strip()
        if not re.fullmatch(r'[a-z][a-z0-9]*(?:-[a-z0-9]+)*', value):
            raise ValueError('URI 必须以英文字母开头，仅包含小写字母、数字和单个中划线')
        if value in RESERVED or value.endswith('-beta'):
            raise ValueError('此 URI 为系统或测试环境保留')
        return value


class PromptInput(BaseModel):
    prompt: str = Field(min_length=1, max_length=30000)

    @field_validator('prompt')
    @classmethod
    def valid_prompt(cls, value):
        if not value.strip() or '\0' in value:
            raise ValueError('需求不能为空或包含 NUL 字符')
        return value.strip()


class PublishInput(BaseModel):
    version_id: str = Field(min_length=1, max_length=100)
    note: str = Field(default='', max_length=1000)


class ArchiveInput(BaseModel):
    archived: bool


class DeleteInput(BaseModel):
    confirmed: StrictBool
    confirm_slug: str


class TagsInput(BaseModel):
    tags: list[str] = Field(max_length=24)

    @field_validator('tags')
    @classmethod
    def normalize_tags(cls, values):
        tags = {}
        for value in values:
            value = value.strip().lstrip('#')
            if not value or len(value) > 24 or re.search(r'[\s<>\x00-\x1f]', value):
                raise ValueError('标签为 1–24 个字符，不含空格或尖括号')
            tags.setdefault(value.casefold(), value)
        if len(tags) > 12:
            raise ValueError('每个网站最多 12 个标签')
        return list(tags.values())


class AgentSettings(BaseModel):
    url: str = Field(default='', max_length=1000)
    account: str = Field(default='', max_length=128)
    model: str = Field(default='', max_length=128)

    @field_validator('url')
    @classmethod
    def valid_url(cls, value):
        value = value.strip().rstrip('/')
        if not value:
            return value
        parsed = urlsplit(value)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError('请填写有效的 HTTP(S) API 地址，不包含账号密码或查询参数')
        return value


class ChatInput(PromptInput):
    request_id: str = Field(min_length=8, max_length=100, pattern=r'^[a-zA-Z0-9_-]+$')
    expected_beta: str | None = Field(default=None, max_length=100)


def create_app(config=None, agent_factory=None, runtime_factory=None):
    config = config or Config()
    store = Store(config.data_dir)
    runtime = (runtime_factory or PythonRuntime)(store, config)
    runner = JobRunner(store, config, agent_factory, runtime)
    if isinstance(runtime, PythonRuntime):
        runtime.agent_factory = runner.factory
    deploy_locks = defaultdict(asyncio.Lock)

    @asynccontextmanager
    async def lifespan(app):
        for job in store.all(f'SELECT id FROM jobs WHERE {ACTIVE}'):
            runner.start(job['id'])
        yield
        await runner.shutdown()

    app = FastAPI(title='即创 InstaSite', version='0.3.8', lifespan=lifespan,
                  docs_url=None, redoc_url=None, openapi_url=None)
    app.state.store, app.state.runner, app.state.config = store, runner, config
    app.state.runtime = runtime
    app.state.proxy_transport = None

    @app.exception_handler(PythonRuntimeError)
    async def runtime_error(request, error):
        return JSONResponse({'detail':str(error)}, status_code=503)

    def get_site(site_id):
        site = store.one('SELECT * FROM sites WHERE id=?', (site_id,))
        if not site:
            raise HTTPException(404, '网站不存在')
        return site

    def get_version(site_id, version_id):
        version = store.one('SELECT * FROM versions WHERE site_id=? AND id=?', (site_id, version_id))
        if not version:
            raise HTTPException(404, '版本不存在或不属于此网站')
        return version

    def active_job(site_id):
        return store.one(f'SELECT * FROM jobs WHERE site_id=? AND {ACTIVE}', (site_id,))

    @app.middleware('http')
    async def boundary(request, call_next):
        path = request.url.path
        if path.startswith('/api/') and request.method not in ('GET', 'HEAD', 'OPTIONS'):
            if request.headers.get('x-oio-request') != '1' or request.headers.get('origin') == 'null':
                return JSONResponse({'detail': '无效请求来源'}, 403)
            origin = request.headers.get('origin')
            if origin and origin.rstrip('/') != (config.public_url or str(request.base_url).rstrip('/')):
                return JSONResponse({'detail': '禁止跨站管理请求'}, 403)
            body = bytearray()
            async for chunk in request.stream():
                body.extend(chunk)
                if len(body) > 256 * 1024:
                    return JSONResponse({'detail': '请求内容过大'}, 413)
            request._body = bytes(body)
        response = await call_next(request)
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Referrer-Policy'] = 'no-referrer'
        if path.startswith('/api/'):
            response.headers['Cache-Control'] = 'no-store'
            response.headers['X-Frame-Options'] = 'DENY'
        elif path == '/' or path.startswith('/_console/'):
            response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"
        return response

    @app.get('/api/health')
    async def health():
        store.one('SELECT 1')
        return {'status': 'ok', 'version': '0.3.8'}

    @app.get('/api/settings')
    async def settings():
        return {**runner.settings(), 'token_configured': bool(config.agent_token), 'version': '0.3.8'}

    @app.put('/api/settings')
    async def update_settings(body: AgentSettings):
        if store.one(f'SELECT id FROM jobs WHERE {ACTIVE}'):
            raise HTTPException(409, '请等待当前 AI 任务结束后修改连接设置')
        if body.url != runner.settings()['url'] and store.one('SELECT id FROM sites WHERE workspace_id IS NOT NULL'):
            raise HTTPException(409, '已有网站关联此底座，切换服务地址需要先迁移远程工作区。可在同地址下更新账号和模型。')
        store.set_setting('agent', body.model_dump())
        return {'success': True}

    @app.post('/api/settings/check')
    async def check_agent():
        if not runner.settings()['url']:
            raise HTTPException(400, '请先保存 CodeAgent API 地址')
        agent = runner.factory()
        try:
            result = await agent.request('GET', 'workspaces', params={'page_size': 1})
            return {'success': True, 'workspaces': result.get('total', 0)}
        except AgentError as error:
            raise HTTPException(502, str(error)) from error
        finally:
            await agent.close()

    def site_list(q, sort, public=False):
        order = 'visits DESC, updated_at DESC' if sort == 'visits' else 'updated_at DESC'
        fields = 'id,slug,name,description,visits,updated_at,production_version' if public else '*'
        where = 'WHERE archived=0 AND production_version IS NOT NULL' if public else ''
        rows = store.all(f'SELECT {fields} FROM sites {where} ORDER BY {order}')
        for site in rows:
            site['tags'] = [row['tag'] for row in store.all('SELECT tag FROM site_tags WHERE site_id=? ORDER BY tag', (site['id'],))]
        query = q[:200].lstrip('#').casefold()
        return [site for site in rows if query in (site['name'] + ' ' + site['slug'] + ' ' + site['description'] + ' ' + ' '.join(site['tags'])).casefold()]

    @app.get('/api/catalog')
    async def catalog(q: str = '', sort: Literal['visits', 'updated'] = 'visits'):
        return {'items': site_list(q, sort, True)}

    @app.get('/api/sites')
    async def sites(q: str = '', sort: Literal['visits', 'updated'] = 'visits'):
        rows = site_list(q, sort)
        for site in rows:
            site['active_job'] = active_job(site['id'])
        return {'items': rows}

    @app.post('/api/sites', status_code=201)
    async def create_site(body: SiteInput):
        site_id, timestamp = uid('site'), now()
        try:
            store.execute('INSERT INTO sites(id,slug,name,description,created_at,updated_at) VALUES (?,?,?,?,?,?)',
                          (site_id, body.slug, body.name, body.description, timestamp, timestamp))
        except sqlite3.IntegrityError as error:
            raise HTTPException(409, '此全局 URI 已被占用，包括已归档的网站') from error
        name = html.escape(body.name)
        initial = f'''<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{name}</title><style>body{{margin:0;background:#f5f5f0;color:#26352d;font-family:system-ui;display:grid;place-items:center;min-height:100vh}}main{{max-width:600px;padding:48px}}h1{{font-size:48px}}p{{line-height:1.8;color:#68746c}}</style></head><body><main><h1>{name}</h1><p>{html.escape(body.description) or '一个新网站，即将与你见面。'}</p><p>内容正在准备中。</p></main></body></html>'''
        save_version(store, config, site_id, {'index.html': initial.encode()}, '初始页面：等待 AI 构建')
        return get_site(site_id)

    @app.get('/api/sites/{site_id}')
    async def site_detail(site_id: str):
        site = get_site(site_id)
        site['tags'] = [row['tag'] for row in store.all('SELECT tag FROM site_tags WHERE site_id=? ORDER BY tag', (site_id,))]
        site['versions'] = store.all('SELECT * FROM versions WHERE site_id=? ORDER BY number DESC', (site_id,))
        site['messages'] = store.all('SELECT * FROM messages WHERE site_id=? ORDER BY id', (site_id,))
        site['jobs'] = store.all('SELECT * FROM jobs WHERE site_id=? ORDER BY created_at DESC LIMIT 30', (site_id,))
        site['events'] = store.all('SELECT * FROM events WHERE site_id=? ORDER BY id DESC LIMIT 100', (site_id,))
        site['runtimes'] = store.all('SELECT * FROM workspace_runtimes WHERE site_id=? ORDER BY updated_at DESC', (site_id,))
        return site

    @app.post('/api/sites/{site_id}/jobs', status_code=202)
    async def create_job(site_id: str, body: PromptInput):
        site = get_site(site_id)
        if deploy_locks[site_id].locked():
            raise HTTPException(409, '正在切换网站版本，请稍后再提交需求')
        if site['archived']:
            raise HTTPException(409, '请先恢复已归档网站')
        if not runner.settings()['url']:
            raise HTTPException(400, '请在平台设置中连接 CodeAgent，再提交 AI 需求')
        job_id, timestamp = uid('job'), now()
        try:
            with store.connect() as db:
                db.execute('INSERT INTO jobs(id,site_id,prompt,status,stage,created_at,updated_at) VALUES (?,?,?,?,?,?,?)',
                           (job_id, site_id, body.prompt, 'queued', 'queued', timestamp, timestamp))
                db.execute('INSERT INTO messages(site_id,job_id,role,content,created_at) VALUES (?,?,?,?,?)',
                           (site_id, job_id, 'user', body.prompt, timestamp))
        except sqlite3.IntegrityError as error:
            raise HTTPException(409, '此网站已有 AI 任务正在执行') from error
        runner.start(job_id)
        return store.one('SELECT * FROM jobs WHERE id=?', (job_id,))

    @app.post('/api/sites/{site_id}/jobs/{job_id}/cancel')
    async def cancel_job(site_id: str, job_id: str):
        site = get_site(site_id)
        job = store.one('SELECT * FROM jobs WHERE id=? AND site_id=?', (job_id, site_id))
        if not job:
            raise HTTPException(404, '任务不存在')
        if job['status'] not in ('queued', 'running'):
            return {'success': True}
        if job['stage'] == 'deploying':
            raise HTTPException(409, '正在构建或启动后端容器，请等待启动检查结束')
        if job['status'] == 'running' and not job['remote_task_id']:
            raise HTTPException(409, '正在创建工作区或提交任务，请稍后取消')
        if job['remote_task_id']:
            agent = runner.factory()
            try:
                await agent.request('POST', f"sessions/{site['session_id']}/tasks/{job['remote_task_id']}/cancel")
            except AgentError as error:
                raise HTTPException(502, str(error)) from error
            finally:
                await agent.close()
        task = runner.tasks.get(job_id)
        if task:
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
        # Collection could have completed while the cancellation request was in flight.
        if store.one('SELECT status FROM jobs WHERE id=?', (job_id,))['status'] in ('queued', 'running'):
            runner.update(job_id, status='cancelled', stage='cancelled', error='用户取消了任务')
            store.execute('INSERT INTO messages(site_id,job_id,role,content,created_at) VALUES (?,?,?,?,?)',
                          (site_id, job_id, 'system', '任务已取消，现有测试环境与生产环境保持原版本。', now()))
        return {'success': True}

    @app.post('/api/sites/{site_id}/jobs/{job_id}/retry-sync')
    async def retry_sync(site_id: str, job_id: str):
        site = get_site(site_id)
        job = store.one('SELECT * FROM jobs WHERE id=? AND site_id=?', (job_id, site_id))
        latest = store.one('SELECT id FROM jobs WHERE site_id=? ORDER BY created_at DESC LIMIT 1', (site_id,))
        if site['archived'] or not job or job['status'] != 'failed' or job['stage'] not in ('collecting','deploying') or not job['remote_task_id']:
            raise HTTPException(409, '只有产物收集或后端启动失败的任务可重新同步')
        if not latest or latest['id'] != job_id:
            raise HTTPException(409, '此任务之后已有新的需求，远程产物可能已改变，不能再次同步旧任务')
        try:
            runner.update(job_id, status='running', error=None)
        except sqlite3.IntegrityError as error:
            raise HTTPException(409, '已有任务正在执行') from error
        runner.start(job_id)
        return {'success': True}

    async def publish(site_id, body, rollback=False):
        if deploy_locks[site_id].locked():
            raise HTTPException(409, '已有版本操作进行中')
        async with deploy_locks[site_id]:
            return await publish_locked(site_id, body, rollback)

    async def publish_locked(site_id, body, rollback=False):
        site = get_site(site_id)
        if site['archived']:
            raise HTTPException(409, '请先恢复已归档网站')
        if active_job(site_id):
            raise HTTPException(409, '请等待 AI 任务结束后发布')
        version = get_version(site_id, body.version_id)
        if not (config.data_dir / 'versions' / version['id'] / 'index.html').is_file():
            raise HTTPException(409, '版本文件缺失，请恢复备份')
        if not rollback and site['beta_version'] != version['id']:
            raise HTTPException(409, '测试环境已更新，请刷新后发布最新版本')
        if rollback and not store.one("SELECT id FROM events WHERE site_id=? AND version_id=? AND action IN ('publish','rollback')", (site_id, version['id'])):
            raise HTTPException(409, '只能回滚到曾经发布过的版本')
        if site['production_version'] == version['id']:
            return {'success': True, 'version_id': version['id']}
        await runtime.prepare(site, 'production', version['id'])
        with store.connect() as db:
            db.execute('UPDATE sites SET production_version=?,updated_at=? WHERE id=?', (version['id'], now(), site_id))
            db.execute('INSERT INTO events(site_id,action,version_id,note,created_at) VALUES (?,?,?,?,?)',
                       (site_id, 'rollback' if rollback else 'publish', version['id'], body.note or f"{'回滚' if rollback else '发布'} v{version['number']}", now()))
        await runtime.stop_others(site_id, 'production', version['id'])
        return {'success': True, 'version_id': version['id']}

    @app.post('/api/sites/{site_id}/publish')
    async def publish_site(site_id: str, body: PublishInput):
        return await publish(site_id, body)

    @app.post('/api/sites/{site_id}/rollback')
    async def rollback_site(site_id: str, body: PublishInput):
        return await publish(site_id, body, True)

    @app.patch('/api/sites/{site_id}/archive')
    async def archive_site(site_id: str, body: ArchiveInput):
        site = get_site(site_id)
        if not body.archived and store.one('SELECT site_id FROM site_deletions WHERE site_id=?', (site_id,)):
            raise HTTPException(409, '此网站已开始永久删除，请重试删除，不能恢复可能已清理的数据。')
        if active_job(site_id) or deploy_locks[site_id].locked():
            raise HTTPException(409, '请等待 AI 任务结束后归档')
        async with deploy_locks[site_id]:
            if not body.archived:
                for environment, version in (('beta',site['beta_version']),('production',site['production_version'])):
                    if version:
                        await runtime.prepare(site, environment, version)
            with store.connect() as db:
                db.execute('UPDATE sites SET archived=?,updated_at=? WHERE id=?', (int(body.archived), now(), site_id))
                db.execute('INSERT INTO events(site_id,action,note,created_at) VALUES (?,?,?,?)',
                           (site_id, 'archive' if body.archived else 'restore', '归档并停止访问' if body.archived else '恢复网站访问', now()))
            if body.archived:
                results = await asyncio.gather(runtime.stop_others(site_id, 'beta'), runtime.stop_others(site_id, 'production'), return_exceptions=True)
                for result in results:
                    if isinstance(result, Exception):
                        raise result
        return {'success': True}

    @app.delete('/api/sites/{site_id}')
    async def delete_site(site_id: str, body: DeleteInput):
        site = get_site(site_id)
        if body.confirmed is not True or body.confirm_slug != site['slug']:
            raise HTTPException(400, '请确认网站英文名称，并勾选“我已确认删除”。')
        if active_job(site_id) or deploy_locks[site_id].locked():
            raise HTTPException(409, '网站正在构建或发布，请等待完成或取消任务后再删除。')
        async with conversations.lock, deploy_locks[site_id]:
            site = get_site(site_id)
            if active_job(site_id):
                raise HTTPException(409, '请等待网站任务结束后再删除。')
            if site['workspace_id'] and store.one('SELECT id FROM sites WHERE workspace_id=? AND id!=?', (site['workspace_id'],site_id)):
                raise HTTPException(409, '工作区还关联其他网站，不能删除。')
            versions_root = (config.data_dir/'versions').resolve()
            paths = []
            for version in store.all('SELECT id FROM versions WHERE site_id=?', (site_id,)):
                path = config.data_dir/'versions'/version['id']
                if path.is_symlink() or path.resolve().parent != versions_root:
                    raise HTTPException(409, '版本目录异常，已停止删除。')
                paths.append(path)
            with store.connect() as db:
                db.execute('UPDATE sites SET archived=1,updated_at=? WHERE id=?', (now(),site_id))
                db.execute('INSERT OR IGNORE INTO site_deletions VALUES (?,?)', (site_id,now()))
            results = await asyncio.gather(runtime.stop_others(site_id,'beta'), runtime.stop_others(site_id,'production'), return_exceptions=True)
            if any(isinstance(result,Exception) for result in results):
                raise HTTPException(503, '网站已停止访问，但远程进程停止尚未确认，未删除工作区。请恢复连接后重试删除。')
            if site['workspace_id']:
                agent = runner.factory()
                workspace_path = 'workspaces/'+quote(site['workspace_id'],safe='')
                try:
                    response = await agent.client.get(workspace_path)
                    if response.status_code != 404:
                        response.raise_for_status()
                        # Re-read page one after removing each batch, so pagination cannot skip sessions.
                        for _ in range(100):
                            listing = await agent.request('GET','sessions',params={'workspace_id':site['workspace_id'],'page':1,'page_size':200})
                            items = listing.get('items',[])
                            if not items:
                                break
                            for session in items:
                                if session.get('workspace_id') != site['workspace_id']:
                                    raise ValueError('Workspace session mismatch')
                                if session.get('status') in ('running','deleting'):
                                    raise ValueError('Workspace session is busy')
                                deleted = await agent.client.delete('sessions/'+quote(session['session_id'],safe=''))
                                if deleted.status_code != 404:
                                    deleted.raise_for_status()
                        else:
                            raise ValueError('Too many workspace sessions')
                        response = await agent.client.delete(workspace_path)
                        if response.status_code != 404:
                            response.raise_for_status()
                        check = await agent.client.get(workspace_path)
                        if check.status_code != 404:
                            raise ValueError('Workspace deletion not confirmed')
                except Exception as error:
                    raise HTTPException(503, '远程工作区删除未完成；网站保持下线，可能已有部分数据被清理。请重试删除，不会伪报成功。') from error
                finally:
                    await agent.close()
            def remove_files():
                for path in paths:
                    if path.exists():
                        shutil.rmtree(path)
                env_file = config.data_dir/'runtime-env'/(site['slug']+'.json')
                if env_file.is_symlink() or env_file.resolve().parent != (config.data_dir/'runtime-env').resolve():
                    raise ValueError('Invalid environment file path')
                env_file.unlink(missing_ok=True)
            try:
                await asyncio.to_thread(remove_files)
            except Exception as error:
                raise HTTPException(503, '本地版本清理未完成，请重试删除。') from error
            with store.connect() as db:
                scope = 'SELECT id FROM conversations WHERE site_id=?'
                db.execute(f'DELETE FROM chat_turns WHERE conversation_id IN ({scope})',(site_id,))
                db.execute(f'DELETE FROM chat_messages WHERE conversation_id IN ({scope}) OR job_id IN (SELECT id FROM jobs WHERE site_id=?)',(site_id,site_id))
                db.execute('DELETE FROM site_threads WHERE site_id=?',(site_id,))
                db.execute('DELETE FROM conversations WHERE site_id=?',(site_id,))
                for table in ('workspace_runtimes','runtimes','messages','events','site_tags','jobs','versions','site_deletions'):
                    db.execute(f'DELETE FROM {table} WHERE site_id=?',(site_id,))
                db.execute('DELETE FROM sites WHERE id=?',(site_id,))
            return {'success':True}

    @app.get('/api/sites/{site_id}/versions/{version_id}/download')
    async def download_version(site_id: str, version_id: str):
        site = get_site(site_id)
        version = get_version(site_id, version_id)
        content = await asyncio.to_thread(version_zip, config, version)
        return Response(content, media_type='application/zip', headers={'Content-Disposition': f'attachment; filename="{site["slug"]}-v{version["number"]}.zip"'})

    @app.put('/api/sites/{site_id}/tags')
    async def update_tags(site_id: str, body: TagsInput):
        get_site(site_id)
        with store.connect() as db:
            db.execute('DELETE FROM site_tags WHERE site_id=?', (site_id,))
            db.executemany('INSERT INTO site_tags VALUES (?,?)', [(site_id, tag) for tag in body.tags])
        return {'tags':body.tags}

    async def chat_tags(site_id, tags):
        from pydantic import ValidationError
        try:
            return await update_tags(site_id, TagsInput(tags=tags))
        except ValidationError as error:
            raise HTTPException(422, '每个网站最多 12 个标签，每个 1–24 字符，不含空格或尖括号。') from error

    async def chat_create(name, slug, description):
        return await create_site(SiteInput(name=name, slug=slug, description=description))

    async def chat_build(site_id, prompt):
        return await create_job(site_id, PromptInput(prompt=prompt))

    async def chat_publish(site_id, version_id):
        return await publish(site_id, PublishInput(version_id=version_id))

    async def chat_rollback(site_id, version_id):
        return await publish(site_id, PublishInput(version_id=version_id), True)

    async def chat_archive(site_id, archived):
        return await archive_site(site_id, ArchiveInput(archived=archived))

    conversations = ConversationService(store, {
        'create':chat_create, 'build':chat_build, 'publish':chat_publish, 'rollback':chat_rollback,
        'archive':chat_archive, 'cancel':cancel_job, 'sync':retry_sync, 'tags':chat_tags,
    })

    @app.post('/api/conversations')
    async def new_conversation():
        return conversations.read(conversations.create())

    @app.get('/api/conversations/{conversation_id}')
    async def read_conversation(conversation_id: str):
        return conversations.read(conversation_id)

    @app.post('/api/sites/{site_id}/conversation')
    async def site_conversation(site_id: str):
        get_site(site_id)
        async with conversations.lock:
            thread = store.one('SELECT conversation_id FROM site_threads WHERE site_id=?', (site_id,))
            if thread:
                return conversations.read(thread['conversation_id'])
            row = store.one('SELECT id FROM conversations WHERE site_id=? ORDER BY created_at DESC LIMIT 1', (site_id,))
            identifier = row['id'] if row else conversations.create(site_id)
            store.execute('INSERT INTO site_threads VALUES (?,?)', (site_id, identifier))
            return conversations.read(identifier)

    @app.post('/api/conversations/{conversation_id}/messages')
    async def send_message(conversation_id: str, body: ChatInput):
        return await conversations.send(conversation_id, body.request_id, body.prompt, body.expected_beta)

    app.mount('/_console', StaticFiles(directory=ROOT / 'frontend'), name='console')

    def routed_site(prefix):
        beta = prefix.endswith('-beta')
        site = store.one('SELECT * FROM sites WHERE slug=?', (prefix[:-5] if beta else prefix,))
        if not site or site['archived']:
            raise HTTPException(404, '网站不存在或已归档')
        return site, 'beta' if beta else 'production'

    @app.api_route('/{prefix}/api/{resource:path}', methods=['GET','POST','PUT','PATCH','DELETE','HEAD','OPTIONS'])
    async def proxy_python(prefix: str, resource: str, request: Request):
        site, environment = routed_site(prefix)
        async with deploy_locks[site['id']]:
            site, environment = routed_site(prefix)
            target = await runtime.target(site, environment)
        if not target:
            raise HTTPException(404, '此网站尚未启用 Python 后端')
        cors = {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,POST,PUT,PATCH,DELETE,HEAD,OPTIONS',
                'Access-Control-Allow-Headers':'Authorization,Content-Type,X-Requested-With','Cache-Control':'no-store'}
        if request.method == 'OPTIONS':
            return Response(status_code=204, headers=cors)
        excluded = {'host','connection','keep-alive','transfer-encoding','upgrade','cookie','x-oio-request','content-length','x-forwarded-host','x-forwarded-for','x-forwarded-proto'}
        excluded.update(request.headers.get('connection','').lower().split(','))
        headers = {k:v for k,v in request.headers.items() if k.lower() not in excluded}
        headers['X-Forwarded-Prefix'] = '/'+prefix
        client = httpx.AsyncClient(timeout=httpx.Timeout(None,connect=10), trust_env=False, transport=app.state.proxy_transport)
        try:
            url = target + '/api/' + resource
            if request.url.query:
                url += '?' + request.url.query
            upstream = await client.send(client.build_request(request.method, url, headers=headers, content=request.stream()), stream=True)
        except httpx.HTTPError as error:
            await client.aclose()
            raise HTTPException(502, '网站后端暂时不可用，请稍后重试') from error
        response_headers = {k:v for k,v in upstream.headers.items() if k.lower() not in {'connection','keep-alive','transfer-encoding','content-encoding','content-length','set-cookie','access-control-allow-origin','access-control-allow-credentials','content-security-policy'}}
        response_headers.update(cors)
        response_headers['Content-Security-Policy'] = "sandbox allow-scripts allow-forms allow-downloads; worker-src 'none'"
        if response_headers.get('location','').startswith('/') and not response_headers['location'].startswith('//'):
            response_headers['location'] = '/'+prefix+response_headers['location']
        async def close():
            await upstream.aclose()
            await client.aclose()
        return StreamingResponse(upstream.aiter_bytes(),status_code=upstream.status_code,headers=response_headers,background=BackgroundTask(close))

    @app.websocket('/{prefix}/api/{resource:path}')
    async def proxy_websocket(websocket: WebSocket, prefix: str, resource: str):
        from websockets.asyncio.client import connect
        try:
            site, environment = routed_site(prefix)
            async with deploy_locks[site['id']]:
                site, environment = routed_site(prefix)
                target = await runtime.target(site, environment)
            if not target:
                await websocket.close(code=1008)
                return
            url = target.replace('http://','ws://',1)+'/api/'+resource
            if websocket.url.query:
                url += '?'+websocket.url.query
            async with connect(url, subprotocols=websocket.scope.get('subprotocols') or None, proxy=None,
                               additional_headers={'X-Forwarded-Prefix':'/'+prefix}, max_size=2**20) as remote:
                await websocket.accept(subprotocol=remote.subprotocol)
                async def to_remote():
                    while True:
                        message = await websocket.receive()
                        if message['type'] == 'websocket.disconnect':
                            break
                        await remote.send(message.get('text') if message.get('text') is not None else message['bytes'])
                async def to_browser():
                    async for message in remote:
                        await (websocket.send_text(message) if isinstance(message,str) else websocket.send_bytes(message))
                tasks = [asyncio.create_task(to_remote()),asyncio.create_task(to_browser())]
                try:
                    await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
                finally:
                    for task in tasks:
                        task.cancel()
                    await asyncio.gather(*tasks,return_exceptions=True)
        except Exception:
            try:
                await websocket.close(code=1011)
            except Exception:
                pass

    @app.get('/')
    async def index():
        return FileResponse(ROOT / 'frontend' / 'index.html', headers={'Cache-Control': 'no-cache'})

    @app.get('/{prefix}')
    async def add_slash(prefix: str, request: Request):
        slug = prefix[:-5] if prefix.endswith('-beta') else prefix
        if not store.one('SELECT id FROM sites WHERE slug=?', (slug,)):
            raise HTTPException(404, '网站不存在')
        suffix = '?' + request.url.query if request.url.query else ''
        return RedirectResponse('/' + prefix + '/' + suffix, status_code=307)

    @app.get('/{prefix}/{resource:path}')
    async def serve_site(prefix: str, resource: str, request: Request):
        if resource.split('/')[0].lower() == 'backend' or resource.lower().rstrip('/') == MANIFEST:
            raise HTTPException(404, '文件不存在')
        beta = prefix.endswith('-beta')
        slug = prefix[:-5] if beta else prefix
        site = store.one('SELECT * FROM sites WHERE slug=?', (slug,))
        if not site or site['archived']:
            raise HTTPException(404, '网站不存在或已归档')
        version = site['beta_version' if beta else 'production_version']
        if not version:
            raise HTTPException(404, '网站尚未发布')
        root = (config.data_dir / 'versions' / version).resolve()
        try:
            relative = safe_path(resource.rstrip('/') or 'index.html')
        except ValueError as error:
            raise HTTPException(404, '文件不存在') from error
        target = root.joinpath(*relative.parts).resolve()
        if not target.is_relative_to(root):
            raise HTTPException(404, '文件不存在')
        if target.is_dir():
            target = target / 'index.html'
        if not target.is_file():
            if relative.suffix:
                raise HTTPException(404, '资源不存在')
            target = root / 'index.html'
        headers = {
            'Cache-Control': 'no-store' if beta else 'no-cache',
            'Content-Security-Policy': "sandbox allow-scripts allow-forms allow-popups allow-downloads; object-src 'none'; frame-src 'none'; worker-src 'none'; base-uri 'self'; frame-ancestors 'self'",
            'X-OIO-Version': version,
            # Sandboxed ES modules have an opaque origin; static bytes are readable without credentials.
            'Access-Control-Allow-Origin': '*',
        }
        if target.suffix.lower() == '.html':
            destination = request.headers.get('sec-fetch-dest', '')
            human = not re.search(r'bot|spider|crawler|preview|prefetch', request.headers.get('user-agent', ''), re.I)
            navigation = destination == 'document' or (not destination and 'text/html' in request.headers.get('accept', ''))
            if not beta and human and navigation and request.headers.get('purpose') != 'prefetch' and request.headers.get('sec-purpose') != 'prefetch':
                store.execute('UPDATE sites SET visits=visits+1 WHERE id=?', (site['id'],))
            return Response(inject_base(target.read_bytes(), prefix), media_type='text/html', headers=headers)
        mime = {'.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css'}.get(target.suffix.lower()) or mimetypes.guess_type(target)[0] or 'application/octet-stream'
        return FileResponse(target, media_type=mime, headers=headers)

    return app


app = create_app()
