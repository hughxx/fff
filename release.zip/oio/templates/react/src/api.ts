/** Same client for the development proxy, beta and production. No cookies required. */
export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  if (!/^api\//.test(path) || path.split('/').includes('..')) {
    throw new Error('Use a relative api/... endpoint');
  }
  const headers = new Headers(options.headers);
  if (typeof options.body === 'string' && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }
  const response = await fetch((window.OIO_BASE_PATH || '/') + path, {
    ...options, headers, credentials: 'omit',
  });
  if (!response.ok) {
    const body = await response.json().catch(() => null);
    throw new Error(typeof body?.detail === 'string' ? body.detail : `Request failed (${response.status})`);
  }
  return response.status === 204 ? undefined as T : response.json();
}
