"""Enable the bundled Python backend without replacing existing application files."""
import shutil
from pathlib import Path


def enable(root):
    source = root / 'python-example'
    if not (source / 'oio-runtime.json').is_file():
        raise RuntimeError('Missing python-example scaffold')
    for file in sorted(source.rglob('*')):
        if not file.is_file() or '__pycache__' in file.parts or file.suffix == '.pyc':
            continue
        target = root / file.relative_to(source)
        target.parent.mkdir(parents=True, exist_ok=True)
        try:
            with target.open('xb') as output, file.open('rb') as content:
                shutil.copyfileobj(content, output)
        except FileExistsError:
            continue


if __name__ == '__main__':
    enable(Path(__file__).resolve().parents[1])
    print('Python backend enabled; existing files preserved.')
