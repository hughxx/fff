# Website scaffold

React + TypeScript + Vite + React Router is already installed as source in this workspace.
Reuse the provided structure and lockfile; implement the requested product rather than
recreating the toolchain. Run `npm ci` once; reuse node_modules for subsequent builds.
Run `npm ci` again if dependencies or the lockfile changed. Always run `npm run build`.

## Python backend (only when required)

Run `python3 scripts/enable_backend.py` from the workspace root. It copies the bundled
FastAPI + SQLite starter into `backend/` and enables `oio-runtime.json`, without
overwriting existing files. The initial notes API is a working example, not the final
product: adapt its data model and endpoints to the user requirements.

- `backend/main.py`: health check and persistent notes list/create endpoints.
- `backend/requirements.txt`: Python 3.10 compatible pinned dependencies.
- `oio-runtime.json`: platform deployment entrypoint, health check and assigned port.
- `src/api.ts`: typed JSON requests using the current website's beta/production prefix.

Example frontend call: `api<{id: number; text: string}[]>('api/notes')`.
JSON write: `api('api/notes', {method: 'POST', body: JSON.stringify({text: 'Hello'})})`.
Handle loading, errors and empty results in the product UI.

For local development only, install backend dependencies in a virtual environment,
then run `python -m uvicorn main:app --app-dir backend --host 127.0.0.1 --port 18749`.
Run `npm run dev`; Vite proxies `/api` to that local backend (including WebSockets).
The platform handles deployed processes: do not launch production services yourself.
Use OIO_DATA_DIR for persistent data; never put business data in dist/ or backend/.
Beta and production databases remain separate. Do not overwrite existing business data.

Pure frontend websites need no Python process. Keep the backend disabled unless needed.
Existing websites retain their current framework and code. Flask/Django and other
Python servers remain supported through the runtime manifest.
