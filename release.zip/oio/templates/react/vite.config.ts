import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The same build is served under /uri/ and /uri-beta/, including nested routes.
export default defineConfig({ plugins: [react()], base: './', server: { proxy: { '/api': { target: 'http://127.0.0.1:18749', ws: true } } }, build: { outDir: 'dist', emptyOutDir: true } });
