# 免 Docker 部署与运维

## 启动

Linux 安装 Python 3.10+、venv/pip、unzip。解压 release.zip，执行 bash start.sh。首次安装依赖需要网络；启动器读取 .env，不把内容作为 shell 执行。默认 18743，备选 18744、28743。--port 仅尝试指定端口，--ports 接受逗号分隔备选。绑定成功的 socket 直接交给 Uvicorn，避免检查后又被其他进程抢占。

默认前台运行，Ctrl+C 停止。需要后台可以使用 README 的 nohup 命令；oio.pid 是启动进程 PID，停止前先确认 ps -p 所显示的命令确为本实例，避免旧 PID 复用。长期使用推荐 systemd。

在 /etc/systemd/system/oio.service 保存（替换 User 和路径）：

```ini
[Unit]
Description=OIO website gateway
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=oio
WorkingDirectory=/opt/oio
ExecStart=/opt/oio/.venv/bin/python /opt/oio/scripts/serve.py
Restart=on-failure
RestartSec=3
UMask=0077

[Install]
WantedBy=multi-user.target
```

先运行一次 bash start.sh 安装依赖，Ctrl+C 退出，再启动 systemd：

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now oio
sudo journalctl -u oio -f
```

HTTPS 代理转发至网关端口，支持 WebSocket Upgrade 和流式响应，设置 OIO_PUBLIC_URL 为实际域名、OIO_SECURE_COOKIE=true。平台只运行单 worker。

## CloudAgent 节点

已内置 http://10.90.113.228:8800/api，设置页可覆盖。节点需要 Linux /proc、Python 3.12、venv/pip、Node 22.12+、npm 和可用模型账号。接口以 USER_API.md 为准，使用 files/upload、commands、command-tasks 和会话任务，不依赖未文档化的端口转发接口。

后台服务通过直接节点端口访问，因此 OIO 到节点 22000–22999 必须可达；限制该范围只接受网关主机访问。默认探测工作区节点地址；特殊网络配置 CLOUDAGENT_RUNTIME_HOSTS，例如 {"node-01":"10.90.113.228"}。端口范围可通过 OIO_RUNTIME_PORT_MIN / MAX 调整。

不能仅凭工作区存在认为操作系统隔离成立。节点服务用户可访问的文件同样可能被工作区命令访问；只给可信使用者共享管理密码。

## 查看与下线

对话“下线”或“归档”会关闭生产和测试地址，并停止两个环境的远程服务。数据与版本保留。对话“恢复网站”会启动原版本。平台暂停不等于微网站进程停止：关闭 OIO 后工作区守护进程继续运行，需要下线请先在对话操作。

通过已登录的 GET /api/sites/{site_id} 查看 runtimes：工作区 ID、部署任务 ID、守护与业务 PID、启动标识、端口、状态、目录。底座命令任务记录用于排查依赖安装；工作区服务目录中的 service.log 和 supervisor.log 用于排查启动。

节点不可达导致停止失败时，平台地址已关闭，但不会宣称进程已停止；恢复连通后再次“下线”。不要直接对旧数据库里的 PID 发 kill，可能误伤已复用的进程。控制器使用启动标识核对身份。

## 备份与升级

先停止 OIO，在项目目录运行 bash scripts/backup.sh，生成含 data 与 .env 的私有备份。非默认 OIO_DATA_DIR 请手动备份对应目录；脚本仅处理默认 data。平台停止期间工作区业务仍可能写数据；业务一致性备份需要先下线站点，再备份对应工作区 .oio/services/*/data。源码也在 CloudAgent 单独备份。

解压升级包保留 .env、data、.venv，重新运行 bash start.sh；systemd 用户先执行依赖安装，再重启服务。数据库迁移保留网站与历史。

旧 v0.2 Docker 部署需要先导出 oio-data 中的平台文件到新项目 data，并备份各环境业务数据。新版本不会自动接管旧 Docker 容器和数据卷；原业务数据须拷入对应工作区环境 data，再恢复服务。确认迁移成功后由管理员停止旧容器；本次代码变更不会主动删除宿主机资源。

## 打包与限制

python scripts/release.py 打包源码，不含虚拟环境、密钥、数据、node_modules。release.json 记录版本与 Git 提交；scripts/verify_release.py 检查压缩包和全新启动。

首次依赖安装受异步命令任务 1800 秒限制；后台服务不依附于命令任务。实际底座是否有额外 cgroup 清理策略须实机验证。节点重启后通过后续 API 请求或恢复操作启动服务，不提供独立节点开机守护安装。日志与历史目录暂未自动轮转，管理员按工作区定期保留和清理。
