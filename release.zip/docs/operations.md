# 部署与运维

## 部署条件

Linux Docker Engine、Compose v2、unzip；可访问镜像仓库及 PyPI。部署使用本机 Unix Docker socket，不支持只配置远程 Docker context 的直接替代。宿主机无需运行 Node；CodeAgent 构建节点需要 Node 22.12+、npm 及模型账号。

运行 bash deploy.sh，默认端口 18743，冲突尝试 18744、28743。--port 指定单一端口；--ports 指定逗号分隔列表。部署失败仅在明确的端口占用错误时换端口，健康检查或构建失败不会被误当作端口冲突。成功后保存端口，保留既有密码与其他设置。DOCKER_GID 从本机 socket 检测以便非 root 网关访问 Docker。

生产入口建议由已有 HTTPS 代理转发至 127.0.0.1:18743，支持 WebSocket Upgrade、长连接和流式响应。在 .env 设置 OIO_PUBLIC_URL 为浏览器实际使用的协议、域名与端口，再运行部署。TLS、DNS、防火墙和代理配置由服务器管理员管理。

平台数据卷为 oio-data。不要使用 docker compose down -v。一个平台仅运行一个 worker；同机多实例必须分别调整 Compose 项目名、数据卷与端口。

## 业务密钥

可在平台数据卷的 runtime-env/<slug>.json 配置：

```json
{
  "beta": {"SERVICE_TOKEN": "测试凭据"},
  "production": {"SERVICE_TOKEN": "生产凭据"}
}
```

该文件仅服务端读取，不放入版本归档或网站前端。生产与测试分别配置，不将真实生产凭据发送给 AI。已有容器的环境不会自动改变；更新后创建新代码版本并重新部署，或由管理员停止并删除对应旧容器后重新启动该版本。不要删除其数据卷。平台备份包含此文件，应按敏感备份保管。

## 备份

```bash
bash scripts/backup.sh
```

脚本短暂停止网关和本实例正在运行的 Python 容器，备份平台数据以及各环境数据卷，退出时恢复原先运行的服务。输出平台 tar.gz 和同名 -python 目录；目录中每个文件名对应一个 Docker 数据卷。另行保管 .env。CodeAgent 工作区及账号不在此备份内，前端源码需在底座独立备份。

## 恢复到空实例

先准备发布包和原 .env，运行部署创建容器，然后停止网关。仅向确认没有待保留数据的目标卷恢复；现有业务容器也必须停止。先恢复平台：

```bash
docker compose stop web
docker compose run --rm --no-deps -T web python -c \
  'import sys,tarfile; t=tarfile.open(fileobj=sys.stdin.buffer,mode="r|gz"); t.extractall("/app",filter="data")' \
  < backups/oio-20261023T000000Z.tar.gz
```

然后对 -python 目录中的每个数据卷归档，以原文件名去掉 .tar.gz 得到卷名，创建并恢复该卷。例如：

```bash
volume='oio_替换为实际实例标识-站点后缀-production-data'
docker volume create --label "io.oio.instance=${volume%%-*}" "$volume"
docker run --rm -i --network none -v "$volume:/snapshot" python:3.12-slim \
  python -c 'import sys,tarfile,os,pathlib; t=tarfile.open(fileobj=sys.stdin.buffer,mode="r|gz"); t.extractall("/snapshot",filter="data"); [os.chown(p,10001,10001) for p in [pathlib.Path("/snapshot"),*pathlib.Path("/snapshot").rglob("*")]]' \
  < "backups/oio-20261023T000000Z-python/$volume.tar.gz"
docker compose up -d --wait
```

必须使用备份里的真实完整卷名；上述命令将业务文件所有者设置为容器使用的 10001 用户。恢复后访问生产与测试地址，平台按已保存清单重建缺失镜像和容器；新机器首次启动需要网络。检查内容、业务数据和版本下载；继续 AI 修改还需要原 CodeAgent 工作区可用。

## 维护与排错

- AI 连接失败：检查容器能否访问底座地址。容器 localhost 不是宿主机；连接测试只验证接口可达，不验证模型余额和节点运行状态。
- 产物收集失败：检查 dist/index.html、相对资源路径、文件限制；在对话说“重新同步”。
- Python 启动失败：检查 requirements.txt、启动命令、8080 监听和健康检查路径；查看对应业务容器日志。原版本继续服务。
- 页面深层路由失败：使用 OIO_BASE_PATH；不要硬编码 /assets 或生产前缀。
- 业务 cookie/localStorage 失败：这是浏览器隔离契约，改用适配的业务 token/API 设计。
- 发布后撤回：对话说“回滚”或“回滚到 v2”，仅允许已发布版本。数据库需单独恢复。
- 磁盘增长：历史版本、镜像、停止的容器、数据卷均不会自动清理。按 io.oio.instance 标签核对所属实例后定向维护，勿删除仍用于运行或回滚的数据。

## 打包

提交代码后运行 python scripts/release.py，生成 release.zip、release.zip.sha256；release.json 记录版本、Git 提交与 dirty 状态。运行 python scripts/verify_release.py 验证解压后的基础服务流程。

requirements.lock 锁定平台依赖，templates/react/package-lock.json 锁定前端模板依赖。发布包排除 .env、数据、虚拟环境、node_modules 与模板构建产物。当前包是源码部署包，不含 Linux 离线镜像。
