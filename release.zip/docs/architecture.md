# 架构与运行契约

OIO 网关使用 FastAPI，管理前端是轻量原生页面；生成的网站默认使用 React、TypeScript、Vite、React Router。SQLite 保存网站、标签、会话、任务、版本、运行实例和访问量。仅运行一个网关 worker，不支持多个副本共享队列。

## 从对话到上线

对话先识别管理命令，否则将需求交给站点自己的 CodeAgent 工作区和会话。新工作区注入 React 模板及 Python 示例。AI 在远程构建 dist，平台校验文件、收集不可变版本；有 Python 清单时先构建并启动测试容器，通过健康检查后再更新 Beta 指针。发布同样先准备生产容器，再切换数据库版本指针，随后停止旧容器。

对话请求 ID 防重复提交。每站任务串行，发布有站点锁。进程重启后继续查询已有远程任务；收集或运行部署失败可以重新同步已有产物。远程任务提交超时、结果不确定时不会盲目再次提交。管理命令使用规则解析，不是任意自然语言自治执行器。

## Python 契约

工作区根目录放置如下 oio-runtime.json：

```json
{
  "python": {
    "command": ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8080"],
    "health_path": "/api/health"
  }
}
```

将 main.py、requirements.txt 和业务模块放进 backend/。工作目录为容器 /app，对应 backend/ 的内容。命令直接按参数数组执行，不经 shell。服务监听 0.0.0.0:8080，健康检查需成功响应。Flask 可改用 `["gunicorn", "--bind", "0.0.0.0:8080", "main:app"]` 并在 requirements.txt 包含 flask、gunicorn；Django 同理，需要自行正确配置项目、数据库与迁移。

平台注入 PORT=8080、OIO_DATA_DIR=/data、OIO_BASE_PATH、OIO_API_BASE 和环境标识。持久文件写入 /data；其他文件系统只读，/tmp 是受限临时目录。每站每环境各有数据卷，代码版本共用该环境数据。升级启动期间新旧代码可能短暂共用数据，迁移必须向后兼容。回滚仅恢复代码，数据库恢复依赖备份。

API 请求路径映射：

| 浏览器 | Python 服务 |
| --- | --- |
| /demo/api/notes | /api/notes |
| /demo-beta/api/notes | /api/notes |
| /demo/api/socket | /api/socket（WebSocket） |

网关支持流式上传、HTTP 响应、SSE 和 WebSocket；转发 Authorization，过滤平台 cookies 与伪造转发头，注入 X-Forwarded-Prefix。业务服务按 /api/* 暴露接口，不能占用平台 /api 根命名空间。WebSocket 浏览器鉴权可使用业务 query 或 subprotocol。后端源码和运行清单不作为静态文件公开。

前端使用 `window.OIO_BASE_PATH` 作为路由 basename，API URL 由该前缀拼接。Vite 配置 base 为 ./；平台对 HTML 注入环境对应的 base，使同一产物可以在测试、生产和深层页面使用。具体见 templates/react；参考 [Vite 部署文档](https://vite.dev/guide/build.html) 和 [BrowserRouter](https://reactrouter.com/api/declarative-routers/BrowserRouter)。

## 运行隔离

每个网站、环境各建 Docker 网络，网关接入这些网络。业务容器不映射宿主机端口，以非 root 用户运行，默认 512 MiB 内存、1 CPU、128 进程，移除 capabilities，禁止新增权限，限制临时目录与日志。允许出站联网。只把该版本 backend/ 送入镜像构建，不将平台密码、数据库或 Docker socket 放入业务容器。

网关为了管理运行实例需要宿主机 Docker socket，因此网关本身拥有很高的主机权限。本版本面向可信共享工作空间，不应直接作为允许陌生人执行代码的多租户服务。依赖安装也属于需要信任的代码构建过程。

微网站 HTML 采用无 allow-same-origin 的 CSP sandbox；后端 HTML 响应也受约束。网站无法读取平台会话、localStorage 或 service worker。API 使用不带凭据的 CORS，过滤 Set-Cookie；业务登录不能直接套用同源 cookie 会话方案。外部 API 必须允许适用的 CORS。

## 版本与检索

标签、名称、URI、描述均可搜索，# 前缀可用于标签检索。生产 HTML 导航累加访问量；SPA 内部 pushState 不额外计数。公开目录只返回已发布且未归档的网站信息。

版本 ZIP 包含 dist/、可选 backend/ 与 oio-runtime.json，以及归档元数据。旧镜像、容器和数据卷保留以支持追溯；停止旧实例并不自动删除历史资源。生产版本和 Beta 指针互相独立，归档会停服且保留 URI、数据和历史。
