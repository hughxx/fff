# v0.2.0 验证记录

验证日期：2026-10-23。环境为 Windows、Python 3.12、Node 22.22、Playwright Chromium。

## 已通过

构建 React 模板后，设置 OIO_BROWSER_TEST=1 与 OIO_REACT_TEST=1，执行 pytest -q --tb=short：**55 passed**。其中包括：

- 原有平台登录、底座适配、任务恢复、版本归档、安全与发布流程。
- 对话建站、标签、发布、回滚、归档恢复；请求幂等、否定意图、过期预览保护。
- 旧 SQLite 数据迁移、标签搜索、目录过滤、生产访问计数。
- 真实 Chromium 访问管理界面、手机宽度、对话流程和搜索，无脚本错误。
- 真实 Vite 构建的 React 页面在生产、Beta、深层路由下运行，交互计数和路由刷新可用。
- 真实 Python HTTP 服务与网关之间的大请求上传、SSE、WebSocket 文本转发；示例 SQLite 数据在模块重载后保留。
- Python 清单校验、后端源码访问阻断、候选版本启动失败不切换、失败后复用版本重新同步。
- Docker SDK 契约：独立网络与环境数据卷、非 root、资源限制、无业务宿主端口、无平台密钥挂载。
- 真实 Bash 执行部署脚本，模拟 Docker 返回端口冲突、健康失败，验证备选端口、指定端口失败、密码保留。
- 部署与备份脚本 Bash 语法检查；发布包解压后的启动与基础发布验证由 verify_release.py 执行。

## 尚未真实联调

机器没有 Docker Engine 和可用 Linux 容器环境，Docker 镜像构建、容器健康检查、socket 权限、数据卷备份恢复尚未在 Linux Docker 实机验证。相关测试使用 SDK/CLI 模拟，不能替代实机验收。

v0.2.1 已内置 CodeAgent 地址 http://10.90.113.228:8800/api；实际 GET /api/workspaces 检查时对端未返回 HTTP 响应便断开连接。接口适配通过按 USER_API.md 实现的模拟服务验证；尚未让真实模型端到端生成并部署业务网站。没有进行负载测试、长期运行测试或公开多租户安全审计。

此版本的“任意 Python 后端”指可按运行契约安装 pip 依赖、监听 HTTP/WebSocket 并使用持久卷的 Python 应用；不表示自动满足任意操作系统依赖、外部服务或浏览器 cookie 鉴权需求。
