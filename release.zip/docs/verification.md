# v0.3.5 验证记录

环境：Windows、Python 3.10.20、Node 22.22、Playwright Chromium。在全新 Python 3.10 虚拟环境通过 pip 安装 requirements.lock，pip check 通过；Linux manylinux2014 x86_64 / CPython 3.10 的全部二进制依赖下载通过。后者不等同于 Linux 实机运行验证。Linux 节点运行控制器只使用标准库，实际依赖 CloudAgent 节点 Linux /proc 和 flock。

## 自动化范围

- 免登录的卡片主页与新建入口、独立站点对话、跨站历史隔离、刷新恢复、标签搜索、发布、回滚、归档恢复和请求幂等；独立浏览器窗口无需 Cookie 即可继续修改、发布和下线别的窗口创建的网站。
- 新建时指定英文网站名、实时地址预览、同名冲突提示，以及缺少英文名时不创建随机地址。
- 真实 React 构建产物、Chromium 深层路由与移动布局。
- 本地真实 Python 服务的 HTTP 上传、SSE、WebSocket 与 SQLite 持久数据。
- CloudAgent 协议模拟：上传不可变服务目录、异步部署任务、PID/启动标识/端口记录、进程接管、下线两个环境、停止失败重试、启动失败保留原版本。
- 控制器单元测试：PID 复用与僵尸进程识别、后台进程独立会话与标准流重定向、延迟部署不能复活下线站点。
- 本地真实 socket 测试默认端口占用后的备选绑定，以及显式端口不擅自切换。
- .env 不经 shell 执行，保留已有连接配置。
- 发布包解压后无密码启动、建站、发布和路由验证。

测试命令：构建 templates/react 后，设置 OIO_BROWSER_TEST=1 和 OIO_REACT_TEST=1，运行 pytest -q --tb=short。

v0.3.4 的完整测试基线为 60 项通过；v0.3.5 品牌更新重新通过卡片、对话、双浏览器协作及手机布局浏览器检查，另一个独立 React 产物用例本次未重跑。框架有一条 TestClient 的依赖弃用提示，不影响执行。

## 未完成实机联调的部分

对 http://10.90.113.228:8800 的 /openapi.json、/api/workspaces 和根路径请求均遇到对端未返回 HTTP 响应即断开连接。因此未验证真实底座的异步进程保活、节点端口可达、远程安装依赖及模型端到端产物。

控制器在 Windows 测试中模拟 Linux flock 和 /proc，并检查脱离进程的参数；这不是 Linux nohup 实测。工作区服务状态测试使用模拟接口，本地真实 HTTP 检查不能替代真实远端检查。不声称 Docker 或工作区具备未验证的安全隔离。
