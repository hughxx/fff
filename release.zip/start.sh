#!/usr/bin/env bash
set -Eeuo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
python_command="${OIO_PYTHON:-python3}"
command -v "$python_command" >/dev/null 2>&1 || { printf '%s\n' 'Python 3.10+ is required. Set OIO_PYTHON if needed.' >&2; exit 1; }
"$python_command" -c 'import sys; assert sys.version_info >= (3,10), "Python 3.10+ is required"'
if [[ ! -x .venv/bin/python ]]; then
  "$python_command" -m venv .venv
fi
.venv/bin/python -m pip install --disable-pip-version-check -r requirements.lock
exec .venv/bin/python scripts/serve.py "$@"
