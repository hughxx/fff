"""Example public notes API. Adapt authentication to the website's actual requirements."""
import os
import sqlite3
from contextlib import closing
from pathlib import Path

from fastapi import FastAPI
from pydantic import BaseModel, Field

data = Path(os.getenv('OIO_DATA_DIR', './data'))
data.mkdir(parents=True, exist_ok=True)
database = data / 'website.sqlite3'
with closing(sqlite3.connect(database)) as connection:
    connection.execute('CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY, text TEXT NOT NULL)')
    connection.commit()

app = FastAPI()


class Note(BaseModel):
    text: str = Field(min_length=1, max_length=1000)


@app.get('/api/health')
def health():
    return {'status':'ok'}


@app.get('/api/notes')
def notes():
    with closing(sqlite3.connect(database)) as connection:
        return [{'id':row[0], 'text':row[1]} for row in connection.execute('SELECT id,text FROM notes ORDER BY id DESC LIMIT 100')]


@app.post('/api/notes', status_code=201)
def add_note(note: Note):
    with closing(sqlite3.connect(database)) as connection:
        with connection:
            cursor = connection.execute('INSERT INTO notes(text) VALUES (?)', (note.text,))
            return {'id':cursor.lastrowid,'text':note.text}
