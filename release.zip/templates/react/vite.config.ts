import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The same build is served under /uri/ and /uri-beta/, including nested routes.
export default defineConfig({ plugins: [react()], base: './', build: { outDir: 'dist', emptyOutDir: true } });
