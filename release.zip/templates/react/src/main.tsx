import { StrictMode, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';
import './style.css';

declare global { interface Window { OIO_BASE_PATH?: string } }

function Home() {
  const [count, setCount] = useState(0);
  return <main><small>A SPACE FOR YOUR IDEAS</small><h1>每一个想法<br/>都值得被看见。</h1><p>这里即将成为你的网站。</p><button onClick={() => setCount(count + 1)}>灵感 + {count}</button></main>;
}

function App() {
  return <><header><Link to="/">我的网站</Link><nav><Link to="/about">关于</Link></nav></header><Routes><Route path="/" element={<Home/>}/><Route path="/about" element={<main><small>ABOUT</small><h1>关于这个网站</h1><p>为你自己的故事留一片空间。</p></main>}/><Route path="*" element={<main><h1>页面不存在</h1><Link to="/">返回本站首页</Link></main>}/></Routes></>;
}

createRoot(document.getElementById('root')!).render(<StrictMode><BrowserRouter basename={window.OIO_BASE_PATH || '/'}><App/></BrowserRouter></StrictMode>);
