from uuid import uuid4
import sqlite3

import pytest

from tests.test_platform import create, wait_job
from backend.store import Store, SCHEMA


def chat(client):
    return client.post('/api/conversations').json()['id']


def say(client, conversation, text, request_id=None, expected=None):
    response = client.post(f'/api/conversations/{conversation}/messages', json={'prompt':text,'request_id':request_id or uuid4().hex,'expected_beta':expected})
    assert response.status_code == 200, response.text
    return response.json()


def test_dialogue_creates_builds_publishes_tags_rolls_back_and_archives(harness):
    client, _, agent = harness
    conversation = chat(client)
    response = say(client, conversation, '帮我做一个网站，名字叫山野咖啡')
    site = response['site']; assert site['slug'].startswith('page-')
    site = wait_job(client, site['id'])
    assert 'react' in agent.source_files['package.json'].decode()
    assert 'python-example/backend/main.py' in agent.source_files
    response = say(client,conversation,'打标签 张三，设计组')
    assert response['site']['tags'] == ['张三','设计组']
    response = say(client,conversation,'发布',expected=site['beta_version'])
    assert response['messages'][-1]['links'][0]['label'] == '生产地址'
    first=client.get('/api/sites/'+site['id']).json()['production_version']
    assert client.get('/'+site['slug']+'/').status_code==200
    say(client,conversation,'把首页标题改得更醒目')
    current=wait_job(client,site['id'])
    say(client,conversation,'发布',expected=current['beta_version'])
    assert client.get('/api/sites/'+site['id']).json()['production_version']!=first
    say(client,conversation,'回到上个版本')
    assert client.get('/api/sites/'+site['id']).json()['production_version']==first
    response=say(client,conversation,'下载版本')
    assert response['messages'][-1]['links'][0]['url'].endswith('/download')
    say(client,conversation,'归档')
    assert client.get('/'+site['slug']+'/').status_code==404
    say(client,conversation,'恢复网站')
    assert client.get('/'+site['slug']+'/').status_code==200
    assert client.get('/api/conversations/'+conversation).json()['site']['id']==site['id']


def test_chat_idempotency_negative_intent_and_stale_preview(harness):
    client, _, _ = harness
    site=create(client)
    conversation=chat(client)
    say(client,conversation,'修改 /studio')
    request_id=uuid4().hex
    say(client,conversation,'首页增加作品列表',request_id=request_id)
    wait_job(client,site['id'])
    say(client,conversation,'首页增加作品列表',request_id=request_id)
    assert len(client.get('/api/sites/'+site['id']).json()['jobs'])==1
    say(client,conversation,'不要发布')
    say(client,conversation,'是不是应该发布呢？')
    assert client.get('/api/sites/'+site['id']).json()['production_version'] is None
    response=say(client,conversation,'发布',expected=site['beta_version'])
    assert '更新' in response['messages'][-1]['content']
    assert client.get('/api/sites/'+site['id']).json()['production_version'] is None


def test_tags_search_public_catalog_and_visits(harness):
    client, _, _ = harness
    first=create(client,'alpha'); second=create(client,'bravo')
    for site in (first,second):
        client.post(f"/api/sites/{site['id']}/publish",json={'version_id':site['beta_version']})
    assert client.put(f"/api/sites/{first['id']}/tags",json={'tags':['张三','团队A','团队a']}).json()['tags']==['张三','团队A']
    assert client.put(f"/api/sites/{first['id']}/tags",json={'tags':['bad tag']}).status_code==422
    for _ in range(3):client.get('/alpha/',headers={'Sec-Fetch-Dest':'document'})
    client.get('/bravo/',headers={'Sec-Fetch-Dest':'document'})
    client.get('/bravo-beta/',headers={'Sec-Fetch-Dest':'document'})
    client.get('/bravo/',headers={'Sec-Fetch-Dest':'iframe'})
    client.get('/bravo/',headers={'Sec-Fetch-Dest':'document','User-Agent':'testbot'})
    catalog=client.get('/api/catalog').json()['items']
    assert [site['visits'] for site in catalog]==[3,1]
    assert catalog[0]['slug']=='alpha'
    assert client.get('/api/catalog?q=%23张三').json()['items'][0]['slug']=='alpha'
    assert len(client.get('/api/sites?q=团队a').json()['items'])==1
    assert 'workspace_id' not in catalog[0]
    client.post('/api/logout')
    assert len(client.get('/api/catalog').json()['items'])==2
    assert client.post('/api/conversations').status_code==401


def test_existing_database_upgrades_without_losing_sites(tmp_path):
    database=sqlite3.connect(tmp_path/'oio.sqlite3')
    database.executescript(SCHEMA)
    database.execute("INSERT INTO sites(id,slug,name,created_at,updated_at) VALUES ('old','old-site','Existing website','2026','2026')")
    database.commit();database.close()
    store=Store(tmp_path)
    assert store.one('SELECT name,visits FROM sites WHERE id=?',('old',))=={'name':'Existing website','visits':0}
    Store(tmp_path)  # idempotent upgrade
