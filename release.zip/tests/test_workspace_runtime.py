import asyncio
import json
import shlex
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import httpx
import pytest
from fastapi.testclient import TestClient

from backend.app import create_app
from backend.config import Config
from backend.runtime import PythonRuntime, RuntimeError
from tests.conftest import PASSWORD, HEADERS
from tests.fake_agent import FakeAgent
from tests.test_platform import create, submit, wait_job


class WorkspaceAgent(FakeAgent):
    def __init__(self, port):
        super().__init__()
        self.port = port
        self.services = {}
        self.commands = {}
        self.deploy_count = 0
        self.fail_stop = False
        self.fail_start = False
        self.source_files['oio-runtime.json'] = json.dumps({'python':{'command':['python','main.py'], 'health_path':'/api/health'}}).encode()
        self.files['backend/main.py'] = b'print("business backend")'

    async def handle(self, request):
        path = request.url.path.removeprefix('/api/').split('/')
        method = request.method
        body = json.loads(request.content) if request.content and 'application/json' in request.headers.get('content-type','') else {}
        if len(path) >= 3 and path[0] == 'workspaces':
            if path[2] == 'files' and len(path) == 4 and path[3] == 'upload':
                name = request.url.params['path']
                if name in self.source_files:
                    return httpx.Response(409, json={})
            if path[2] == 'files' and len(path) == 4 and path[3] == 'download' and request.url.params['path'] in self.source_files:
                return httpx.Response(200, content=self.source_files[request.url.params['path']])
            if path[2] == 'commands':
                parts = shlex.split(body['command'])
                action, directory = parts[-2:]
                if action == 'stop':
                    if self.fail_stop:
                        return httpx.Response(200,json={'exit_code':1,'stdout':'','timed_out':False})
                    self.services.pop(directory, None)
                    result = {'stopped':True}
                else:
                    result = self.services.get(directory, {'ready':False})
                return httpx.Response(200,json={'exit_code':0,'stdout':json.dumps(result),'timed_out':False})
            if path[2] == 'command-tasks':
                if method == 'POST' and len(path) == 3:
                    self.deploy_count += 1
                    directory = shlex.split(body['command'])[-1]
                    task_id = 'task_'+str(self.deploy_count)
                    self.commands[task_id] = directory
                    if not self.fail_start:
                        self.services[directory] = {'supervisor':700+self.deploy_count, 'service_pid':900+self.deploy_count,
                                                    'start_time':str(10000+self.deploy_count), 'ready':True, 'port':self.port, 'addresses':['127.0.0.1']}
                    return httpx.Response(202,json={'task_id':task_id,'status':'queued'})
                return httpx.Response(200,json={'task_id':path[3],'status':'success','exit_code':0,'timed_out':False})
        return await super().handle(request)


@pytest.fixture
def workspace_platform(tmp_path):
    class Health(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200); self.end_headers(); self.wfile.write(b'{"status":"ok"}')
        def log_message(self,*args):
            pass
    server = ThreadingHTTPServer(('127.0.0.1',0), Health)
    thread = threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    agent = WorkspaceAgent(server.server_port)
    config = Config(data_dir=tmp_path, admin_password=PASSWORD, agent_url='http://agent/api',poll_seconds=.01,
                    runtime_hosts='{"*":"127.0.0.1"}',runtime_start_timeout=.02)
    app = create_app(config, agent.factory)
    try:
        with TestClient(app) as client:
            client.headers.update(HEADERS);client.post('/api/login',json={'password':PASSWORD})
            yield client, app, agent, config
    finally:
        server.shutdown();server.server_close();thread.join(timeout=3)


def test_workspace_process_ids_persist_restart_offline_and_restore(workspace_platform):
    client,app,agent,config = workspace_platform
    site = create(client);submit(client,site);built=wait_job(client,site['id'])
    version = built['beta_version']
    rows = client.get('/api/sites/'+site['id']).json()['runtimes']
    assert rows[0]['workspace_id'] == 'oio_'+site['id']
    assert rows[0]['task_id']=='task_1' and rows[0]['supervisor_pid']==701 and rows[0]['service_pid']==901
    assert rows[0]['start_time']=='10001' and rows[0]['status']=='running'
    assert client.post(f'/api/sites/{site["id"]}/publish',json={'version_id':version}).status_code==200
    rows = client.get('/api/sites/'+site['id']).json()['runtimes']
    assert len(rows)==2 and rows[0]['directory'] != rows[1]['directory']
    fresh = PythonRuntime(app.state.store,config);fresh.agent_factory=agent.factory
    async def reconnect():
        return await fresh.target(client.get('/api/sites/'+site['id']).json(),'beta')
    assert asyncio.run(reconnect()).endswith(':'+str(agent.port))
    assert agent.deploy_count==2  # reconnect adopts the existing process, never duplicates it
    assert client.patch(f'/api/sites/{site["id"]}/archive',json={'archived':True}).status_code==200
    assert not agent.services
    assert all(row['status']=='stopped' for row in client.get('/api/sites/'+site['id']).json()['runtimes'])
    assert client.get('/studio/').status_code==404
    assert client.patch(f'/api/sites/{site["id"]}/archive',json={'archived':False}).status_code==200
    assert len(agent.services)==2 and agent.deploy_count==4


def test_offline_stops_both_environments_and_reports_failure(workspace_platform):
    client,app,agent,_ = workspace_platform
    site=create(client);submit(client,site);version=wait_job(client,site['id'])['beta_version']
    client.post(f'/api/sites/{site["id"]}/publish',json={'version_id':version})
    agent.fail_stop=True
    response=client.patch(f'/api/sites/{site["id"]}/archive',json={'archived':True})
    assert response.status_code==503
    assert client.get('/studio/').status_code==404
    assert all(row['status']=='stop_failed' for row in client.get('/api/sites/'+site['id']).json()['runtimes'])
    agent.fail_stop=False
    assert client.patch(f'/api/sites/{site["id"]}/archive',json={'archived':True}).status_code==200
    assert not agent.services


def test_failed_start_keeps_previous_beta_and_tracks_task(workspace_platform):
    client,app,agent,_=workspace_platform
    site=create(client);agent.fail_start=True;submit(client,site)
    failed=wait_job(client,site['id'],'failed')
    assert failed['beta_version']==site['beta_version']
    row=client.get('/api/sites/'+site['id']).json()['runtimes'][0]
    assert row['task_id']=='task_1' and row['status']=='error'
