import importlib.util
import json
from pathlib import Path
import sys
from types import SimpleNamespace

import pytest

from backend.config import ROOT


@pytest.fixture
def controller(monkeypatch):
    if sys.platform == 'win32':
        monkeypatch.setitem(sys.modules,'fcntl',SimpleNamespace(LOCK_EX=1,LOCK_NB=2,flock=lambda *args:None))
    spec=importlib.util.spec_from_file_location('workspace_controller',ROOT/'backend/workspace_service.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def test_pid_reuse_and_zombie_are_not_treated_as_our_service(controller,tmp_path,monkeypatch):
    (tmp_path/'state.json').write_text(json.dumps({'supervisor':123,'start_time':'456','ready':True}))
    original=Path.read_text
    values=['S']+['0']*18+['999']
    def read(path,*args,**kwargs):
        if str(path).replace('\\','/')=='/proc/123/stat':return '123 (python helper) '+' '.join(values)
        return original(path,*args,**kwargs)
    monkeypatch.setattr(Path,'read_text',read)
    assert controller.running(tmp_path) is None
    values[19]='456'
    assert controller.running(tmp_path)['supervisor']==123
    values[0]='Z'
    assert controller.running(tmp_path) is None


def test_detached_process_redirects_every_standard_stream(controller,tmp_path,monkeypatch):
    (tmp_path/'venv/bin').mkdir(parents=True);(tmp_path/'venv/bin/python').touch()
    calls=[]
    monkeypatch.setattr(controller,'running',lambda root: None if not calls else {'supervisor':123,'ready':False})
    monkeypatch.setattr(controller.subprocess,'Popen',lambda args,**kwargs:calls.append((args,kwargs)))
    monkeypatch.setattr(sys,'argv',['controller.py','deploy',str(tmp_path)])
    controller.main()
    args,options=calls[0]
    assert args[-2]=='supervise'
    assert options['start_new_session'] is True
    assert options['stdin']==controller.subprocess.DEVNULL
    assert options['stdout']==options['stderr']


def test_delayed_deploy_cannot_resurrect_an_offline_site(controller,tmp_path,monkeypatch):
    (tmp_path/'stop').touch()
    monkeypatch.setattr(sys,'argv',['controller.py','deploy',str(tmp_path)])
    with pytest.raises(RuntimeError,match='disabled'):controller.main()
