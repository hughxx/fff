import os
import shutil
import subprocess
from pathlib import Path

import pytest

from backend.config import ROOT

BASH = shutil.which('bash') if os.name!='nt' else 'D:/Program Files/Git/bin/bash.exe'
pytestmark=pytest.mark.skipif(not BASH or not Path(BASH).exists(),reason='Bash unavailable')


@pytest.fixture
def deploy(tmp_path):
    shutil.copyfile(ROOT/'deploy.sh',tmp_path/'deploy.sh')
    (tmp_path/'.env').write_text('OIO_ADMIN_PASSWORD=keep-this-password\nOIO_PORT=18743\nOIO_PORT_CANDIDATES=18744,28743\n')
    binary=tmp_path/'bin';binary.mkdir()
    stub=binary/'docker'
    stub.write_text('''#!/usr/bin/env bash
if [[ "$1 $2" == "compose up" ]]; then
  printf '%s\\n' "$OIO_PORT" >> attempts
  if [[ "${FAIL_MODE:-}" == "health" ]]; then echo 'container is unhealthy';exit 1;fi
  if [[ "$OIO_PORT" == "18743" ]]; then echo 'port is already allocated';exit 1;fi
fi
exit 0
''',newline='\n');stub.chmod(0o755)
    env={**os.environ,'PATH':str(binary)+os.pathsep+os.environ['PATH']}
    # Git Bash rewrites PATH; export its own path syntax inside Bash, without interpolating shell code.
    def run(*args,fail_mode=''):
        env['FAIL_MODE']=fail_mode
        return subprocess.run([BASH,'-c','export PATH="$PWD/bin:$PATH"; bash deploy.sh "$@"','deploy',*args],cwd=tmp_path,env=env,capture_output=True,text=True)
    return tmp_path,run


def test_port_fallback_and_secret_preservation(deploy):
    path,run=deploy;result=run()
    assert result.returncode==0,result.stderr
    assert (path/'attempts').read_text().splitlines()==['18743','18744']
    assert 'OIO_PORT=18744' in (path/'.env').read_text()
    assert 'OIO_ADMIN_PASSWORD=keep-this-password' in (path/'.env').read_text()
    assert 'keep-this-password' not in result.stdout+result.stderr
    assert 'YOUR_SERVER:18744' in result.stdout


def test_explicit_port_is_honored(deploy):
    path,run=deploy;result=run('--port','28743')
    assert result.returncode==0,result.stderr
    assert (path/'attempts').read_text().splitlines()==['28743']


def test_health_failure_does_not_trigger_port_fallback(deploy):
    path,run=deploy;result=run(fail_mode='health')
    assert result.returncode!=0
    assert (path/'attempts').read_text().splitlines()==['18743']


def test_invalid_port_is_rejected(deploy):
    path,run=deploy;result=run('--port','70000')
    assert result.returncode==2
    assert not (path/'attempts').exists()
