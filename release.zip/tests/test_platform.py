import hashlib
import io
import time
import zipfile

import pytest
from fastapi.testclient import TestClient

from backend.app import create_app
from backend.artifacts import safe_path, validate_files
from backend.config import Config
from backend.store import now
from tests.conftest import HEADERS, PASSWORD


def create(client, slug='studio'):
    response = client.post('/api/sites', json={'name':'山野工作室', 'slug':slug, 'description':'用想法构建微网站'})
    assert response.status_code == 201, response.text
    return response.json()


def wait_job(client, site_id, expected='success'):
    deadline = time.monotonic() + 8
    while time.monotonic() < deadline:
        site = client.get('/api/sites/' + site_id).json()
        if site['jobs'] and site['jobs'][0]['status'] in ('success', 'failed', 'cancelled'):
            assert site['jobs'][0]['status'] == expected, site['jobs'][0]
            return site
        time.sleep(.02)
    pytest.fail('job did not complete')


def submit(client, site):
    response = client.post(f"/api/sites/{site['id']}/jobs", json={'prompt':'请制作一个品牌主页，添加关于页面'})
    assert response.status_code == 202, response.text
    return response.json()


def test_full_lifecycle_and_binary_archive(harness):
    client, app, agent = harness
    site = create(client)
    assert client.get('/studio/').status_code == 404
    assert client.get('/studio-beta/').status_code == 200
    submit(client, site)
    site = wait_job(client, site['id'])
    version = site['beta_version']
    assert len(site['versions']) == 2
    assert site['workspace_id'].startswith('oio_site_')
    assert site['session_id'] == 'sess_1'
    assert '测试环境更新为 v2' in site['events'][0]['note']
    html = client.get('/studio-beta/about/').text
    assert '<base href="/studio-beta/">' in html and 'About this site' in html
    assert client.get('/studio-beta/nested/spa/route').status_code == 200
    assert client.get('/studio-beta/assets/missing.js').status_code == 404
    assert client.get('/studio-beta/assets/logo.png').content == agent.files['assets/logo.png']
    stale = client.post(f"/api/sites/{site['id']}/publish", json={'version_id':site['versions'][-1]['id']})
    assert stale.status_code == 409
    assert client.post(f"/api/sites/{site['id']}/publish", json={'version_id':version}).status_code == 200
    assert 'Generated website' in client.get('/studio/').text
    assert '<base href="/studio/">' in client.get('/studio/nested/route').text
    assert client.get('/studio?x=1', follow_redirects=False).headers['location'] == '/studio/?x=1'
    assert client.get('/studio/').headers['x-oio-version'] == version

    agent.files['index.html'] = b'<html><head></head><body>Second release</body></html>'
    submit(client, site)
    updated = wait_job(client, site['id'])
    assert 'Second release' in client.get('/studio-beta/').text
    assert 'Generated website' in client.get('/studio/').text
    assert len(agent.sessions) == 1  # subsequent requests retain workspace and conversation
    second = updated['beta_version']
    client.post(f"/api/sites/{site['id']}/publish", json={'version_id':second})
    assert 'Second release' in client.get('/studio/').text
    assert client.post(f"/api/sites/{site['id']}/rollback", json={'version_id':version}).status_code == 200
    assert 'Generated website' in client.get('/studio/').text
    assert 'Second release' in client.get('/studio-beta/').text
    archive = client.get(f"/api/sites/{site['id']}/versions/{version}/download")
    assert archive.status_code == 200
    with zipfile.ZipFile(io.BytesIO(archive.content)) as zipped:
        assert zipped.read('dist/assets/logo.png') == agent.files['assets/logo.png']
        assert b'Generated website' in zipped.read('dist/index.html')
        assert 'oio-version.json' in zipped.namelist()
    assert client.patch(f"/api/sites/{site['id']}/archive", json={'archived':True}).status_code == 200
    assert client.get('/studio/').status_code == client.get('/studio-beta/').status_code == 404
    assert client.post(f"/api/sites/{site['id']}/jobs", json={'prompt':'修改页面'}).status_code == 409
    assert client.post('/api/sites', json={'name':'Other','slug':'studio'}).status_code == 409
    client.patch(f"/api/sites/{site['id']}/archive", json={'archived':False})
    assert client.get('/studio/').status_code == 200


@pytest.mark.parametrize('slug', ['api','admin','hello-beta','x','a/b','你好','-alpha','a--b','a_foo','a.b','2alpha'])
def test_reserved_and_invalid_uris(harness, slug):
    client, _, _ = harness
    assert client.post('/api/sites', json={'name':'网站','slug':slug}).status_code == 422


def test_unique_uri_and_cross_site_version_guard(harness):
    client, _, _ = harness
    first = create(client)
    assert client.post('/api/sites', json={'name':'Duplicate','slug':'STUDIO'}).status_code == 409
    second = create(client, 'second')
    assert client.post(f"/api/sites/{second['id']}/publish", json={'version_id':first['beta_version']}).status_code == 404
    assert client.get(f"/api/sites/{second['id']}/versions/{first['beta_version']}/download").status_code == 404


def test_auth_csrf_and_script_isolation(harness):
    client, app, _ = harness
    site = create(client)
    client.post(f"/api/sites/{site['id']}/publish", json={'version_id':site['beta_version']})
    assert 'allow-same-origin' not in client.get('/studio/').headers['content-security-policy']
    assert 'worker-src \'none\'' in client.get('/studio/').headers['content-security-policy']
    assert client.post('/api/sites', json={'name':'Cross-site','slug':'cross-site'}, headers={'Origin':'null'}).status_code == 403
    assert client.post('/api/sites', json={'name':'Cross-site','slug':'cross-site'}, headers={'Origin':'https://evil.example'}).status_code == 403
    assert client.post('/api/sites', json={'name':'Cross-site','slug':'cross-site'}, headers={'X-OIO-Request':''}).status_code == 403
    assert client.get('/api/sites', headers={'Origin':'null'}).headers.get('access-control-allow-origin') is None
    for path in ('/studio/%2eenv','/studio/assets/%2e%2e/%2e%2e/oio.sqlite3','/studio/a%5c..%5coio.sqlite3'):
        assert client.get(path).status_code == 404
    token = client.cookies['oio_session']
    assert app.state.store.one('SELECT * FROM sessions')['token'] != token
    assert client.post('/api/logout').status_code == 200
    assert client.get('/api/sites').status_code == 401
    assert client.get('/studio/').status_code == 200  # public production
    assert client.get('/studio-beta/').status_code == 200  # public test link
    assert client.post('/api/login', json={'password':'wrong'}).status_code == 401


def test_failure_keeps_beta_and_production_and_checks_is_error(harness):
    client, _, agent = harness
    site = create(client)
    initial = site['beta_version']
    client.post(f"/api/sites/{site['id']}/publish", json={'version_id':initial})
    agent.result_error = True
    submit(client, site)
    failed = wait_job(client, site['id'], 'failed')
    assert failed['beta_version'] == failed['production_version'] == initial
    assert len(failed['versions']) == 1


def test_collection_failure_retry_does_not_rerun_ai(harness):
    client, _, agent = harness
    site = create(client)
    agent.fail_download = True
    job = submit(client, site)
    failed = wait_job(client, site['id'], 'failed')
    assert failed['beta_version'] == site['beta_version']
    agent.fail_download = False
    assert client.post(f"/api/sites/{site['id']}/jobs/{job['id']}/retry-sync").status_code == 200
    completed = wait_job(client, site['id'])
    assert completed['beta_version'] != site['beta_version']
    assert len(agent.tasks) == 1


def test_concurrency_and_cancel(harness):
    client, _, agent = harness
    agent.hold = True
    site = create(client)
    job = submit(client, site)
    deadline = time.monotonic() + 5
    while not agent.tasks and time.monotonic() < deadline:
        time.sleep(.01)
    assert agent.tasks
    assert client.post(f"/api/sites/{site['id']}/jobs", json={'prompt':'duplicate'}).status_code == 409
    assert client.post(f"/api/sites/{site['id']}/publish", json={'version_id':site['beta_version']}).status_code == 409
    assert client.patch(f"/api/sites/{site['id']}/archive", json={'archived':True}).status_code == 409
    assert client.put('/api/settings', json={'url':'http://other/api'}).status_code == 409
    assert client.post(f"/api/sites/{site['id']}/jobs/{job['id']}/cancel").status_code == 200
    cancelled = wait_job(client, site['id'], 'cancelled')
    assert cancelled['beta_version'] == site['beta_version']
    assert next(iter(agent.tasks.values()))['status'] == 'cancelled'


def test_unconfigured_agent_never_fakes_generation(harness):
    client, _, _ = harness
    client.put('/api/settings', json={'url':''})
    site = create(client)
    response = client.post(f"/api/sites/{site['id']}/jobs", json={'prompt':'build'})
    assert response.status_code == 400
    assert not client.get(f"/api/sites/{site['id']}").json()['jobs']


def test_restart_resumes_existing_remote_task_without_resubmission(harness):
    client, app, agent = harness
    site = create(client)
    workspace = 'oio_' + site['id']
    agent.workspaces[workspace] = {'id':workspace, 'status':'ready'}
    agent.sessions['sess_resume'] = {'session_id':'sess_resume', 'workspace_id':workspace}
    agent.tasks['task_resume'] = {'task_id':'task_resume', 'status':'running', 'result':None}
    store = app.state.store
    store.execute('UPDATE sites SET workspace_id=?,session_id=? WHERE id=?', (workspace,'sess_resume',site['id']))
    store.execute("INSERT INTO jobs(id,site_id,prompt,status,stage,remote_task_id,created_at,updated_at) VALUES (?,?,?,'running','generating',?,?,?)",
                  ('job_resume',site['id'],'resumed task','task_resume',now(),now()))
    second = create_app(app.state.config, agent.factory)
    with TestClient(second) as other:
        other.headers.update(HEADERS)
        other.post('/api/login', json={'password':PASSWORD})
        result = wait_job(other, site['id'])
        assert result['beta_version'] != site['beta_version']
    assert not agent.posts


def test_uncertain_submission_is_not_retried(harness):
    client, _, agent = harness
    agent.ambiguous_submit = True
    site = create(client)
    submit(client, site)
    failed = wait_job(client, site['id'], 'failed')
    assert failed['jobs'][0]['stage'] == 'submitting'
    assert len(agent.tasks) == 1
    assert failed['beta_version'] == site['beta_version']


@pytest.mark.parametrize('bad', ['../secret','/root','a//b','a/./b','a\\b','a/.env','C:/test','a/..','a\x00b'])
def test_artifact_paths_reject_traversal(bad):
    with pytest.raises(ValueError):
        safe_path(bad)


def test_symlinks_and_missing_build_never_replace_beta(harness):
    client, _, agent = harness
    site = create(client)
    agent.symlink = True
    submit(client, site)
    failed = wait_job(client, site['id'], 'failed')
    assert failed['beta_version'] == site['beta_version']
    agent.symlink = False
    del agent.files['index.html']
    submit(client, site)
    assert wait_job(client, site['id'], 'failed')['beta_version'] == site['beta_version']


def test_size_cap_and_base_conflict(tmp_path):
    config = Config(data_dir=tmp_path, max_bytes=10)
    with pytest.raises(ValueError):
        validate_files({'index.html':b'x'*11},config)
    config.max_bytes = 1000
    with pytest.raises(ValueError):
        validate_files({'index.html':b'<head><base href="/"></head>'},config)


def test_settings_validation_and_connection(harness):
    client, _, _ = harness
    assert client.post('/api/settings/check').json()['success']
    for url in ['file:///etc/passwd','http://user:password@host/api','https://host/api?token=secret']:
        assert client.put('/api/settings', json={'url':url}).status_code == 422
    site = create(client)
    submit(client, site)
    wait_job(client, site['id'])
    assert client.put('/api/settings', json={'url':'http://different/api'}).status_code == 409


def test_old_failed_sync_cannot_capture_newer_work(harness):
    client, _, agent = harness
    site = create(client)
    agent.fail_download = True
    old = submit(client, site)
    wait_job(client, site['id'], 'failed')
    agent.fail_download = False
    submit(client, site)
    current = wait_job(client, site['id'])
    response = client.post(f"/api/sites/{site['id']}/jobs/{old['id']}/retry-sync")
    assert response.status_code == 409
    assert client.get('/api/sites/' + site['id']).json()['beta_version'] == current['beta_version']


def test_https_proxy_origin_is_explicit(harness):
    client, app, _ = harness
    app.state.config.public_url = 'https://web.example.com'
    assert client.post('/api/settings/check', headers={'Origin':'https://web.example.com'}).status_code == 200
    assert client.post('/api/settings/check', headers={'Origin':'https://other.example.com'}).status_code == 403


def test_expired_session_and_body_limit(harness):
    client, app, _ = harness
    assert client.post('/api/sites', content=b'x' * (256*1024+1)).status_code == 413
    app.state.store.execute('UPDATE sessions SET expires=0')
    assert client.get('/api/sites').status_code == 401
    assert not client.get('/api/auth').json()['authenticated']
