import os
from types import SimpleNamespace

import docker

from backend.config import Config
from backend.runtime import PythonRuntime
from backend.store import Store


def test_docker_runtime_isolation_and_persistent_volume_contract(tmp_path,monkeypatch):
    config=Config(data_dir=tmp_path)
    runtime=PythonRuntime(Store(tmp_path),config)
    created=[];networks={};volumes=[]
    gateway=SimpleNamespace(attrs={'NetworkSettings':{'Networks':{}}},reload=lambda:None)
    class Networks:
        def get(self,name):
            if name not in networks:raise docker.errors.NotFound('missing')
            return networks[name]
        def create(self,name,**kwargs):
            value=SimpleNamespace(name=name,connect=lambda container:container.attrs['NetworkSettings']['Networks'].update({name:{}}))
            networks[name]=value;return value
    class Containers:
        def get(self,name):
            if name=='gateway':return gateway
            raise docker.errors.NotFound('missing')
        def create(self,image,**kwargs):
            created.append((image,kwargs))
            return SimpleNamespace(id=kwargs['name'],status='created',reload=lambda:None,start=lambda:None)
    client=SimpleNamespace(images=SimpleNamespace(get=lambda name:None),networks=Networks(),containers=Containers(),
                           volumes=SimpleNamespace(create=lambda name,**kwargs:volumes.append(name)),close=lambda:None)
    monkeypatch.setattr(runtime,'client',lambda:client);monkeypatch.setenv('OIO_GATEWAY_CONTAINER','gateway')
    site={'id':'site_0123456789abcdef','slug':'demo'}
    spec={'command':['python','main.py'],'health_path':'/api/health'}
    runtime.provision(site,'beta','ver_123',spec)
    runtime.provision(site,'production','ver_123',spec)
    assert len(set(volumes))==2
    beta,production=created[0][1],created[1][1]
    assert beta['network']!=production['network']
    assert beta['environment']['OIO_BASE_PATH']=='/demo-beta/'
    assert production['environment']['OIO_BASE_PATH']=='/demo/'
    for _,options in created:
        assert 'ports' not in options
        assert options['read_only'] and options['user']=='10001:10001'
        assert options['cap_drop']==['ALL']
        assert options['pids_limit']==128 and options['mem_limit']=='512m'
        assert all('docker.sock' not in key for key in options['volumes'])
        assert 'OIO_ADMIN_PASSWORD' not in options['environment']
