import os
import socket
import threading
import time
from contextlib import contextmanager
from pathlib import Path

import httpx
import pytest
import uvicorn

from backend.app import create_app
from backend.artifacts import save_version
from backend.config import Config, ROOT
from tests.conftest import PASSWORD, HEADERS
from tests.fake_agent import FakeAgent

pytestmark=pytest.mark.skipif(os.getenv('OIO_BROWSER_TEST')!='1',reason='Set OIO_BROWSER_TEST=1 to run Chromium QA')


@contextmanager
def serve(app):
    sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    server=uvicorn.Server(uvicorn.Config(app,log_level='error',lifespan='on'))
    thread=threading.Thread(target=server.run,kwargs={'sockets':[sock]},daemon=True);thread.start()
    deadline=time.monotonic()+10
    while not server.started and time.monotonic()<deadline:time.sleep(.02)
    assert server.started
    try:yield f'http://127.0.0.1:{port}'
    finally:server.should_exit=True;thread.join(timeout=10);sock.close()


def test_browser_conversation_catalog_and_mobile(tmp_path):
    from playwright.sync_api import sync_playwright,expect
    agent=FakeAgent();app=create_app(Config(data_dir=tmp_path,admin_password=PASSWORD,agent_url='http://agent.test/api',poll_seconds=.02),agent.factory)
    output=ROOT/'artifacts';output.mkdir(exist_ok=True)
    with serve(app) as url,sync_playwright() as playwright:
        browser=playwright.chromium.launch();page=browser.new_page(viewport={'width':1440,'height':1000})
        errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
        page.goto(url)
        expect(page.locator('#prompt')).to_be_visible()
        assert page.locator('#publish-site, #archive-site, #create-site').count()==0
        page.locator('#prompt').fill('制作一个咖啡店网站，名字叫山野咖啡')
        page.locator('#send').click()
        expect(page.locator('#login-form')).to_be_visible()
        page.locator('#password').fill(PASSWORD)
        page.locator('#login-form button[type=submit]').click()
        expect(page.locator('.job.success')).to_be_visible(timeout=20000)
        expect(page.locator('.context-addresses .address')).to_have_count(2)
        def say(text):
            page.locator('#prompt').fill(text);page.locator('#send').click()
            expect(page.locator('#prompt')).to_have_value('')
            expect(page.locator('#send')).to_be_enabled()
        say('打标签 张三，设计组')
        expect(page.locator('.card-tags')).to_contain_text('张三')
        say('发布')
        expect(page.locator('.card-name small')).to_have_text('已上线')
        say('预览')
        page.screenshot(path=str(output/'dashboard.png'),full_page=True)
        with page.expect_popup() as opened:page.locator('.site-cover').click()
        website=opened.value
        expect(website.locator('h1')).to_have_text('Generated website')
        expect(website.locator('body')).to_have_attribute('data-module-loaded','yes')
        assert website.locator('a[href="/"]').count()==0
        website.get_by_text('About',exact=True).click()
        expect(website.locator('h1')).to_have_text('About this site');website.close()
        page.locator('#search').fill('#张三');expect(page.locator('.site-card')).to_have_count(1)
        page.locator('#search').fill('not-a-match');expect(page.locator('.site-card')).to_have_count(0)
        page.locator('#search').fill('')
        page.set_viewport_size({'width':390,'height':844})
        assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
        page.screenshot(path=str(output/'dashboard-mobile.png'),full_page=True)
        page.reload();expect(page.locator('.context-label')).to_contain_text('山野咖啡')
        say('归档');expect(page.locator('.site-card')).to_have_count(0)
        say('恢复网站');expect(page.locator('.site-card')).to_have_count(1)
        page.locator('#settings').click();page.locator('#check-connection').click()
        expect(page.locator('#settings-result')).to_have_text('连接成功')
        assert not errors,errors
        browser.close()


@pytest.mark.skipif(os.getenv('OIO_REACT_TEST')!='1',reason='Build templates/react and set OIO_REACT_TEST=1')
def test_actual_react_build_under_beta_and_production(tmp_path):
    from playwright.sync_api import sync_playwright,expect
    built=ROOT/'templates/react/dist'
    assert (built/'index.html').is_file(),'Run npm ci && npm run build in templates/react first'
    config=Config(data_dir=tmp_path,admin_password=PASSWORD)
    app=create_app(config)
    with serve(app) as url:
        with httpx.Client(base_url=url,headers=HEADERS) as client:
            client.post('/api/login',json={'password':PASSWORD})
            site=client.post('/api/sites',json={'name':'React website','slug':'react-demo'}).json()
            files={p.relative_to(built).as_posix():p.read_bytes() for p in built.rglob('*') if p.is_file()}
            version=save_version(app.state.store,config,site['id'],files,'Real React build')
            assert client.post(f"/api/sites/{site['id']}/publish",json={'version_id':version}).status_code==200
        with sync_playwright() as playwright:
            browser=playwright.chromium.launch();page=browser.new_page()
            errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
            for prefix in ('react-demo-beta','react-demo'):
                page.goto(url+'/'+prefix+'/')
                expect(page.get_by_role('button')).to_have_text('灵感 + 0')
                page.get_by_role('button').click();expect(page.get_by_role('button')).to_have_text('灵感 + 1')
                page.get_by_role('link',name='关于',exact=True).click()
                expect(page.locator('h1')).to_have_text('关于这个网站')
                assert page.url.endswith('/'+prefix+'/about')
                page.reload();expect(page.locator('h1')).to_have_text('关于这个网站')
                assert page.locator('a[href="/"]').count()==0
            assert not errors,errors
            browser.close()
