import importlib.util
import socket
import threading
import time
from pathlib import Path

import pytest
import uvicorn
from fastapi import FastAPI, Request, WebSocket
from fastapi.responses import StreamingResponse
from fastapi.testclient import TestClient

from backend.app import create_app
from backend.config import Config, ROOT
from tests.conftest import PASSWORD, HEADERS
from tests.test_platform import create


def test_real_python_http_sse_upload_and_websocket_gateway(tmp_path):
    upstream=FastAPI()

    @upstream.post('/api/upload')
    async def upload(request: Request):
        return {'size':len(await request.body()),'prefix':request.headers.get('x-forwarded-prefix')}

    @upstream.get('/api/events')
    async def events():
        async def stream():
            yield b'data: first\n\n';yield b'data: second\n\n'
        return StreamingResponse(stream(),media_type='text/event-stream')

    @upstream.websocket('/api/socket')
    async def socket_echo(socket: WebSocket):
        await socket.accept()
        try:
            while True:await socket.send_text('echo:'+await socket.receive_text())
        except Exception:pass

    sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    server=uvicorn.Server(uvicorn.Config(upstream,log_level='error'))
    thread=threading.Thread(target=server.run,kwargs={'sockets':[sock]},daemon=True);thread.start()
    deadline=time.monotonic()+10
    while not server.started and time.monotonic()<deadline:time.sleep(.02)
    assert server.started
    class LocalRuntime:
        def __init__(self,*args):pass
        async def prepare(self,*args):pass
        async def stop_others(self,*args):pass
        async def target(self,*args):return f'http://127.0.0.1:{port}'
    try:
        app=create_app(Config(data_dir=tmp_path,admin_password=PASSWORD),runtime_factory=LocalRuntime)
        with TestClient(app) as client:
            client.headers.update(HEADERS);client.post('/api/login',json={'password':PASSWORD})
            site=create(client)
            client.post(f"/api/sites/{site['id']}/publish",json={'version_id':site['beta_version']})
            response=client.post('/studio/api/upload',content=b'x'*300000)
            assert response.json()=={'size':300000,'prefix':'/studio'}
            response=client.get('/studio-beta/api/events')
            assert response.text=='data: first\n\ndata: second\n\n'
            assert response.headers['content-type'].startswith('text/event-stream')
            with client.websocket_connect('/studio/api/socket') as connection:
                connection.send_text('hello');assert connection.receive_text()=='echo:hello'
    finally:
        server.should_exit=True;thread.join(timeout=10);sock.close()


def test_example_python_backend_persists_real_data(tmp_path,monkeypatch):
    monkeypatch.setenv('OIO_DATA_DIR',str(tmp_path))
    spec=importlib.util.spec_from_file_location('example_backend',ROOT/'templates/python/backend/main.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    with TestClient(module.app) as client:
        assert client.get('/api/health').json()['status']=='ok'
        assert client.post('/api/notes',json={'text':'persistent note'}).status_code==201
    reloaded=importlib.util.module_from_spec(spec);spec.loader.exec_module(reloaded)
    with TestClient(reloaded.app) as client:
        assert client.get('/api/notes').json()[0]['text']=='persistent note'
