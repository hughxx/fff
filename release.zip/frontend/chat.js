const $ = (s, root = document) => root.querySelector(s);
const esc = (value) =>
  String(value ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
const state = {
  conversation: null,
  workspace: null,
  sites: [],
  query: "",
  tag: "",
  sort: "visits",
  sending: false,
  request: null,
  route: 0,
};
const phases = {
  queued: "正在安排",
  provisioning: "正在准备网站",
  submitting: "正在理解需求",
  generating: "正在构建",
  collecting: "正在整理新版本",
  deploying: "正在启动测试服务",
  complete: "测试地址已更新",
  cancelled: "任务已停止",
};
const siteRoute = () =>
  /^#\/sites\/([a-zA-Z0-9_-]+)$/.exec(location.hash)?.[1] || null;
const newId = () =>
  crypto.randomUUID
    ? crypto.randomUUID()
    : Date.now() + "-" + Math.random().toString(36).slice(2);
async function api(path, method = "GET", body) {
  const response = await fetch("/api" + path, {
    method,
    headers: { "Content-Type": "application/json", "X-OIO-Request": "1" },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  const value = await response.json();
  if (!response.ok) {
    const error = new Error(
      Array.isArray(value.detail)
        ? value.detail.map((x) => x.msg).join("；")
        : value.detail || "请求失败",
    );
    error.status = response.status;
    throw error;
  }
  return value;
}
function toast(message) {
  $("#toast").textContent = message;
  $("#toast").className = "visible";
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => ($("#toast").className = ""), 4500);
}
function modal(html) {
  const dialog = $("#dialog");
  dialog.innerHTML = html;
  if (!dialog.open) dialog.showModal();
  $("[data-close]", dialog).onclick = () => dialog.close();
  return dialog;
}
function links(items) {
  return (items || [])
    .map(
      (link) =>
        `<a href="${esc(link.url)}" target="_blank" rel="noopener" class="address"><span>${esc(link.label)}</span><strong>${esc(link.url.startsWith("/api/") ? "版本归档" : location.host + link.url)}</strong><i>↗</i></a>`,
    )
    .join("");
}
function shell() {
  const inside = !!siteRoute(),
    site = state.workspace;
  $("#app").innerHTML =
    `<header class="home-header"><a class="logo" href="#/">OIO<span>✳</span></a><span class="header-label">微站工坊</span><div class="header-right"><button class="quiet" id="settings" aria-label="连接设置">⚙</button></div></header><main class="home-main ${inside ? "workspace-main" : ""}">${
      inside
        ? `
    <a class="back-home" href="#/">← 所有网站</a>
    <section class="workspace-heading"><span class="eyebrow">WEBSITE WORKSPACE</span><h1 id="workspace-title">${esc(site?.name || "正在打开网站…")}</h1><p>在这里和 AI 沟通需求，完成后打开测试页查看，再说“发布”。</p></section>
    <div id="context"></div>
    <section class="chat-shell" aria-label="网站对话"><div class="workspace-chat-title">✧ 网站对话 <span>所有修改都会先更新测试环境</span></div><div id="messages" aria-live="polite"></div><form id="chat-form"><label class="sr-only" for="prompt">描述网站需求</label><textarea id="prompt" rows="3" maxlength="30000" placeholder="说说这个网站要做什么，或描述你想修改的地方…" required></textarea><div class="composer-bottom"><span>⌘ / Ctrl + Enter 发送</span><button class="send" id="send" aria-label="发送消息" type="submit">↗</button></div></form><div class="chat-hint">可以说“打标签 设计组”“发布”“回滚”“下线”或“恢复网站”。</div></section>`
        : `
    <section class="catalog-heading"><div><span class="eyebrow">YOUR WEBSITES, ONE HOME.</span><h1>所有网站，都在这里<span>。</span></h1><p>选择一张卡片，进入网站的对话与管理空间。</p></div><button id="create-site" class="btn primary">＋ 新建网站</button></section>
    <section class="collection"><div class="collection-toolbar"><div><h2>所有网站 <span id="count"></span></h2></div><div class="collection-tools"><label class="search"><span>⌕</span><input type="search" id="search" placeholder="搜索网站、地址或 #标签" aria-label="搜索网站和标签"></label><select id="sort" aria-label="网站排序"><option value="visits">最多访问</option><option value="updated">最近更新</option></select></div></div><div id="tags" class="tag-filter"></div><div id="site-grid" class="site-grid"></div></section>`
    }<footer class="home-footer"><span>一个网站，一段持续的对话。</span><span>OIO · SMALL WEBSITES, BIG IDEAS</span></footer></main>`;
  $("#settings")?.addEventListener("click", settingsDialog);
  if (inside) {
    $("#chat-form").onsubmit = (e) => {
      e.preventDefault();
      send($("#prompt").value);
    };
    $("#prompt").onkeydown = (e) => {
      if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        $("#chat-form").requestSubmit();
      }
    };
    renderConversation();
  } else {
    $("#create-site").onclick = newSiteDialog;
    $("#search").value = state.query;
    $("#sort").value = state.sort;
    $("#search").oninput = (e) => {
      state.query = e.target.value;
      renderCards();
    };
    $("#sort").onchange = (e) => {
      state.sort = e.target.value;
      renderCards();
    };
    renderCards();
  }
}
function renderConversation() {
  const container = $("#messages");
  if (!container) return;
  const data = state.conversation,
    site = data?.site || state.workspace;
  const near =
      container.scrollHeight - container.scrollTop - container.clientHeight <
      100,
    old = container.scrollTop;
  $("#workspace-title").textContent = site?.name || "网站管理";
  $("#context").innerHTML = site
    ? `<div class="context-label"><span>${site.archived ? "已下线 · 数据与版本已保留" : site.production_version ? "已上线 · 测试修改不会覆盖生产" : "尚未发布 · 先在对话中创建内容"}</span><span>${(site.tags || []).map((tag) => "#" + esc(tag)).join(" ")}</span></div><div class="context-addresses">${links(
        [
          {
            label: site.archived
              ? "生产页面（已下线）"
              : site.production_version
                ? "进入生产页面"
                : "生产页面（待发布）",
            url: `/${site.slug}/`,
          },
          {
            label: site.archived ? "测试页面（已下线）" : "进入测试页面",
            url: `/${site.slug}-beta/`,
          },
        ],
      )}</div>`
    : "";
  container.innerHTML = data?.messages.length
    ? data.messages
        .map(
          (message) =>
            `<article class="message ${message.role}"><span class="message-role">${message.role === "user" ? "你" : "✳ OIO"}</span><div class="message-text">${esc(message.content)}</div>${message.links?.length && !message.job_id ? `<div class="message-links">${links(message.links)}</div>` : ""}${message.job ? `<div class="job ${esc(message.job.status)}"><span>${["running", "queued"].includes(message.job.status) ? '<i class="spinner"></i>' : ""}${esc(phases[message.job.stage] || message.job.stage)}</span><p>${esc(message.job.status === "success" ? message.job.result : message.job.error || "在后台继续执行，离开页面也不会中断。")}</p></div>` : ""}</article>`,
        )
        .join("")
    : `<div class="conversation-empty"><span>✧</span><h2>从这个网站的第一个想法开始</h2><p>描述页面、功能或 Python 后端需求，AI 会先更新测试环境。</p></div>`;
  container.scrollTop = near ? container.scrollHeight : old;
  $("#send").disabled = state.sending;
}
function renderCards() {
  if (!$("#site-grid")) return;
  const allTags = [
    ...new Set(state.sites.flatMap((site) => site.tags || [])),
  ].sort();
  $("#tags").innerHTML = allTags.length
    ? `<button data-tag="" class="${!state.tag ? "selected" : ""}">全部</button>` +
      allTags
        .map(
          (tag) =>
            `<button data-tag="${esc(tag)}" class="${state.tag === tag ? "selected" : ""}">#${esc(tag)}</button>`,
        )
        .join("")
    : "";
  const query = state.query.replace(/^#/, "").toLocaleLowerCase();
  const sites = state.sites.filter(
    (site) =>
      (!state.tag || (site.tags || []).includes(state.tag)) &&
      [site.name, site.slug, site.description, ...(site.tags || [])]
        .join(" ")
        .toLocaleLowerCase()
        .includes(query),
  );
  sites.sort((a, b) =>
    state.sort === "visits"
      ? b.visits - a.visits || b.updated_at.localeCompare(a.updated_at)
      : b.updated_at.localeCompare(a.updated_at),
  );
  $("#count").textContent = sites.length;
  $("#site-grid").innerHTML =
    sites
      .map((site, index) => {
        const route = `#/sites/${site.id}`;
        return `<article class="site-card ${site.archived ? "archived" : ""}"><a class="site-cover theme-${index % 4}" href="${route}" aria-label="管理 ${esc(site.name)}"><span class="cover-kicker">${esc(site.slug.toUpperCase())} <i>↗</i></span><h3>${esc(site.name)}</h3><span class="cover-symbol">${["✳", "◒", "✧", "◈"][index % 4]}</span><span class="cover-address">/${esc(site.slug)}/</span></a><div class="card-info"><div class="card-name"><a href="${route}">${esc(site.name)}</a><small>${site.archived ? "已下线" : site.production_version ? "已上线" : "测试中"}</small></div><p>${esc(site.description || "进入网站空间，和 AI 一起完善你的想法。")}</p><div class="card-tags">${(site.tags || []).map((tag) => `<button data-tag="${esc(tag)}">#${esc(tag)}</button>`).join("")}</div><div class="card-bottom"><span>${Number(site.visits).toLocaleString()} 次访问</span><a class="talk" href="${route}">进入网站空间 →</a></div></div></article>`;
      })
      .join("") ||
    `<div class="empty"><span>✧</span><h3>${query || state.tag ? "没有找到这个网站" : "创建你的第一张网站卡片"}</h3><p>${query || state.tag ? "换个名字、英文地址或标签试试。" : "点击“新建网站”，让第一个想法拥有自己的空间。"}</p></div>`;
  document.querySelectorAll("[data-tag]").forEach(
    (button) =>
      (button.onclick = () => {
        state.tag = button.dataset.tag;
        renderCards();
      }),
  );
}
async function loadSites() {
  state.sites = (await api("/sites")).items;
  renderCards();
}
async function route() {
  const serial = ++state.route,
    id = siteRoute();
  state.conversation = null;
  state.workspace = state.sites.find((site) => site.id === id) || null;
  state.request = null;
  shell();
  if (!id) return;
  try {
    const data = await api("/sites/" + id + "/conversation", "POST");
    if (serial !== state.route) return;
    state.conversation = data;
    state.workspace = data.site;
    renderConversation();
  } catch (error) {
    if (serial === state.route) {
      toast(error.message);
      if (error.status === 404) {
        location.hash = "#/";
      }
    }
  }
}
async function newSiteDialog() {
  const dialog = modal(
    `<form id="create-form"><div class="dialog-title"><div><span class="eyebrow">A NEW WEBSITE</span><h2>新建网站</h2></div><button class="quiet" type="button" data-close aria-label="关闭">×</button></div><p class="muted">先给网站起个名字。创建后进入专属对话，告诉 AI 你想做什么。</p><label for="site-name">网站名称</label><input id="site-name" maxlength="80" placeholder="例如：设计小组的留言板" required><p class="muted">英文地址会自动生成，测试和生产地址会显示在网站管理页。</p><p id="create-error" class="error" role="alert"></p><button class="btn primary" type="submit">创建并进入 →</button></form>`,
  );
  $("#site-name").focus();
  $("#create-form").onsubmit = async (event) => {
    event.preventDefault();
    const button = $("button[type=submit]", event.target);
    button.disabled = true;
    try {
      const site = await api("/sites", "POST", {
        name: $("#site-name").value.trim(),
        slug: "page-" + newId().replace(/-/g, "").slice(0, 12),
      });
      dialog.close();
      await loadSites();
      location.hash = "#/sites/" + site.id;
    } catch (error) {
      $("#create-error").textContent = error.message;
      button.disabled = false;
    }
  };
}
async function send(text) {
  text = text.trim();
  if (!text || state.sending) return;
  if (/^(新建网站|创建网站|做个新网站)$/.test(text)) {
    newSiteDialog();
    return;
  }
  if (/^(返回主页|回到主页|主页|换个网站|结束当前对话)$/.test(text)) {
    location.hash = "#/";
    return;
  }
  if (!state.conversation) {
    toast("网站对话仍在加载，请稍后重试");
    return;
  }
  const conversation = state.conversation,
    serial = state.route;
  state.sending = true;
  $("#send").disabled = true;
  try {
    if (
      !state.request ||
      state.request.prompt !== text ||
      state.request.conversation !== conversation.id
    )
      state.request = {
        prompt: text,
        request_id: newId(),
        expected_beta: conversation.site?.beta_version || null,
        conversation: conversation.id,
      };
    const data = await api(
      "/conversations/" + conversation.id + "/messages",
      "POST",
      state.request,
    );
    if (serial === state.route) {
      state.request = null;
      state.conversation = data;
      state.workspace = data.site;
      $("#prompt").value = "";
      if (data.site?.id !== siteRoute()) {
        location.hash = data.site ? "#/sites/" + data.site.id : "#/";
      } else renderConversation();
    }
    await loadSites();
  } catch (error) {
    toast(error.message);
  } finally {
    state.sending = false;
    if ($("#send")) $("#send").disabled = false;
  }
}
async function poll() {
  try {
    const conversation = state.conversation,
      serial = state.route;
    if (conversation && !state.sending) {
      const value = await api("/conversations/" + conversation.id);
      if (
        serial === state.route &&
        state.conversation?.id === value.id &&
        !state.sending
      ) {
        state.conversation = value;
        state.workspace = value.site;
        renderConversation();
      }
    } else if (!siteRoute()) {
      await loadSites();
    }
  } catch (error) {
    // A temporary connection failure is retried on the next poll.
  }
  setTimeout(poll, 3000);
}
async function boot() {
  try {
    await loadSites();
    await route();
    window.addEventListener("hashchange", () => route());
    poll();
  } catch (error) {
    $("#app").innerHTML =
      `<main class="empty"><h2>暂时无法连接</h2><p>${esc(error.message)}</p><a href="/">重新打开主页</a></main>`;
  }
}
boot();

async function settingsDialog() {
  try {
    const value = await api("/settings");
    const dialog = modal(
      `<form id="settings-form"><div class="dialog-title"><h2>连接 AI 服务</h2><button class="quiet" type="button" data-close aria-label="关闭">×</button></div><label for="agent-url">CodeAgent API 地址</label><input id="agent-url" type="url" value="${esc(value.url)}" placeholder="http://host:port/api"><label for="agent-account">账号 ID（可选）</label><input id="agent-account" value="${esc(value.account)}"><label for="agent-model">模型（可选）</label><input id="agent-model" value="${esc(value.model)}"><p id="settings-result" class="muted" role="status"></p><div class="dialog-actions"><button class="btn" type="button" id="check-connection">测试已保存连接</button><button class="btn primary" type="submit">保存</button></div></form>`,
    );
    $("#settings-form").onsubmit = async (event) => {
      event.preventDefault();
      try {
        await api("/settings", "PUT", {
          url: $("#agent-url").value,
          account: $("#agent-account").value,
          model: $("#agent-model").value,
        });
        $("#settings-result").textContent =
          "已保存，可以进入网站空间继续对话。";
      } catch (error) {
        $("#settings-result").textContent = error.message;
      }
    };
    $("#check-connection").onclick = async () => {
      try {
        await api("/settings/check", "POST");
        $("#settings-result").textContent = "连接成功";
      } catch (error) {
        $("#settings-result").textContent = error.message;
      }
    };
  } catch (error) {
    toast(error.message);
  }
}
