const $ = (s, root = document) => root.querySelector(s);
const esc = (value) =>
  String(value ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
const state = {
  authenticated: false,
  conversation: null,
  sites: [],
  query: "",
  tag: "",
  sort: "visits",
  sending: false,
  request: null,
};
const phases = {
  queued: "正在安排",
  provisioning: "正在准备网站",
  submitting: "正在理解需求",
  generating: "正在构建",
  collecting: "正在整理新版本",
  deploying: "正在启动测试服务",
  complete: "测试地址已更新",
  cancelled: "任务已停止",
};
async function api(path, method = "GET", body) {
  const response = await fetch("/api" + path, {
    method,
    headers: { "Content-Type": "application/json", "X-OIO-Request": "1" },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  const value = await response.json();
  if (!response.ok) {
    const error = new Error(
      Array.isArray(value.detail)
        ? value.detail.map((x) => x.msg).join("；")
        : value.detail || "请求失败",
    );
    error.status = response.status;
    throw error;
  }
  return value;
}
function toast(message) {
  $("#toast").textContent = message;
  $("#toast").className = "visible";
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => ($("#toast").className = ""), 4500);
}
function modal(html) {
  const dialog = $("#dialog");
  dialog.innerHTML = html;
  if (!dialog.open) dialog.showModal();
  $("[data-close]", dialog).onclick = () => dialog.close();
  return dialog;
}
function shell() {
  $("#app").innerHTML =
    `<header class="home-header"><a class="logo" href="/">OIO<span>✳</span></a><span class="header-label">微站工坊</span><div class="header-right">${state.authenticated ? '<span>● 共享工作空间</span><button class="quiet" id="settings" aria-label="平台设置">⚙</button>' : '<button class="quiet" id="login">管理登录 ↗</button>'}</div></header><main class="home-main"><section class="hero"><span class="eyebrow">ONE HOME. ENDLESS POSSIBILITIES.</span><h1>把想法说出来，<br class="mobile-break">剩下的交给 AI<span>。</span></h1><p>你的所有网站，一个熟悉的入口。</p></section><section class="chat-shell" aria-label="网站对话"><div id="context"></div><div id="messages" aria-live="polite"></div><form id="chat-form"><label class="sr-only" for="prompt">描述你的想法</label><textarea id="prompt" rows="2" maxlength="30000" placeholder="帮我做一个咖啡店网站，支持菜单、预约和留言…" required></textarea><div class="composer-bottom"><span>✧ 用对话创建、修改和管理网站</span><button class="send" id="send" aria-label="发送消息" type="submit">↗</button></div></form><div class="chat-hint">可以说“修改 /coffee”“发布”“回到上个版本”或“打标签 设计组”。</div></section><section class="collection"><div class="collection-toolbar"><div><span class="eyebrow">YOUR WEBSITES</span><h2>每一个想法，都有自己的地址 <span id="count"></span></h2></div><div class="collection-tools"><label class="search"><span>⌕</span><input type="search" id="search" placeholder="搜索网站、地址或 #标签" aria-label="搜索网站和标签"></label><select id="sort" aria-label="网站排序"><option value="visits">最多访问</option><option value="updated">最近更新</option></select></div></div><div id="tags" class="tag-filter"></div><div id="site-grid" class="site-grid"></div></section><footer class="home-footer"><span>记住这一个地址，就能找到所有好想法。</span><span>OIO · SMALL WEBSITES, BIG IDEAS</span></footer></main>`;
  $("#login")?.addEventListener("click", () => loginDialog());
  $("#settings")?.addEventListener("click", settingsDialog);
  $("#chat-form").onsubmit = (e) => {
    e.preventDefault();
    send($("#prompt").value);
  };
  $("#prompt").onkeydown = (e) => {
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      $("#chat-form").requestSubmit();
    }
  };
  $("#search").value = state.query;
  $("#sort").value = state.sort;
  $("#search").oninput = (e) => {
    state.query = e.target.value;
    renderCards();
  };
  $("#sort").onchange = (e) => {
    state.sort = e.target.value;
    renderCards();
  };
  renderConversation();
  renderCards();
}
function links(items) {
  return (items || [])
    .map(
      (link) =>
        `<a href="${esc(link.url)}" target="_blank" rel="noopener" class="address"><span>${esc(link.label)}</span><strong>${esc(link.url.startsWith("/api/") ? "版本归档" : location.host + link.url)}</strong><i>↗</i></a>`,
    )
    .join("");
}
function renderConversation() {
  const data = state.conversation,
    container = $("#messages");
  if (!container) return;
  const near =
      container.scrollHeight - container.scrollTop - container.clientHeight <
      100,
    old = container.scrollTop;
  $("#context").innerHTML = data?.site
    ? `<div class="context-label"><span>✳ 正在聊「${esc(data.site.name)}」${data.site.archived ? " · 已归档" : ""}</span><span>说“新建网站”开始下一个想法</span></div><div class="context-addresses">${links(data.links)}</div>`
    : "";
  container.hidden = !data?.messages.length;
  container.innerHTML = (data?.messages || [])
    .map(
      (message) =>
        `<article class="message ${message.role}"><span class="message-role">${message.role === "user" ? "你" : "✳ OIO"}</span><div class="message-text">${esc(message.content)}</div>${message.links?.length && !message.job_id ? `<div class="message-links">${links(message.links)}</div>` : ""}${message.job ? `<div class="job ${esc(message.job.status)}"><span>${["running", "queued"].includes(message.job.status) ? '<i class="spinner"></i>' : ""}${esc(phases[message.job.stage] || message.job.stage)}</span><p>${esc(message.job.status === "success" ? message.job.result : message.job.error || "在后台继续执行，离开页面也不会中断。")}</p></div>` : ""}</article>`,
    )
    .join("");
  container.scrollTop = near ? container.scrollHeight : old;
  $("#send").disabled = state.sending;
}
function renderCards() {
  if (!$("#site-grid")) return;
  const allTags = [
    ...new Set(state.sites.flatMap((site) => site.tags || [])),
  ].sort();
  $("#tags").innerHTML = allTags.length
    ? `<button data-tag="" class="${!state.tag ? "selected" : ""}">全部</button>` +
      allTags
        .map(
          (tag) =>
            `<button data-tag="${esc(tag)}" class="${state.tag === tag ? "selected" : ""}">#${esc(tag)}</button>`,
        )
        .join("")
    : "";
  $("#tags")
    .querySelectorAll("[data-tag]")
    .forEach(
      (button) =>
        (button.onclick = () => {
          state.tag = button.dataset.tag;
          renderCards();
        }),
    );
  const query = state.query.replace(/^#/, "").toLocaleLowerCase();
  const sites = state.sites.filter(
    (site) =>
      !site.archived &&
      (!state.tag || (site.tags || []).includes(state.tag)) &&
      [site.name, site.slug, site.description, ...(site.tags || [])]
        .join(" ")
        .toLocaleLowerCase()
        .includes(query),
  );
  sites.sort((a, b) =>
    state.sort === "visits"
      ? b.visits - a.visits || b.updated_at.localeCompare(a.updated_at)
      : b.updated_at.localeCompare(a.updated_at),
  );
  $("#count").textContent = sites.length;
  $("#site-grid").innerHTML =
    sites
      .map((site, index) => {
        const live = site.production_version !== null,
          url = `/${site.slug}${live ? "" : "-beta"}/`;
        return `<article class="site-card"><a class="site-cover theme-${index % 4}" href="${url}" target="_blank" rel="noopener"><span class="cover-kicker">${esc(site.slug.toUpperCase())} <i>↗</i></span><h3>${esc(site.name)}</h3><span class="cover-symbol">${["✳", "◒", "✧", "◈"][index % 4]}</span><span class="cover-address">${esc(url)}</span></a><div class="card-info"><div class="card-name"><a href="${url}" target="_blank" rel="noopener">${esc(site.name)}</a><small>${live ? "已上线" : "测试中"}</small></div><p>${esc(site.description || "一个独立的小网站，一份自己的想法。")}</p><div class="card-tags">${(site.tags || []).map((tag) => `<button data-tag="${esc(tag)}">#${esc(tag)}</button>`).join("")}</div><div class="card-bottom"><span>${Number(site.visits).toLocaleString()} 次访问</span>${state.authenticated ? `<button class="talk" data-talk="${esc(site.slug)}">✧ 聊聊这个网站</button>` : `<a href="${url}" target="_blank" rel="noopener">打开网站 ↗</a>`}</div></div></article>`;
      })
      .join("") ||
    `<div class="empty"><span>✧</span><h3>${query || state.tag ? "没有找到这个网站" : "下一张卡片，就是你的想法。"}</h3><p>${query || state.tag ? "换个名字、英文地址或标签试试。" : "在上面的对话框里，说说你想做什么。"}</p></div>`;
  $("#site-grid")
    .querySelectorAll("[data-talk]")
    .forEach(
      (button) =>
        (button.onclick = () => {
          send("修改 /" + button.dataset.talk);
          $(".chat-shell").scrollIntoView({
            behavior: "smooth",
            block: "start",
          });
        }),
    );
  $("#site-grid")
    .querySelectorAll("[data-tag]")
    .forEach(
      (button) =>
        (button.onclick = () => {
          state.tag = button.dataset.tag;
          renderCards();
        }),
    );
}
async function loadSites() {
  state.sites = (await api(state.authenticated ? "/sites" : "/catalog")).items;
  renderCards();
}
async function ensureConversation() {
  if (state.conversation) return;
  const stored = localStorage.getItem("oio-conversation");
  if (stored) {
    try {
      state.conversation = await api("/conversations/" + stored);
      return;
    } catch (error) {
      if (error.status !== 404) throw error;
    }
  }
  state.conversation = await api("/conversations", "POST");
  localStorage.setItem("oio-conversation", state.conversation.id);
}
async function send(text) {
  text = text.trim();
  if (!text || state.sending) return;
  if (!state.authenticated) {
    loginDialog(() => send(text));
    return;
  }
  state.sending = true;
  $("#send").disabled = true;
  try {
    await ensureConversation();
    if (
      !state.request ||
      state.request.prompt !== text ||
      state.request.conversation !== state.conversation.id
    )
      state.request = {
        prompt: text,
        request_id: crypto.randomUUID
          ? crypto.randomUUID()
          : Date.now() + "-" + Math.random().toString(36).slice(2),
        expected_beta: state.conversation.site?.beta_version || null,
        conversation: state.conversation.id,
      };
    state.conversation = await api(
      "/conversations/" + state.conversation.id + "/messages",
      "POST",
      state.request,
    );
    state.request = null;
    $("#prompt").value = "";
    renderConversation();
    await loadSites();
  } catch (error) {
    toast(error.message);
    if (error.status === 401) {
      state.authenticated = false;
      loginDialog();
    }
  } finally {
    state.sending = false;
    if ($("#send")) $("#send").disabled = false;
  }
}
function loginDialog(after) {
  const dialog = modal(
    `<form id="login-form"><div class="dialog-title"><div><span class="eyebrow">YOUR SHARED WORKSPACE</span><h2>继续你的对话</h2></div><button class="quiet" type="button" data-close aria-label="关闭">×</button></div><p class="muted">浏览网站无需登录。创建和修改使用工作空间的共享管理密码。</p><label for="password">管理密码</label><input id="password" type="password" autocomplete="current-password" required minlength="12"><p id="login-error" class="error" role="alert"></p><button class="btn primary" type="submit">继续 ↗</button></form>`,
  );
  $("#login-form").onsubmit = async (event) => {
    event.preventDefault();
    const button = $("button[type=submit]", event.target);
    button.disabled = true;
    try {
      await api("/login", "POST", { password: $("#password").value });
      state.authenticated = true;
      dialog.close();
      await ensureConversation();
      shell();
      await loadSites();
      after?.();
    } catch (error) {
      $("#login-error").textContent = error.message;
    } finally {
      button.disabled = false;
    }
  };
}
async function settingsDialog() {
  try {
    const value = await api("/settings");
    const dialog = modal(
      `<form id="settings-form"><div class="dialog-title"><h2>连接 AI 服务</h2><button class="quiet" type="button" data-close aria-label="关闭">×</button></div><label for="agent-url">CodeAgent API 地址</label><input id="agent-url" type="url" value="${esc(value.url)}" placeholder="http://host:port/api"><label for="agent-account">账号 ID（可选）</label><input id="agent-account" value="${esc(value.account)}"><label for="agent-model">模型（可选）</label><input id="agent-model" value="${esc(value.model)}"><p id="settings-result" class="muted" role="status"></p><div class="dialog-actions"><button class="btn" type="button" id="check-connection">测试已保存连接</button><button class="btn primary" type="submit">保存</button></div><button class="quiet logout" type="button" id="logout">退出管理登录</button></form>`,
    );
    $("#settings-form").onsubmit = async (event) => {
      event.preventDefault();
      try {
        await api("/settings", "PUT", {
          url: $("#agent-url").value,
          account: $("#agent-account").value,
          model: $("#agent-model").value,
        });
        $("#settings-result").textContent = "已保存，可以回主页继续对话。";
      } catch (error) {
        $("#settings-result").textContent = error.message;
      }
    };
    $("#check-connection").onclick = async () => {
      try {
        await api("/settings/check", "POST");
        $("#settings-result").textContent = "连接成功";
      } catch (error) {
        $("#settings-result").textContent = error.message;
      }
    };
    $("#logout").onclick = async () => {
      await api("/logout", "POST");
      state.authenticated = false;
      state.conversation = null;
      dialog.close();
      shell();
      await loadSites();
    };
  } catch (error) {
    toast(error.message);
  }
}
async function poll() {
  try {
    if (state.authenticated && state.conversation && !state.sending) {
      const value = await api("/conversations/" + state.conversation.id);
      const key = JSON.stringify(value);
      if (key !== state.key) {
        state.key = key;
        state.conversation = value;
        renderConversation();
        await loadSites();
      }
    }
  } catch (error) {
    if (error.status === 401) {
      state.authenticated = false;
      state.conversation = null;
      shell();
      await loadSites();
    }
  }
  setTimeout(poll, 3000);
}
async function boot() {
  try {
    state.authenticated = (await api("/auth")).authenticated;
    if (state.authenticated) await ensureConversation();
    shell();
    await loadSites();
    poll();
  } catch (error) {
    $("#app").innerHTML =
      `<main class="empty"><h2>暂时无法连接</h2><p>${esc(error.message)}</p><a href="/">重新打开主页</a></main>`;
  }
}
boot();
