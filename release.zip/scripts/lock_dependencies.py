"""Lock the installed runtime dependency closure after installing requirements.txt."""
from importlib.metadata import distribution
from pathlib import Path

from packaging.requirements import Requirement
from packaging.utils import canonicalize_name

seen = {}
pending = ['fastapi', 'uvicorn', 'httpx', 'websockets']
while pending:
    name = pending.pop()
    key = canonicalize_name(name)
    if key in seen:
        continue
    package = distribution(name)
    seen[key] = package.version
    for raw in package.requires or []:
        requirement = Requirement(raw)
        if not requirement.marker or requirement.marker.evaluate({'extra': ''}):
            pending.append(requirement.name)
Path(__file__).resolve().parents[1].joinpath('requirements.lock').write_text(
    '\n'.join(f'{name}=={version}' + ('; sys_platform == "win32"' if name=='pywin32' else '') for name, version in sorted(seen.items())) + '\n', encoding='utf-8',
)
