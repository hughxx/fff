#!/usr/bin/env bash
set -Eeuo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."
umask 077
mkdir -p backups
printf '%s\n' 'Stop OIO before backing up. Website business data remains in CloudAgent workspaces and must be backed up there.'
archive="backups/oio-$(date -u +%Y%m%dT%H%M%SZ).tar.gz"
[[ ! -e "$archive" ]] || { printf '%s\n' 'Backup file already exists.' >&2; exit 1; }
tar -czf "$archive" data .env
printf 'Platform backup: %s (includes credentials; keep private)\n' "$archive"
