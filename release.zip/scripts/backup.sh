#!/usr/bin/env bash
set -Eeuo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."
umask 077
mkdir -p backups
backup_path="backups/oio-$(date -u +%Y%m%dT%H%M%SZ).tar.gz"
if [[ -e "$backup_path" ]]; then
  printf '%s\n' 'A backup with this timestamp already exists. Try again in a second.' >&2
  exit 1
fi
instance="$(docker compose exec -T web python -c 'import sqlite3,json; c=sqlite3.connect("/app/data/oio.sqlite3"); r=c.execute("SELECT value FROM settings WHERE key=?",("runtime_instance",)).fetchone(); print(json.loads(r[0]) if r else "")' | tr -d '\r')"
if [[ ! "$instance" =~ ^oio_[a-f0-9]+$ ]]; then
  printf '%s\n' 'Cannot determine this instance runtime ownership.' >&2
  exit 1
fi
runtime_dir="${backup_path%.tar.gz}-python"
mkdir -p "$runtime_dir"
running_ids="$(docker ps -q --filter "label=io.oio.instance=$instance")"
restart_services() {
  if [[ -n "$running_ids" ]]; then
    while IFS= read -r identifier; do docker start "$identifier" >/dev/null || true; done <<< "$running_ids"
  fi
  docker compose start web >/dev/null
}
trap restart_services EXIT
# Stop every writer before snapshotting the platform and per-environment volumes.
docker compose stop web
if [[ -n "$running_ids" ]]; then
  while IFS= read -r identifier; do docker stop "$identifier" >/dev/null; done <<< "$running_ids"
fi
docker compose run --rm --no-deps -T web python -c \
  'import sys,tarfile; t=tarfile.open(fileobj=sys.stdout.buffer,mode="w|gz"); t.add("/app/data",arcname="data"); t.close()' > "$backup_path"
volumes="$(docker volume ls -q --filter "label=io.oio.instance=$instance")"
if [[ -n "$volumes" ]]; then
  while IFS= read -r volume; do
    [[ "$volume" =~ ^oio_[a-f0-9]+-[a-f0-9]+-(beta|production)-data$ ]] || exit 1
    docker run --rm --network none --read-only -v "$volume:/snapshot:ro" python:3.12-slim \
      tar -C /snapshot -czf - . > "$runtime_dir/$volume.tar.gz"
  done <<< "$volumes"
fi
printf 'Backup saved to %s\n' "$backup_path"
printf 'Python data volumes saved to %s\n' "$runtime_dir"
printf '%s\n' 'Keep .env separately; it is not included in the data backup.'
