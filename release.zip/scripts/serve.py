"""Run the OIO gateway directly; no shell evaluation of .env values."""
import argparse
import errno
import os
from pathlib import Path
import socket
import sys

ROOT = Path(__file__).resolve().parents[1]


def load_environment(root):
    path = root / '.env'
    if not path.exists():
        content = ('OIO_PORT=18743\nOIO_PORT_CANDIDATES=18744,28743\n'
                   'OIO_BIND=0.0.0.0\nCLOUDAGENT_URL=http://10.90.113.228:8800/api\n'
                   'OIO_PYTHON_RUNTIME=true\n')
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, 'w', encoding='utf-8') as handle:
            handle.write(content)
        print('Created .env. OIO is open to everyone; no login is required.', flush=True)
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        key, separator, value = line.partition('=')
        if not separator or not key.strip().isidentifier():
            raise ValueError('Invalid .env entry; use KEY=value')
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
            value = value[1:-1]
        os.environ.setdefault(key.strip(), value)
    if not os.environ.get('CLOUDAGENT_URL'):
        os.environ['CLOUDAGENT_URL'] = 'http://10.90.113.228:8800/api'


def bind_port(host, ports):
    for port in ports:
        connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            connection.bind((host, port))
            connection.listen(2048)
            return connection
        except OSError as error:
            connection.close()
            if error.errno not in (errno.EADDRINUSE, 10048):
                raise
    raise OSError('All requested ports are occupied; use --port or --ports')


def main():
    parser = argparse.ArgumentParser(description='Start OIO without Docker')
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--port', type=int)
    group.add_argument('--ports', help='Comma-separated port candidates')
    args = parser.parse_args()
    os.chdir(ROOT)
    sys.path.insert(0, str(ROOT))
    load_environment(ROOT)
    raw = args.ports or (str(args.port) if args.port is not None else
                         os.environ.get('OIO_PORT', '18743') + ',' + os.environ.get('OIO_PORT_CANDIDATES', '18744,28743'))
    try:
        ports = [int(item) for item in raw.split(',')]
        if not ports or any(not 1 <= port <= 65535 for port in ports):
            raise ValueError()
    except ValueError:
        parser.error('Ports must be integers between 1 and 65535')
    import uvicorn
    from backend.app import app
    connection = bind_port(os.environ.get('OIO_BIND', '0.0.0.0'), ports)
    port = connection.getsockname()[1]
    print(f'OIO home: http://YOUR_SERVER:{port}/ (Ctrl+C to stop)', flush=True)
    try:
        uvicorn.Server(uvicorn.Config(app, proxy_headers=False)).run(sockets=[connection])
    finally:
        connection.close()


if __name__ == '__main__':
    main()
