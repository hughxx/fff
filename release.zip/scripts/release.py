"""Produce a source release; never include local data, passwords, Git or virtualenvs."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = ['Dockerfile', '.dockerignore', 'compose.yaml', '.env.example', 'deploy.sh',
         'requirements.txt', 'requirements.lock', 'requirements-dev.txt', 'README.md',
         'CHANGELOG.md', 'USER_API.md', '.gitignore', '.gitattributes', 'pytest.ini']
DIRECTORIES = ['backend', 'frontend', 'scripts', 'tests', 'docs', 'templates']


def main():
    output = ROOT / 'release.zip'
    paths = [ROOT / name for name in FILES]
    for directory in DIRECTORIES:
        paths.extend(p for p in (ROOT / directory).rglob('*') if p.is_file() and not any(part in ('__pycache__', 'node_modules', 'dist') for part in p.parts) and p.suffix != '.pyc')
    try:
        commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
        dirty = bool(subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip())
    except subprocess.CalledProcessError:
        commit, dirty = None, True
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(paths):
            if not path.is_file():
                raise RuntimeError(f'Missing release file: {path.name}')
            relative = path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(relative)
            info.create_system = 3
            info.external_attr = (0o100755 if path.suffix == '.sh' else 0o100644) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            content = path.read_bytes()
            if path.suffix == '.sh':
                content = content.replace(b'\r\n', b'\n')
            archive.writestr(info, content)
        archive.writestr('release.json', json.dumps({'name': 'OIO', 'version': '0.2.1', 'commit': commit, 'dirty': dirty}, indent=2))
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    (ROOT / 'release.zip.sha256').write_text(f'{digest}  release.zip\n', encoding='ascii')
    print(f'{output.name}: {output.stat().st_size:,} bytes; SHA256 {digest}')


if __name__ == '__main__':
    main()
