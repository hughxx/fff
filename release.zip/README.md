# OIO · 对话式微网站平台

进入主页，用一句话创建网站；AI 编写前端和 Python 后端，构建后更新测试地址。说“发布”才更新生产。主页提供按访问量排序的卡片、标签和搜索，微网站本身没有平台回跳按钮。

```text
https://你的域名/                  公开网站目录与对话入口
https://你的域名/page-a1b2c3/      生产地址
https://你的域名/page-a1b2c3-beta/ 测试地址
https://你的域名/page-a1b2c3/about 网站内部路由
```

英文 URI 在同一实例内唯一，自动分配，归档后保留；保留后缀 `-beta`。目前是共享管理密码的工作空间，没有用户注册系统。公开目录只展示已发布且未归档的网站；管理者可查看未发布网站。生产、测试地址都是公开链接。

## Linux 一键部署

需要 Linux、Docker Engine、Docker Compose v2 和 unzip。首次部署需联网拉取镜像及 Python 依赖；发布包不包含离线镜像，也不包含 CodeAgent 底座。

```bash
unzip release.zip -d oio
cd oio
bash deploy.sh
```

默认使用 **18743**，占用时依次尝试 **18744、28743**，成功端口保存到 `.env`。访问脚本输出的主页地址；管理密码见自动生成的 `.env` 中 `OIO_ADMIN_PASSWORD`，日志不输出密码。

```bash
bash deploy.sh --port 28745             # 指定唯一端口，占用即报错
bash deploy.sh --ports 18743,18744,28743 # 自定义备选顺序
docker compose logs -f --tail=100 web
```

前后端由同一网关提供，平台数据库使用 SQLite。Python 微网站由平台自动构建和启动独立容器，不需要手工逐站部署。升级前运行 `bash scripts/backup.sh`，保留原 `.env` 和数据卷后重新运行部署脚本。完整说明见 [运维文档](docs/operations.md)。

## 通过对话使用

初次直接输入需求，管理登录后继续发送，不需要先填写建站表单。首次使用须在设置中连接 CodeAgent；适配协议来自用户提供的 [USER_API.md](USER_API.md)。

- “做一个团队留言板，名字叫设计小组，支持 Python 后端保存留言。”
- “打标签 张三，设计组”——主页搜 `#张三`、`设计组` 或网站名即可找到。
- “修改 /page-a1b2c3”——切换当前网站，再描述修改需求。
- “预览”——给出测试与生产地址。
- “发布”“回滚”“回滚到 v2”“历史版本”“下载版本”。
- “归档”“恢复网站”“取消任务”“重新同步”“新建网站”。

生命周期指令由明确的命令规则识别；复杂页面需求交给 CodeAgent。模糊发布意图会要求说清楚，不会将“给页面加一个发布按钮”当作上线命令。每次修改先进入测试，发布前检查版本是否过期；启动检查失败不会切换现有版本。

每站最多 12 个标签，每个最多 24 个字符。标签用于分类与检索，**不是所有权或权限隔离**；知道共享管理密码的人可修改所有网站。访问量是生产 HTML 导航次数，排除测试页、iframe、资源和可识别爬虫，不是独立访客数。

## 前端与 Python 后端

默认给 AI 提供 **React + TypeScript + Vite + React Router** 模板，支持独立页面和深层路由刷新。也可生成其他能构建为静态前端的框架；Node 服务端渲染运行时不在当前范围。

Python 后端支持自定义启动命令和 pip 依赖，不限定 FastAPI；Flask、Django、其他 Python HTTP 服务可按相同运行契约接入。产物包括：

```text
dist/                 构建完成的前端
backend/              Python 源码与 requirements.txt
oio-runtime.json      启动命令和健康检查
```

没有运行清单就是纯前端站点。清单、API 路由、数据卷、环境变量和框架接入例子见 [架构与运行契约](docs/architecture.md)。已有可运行的 [Python 留言板示例](templates/python/backend/main.py)。

生产和测试使用不同的持久数据卷。发布、回滚切换前后端代码版本，**不会复制测试数据，也不会回滚数据库**。需要登录、支付或外部数据库时，仍须提供对应业务配置；平台不会凭空生成外部服务凭据。

微网站采用浏览器 CSP 沙箱，不能使用同源 cookies、localStorage 或 service worker；业务鉴权需适配显式 token 等方式。Python 代码在受限容器执行，当前基础镜像为 Python 3.12 slim，只自动安装 pip 依赖；需要系统软件包、特权设备或独立数据库集群的需求须另行扩展运行环境。

## 底座连接与验证

CodeAgent 默认地址已内置为 `http://10.90.113.228:8800/api`，部署后无需填写地址。可选账号 ID 和模型；也可通过设置或 `CLOUDAGENT_URL`、`CLOUDAGENT_ACCOUNT_ID`、`CLOUDAGENT_MODEL` 覆盖默认配置。反向代理认证 token 使用服务端 `CLOUDAGENT_TOKEN`。远程节点需要 Node 22.12+ 和 npm 来构建 React 模板。

平台代码已有本地 Git 历史，发布包记录提交号；网站前端源码仍在 CodeAgent 工作区，需独立备份。版本 ZIP 保存前端产物及 Python 源码，不等于完整远程源码仓库。

本次 55 项测试通过，包含浏览器对话流程、真实 React 构建、HTTP/SSE/WebSocket、持久数据示例和端口备选逻辑。当前机器没有 Docker Engine，Docker 编排使用契约测试，AI 接口使用模拟服务。已配置真实 CodeAgent 地址，但访问时对端未返回 HTTP 响应便断开连接，尚未完成真实 Linux 容器与真实底座联调。详见 [验证记录](docs/verification.md)。
