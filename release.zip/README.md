# OIO · 对话式微网站平台

主页用对话创建和修改网站，CloudAgent 工作区负责编码、构建和运行 Python 后端；OIO 提供网站目录、标签搜索、版本、发布与访问转发。不需要 Docker。

## 启动

Linux 服务器安装 Python 3.10+（带 venv、pip）和 unzip 后：

```bash
unzip -o release.zip -d oio
cd oio
bash start.sh
```

脚本创建本地 .venv、安装锁定依赖、生成 .env 管理密码并启动前后端网关。默认端口 18743，冲突依次尝试 18744、28743；以启动输出为准。默认前台运行，Ctrl+C 停止网关。

已在 Python 3.10.20 实测安装与运行；启动器优先使用 python3.10，也可指定 OIO_PYTHON。依赖锁固定兼容 3.10 的 Starlette 1.7.0，并包含 exceptiongroup；不要替换为要求 3.11 的 Starlette 1.9.0。

```bash
bash start.sh --port 28745
bash start.sh --ports 18743,18744,28743
grep '^OIO_ADMIN_PASSWORD=' .env
```

后台运行网关：

```bash
nohup bash start.sh > oio.log 2>&1 < /dev/null &
echo $! > oio.pid
tail -f oio.log
```

生产常驻建议使用 systemd，见 [运维文档](docs/operations.md)。原命令 bash deploy.sh 现在也转入免 Docker 启动。

CodeAgent 默认地址 **http://10.90.113.228:8800/api**，无需再填。账号和模型可在设置中指定，否则由底座选择。工作区节点需 Linux、Python 3.10、venv/pip、Node 22.12+ 和 npm。

## 地址与对话

- 主页：`http://服务器IP:18743/`
- 生产：`/page-英文标识/`
- 测试：`/page-英文标识-beta/`
- 内部路由：`/page-英文标识/about`

实例内英文 URI 唯一；归档后仍保留。微网站只有自己的品牌和导航，不添加平台回跳按钮。生产和测试地址均为公开链接。

可以直接说：

- “做一个有 Python 后端的团队留言板，名字叫设计小组。”
- “打标签 张三，设计组”——主页搜 #张三、设计组或网站名。
- “修改 /page-abcdef”——选择网站，然后继续描述需求。
- “预览”“发布”“历史版本”“回滚”“回滚到 v2”“下载版本”。
- “下线”或“归档”——停止测试、生产服务并关闭两个地址。
- “恢复网站”——重新启动原版本，保留数据。
- “取消任务”“重新同步”“新建网站”。

管理使用共享密码，没有用户注册。标签用于分类，不是权限或所有权；管理密码持有者能修改所有网站。目录默认按生产页面访问量排序，支持搜索；访问量是页面导航数而非独立访客数。

## CloudAgent 运行方式

每站一个工作区。React + TypeScript + Vite + React Router 是默认前端栈；前端构建在 CloudAgent，构建快照保存在 OIO 以提供稳定地址。Python 后端也在 CloudAgent，OIO 本机不执行业务代码。

异步 command-tasks 安装依赖并准备版本。常驻服务使用与 nohup 相同目的的独立会话、重定向标准流及忽略 SIGHUP，脱离命令任务存活。守护进程管理业务子进程，异常退出后重试。

OIO 持久保存工作区 ID、命令任务 ID、服务目录、守护进程 PID、业务 PID、启动标识、端口和状态。重新连接会核对 PID 与启动标识，避免 PID 复用误认进程。下线失败不会伪报停止成功，支持再次下线重试。

每个环境和版本独立虚拟环境，测试和生产分别有持久数据目录。发布、回滚只切换代码，不复制或回滚数据库。详见 [运行契约](docs/architecture.md)。

OIO 需要能访问工作区节点的业务端口，默认范围 22000–22999。自动尝试节点上报地址及 CodeAgent 主机；多节点或特殊网络可在 .env 配置：

```dotenv
CLOUDAGENT_RUNTIME_HOSTS={"node-01":"10.90.113.228","node-02":"10.90.113.229"}
```

这些端口是网关到工作节点的内部通道，用户仍只访问 OIO 地址。网络不可达时保留现有版本并报告错误。

## 边界与验证

按提供的接口文档，工作区命令使用节点服务的系统用户权限。工作区目录和虚拟环境能分开项目及依赖，**不是容器或操作系统安全隔离**。此版本适合可信共享空间。业务页面仍使用浏览器沙箱，不提供同源 cookies、localStorage、service worker；业务登录须适配 token 等方案。

真实 CloudAgent 的 HTTP 检查目前遇到对端未返回响应便断开连接，不能声称已完成远程实机联调。协议与运行状态使用模拟底座测试；HTTP/SSE/WebSocket、React 浏览器和网关启动有本地实测。详见 [验证记录](docs/verification.md)。

从旧 Docker 版本迁移应先导出原平台数据和各 Python 业务数据。新版不会自动删除旧容器、读取旧 Docker 卷或停止旧服务；迁移步骤见运维文档。
