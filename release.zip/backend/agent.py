import asyncio
from urllib.parse import quote

import httpx

from .artifacts import safe_path, save_version, activate_beta
from .runtime import MANIFEST, RuntimeError as PythonRuntimeError
from .config import ROOT
from .store import now


class AgentError(Exception):
    pass


class CloudAgent:
    """Adapter for the USER_API.md contract. AI runs on the remote worker only."""

    def __init__(self, url, token='', transport=None):
        self.client = httpx.AsyncClient(
            base_url=url.rstrip('/') + '/', timeout=httpx.Timeout(60, connect=10),
            headers={'Authorization': f'Bearer {token}'} if token else {},
            transport=transport, follow_redirects=False,
        )

    async def close(self):
        await self.client.aclose()

    async def request(self, method, path, **kwargs):
        try:
            response = await self.client.request(method, path.lstrip('/'), **kwargs)
        except httpx.HTTPError as error:
            raise AgentError(f'CodeAgent 连接失败: {type(error).__name__}') from error
        if not response.is_success:
            # Do not expose remote response bodies: they can contain credentials or paths.
            raise AgentError(f'CodeAgent 接口返回 HTTP {response.status_code} ({method} {path.split("?")[0]})')
        try:
            return response.json()
        except ValueError as error:
            raise AgentError('CodeAgent 返回了无效 JSON') from error

    async def ensure_workspace(self, name, account):
        response = await self.client.get(f'workspaces/{quote(name, safe="")}')
        if response.status_code == 404:
            body = {'name': name, 'python_version': '3.10'}
            if account:
                body['account_id'] = account
            result = await self.request('POST', 'workspaces', json=body)
        elif response.is_success:
            result = response.json()
        else:
            raise AgentError(f'无法读取工作区 (HTTP {response.status_code})')
        for _ in range(60):
            if result.get('status') == 'ready':
                return result['id']
            if result.get('status') != 'creating':
                raise AgentError('远程工作区未就绪，请在 CodeAgent 检查账号和节点')
            await asyncio.sleep(2)
            result = await self.request('GET', f'workspaces/{quote(name, safe="")}')
        raise AgentError('等待工作区创建超时')

    async def collect(self, workspace, config):
        files, total, count = {}, 0, 0
        root = f'workspaces/{quote(workspace, safe="")}/files'

        async def visit(directory, depth=0):
            nonlocal total, count
            if depth > 20:
                raise AgentError('构建产物目录过深')
            listing = await self.request('GET', root, params={'path': directory})
            for item in listing.get('items', []):
                count += 1
                if count > config.max_files * 2:
                    raise AgentError('产物目录项过多')
                name = item.get('name', '')
                if len(safe_path(name).parts) != 1:
                    raise AgentError('远程文件名非法')
                remote = directory + '/' + name
                if item.get('type') == 'directory':
                    await visit(remote, depth + 1)
                elif item.get('type') == 'file':
                    if len(files) >= config.max_files or item.get('size', 0) > config.max_bytes:
                        raise AgentError('构建产物超过大小限制')
                    content = bytearray()
                    async with self.client.stream('GET', root + '/download', params={'path': remote}) as response:
                        if not response.is_success:
                            raise AgentError(f'下载构建产物失败: HTTP {response.status_code}')
                        async for chunk in response.aiter_bytes():
                            total += len(chunk)
                            if total > config.max_bytes:
                                raise AgentError('构建产物超过 64 MiB')
                            content.extend(chunk)
                    files[remote.removeprefix('dist/')] = bytes(content)
                else:
                    raise AgentError('构建产物禁止符号链接')
        await visit('dist')
        manifest = await self.client.get(root + '/content', params={'path':MANIFEST})
        if manifest.is_success:
            files[MANIFEST] = manifest.json()['content'].encode('utf-8')
            total += len(files[MANIFEST])
            await visit('backend')
        elif manifest.status_code != 404:
            raise AgentError('无法确认 Python 运行时配置')
        return files

    async def seed_starter(self, workspace):
        root = f'workspaces/{quote(workspace, safe="")}/files'
        template = ROOT / 'templates'
        for file in sorted(template.rglob('*')):
            relative = file.relative_to(template)
            if not file.is_file() or any(part in ('node_modules', 'dist') for part in relative.parts):
                continue
            remote_path = relative.as_posix().removeprefix('react/').replace('python/', 'python-example/', 1)
            response = await self.client.get(root + '/content', params={'path':remote_path})
            if response.status_code == 404:
                # Upload creates parent directories and never overwrites an existing file.
                await self.request('POST', root + '/upload', params={'path':remote_path},
                                   content=file.read_bytes(), headers={'Content-Type':'application/octet-stream'})
            elif not response.is_success:
                raise AgentError(f'读取工程模板状态失败: HTTP {response.status_code}')


def build_prompt(site, prompt):
    return f'''你是 InstaSite 微网站的开发代理。请实际编辑本工作区文件并完成构建，不要只给建议。
网站名称: {site['name']}
网站说明: {site['description']}
生产路径: /{site['slug']}/；测试路径: /{site['slug']}-beta/。
用户需求:
{prompt}

交付约定（必须满足）:
1. 在现有源代码上增量修改，保留用户已有功能。第一次创建时生成完整、精致、响应式网站。
2. 最终静态产物写到工作区 dist/，必须有 UTF-8 的 dist/index.html；不要将源代码、密钥、.env、node_modules 或服务端文件放进 dist/。
3. 新工作区已提供 React + TypeScript + Vite + React Router 工程。默认使用此主流框架栈，按需求使用组件库、图表、动画等生态包；用户明确要求 Vue 等其他主流框架时可改用对应工程。已有项目先保留其现有框架。必须运行 npm ci（修改依赖则 npm install 并更新 lock）和 npm run build，修复类型和构建错误。Node 需要 22.12+。
4. 所有本地资源和导航使用相对路径，不写 /assets 或固定网站前缀，不添加 <base> 标签。InstaSite 会注入正确 base 和 window.OIO_BASE_PATH，确保同一产物适配生产和 beta 及深层路由。
5. 静态多页面可用 about/index.html；SPA 的 router basename 读取 window.OIO_BASE_PATH。不要使用 service worker。
6. 页面运行于 CSP sandbox（allow-scripts allow-forms allow-popups allow-downloads，不允许 allow-same-origin），不能使用 cookies/localStorage 或访问 InstaSite 管理 API。外部 API 必须支持无凭据跨域请求。
7. 支持任意 Python HTTP 后端：FastAPI、Flask、Django 或自定义服务器。后端源码放 backend/，依赖放 backend/requirements.txt，在根目录交付 oio-runtime.json，格式为 {{"python":{{"command":["uvicorn","main:app","--host","0.0.0.0","--port","{{port}}"],"health_path":"/api/health"}}}}。服务监听 0.0.0.0，端口读取 PORT 环境变量或命令的 {{port}} 占位符。InstaSite 通过 CloudAgent 异步命令准备独立虚拟环境，并以脱离会话的守护进程运行；不要自行启动正式服务、不要修改 .oio/ 运行目录。/api/* 转发到后端原路径；前端使用 window.OIO_BASE_PATH + 'api/...'; 数据写 OIO_DATA_DIR 指向的工作区环境数据目录，禁止硬编码 /data。Beta 和生产数据独立；不要把测试数据假称为生产数据。WS、SSE、上传均可走 /api/*。前端沙箱不支持 cookie/localStorage，认证可用显式 Bearer token；外部服务凭据须由管理员提供，不伪造支付等成功结果。Python3.10，使用工作区系统权限，不安装 Docker、不运行 sudo、不改工作区外的文件。可参考 python-example/，复制到根目录对应位置；纯展示网站可以不启用后端。
8. 不部署正式环境、不修改其他工作区。最终回复简要说明改动、检查结果和限制。清除 dist 中已不用的旧构建文件。
9. 网站应是完全独立的产品：自己的名称、导航、标题和内容。禁止加入 InstaSite 品牌、平台管理按钮、回到工坊或平台主页的链接。本站首页链接只指向本站根路径，不指向域名根目录。
'''


class JobRunner:
    def __init__(self, store, config, factory=None, runtime=None):
        self.store, self.config = store, config
        self.factory = factory or (lambda: CloudAgent(self.settings()['url'], config.agent_token))
        self.tasks = {}
        self.runtime = runtime

    def settings(self):
        return self.store.setting('agent', {
            'url': self.config.agent_url, 'account': self.config.agent_account, 'model': self.config.agent_model,
        })

    def start(self, job_id):
        task = asyncio.create_task(self.run(job_id))
        self.tasks[job_id] = task
        task.add_done_callback(lambda finished: self.tasks.pop(job_id, None) if self.tasks.get(job_id) is finished else None)

    async def shutdown(self):
        tasks = list(self.tasks.values())
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)

    def update(self, job_id, **values):
        values['updated_at'] = now()
        self.store.execute('UPDATE jobs SET ' + ','.join(f'{key}=?' for key in values) + ' WHERE id=?', (*values.values(), job_id))

    async def run(self, job_id):
        agent = None
        try:
            agent = self.factory()
            job = self.store.one('SELECT * FROM jobs WHERE id=?', (job_id,))
            if job['status'] not in ('queued', 'running'):
                return
            site = self.store.one('SELECT * FROM sites WHERE id=?', (job['site_id'],))
            if not job['remote_task_id']:
                if job['stage'] == 'submitting':
                    raise AgentError('提交结果不确定：请在 CodeAgent 会话确认是否已创建任务；本平台未自动重发。确认远程任务结束后再提交新需求。')
                self.update(job_id, status='running', stage='provisioning')
                settings = self.settings()
                workspace = await agent.ensure_workspace(site['workspace_id'] or ('oio_' + site['id']), settings['account'])
                if not site['workspace_id']:
                    await agent.seed_starter(workspace)
                self.store.execute('UPDATE sites SET workspace_id=? WHERE id=?', (workspace, site['id']))
                if not site['session_id']:
                    session = await agent.request('POST', 'sessions', json={'workspace_id': workspace, 'title': site['name']})
                    site['session_id'] = session['session_id']
                    self.store.execute('UPDATE sites SET session_id=? WHERE id=?', (site['session_id'], site['id']))
                # The upstream has no idempotency key. Persist intent before submitting.
                self.update(job_id, stage='submitting')
                body = {'input': build_prompt(site, job['prompt'])}
                if settings['model']:
                    body['model'] = settings['model']
                remote = await agent.request('POST', f"sessions/{quote(site['session_id'], safe='')}/tasks", json=body)
                job['remote_task_id'] = remote['task_id']
                self.update(job_id, remote_task_id=remote['task_id'], stage='generating')
            else:
                workspace = site['workspace_id']
            path = f"sessions/{quote(site['session_id'], safe='')}/tasks/{quote(job['remote_task_id'], safe='')}"
            while True:
                try:
                    remote = await agent.request('GET', path)
                except AgentError as error:
                    self.update(job_id, error=str(error) + '；保留任务，稍后继续查询')
                    await asyncio.sleep(max(self.config.poll_seconds, 3))
                    continue
                self.update(job_id, error=None)
                if remote['status'] in ('success', 'failed', 'cancelled'):
                    break
                await asyncio.sleep(self.config.poll_seconds)
            result = remote.get('result') or {}
            if remote['status'] != 'success' or result.get('is_error'):
                raise AgentError(str(remote.get('error') or result.get('result') or 'AI 任务未成功完成')[:2000])
            summary = str(result.get('result') or 'AI 已完成修改')[:12000]
            if job['stage'] == 'deploying' and job['version_id']:
                version_id = job['version_id']
            else:
                self.update(job_id, stage='collecting', result=summary)
                files = await agent.collect(workspace, self.config)
                version_id = save_version(self.store, self.config, site['id'], files, summary, job_id, activate=False)
                self.update(job_id, stage='deploying', version_id=version_id)
            if self.runtime:
                await self.runtime.prepare(site, 'beta', version_id)
            activate_beta(self.store, site['id'], version_id, job_id)
            if self.runtime:
                await self.runtime.stop_others(site['id'], 'beta', version_id)
            self.store.execute('INSERT INTO messages(site_id,job_id,role,content,created_at) VALUES (?,?,?,?,?)',
                               (site['id'], job_id, 'assistant', summary, now()))
        except asyncio.CancelledError:
            # Process restart must not cancel a durable upstream task.
            raise
        except Exception as error:
            message = str(error)[:2000] if isinstance(error, (AgentError, ValueError, PythonRuntimeError)) else f'任务处理失败 ({type(error).__name__})，请检查服务日志或重试同步'
            current = self.store.one('SELECT stage,remote_task_id FROM jobs WHERE id=?', (job_id,))
            if current and current['stage'] == 'submitting' and not current['remote_task_id']:
                message += ' 提交结果可能不确定，请先到 CodeAgent 会话确认任务状态；平台没有自动重发。'
            self.update(job_id, status='failed', error=message)
            job = self.store.one('SELECT site_id FROM jobs WHERE id=?', (job_id,))
            self.store.execute('INSERT INTO messages(site_id,job_id,role,content,created_at) VALUES (?,?,?,?,?)',
                               (job['site_id'], job_id, 'system', message, now()))
        finally:
            if agent:
                await agent.close()
