"""Uploaded to CloudAgent; Linux workspace service controller (stdlib only)."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import random
import signal
import socket
import subprocess
import sys
import time
import urllib.request


def save(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value), encoding='utf-8')
    temporary.replace(path)


def running(root):
    try:
        state = json.loads((root / 'state.json').read_text())
        pid = state['supervisor']
        # PID alone is insufficient after a node restart or PID reuse.
        fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
        return state if fields[0] != 'Z' and fields[19] == state['start_time'] else None
    except (OSError, ValueError, KeyError):
        return None


def supervise(root):
    signal.signal(signal.SIGHUP, signal.SIG_IGN)
    lock = (root / 'service.lock').open('w')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        return
    config = json.loads((root / 'config.json').read_text())
    state_path = root / 'state.json'
    stop = root / 'stop'
    state = {'supervisor': os.getpid(), 'start_time': Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19], 'ready': False}
    save(state_path, state)
    process = None
    signal.signal(signal.SIGTERM, lambda *_: stop.touch())
    signal.signal(signal.SIGINT, lambda *_: stop.touch())
    try:
        while not stop.exists():
            ports = list(range(config['port_min'], config['port_max'] + 1))
            random.shuffle(ports)
            port = None
            for candidate in ports:
                with socket.socket() as connection:
                    try:
                        connection.bind(('0.0.0.0', candidate))
                        port = candidate
                        break
                    except OSError:
                        continue
            if port is None:
                raise RuntimeError('No available service ports')
            environment = dict(os.environ)
            # Do not forward node control-plane credentials by default.
            environment = {key: value for key, value in environment.items()
                           if key in ('HOME', 'LANG', 'LC_ALL', 'TZ', 'PATH', 'TMPDIR', 'SSL_CERT_FILE', 'SSL_CERT_DIR')}
            environment.update(config.get('env', {}))
            environment.update(PORT=str(port), OIO_DATA_DIR=str(root.parent.parent / 'data'),
                               OIO_BASE_PATH=config['prefix'], OIO_API_BASE=config['prefix']+'api/',
                               OIO_ENVIRONMENT=config['environment'], PYTHONUNBUFFERED='1',
                               PATH=str(root / 'venv/bin') + ':' + os.environ.get('PATH', '/usr/bin:/bin'))
            Path(environment['OIO_DATA_DIR']).mkdir(parents=True, exist_ok=True)
            command = [arg.replace('{port}', str(port)) for arg in config['command']]
            # Compatibility with v0.2 manifests, which used fixed 8080.
            command = [str(port) if arg == '8080' else arg.replace(':8080', ':'+str(port)) for arg in command]
            state.update(port=port, ready=False)
            save(state_path, state)
            with (root / 'service.log').open('ab', buffering=0) as log:
                process = subprocess.Popen(command, cwd=root / 'backend', env=environment,
                                           stdin=subprocess.DEVNULL, stdout=log, stderr=log, start_new_session=True)
                state['service_pid'] = process.pid
                save(state_path, state)
                deadline = time.monotonic() + 60
                opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
                while not stop.exists() and process.poll() is None:
                    if not state['ready']:
                        try:
                            with opener.open(f'http://127.0.0.1:{port}'+config['health_path'], timeout=2) as response:
                                state['ready'] = 200 <= response.status < 300
                            save(state_path, state)
                        except Exception:
                            if time.monotonic() > deadline:
                                break
                    time.sleep(1)
                state['ready'] = False
                save(state_path, state)
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGTERM)
                    try:
                        process.wait(timeout=8)
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGKILL)
                        process.wait()
            if not stop.exists():
                time.sleep(3)
    finally:
        if process and process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
        state['ready'] = False
        save(state_path, state)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['deploy', 'supervise', 'status', 'stop', 'enable'])
    parser.add_argument('directory')
    args = parser.parse_args()
    root = Path(args.directory).resolve()
    root.mkdir(parents=True, exist_ok=True)
    if args.action == 'supervise':
        supervise(root)
        return
    if args.action == 'enable':
        (root / 'stop').unlink(missing_ok=True)
        print(json.dumps({'enabled':True}))
        return
    if args.action == 'stop':
        (root / 'stop').touch()
        for _ in range(15):
            if not running(root):
                break
            time.sleep(1)
        print(json.dumps({'stopped': not bool(running(root))}))
        return
    if args.action == 'deploy':
        with (root / 'deploy.lock').open('w') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            if (root / 'stop').exists():
                raise RuntimeError('Deployment was disabled')
            if not running(root):
                python = root / 'venv/bin/python'
                if not python.exists():
                    subprocess.run([sys.executable, '-m', 'venv', str(root / 'venv')], check=True)
                requirements = root / 'backend/requirements.txt'
                if requirements.exists() and not (root / 'dependencies.ok').exists():
                    subprocess.run([str(python), '-m', 'pip', 'install', '-r', str(requirements)], check=True)
                (root / 'dependencies.ok').touch()
                if (root / 'stop').exists():
                    raise RuntimeError('Deployment was disabled during dependency installation')
                with (root / 'supervisor.log').open('ab', buffering=0) as log:
                    subprocess.Popen([sys.executable, str(Path(__file__).resolve()), 'supervise', str(root)],
                                     stdin=subprocess.DEVNULL, stdout=log, stderr=log, start_new_session=True)
                for _ in range(10):
                    if running(root):
                        break
                    time.sleep(.2)
    state = running(root) or {'ready': False}
    if state.get('ready'):
        addresses = set()
        try:
            addresses.update(socket.gethostbyname_ex(socket.gethostname())[2])
            config = json.loads((root / 'config.json').read_text())
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as connection:
                connection.connect((config['agent_host'], 8800))
                addresses.add(connection.getsockname()[0])
        except OSError:
            pass
        state['addresses'] = sorted(addresses)
    print(json.dumps(state))


if __name__ == '__main__':
    main()
