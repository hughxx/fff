import hashlib
import io
import json
import re
import shutil
import zipfile
from pathlib import PurePosixPath

from .store import now, uid
from .runtime import MANIFEST, parse_manifest

ALLOWED_EXTENSIONS = {'.html', '.css', '.js', '.mjs', '.json', '.svg', '.png', '.jpg', '.jpeg',
                      '.gif', '.webp', '.avif', '.ico', '.woff', '.woff2', '.ttf', '.txt', '.xml',
                      '.webmanifest', '.mp4', '.webm', '.mp3', '.ogg', '.pdf', '.wasm'}


def safe_path(value):
    if not isinstance(value, str) or not value or len(value) > 500 or '\\' in value or ':' in value:
        raise ValueError('非法文件路径')
    parts = value.split('/')
    if any(p in ('', '.', '..') or p.startswith('.') or any(ord(c) < 32 for c in p) for p in parts):
        raise ValueError('禁止隐藏文件、空路径或目录穿越')
    return PurePosixPath(value)


def validate_files(files, config):
    if 'index.html' not in files:
        raise ValueError('构建产物必须包含 dist/index.html')
    if not files['index.html'].strip():
        raise ValueError('index.html 不能为空')
    if len(files) > config.max_files or sum(len(v) for v in files.values()) > config.max_bytes:
        raise ValueError('产物超过 1000 文件或 64 MiB 限制')
    seen = set()
    if MANIFEST in files:
        parse_manifest(files[MANIFEST])
        if not any(name.startswith('backend/') for name in files):
            raise ValueError('Python 版本必须包含 backend/ 源码')
    for name, content in files.items():
        path = safe_path(name)
        if not name.startswith('backend/') and path.suffix.lower() not in ALLOWED_EXTENSIONS:
            raise ValueError(f'不支持公开托管此文件类型: {name}')
        if name.casefold() in seen:
            raise ValueError('文件名大小写冲突')
        seen.add(name.casefold())
        if not name.startswith('backend/') and path.suffix.lower() == '.html':
            html = content.decode('utf-8')
            if re.search(r'<base\b', html, re.I):
                raise ValueError('HTML 不得包含 base 标签，平台统一注入环境路径')


def save_version(store, config, site_id, files, summary, job_id=None, activate=True):
    validate_files(files, config)
    version_id = uid('ver')
    root = config.data_dir / 'versions'
    root.mkdir(exist_ok=True)
    temporary = root / (version_id + '.staging')
    final = root / version_id
    temporary.mkdir()
    digest = hashlib.sha256()
    try:
        for name, content in sorted(files.items()):
            target = temporary.joinpath(*safe_path(name).parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(content)
            digest.update(name.encode() + b'\0' + hashlib.sha256(content).digest())
        temporary.rename(final)
        timestamp = now()
        with store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if job_id:
                job = db.execute('SELECT status FROM jobs WHERE id=?', (job_id,)).fetchone()
                if not job or job['status'] != 'running':
                    raise ValueError('任务已结束，未更新测试环境')
            number = db.execute('SELECT COALESCE(MAX(number),0)+1 FROM versions WHERE site_id=?', (site_id,)).fetchone()[0]
            db.execute('INSERT INTO versions VALUES (?,?,?,?,?,?,?,?)',
                       (version_id, site_id, number, summary[:2000], len(files), sum(map(len, files.values())), digest.hexdigest(), timestamp))
            if activate:
                db.execute('UPDATE sites SET beta_version=?, updated_at=? WHERE id=?', (version_id, timestamp, site_id))
            if job_id and activate:
                db.execute("UPDATE jobs SET status='success',stage='complete',version_id=?,updated_at=? WHERE id=?",
                           (version_id, timestamp, job_id))
            if activate:
                db.execute('INSERT INTO events(site_id,action,version_id,note,created_at) VALUES (?,?,?,?,?)',
                           (site_id, 'beta', version_id, f'测试环境更新为 v{number}', timestamp))
    except BaseException:
        shutil.rmtree(temporary, ignore_errors=True)
        shutil.rmtree(final, ignore_errors=True)
        raise
    return version_id


def activate_beta(store, site_id, version_id, job_id):
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        row = db.execute('SELECT status FROM jobs WHERE id=? AND site_id=?', (job_id,site_id)).fetchone()
        if not row or row['status'] != 'running':
            raise ValueError('任务已结束，未更新测试环境')
        number = db.execute('SELECT number FROM versions WHERE id=? AND site_id=?', (version_id,site_id)).fetchone()['number']
        db.execute('UPDATE sites SET beta_version=?,updated_at=? WHERE id=?', (version_id,now(),site_id))
        db.execute("UPDATE jobs SET status='success',stage='complete',version_id=?,updated_at=? WHERE id=?", (version_id,now(),job_id))
        db.execute('INSERT INTO events(site_id,action,version_id,note,created_at) VALUES (?,?,?,?,?)', (site_id,'beta',version_id,f'测试环境更新为 v{number}',now()))


def version_zip(config, version):
    output = io.BytesIO()
    root = config.data_dir / 'versions' / version['id']
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(root.rglob('*')):
            if path.is_file():
                relative = path.relative_to(root).as_posix()
                archive.write(path, relative if relative.startswith('backend/') or relative == MANIFEST else 'dist/'+relative)
        archive.writestr('oio-version.json', json.dumps(version, ensure_ascii=False, indent=2))
    return output.getvalue()


def inject_base(content, prefix):
    html = content.decode('utf-8')
    tag = f'<base href="/{prefix}/"><script>window.OIO_BASE_PATH="/{prefix}/";</script>'
    head = re.search(r'<head(?:\s[^>]*)?>', html, re.I)
    if head:
        return (html[:head.end()] + tag + html[head.end():]).encode('utf-8')
    return (tag + html).encode('utf-8')
