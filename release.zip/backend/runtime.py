"""Python services hosted inside CloudAgent workspaces."""
import asyncio
import hashlib
import json
import re
import shlex
import time
from urllib.parse import quote, urlsplit

import httpx

from .config import ROOT
from .store import now

MANIFEST = 'oio-runtime.json'


def parse_manifest(content):
    value = json.loads(content)
    if not isinstance(value, dict) or set(value) != {'python'} or not isinstance(value['python'], dict):
        raise ValueError('oio-runtime.json 必须包含 python 配置')
    runtime = value['python']
    if set(runtime) - {'command', 'health_path'}:
        raise ValueError('Python 配置仅支持 command 和 health_path')
    command = runtime.get('command')
    if not isinstance(command, list) or not 1 <= len(command) <= 32 or any(not isinstance(arg, str) or not arg or len(arg)>2000 or '\0' in arg for arg in command):
        raise ValueError('Python command 必须为非空字符串数组')
    health = runtime.get('health_path', '/api/health')
    if not isinstance(health, str) or not re.fullmatch(r'/[a-zA-Z0-9/_-]*', health) or health.startswith('//'):
        raise ValueError('health_path 必须为本地 HTTP 路径')
    return {'command':command, 'health_path':health}


def manifest_at(root):
    file = root / MANIFEST
    return parse_manifest(file.read_bytes()) if file.is_file() else None


class RuntimeError(Exception):
    pass


class PythonRuntime:
    def __init__(self, store, config):
        self.store, self.config = store, config
        self.locks = {}
        self.checked = {}
        self.agent_factory = None

    def agent(self):
        if self.agent_factory:
            return self.agent_factory()
        from .agent import CloudAgent
        settings = self.store.setting('agent', {'url': self.config.agent_url})
        return CloudAgent(settings['url'], self.config.agent_token)

    def record(self, site_id, environment, version_id):
        return self.store.one('SELECT * FROM workspace_runtimes WHERE site_id=? AND environment=? AND version_id=?',
                              (site_id, environment, version_id))

    def update(self, row, **fields):
        fields['updated_at'] = now()
        self.store.execute('UPDATE workspace_runtimes SET '+','.join(key+'=?' for key in fields)+
                           ' WHERE site_id=? AND environment=? AND version_id=?',
                           (*fields.values(), row['site_id'], row['environment'], row['version_id']))

    async def upload(self, agent, workspace, path, content):
        base = f'workspaces/{quote(workspace, safe="")}/files'
        response = await agent.client.post(base+'/upload', params={'path': path}, content=content,
                                           headers={'Content-Type':'application/octet-stream'})
        if response.status_code == 409:
            existing = await agent.client.get(base+'/download', params={'path':path})
            if not existing.is_success or hashlib.sha256(existing.content).digest() != hashlib.sha256(content).digest():
                raise RuntimeError('工作区版本文件与快照不一致；未覆盖远程文件，请重新生成版本。')
        elif not response.is_success:
            raise RuntimeError(f'上传运行文件失败 (HTTP {response.status_code})')

    @staticmethod
    def command(row, action):
        return 'python '+shlex.quote(row['directory']+'/controller.py')+' '+action+' '+shlex.quote(row['directory'])

    async def status(self, agent, row):
        result = await agent.request('POST', f'workspaces/{quote(row["workspace_id"], safe="")}/commands',
                                     json={'command':self.command(row, 'status'), 'timeout_seconds':30})
        if result.get('exit_code') != 0 or result.get('timed_out'):
            return {'ready':False}
        return json.loads(result['stdout'].strip().splitlines()[-1])

    async def resolve_url(self, agent, row, state, spec):
        workspace = await agent.request('GET', 'workspaces/'+quote(row['workspace_id'], safe=''))
        mapping = json.loads(self.config.runtime_hosts)
        preferred = mapping.get(workspace.get('node_id')) or mapping.get('*')
        settings = self.store.setting('agent', {'url': self.config.agent_url})
        candidates = [preferred] if preferred else state.get('addresses', [])
        if not preferred:
            candidates = [host for host in candidates if host not in ('127.0.0.1', '0.0.0.0')]
            # Single-node deployments commonly use the same host as the control API.
            candidates.append(urlsplit(settings['url']).hostname)
        async with httpx.AsyncClient(timeout=3, trust_env=False) as client:
            for host in dict.fromkeys(candidates):
                if not host or not re.fullmatch(r'[a-zA-Z0-9_.-]+', host):
                    continue
                url = f'http://{host}:{int(state["port"])}'
                try:
                    response = await client.get(url + spec['health_path'])
                    if response.is_success:
                        return url
                except httpx.HTTPError:
                    continue
        raise RuntimeError('工作区服务已启动，但 OIO 无法访问节点端口。请检查节点网络或配置 CLOUDAGENT_RUNTIME_HOSTS；原版本未切换。')

    async def prepare(self, site, environment, version_id):
        root = self.config.data_dir / 'versions' / version_id
        spec = manifest_at(root)
        if not spec:
            return None
        if not self.config.python_runtime:
            raise RuntimeError('Python 工作区运行已禁用，请启用 OIO_PYTHON_RUNTIME。')
        if not 1024 <= self.config.runtime_port_min <= self.config.runtime_port_max <= 65535:
            raise RuntimeError('工作区服务端口范围无效')
        key = (site['id'], environment, version_id)
        async with self.locks.setdefault(key, asyncio.Lock()):
            agent = self.agent()
            row = None
            try:
                # The caller can hold a site dict from before the build created its workspace.
                current = self.store.one('SELECT workspace_id FROM sites WHERE id=?', (site['id'],))
                workspace = (current or {}).get('workspace_id') or site.get('workspace_id')
                if not workspace:
                    raise RuntimeError('网站还没有 CloudAgent 工作区，请先生成网站。')
                directory = f'.oio/services/{environment}/versions/{version_id}'
                self.store.execute('INSERT OR IGNORE INTO workspace_runtimes '
                                   '(site_id,environment,version_id,workspace_id,directory,updated_at) VALUES (?,?,?,?,?,?)',
                                   (*key, workspace, directory, now()))
                row = self.record(*key)
                state = await self.status(agent, row)
                if not state.get('supervisor'):
                    env_file = self.config.data_dir / 'runtime-env' / (site['slug']+'.json')
                    custom = json.loads(env_file.read_text()).get(environment, {}) if env_file.exists() else {}
                    if not isinstance(custom, dict) or any(not isinstance(k,str) or not isinstance(v,str) for k,v in custom.items()):
                        raise RuntimeError('runtime-env 环境变量必须为字符串字典')
                    settings = self.store.setting('agent', {'url':self.config.agent_url})
                    configuration = {**spec, 'environment':environment,
                                     'prefix':f'/{site["slug"]}{"-beta" if environment == "beta" else ""}/',
                                     'env':custom, 'port_min':self.config.runtime_port_min, 'port_max':self.config.runtime_port_max,
                                     'agent_host':urlsplit(settings['url']).hostname}
                    await self.upload(agent, workspace, directory+'/controller.py', (ROOT/'backend/workspace_service.py').read_bytes())
                    await self.upload(agent, workspace, directory+'/config.json', json.dumps(configuration).encode())
                    for file in sorted((root/'backend').rglob('*')):
                        if file.is_file():
                            await self.upload(agent, workspace, directory+'/backend/'+file.relative_to(root/'backend').as_posix(), file.read_bytes())
                    enabled = await agent.request('POST', f'workspaces/{quote(workspace,safe="")}/commands',
                                                  json={'command':self.command(row,'enable'), 'timeout_seconds':30})
                    if enabled.get('exit_code') != 0:
                        raise RuntimeError('无法启用工作区服务')
                    # Persist and poll deployment tasks. A lost response can be retried safely:
                    # the remote deployment and supervisor locks serialize this immutable version.
                    task = None
                    if row['task_id']:
                        task = await agent.request('GET', f'workspaces/{quote(workspace,safe="")}/command-tasks/{row["task_id"]}')
                    if not task or task.get('status') not in ('queued','running'):
                        task = await agent.request('POST', f'workspaces/{quote(workspace,safe="")}/command-tasks',
                                                   json={'command':self.command(row,'deploy'), 'timeout_seconds':1800})
                        self.update(row, task_id=task['task_id'], status='deploying')
                    task_id = task['task_id']
                    deadline = time.monotonic()+1850
                    while task.get('status') in ('queued','running'):
                        if time.monotonic()>deadline:
                            raise RuntimeError('工作区依赖安装等待超时，可重新同步查询原任务。')
                        await asyncio.sleep(self.config.poll_seconds)
                        task = await agent.request('GET', f'workspaces/{quote(workspace,safe="")}/command-tasks/{task_id}')
                    if task.get('exit_code') != 0 or task.get('timed_out') or task.get('status') in ('failed','cancelled'):
                        raise RuntimeError('工作区部署命令失败，请查看已记录的 command-task 日志。')
                deadline = time.monotonic()+self.config.runtime_start_timeout
                while True:
                    state = await self.status(agent, row)
                    if state.get('supervisor'):
                        self.update(row, supervisor_pid=state['supervisor'], service_pid=state.get('service_pid'), start_time=state['start_time'], port=state.get('port'))
                    if state.get('ready'):
                        break
                    if time.monotonic()>deadline:
                        raise RuntimeError('工作区 Python 服务未通过健康检查，请查看 service.log；原版本未切换。')
                    await asyncio.sleep(.5)
                url = await self.resolve_url(agent, row, state, spec)
                self.update(row, url=url, status='running')
                self.checked[key] = time.monotonic()
                return url
            except Exception as error:
                if row:
                    self.update(row, status='error')
                    current = self.store.one('SELECT beta_version,production_version FROM sites WHERE id=?', (site['id'],))
                    if current and current['beta_version' if environment=='beta' else 'production_version'] != version_id:
                        # Disable a failed candidate, including a delayed deployment still installing dependencies.
                        # Never stop the currently active version on a transient health/network failure.
                        try:
                            await agent.request('POST', f'workspaces/{quote(row["workspace_id"],safe="")}/commands',
                                                json={'command':self.command(row,'stop'), 'timeout_seconds':30})
                        except Exception:
                            self.update(row, status='stop_failed')
                if isinstance(error, RuntimeError):
                    raise
                raise RuntimeError(f'CloudAgent 工作区服务操作失败 ({type(error).__name__})；运行标识已保存，可重新同步。') from error
            finally:
                await agent.close()

    async def stop_others(self, site_id, environment, keep=None):
        agent = self.agent()
        errors = []
        try:
            for row in self.store.all('SELECT * FROM workspace_runtimes WHERE site_id=? AND environment=?', (site_id,environment)):
                if row['version_id'] == keep or row['status'] == 'stopped':
                    continue
                try:
                    base = f'workspaces/{quote(row["workspace_id"],safe="")}'
                    if row['task_id']:
                        task = await agent.request('GET', base+'/command-tasks/'+row['task_id'])
                        if task.get('status') in ('queued','running'):
                            cancelled = await agent.request('POST', base+'/command-tasks/'+row['task_id']+'/cancel')
                            if cancelled.get('status') in ('queued','running'):
                                raise RuntimeError('部署任务取消尚未确认')
                    result = await agent.request('POST', base+'/commands', json={'command':self.command(row,'stop'), 'timeout_seconds':30})
                    stopped = result.get('exit_code') == 0 and json.loads(result['stdout'].strip().splitlines()[-1]).get('stopped')
                    if not stopped:
                        raise RuntimeError('停止服务未确认')
                    self.update(row, status='stopped')
                    self.checked.pop((site_id,environment,row['version_id']), None)
                except Exception:
                    self.update(row, status='stop_failed')
                    errors.append(row['version_id'])
            if errors and keep is None:
                raise RuntimeError('网站访问已关闭，但部分远程进程停止尚未确认；恢复底座连接后再次说“下线”以重试。')
        finally:
            await agent.close()

    async def target(self, site, environment):
        version = site['beta_version' if environment=='beta' else 'production_version']
        if not version or not manifest_at(self.config.data_dir/'versions'/version):
            return None
        key = (site['id'],environment,version)
        row = self.record(*key)
        if row and row['status']=='running' and time.monotonic()-self.checked.get(key, -100) < 10:
            return row['url']
        return await self.prepare(site,environment,version)
