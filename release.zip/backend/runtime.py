"""Versioned Python runtimes. Generated Python executes only in dedicated containers."""
import asyncio
import io
import json
import os
import re
import tarfile
import time

import httpx

from .store import uid

MANIFEST = 'oio-runtime.json'


def parse_manifest(content):
    value = json.loads(content)
    if not isinstance(value, dict) or set(value) != {'python'} or not isinstance(value['python'], dict):
        raise ValueError('oio-runtime.json 必须包含 python 配置')
    runtime = value['python']
    if set(runtime) - {'command', 'health_path'}:
        raise ValueError('Python 配置仅支持 command 和 health_path')
    command = runtime.get('command')
    if not isinstance(command, list) or not 1 <= len(command) <= 32 or any(not isinstance(arg, str) or not arg or len(arg)>2000 or '\0' in arg for arg in command):
        raise ValueError('Python command 必须为非空字符串数组')
    health = runtime.get('health_path', '/api/health')
    if not isinstance(health, str) or not re.fullmatch(r'/[a-zA-Z0-9/_-]*', health) or health.startswith('//'):
        raise ValueError('health_path 必须为本地 HTTP 路径')
    return {'command':command, 'health_path':health}


def manifest_at(root):
    file = root / MANIFEST
    return parse_manifest(file.read_bytes()) if file.is_file() else None


class RuntimeError(Exception):
    pass


class PythonRuntime:
    def __init__(self, store, config):
        self.store, self.config = store, config
        self.instance = store.setting('runtime_instance')
        if not self.instance:
            self.instance = uid('oio')[:16]
            store.set_setting('runtime_instance', self.instance)
        self.locks = {}
        self.stopping = set()
        self.ready = set()

    def client(self):
        import docker
        return docker.from_env(timeout=300)

    def name(self, site_id, environment, version_id):
        return f'{self.instance}-{site_id[-12:]}-{environment}-{version_id[-12:]}'

    def provision(self, site, environment, version_id, spec):
        import docker
        client = self.client()
        try:
            root = self.config.data_dir / 'versions' / version_id
            image_name = f'{self.instance}:{version_id}'
            try:
                client.images.get(image_name)
            except docker.errors.ImageNotFound:
                context = io.BytesIO()
                dockerfile = b'''FROM python:3.12-slim
ENV PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1 PORT=8080 OIO_DATA_DIR=/data
WORKDIR /app
COPY backend/ /app/
RUN if [ -f requirements.txt ]; then pip install --no-cache-dir -r requirements.txt; fi
RUN groupadd -g 10001 website && useradd -u 10001 -g website website && mkdir /data && chown website:website /data
USER website
EXPOSE 8080
'''
                with tarfile.open(fileobj=context, mode='w') as archive:
                    info = tarfile.TarInfo('Dockerfile'); info.size = len(dockerfile)
                    archive.addfile(info, io.BytesIO(dockerfile))
                    for file in sorted((root / 'backend').rglob('*')):
                        if file.is_file():
                            archive.add(file, arcname='backend/'+file.relative_to(root/'backend').as_posix(), recursive=False)
                context.seek(0)
                client.images.build(fileobj=context, custom_context=True, tag=image_name, rm=True,
                                    labels={'io.oio.instance':self.instance, 'io.oio.version':version_id})
            # Every site/environment has its own network. Only the gateway joins all of them.
            network_name = f'{self.instance}-{site["id"][-12:]}-{environment}'
            try:
                network = client.networks.get(network_name)
            except docker.errors.NotFound:
                network = client.networks.create(network_name, labels={'io.oio.instance':self.instance})
            gateway = client.containers.get(os.getenv('OIO_GATEWAY_CONTAINER') or os.environ.get('HOSTNAME', ''))
            gateway.reload()
            if network.name not in gateway.attrs['NetworkSettings']['Networks']:
                network.connect(gateway)
            name = self.name(site['id'], environment, version_id)
            try:
                container = client.containers.get(name)
            except docker.errors.NotFound:
                volume = network_name + '-data'
                client.volumes.create(volume, labels={'io.oio.instance':self.instance, 'io.oio.site':site['id'], 'io.oio.environment':environment})
                prefix = f"/{site['slug']}{'-beta' if environment=='beta' else ''}"
                env_file = self.config.data_dir / 'runtime-env' / (site['slug']+'.json')
                custom = json.loads(env_file.read_text()).get(environment, {}) if env_file.is_file() else {}
                if not isinstance(custom, dict) or any(not isinstance(k,str) or not isinstance(v,str) for k,v in custom.items()):
                    raise ValueError('runtime-env 必须是环境名到字符串变量字典的映射')
                container = client.containers.create(image_name, command=spec['command'], name=name,
                    detach=True, network=network.name, user='10001:10001',
                    environment={**custom,'PORT':'8080','OIO_DATA_DIR':'/data','OIO_BASE_PATH':prefix+'/',
                                 'OIO_API_BASE':prefix+'/api/','OIO_ENVIRONMENT':environment},
                    volumes={volume:{'bind':'/data','mode':'rw'}},
                    read_only=True, tmpfs={'/tmp':'rw,noexec,nosuid,size=67108864,mode=1777'},
                    cap_drop=['ALL'], security_opt=['no-new-privileges:true'],
                    mem_limit=self.config.runtime_memory, nano_cpus=1_000_000_000,
                    pids_limit=128, restart_policy={'Name':'unless-stopped'},
                    labels={'io.oio.instance':self.instance,'io.oio.site':site['id'],'io.oio.environment':environment,'io.oio.version':version_id},
                    log_config=docker.types.LogConfig(type='json-file', config={'max-size':'10m','max-file':'2'}))
            container.reload()
            if container.status != 'running':
                container.start()
            return {'container_id':container.id, 'url':f'http://{name}:8080'}
        finally:
            client.close()

    async def prepare(self, site, environment, version_id):
        spec = manifest_at(self.config.data_dir / 'versions' / version_id)
        if not spec:
            return None
        if not self.config.python_runtime:
            raise RuntimeError('此版本需要 Python 后端。请使用 Linux Docker 部署并启用 OIO_PYTHON_RUNTIME=true。原环境未被替换。')
        key = (site['id'], environment, version_id)
        lock = self.locks.setdefault(key, asyncio.Lock())
        async with lock:
            try:
                result = await asyncio.to_thread(self.provision, site, environment, version_id, spec)
                deadline = time.monotonic() + self.config.runtime_start_timeout
                async with httpx.AsyncClient(timeout=3, trust_env=False) as client:
                    while True:
                        try:
                            response = await client.get(result['url'] + spec['health_path'])
                            if response.is_success:
                                break
                        except httpx.HTTPError:
                            pass
                        if time.monotonic() > deadline:
                            await asyncio.to_thread(self.stop_one, result['container_id'])
                            raise RuntimeError('Python 后端健康检查未通过，请检查监听端口 8080 和 health_path；原版本保持不变。')
                        await asyncio.sleep(.5)
                self.store.execute('INSERT OR REPLACE INTO runtimes VALUES (?,?,?,?,?)',
                                   (site['id'], environment, version_id, result['container_id'], result['url']))
                self.ready.add(key)
                return result['url']
            except RuntimeError:
                raise
            except Exception as error:
                raise RuntimeError(f'Python 容器构建或启动失败 ({type(error).__name__})。请检查 Docker、依赖和后端启动命令。') from error

    def stop_one(self, container_id):
        client = self.client()
        try:
            client.containers.get(container_id).stop(timeout=10)
        finally:
            client.close()

    async def stop_others(self, site_id, environment, keep=None):
        for row in self.store.all('SELECT * FROM runtimes WHERE site_id=? AND environment=?', (site_id,environment)):
            if row['version_id'] != keep:
                try:
                    await asyncio.to_thread(self.stop_one, row['container_id'])
                except Exception:
                    pass  # A failed cleanup never undoes a successful publication.

    async def target(self, site, environment):
        version_id = site['beta_version' if environment=='beta' else 'production_version']
        if not version_id or not manifest_at(self.config.data_dir/'versions'/version_id):
            return None
        row = self.store.one('SELECT url FROM runtimes WHERE site_id=? AND environment=? AND version_id=?', (site['id'],environment,version_id))
        return row['url'] if row and (site['id'],environment,version_id) in self.ready else await self.prepare(site, environment, version_id)
