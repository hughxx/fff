#!/usr/bin/env bash
# Linux, no Docker. Run from anywhere: bash /path/to/DeepTutor/deploy.sh
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
export DEEPTUTOR_HOME="$ROOT"
export PYTHONUTF8=1
export PIP_DEFAULT_TIMEOUT="${PIP_DEFAULT_TIMEOUT:-120}"
export PIP_RETRIES="${PIP_RETRIES:-5}"
export NEXT_TELEMETRY_DISABLED=1
export DEEPTUTOR_BACKEND_READY_TIMEOUT=180
export DEEPTUTOR_FRONTEND_READY_TIMEOUT=240
export NO_PROXY="${NO_PROXY:-},127.0.0.1,localhost,10.90.113.228,.rnd.huawei.com"
export no_proxy="$NO_PROXY"
export PATH="$ROOT/.runtime/node/bin:$ROOT/.venv/bin:$PATH"
ACTION="${1:-start}"
mkdir -p data/deployment

fail() { echo "[ERROR] $*" >&2; exit 1; }
trap 'echo "[ERROR] Deployment stopped at line $LINENO. Fix the error above and run bash deploy.sh again; data is preserved." >&2' ERR

if [[ "$ACTION" == "check" ]]; then
    [[ -x .venv/bin/python ]] || fail "Run bash deploy.sh first."
    exec .venv/bin/python -m deployment.check
fi
[[ "$ACTION" == "start" ]] || fail "Usage: bash deploy.sh [start|check]"
[[ "$(uname -s)" == "Linux" ]] || fail "This Bash installer targets Linux (Ubuntu 22.04/24.04, Debian 12, or an existing Python 3.11-3.14 environment)."
command -v flock >/dev/null || fail "Install util-linux (flock) first."
exec 9>data/deployment/launcher.lock
flock -n 9 || fail "Another deploy.sh instance is already running for this directory."

PYTHON=""
for candidate in python3.12 python3.11 python3.13 python3.14 python3; do
    if command -v "$candidate" >/dev/null && "$candidate" -c 'import sys; sys.exit(not ((3,11) <= sys.version_info[:2] < (3,15)))' 2>/dev/null; then
        PYTHON="$candidate"; break
    fi
done
if [[ -z "$PYTHON" ]]; then
    command -v apt-get >/dev/null || fail "Install Python 3.11-3.14 and its venv package, then rerun."
    if [[ "$EUID" -eq 0 ]]; then SUDO=(); else command -v sudo >/dev/null || fail "Python installation requires sudo."; SUDO=(sudo); fi
    "${SUDO[@]}" apt-get update
    if apt-cache show python3.12 >/dev/null 2>&1; then PYTHON=python3.12; else PYTHON=python3.11; fi
    apt-cache show "$PYTHON" >/dev/null 2>&1 || fail "System repositories do not contain Python 3.11+. Install it and rerun (no third-party apt repositories added)."
    "${SUDO[@]}" apt-get install -y "$PYTHON" "${PYTHON}-venv" build-essential libgomp1 curl ca-certificates xz-utils
fi
if [[ ! -x .venv/bin/python ]]; then
    if ! "$PYTHON" -m venv .venv; then
        if command -v apt-get >/dev/null; then
            if [[ "$EUID" -eq 0 ]]; then SUDO=(); else SUDO=(sudo); fi
            VERSION="$($PYTHON -c 'import sys; print(f"python{sys.version_info.major}.{sys.version_info.minor}-venv")')"
            "${SUDO[@]}" apt-get update
            "${SUDO[@]}" apt-get install -y "$VERSION"
            "$PYTHON" -m venv .venv
        else fail "Install the venv/ensurepip package for $PYTHON and rerun."; fi
    fi
fi
.venv/bin/python -m pip --version >/dev/null || fail "Virtual environment is incomplete; install python venv/ensurepip."

if ! command -v node >/dev/null || ! node -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 22 ? 0 : 1)'; then
    case "$(uname -m)" in x86_64) ARCH=x64;; aarch64|arm64) ARCH=arm64;; *) fail "Provide Node.js 22+ for this CPU architecture.";; esac
    NODE_VERSION=22.22.0
    mkdir -p .runtime
    # Python downloads and verifies the official SHA256 before extracting; local to this checkout.
    "$PYTHON" deployment/install_node.py "$NODE_VERSION" "$ARCH"
    export PATH="$ROOT/.runtime/node/bin:$PATH"
fi
echo "[1/5] Installing Python dependencies (first run may take several minutes)..."
FINGERPRINT="$(.venv/bin/python -c 'import hashlib,pathlib; print(hashlib.sha256(pathlib.Path("pyproject.toml").read_bytes()+pathlib.Path("deployment/bridge.py").read_bytes()).hexdigest())')"
if [[ ! -f data/deployment/python-installed ]] || [[ "$(cat data/deployment/python-installed)" != "$FINGERPRINT" ]]; then
    .venv/bin/python -m pip install --upgrade pip
    .venv/bin/python -m pip install -e .
    printf '%s' "$FINGERPRINT" > data/deployment/python-installed
fi
echo "[2/5] Installing frontend dependencies..."
WEB_FINGERPRINT="$(.venv/bin/python -c 'import hashlib,pathlib; print(hashlib.sha256(pathlib.Path("web/package-lock.json").read_bytes()).hexdigest())')"
if [[ ! -d web/node_modules ]] || [[ ! -f data/deployment/web-installed ]] || [[ "$(cat data/deployment/web-installed)" != "$WEB_FINGERPRINT" ]]; then
    (cd web && npm ci --legacy-peer-deps)
    printf '%s' "$WEB_FINGERPRINT" > data/deployment/web-installed
fi
echo "[3/5] Initializing configuration..."
.venv/bin/python -m deployment.configure
echo "[4/5] Checking cloud inference, tool round trip and embedding (real small model calls)..."
.venv/bin/python -m deployment.check
# Detect occupied ports before creating either process. Do not reuse unrelated listeners.
.venv/bin/python - <<'PY'
import json, socket
from pathlib import Path
s = json.loads(Path('data/user/settings/system.json').read_text())
for port in (8765, int(s.get('backend_port',8001)), int(s.get('frontend_port',3782))):
    with socket.socket() as sock:
        try: sock.bind(('0.0.0.0', port))
        except OSError: raise SystemExit(f'Port {port} is occupied. Stop the existing service before starting.')
PY
echo "[5/5] Starting bridge and DeepTutor; first run builds the production frontend..."
BRIDGE_PID=""
APP_PID=""
cleanup() {
    trap - EXIT INT TERM
    [[ -z "$APP_PID" ]] || kill -TERM "$APP_PID" 2>/dev/null || true
    [[ -z "$APP_PID" ]] || wait "$APP_PID" 2>/dev/null || true
    [[ -z "$BRIDGE_PID" ]] || kill -TERM "$BRIDGE_PID" 2>/dev/null || true
    [[ -z "$BRIDGE_PID" ]] || wait "$BRIDGE_PID" 2>/dev/null || true
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
.venv/bin/python -m uvicorn deployment.bridge:app --host 127.0.0.1 --port 8765 >>data/deployment/bridge.log 2>&1 &
BRIDGE_PID=$!
.venv/bin/python - <<'PY'
import time, urllib.request
opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
for _ in range(30):
    try:
        with opener.open('http://127.0.0.1:8765/health', timeout=1) as response:
            if response.status == 200: break
    except OSError: time.sleep(1)
else: raise SystemExit('Bridge failed to start. See data/deployment/bridge.log')
PY
.venv/bin/deeptutor start &
APP_PID=$!
echo "Default web URL: http://<this-server-IP>:3782 (wait for DeepTutor's ready message)."
echo "Keep this terminal open. Ctrl+C stops all local services. Data stays in ./data/."
set +e
wait -n "$APP_PID" "$BRIDGE_PID"
STATUS=$?
set -e
exit "$STATUS"
