const app = document.querySelector('#app');
const externalIcon = '<svg viewBox="0 0 24 24"><path d="M14 4h6v6M20 4l-9 9"/><path d="M18 13v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h5"/></svg>';
function stageFilter() {
  return `<div class="stage-filter">
    <button class="action-button stage-trigger" aria-expanded="false">环节</button>
    <div class="stage-menu">
      <button data-stage="全部">全部</button>
      <button data-stage="开发">开发</button>
      <button data-stage="测试">测试</button>
      <button data-stage="设计">设计</button>
    </div>
  </div>`;
}

const totalCards = () => `
  <section class="section">

    <div class="total-cards">
      <div class="total-card"><div class="label">全量产业知识</div><div class="facts"><span>33产品知识库</span><span>12111产业知识</span></div></div>
      <div class="total-card"><div class="label">全量作业数据</div><div class="facts"><span>1000代码仓资产</span><span>5作业系统对接</span></div></div>
      <div class="total-card"><div class="label">全量领域知识</div><div class="facts"><span>33开发规范</span><span>20测试规范</span><span>10设计规范</span><span>400Skills</span></div></div>
    </div>
  </section>`;

function totalPage() {
  return `
    <header class="page-title"><h1>知识资产总览</h1></header>
    ${totalCards()}
    <section class="section">
      <h2 class="section-title">各环节知识建设现状</h2>
      <div class="overview-flow">
        ${phaseCard('design', '设计环节')}
        ${phaseCard('develop', '开发环节')}
        ${phaseCard('test', '测试环节')}
        <div class="common-line"><span>产业知识</span><span>12111</span></div>
      </div>
    </section>
    <section class="section content-section">
      <div class="content-head"><div class="title-tools"><h2>知识资产建设情况</h2>${stageFilter()}</div></div>
      <div class="table-wrap"><table>
        <thead class="asset-table-head">
          <tr>
            <th rowspan="2">PDU</th>
            <th rowspan="2">开发部</th>
            <th rowspan="2">产品</th>
            <th rowspan="2" class="asset-group">产业知识</th>
            <th colspan="1" class="asset-group">作业数据</th>
            <th colspan="2" class="asset-group">领域知识</th>
          </tr>
          <tr class="asset-subhead">
            <th>代码仓资产</th>
            <th>规范</th>
            <th>Skills</th>
          </tr>
        </thead>
        <tbody>
          <tr><td><button class="hierarchy-link" data-dashboard="分组核心产品" data-path="分组核心网/分组核心产品">分组核心产品</button></td><td><button class="hierarchy-link" data-dashboard="New Calling" data-path="分组核心网/NewCalling">New Calling</button> <span class="expand">+</span></td><td><button class="product-link" data-dashboard="NCP" data-path="分组核心网/NewCalling/NCP">NCP</button></td><td><span class="asset-pill">356项知识</span></td><td><span class="asset-pill">100/222代码仓</span></td><td><span class="asset-pill">10项规范</span></td><td><span class="asset-pill">20项经验</span></td></tr>
          <tr><td></td><td></td><td><button class="product-link" data-dashboard="New Calling" data-path="分组核心网/NewCalling/New Calling">New Calling</button></td><td><span class="asset-pill">356项知识</span></td><td><span class="asset-pill">100/222代码仓</span></td><td><span class="asset-pill">10项规范</span></td><td><span class="asset-pill empty">未接入</span></td></tr>
          <tr><td></td><td><button class="hierarchy-link" data-dashboard="SPC" data-path="分组核心网/SPC">SPC</button> <span class="expand">+</span></td><td><button class="product-link" data-dashboard="UEG" data-path="分组核心网/SPC/UEG">UEG</button></td><td><span class="asset-pill">356项知识</span></td><td><span class="asset-pill">100/222代码仓</span></td><td><span class="asset-pill">10项规范</span></td><td><span class="asset-pill">20项经验</span></td></tr>
        </tbody>
      </table></div>
    </section>`;
}

function phaseCard(type, title) {
  return `<div class="phase ${type}">
    <h3>${title}</h3>
    <div class="phase-groups">
      <div class="phase-group">
        <div class="group-title"><span>作业数据</span></div>
        <div class="group-item"><span>代码仓资产</span><strong>10</strong></div>
      </div>
      <div class="phase-group">
        <div class="group-title"><span>领域知识</span><strong>20</strong></div>
        <div class="group-item"><span>规范</span><strong>10</strong></div>
        <div class="group-item"><span>Skill</span><strong>10</strong></div>
      </div>
    </div>
  </div>`;
}

function knowledgeOverview(active) {
  return `<section class="section">
    <h2 class="section-title">知识总览</h2>
    <div class="knowledge-cards">
      <button class="knowledge-card ${active === 'industry' ? 'active' : ''}" data-major="industry"><div class="label">产业知识</div><div class="facts"><span>2产品知识库</span><span>100产品知识</span></div></button>
      <button class="knowledge-card ${active === 'job' ? 'active' : ''}" data-major="job"><div class="label">作业数据</div><div class="facts"><span>1000代码仓资产</span><span>5作业系统对接</span></div></button>
      <button class="knowledge-card ${active === 'domain' ? 'active' : ''}" data-major="domain"><div class="label">领域知识</div><div class="facts"><span>33开发规范</span><span>20测试规范</span><span>10设计规范</span><span>400Skills</span></div></button>
    </div>
  </section>`;
}

function industryContent() {
  return `<section class="section content-section">
    <div class="content-head"><h2>产品知识集清单</h2><button class="action-button" data-open-knowledge>新增关联知识集</button></div>
    <div class="table-wrap"><table><thead><tr><th>名称</th><th>归属产品</th><th>url</th><th>知识数量</th><th>操作</th></tr></thead><tbody>
      <tr><td>NCP产品知识集1</td><td>NCP</td><td>url1</td><td>100</td><td><button class="icon-link">${externalIcon}</button></td></tr>
      <tr><td>NCP产品知识集2</td><td>NCP</td><td>url2</td><td>55</td><td><button class="icon-link">${externalIcon}</button></td></tr>
    </tbody></table></div>
  </section>
  <div class="knowledge-modal" data-knowledge-modal hidden>
    <div class="knowledge-dialog" role="dialog" aria-modal="true" aria-labelledby="knowledge-dialog-title">
      <div class="knowledge-dialog-head">
        <h2 id="knowledge-dialog-title">雅典娜知识集对接</h2>
        <span class="help-icon" title="雅典娜知识集对接说明">?</span>
      </div>
      <form class="knowledge-form" data-knowledge-form>
        <label><span>知识集链接</span><input name="knowledgeUrl" required /></label>
        <label><span>知识集id</span><input name="knowledgeId" required /></label>
        <div class="knowledge-dialog-actions">
          <button type="button" class="dialog-button" data-cancel-knowledge>取消</button>
          <button type="submit" class="dialog-button primary">关联</button>
        </div>
      </form>
    </div>
  </div>`;
}

function jobOverview(active) {
  return `<section class="section"><h2 class="section-title">作业数据总览</h2><div class="sub-overview">
    <button class="sub-card ${active === 'repository' ? 'active' : ''}" data-sub="repository"><div class="label">代码仓资产</div><div class="facts"><span>2产品知识库</span></div></button>
    <button class="sub-card ${active === 'system' ? 'active' : ''}" data-sub="system"><div class="label">作业系统对接</div><div class="facts"><span>5作业系统对接</span></div></button>
  </div></section>`;
}

function repositoryContent() {
  return `<section class="section content-section"><div class="content-head"><div class="title-tools"><h2>关联代码仓列表</h2>${stageFilter()}</div></div><div class="table-wrap"><table><thead><tr><th>名称</th><th>url</th><th>Spec</th></tr></thead><tbody><tr><td>代码仓名称</td><td>git-url</td><td>未生成/生成中/完成</td></tr></tbody></table></div></section>`;
}

function systemContent() {
  return `<section class="section content-section"><div class="content-head"><div class="title-tools"><h2>作业系统</h2>${stageFilter()}</div></div><div class="table-wrap"><table><thead><tr><th>作业平台</th><th>是否正在使用</th></tr></thead><tbody>
    <tr><td>Corealm</td><td><span class="check-box"></span></td></tr><tr><td>Codehub</td><td><span class="check-box red"></span></td></tr><tr><td>CIDA</td><td><span class="check-box"></span></td></tr>
  </tbody></table></div></section>`;
}

function domainOverview(active) {
  return `<section class="section"><h2 class="section-title">领域知识总览</h2><div class="sub-overview">
    <button class="sub-card ${active === 'standard' ? 'active' : ''}" data-sub="standard"><div class="label">规范</div><div class="facts"><span>33开发规范</span><span>20测试规范</span><span>10设计规范</span></div></button>
    <button class="sub-card ${active === 'skill' ? 'active' : ''}" data-sub="skill"><div class="label">Skill</div><div class="facts"><span>100Skills</span></div></button>
  </div></section>`;
}

function skillContent() {
  return `<section class="section content-section"><div class="content-head"><div class="title-tools"><h2>Skill规划清单</h2>${stageFilter()}</div><button class="action-button">前往Skill广场</button></div><div class="table-wrap"><table><thead><tr><th>经验名称</th><th>说明</th><th>一级场景</th><th>二级场景</th><th>归属活动</th><th>归属子活动</th><th>归属部门</th><th>责任owner</th><th>状态</th></tr></thead><tbody><tr><td>pcf-requirement-design</td><td>需求澄清，头脑风暴</td><td>需求开发</td><td>MML开发</td><td>设计</td><td>需求设计</td><td>分组核心/网产品部</td><td>董飞 00865306</td><td>未开始/开发中/已完成</td></tr></tbody></table></div></section>`;
}

function standardContent() {
  return `<section class="section content-section"><div class="content-head"><h2>产品规范</h2><button class="action-button">新增</button></div><div class="spec-layout">
    <aside class="tree"><div>⊞ <span class="folder">■</span> 产品</div><div class="indent">⊟ <span class="folder">■</span> company</div><div class="indent2">⊞ <span class="folder">■</span> 编程规范</div><div class="indent">⊞ <span class="folder">■</span> pdu</div><div class="indent">⊞ <span class="folder">■</span> product-lines</div></aside>
    <article class="doc"><h3>Huawei CleanCode C 核心原则</h3><p>本文档描述Huawei CleanCode C编程语言的核心原则。</p><h4>规则级别</h4><ul><li>【要求】：必须遵守的规则。</li><li>【建议】：推荐遵守的规则。</li></ul><h4>核心设计原则</h4><p><strong>命名规范</strong></p><p>使用清晰、准确的命名表达代码意图。</p></article>
    <aside class="toc"><strong>Huawei CleanCode C 核心原则</strong><span>规则级别</span><span>核心设计原则</span><span>命名规范</span><span>注释规范</span><span>格式规范</span><span>编程与测试</span><span>大型工程</span><span>行为与语句</span><span>预处理规范</span></aside>
  </div></section>`;
}

const state = { view: 'total', product: 'NCP', path: '分组核心网/NewCalling/NCP', major: 'industry', jobSub: 'repository', domainSub: 'standard' };

function childPage() {
  let content = '';
  if (state.major === 'industry') content = industryContent();
  if (state.major === 'job') content = jobOverview(state.jobSub) + (state.jobSub === 'repository' ? repositoryContent() : systemContent());
  if (state.major === 'domain') content = domainOverview(state.domainSub) + (state.domainSub === 'standard' ? standardContent() : skillContent());
  return `<button class="back-home" data-back>← 返回主页</button><header class="page-title"><h1>${state.product}知识资产驾驶舱</h1><p class="product-path">${state.path}</p></header>${knowledgeOverview(state.major)}${content}`;
}

function render() {
  app.innerHTML = state.view === 'total' ? totalPage() : childPage();
  document.title = state.view === 'total' ? '知识资产总览' : `${state.product}知识资产驾驶舱`;
  bind();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function bind() {
  app.querySelectorAll('[data-dashboard]').forEach(button => button.addEventListener('click', () => {
    state.product = button.dataset.dashboard;
    state.path = button.dataset.path;
    state.view = 'product';
    state.major = 'industry';
    render();
  }));
  app.querySelector('[data-back]')?.addEventListener('click', () => { state.view = 'total'; render(); });
  app.querySelectorAll('[data-major]').forEach(button => button.addEventListener('click', () => { state.major = button.dataset.major; render(); }));
  app.querySelectorAll('[data-sub]').forEach(button => button.addEventListener('click', () => {
    if (state.major === 'job') state.jobSub = button.dataset.sub;
    if (state.major === 'domain') state.domainSub = button.dataset.sub;
    render();
  }));
  app.querySelectorAll('.stage-trigger').forEach(trigger => trigger.addEventListener('click', event => {
    event.stopPropagation();
    const filter = trigger.closest('.stage-filter');
    const willOpen = !filter.classList.contains('open');
    app.querySelectorAll('.stage-filter').forEach(item => item.classList.remove('open'));
    filter.classList.toggle('open', willOpen);
    trigger.setAttribute('aria-expanded', String(willOpen));
  }));
  app.querySelectorAll('[data-stage]').forEach(option => option.addEventListener('click', event => {
    event.stopPropagation();
    const filter = option.closest('.stage-filter');
    const trigger = filter.querySelector('.stage-trigger');
    trigger.textContent = option.dataset.stage === '全部' ? '环节' : option.dataset.stage;
    filter.querySelectorAll('[data-stage]').forEach(item => item.classList.toggle('active', item === option));
    filter.classList.remove('open');
    trigger.setAttribute('aria-expanded', 'false');
  }));
  const knowledgeModal = app.querySelector('[data-knowledge-modal]');
  const closeKnowledgeModal = () => {
    if (!knowledgeModal) return;
    knowledgeModal.classList.remove('open');
    setTimeout(() => { knowledgeModal.hidden = true; }, 160);
  };
  app.querySelector('[data-open-knowledge]')?.addEventListener('click', () => {
    knowledgeModal.hidden = false;
    requestAnimationFrame(() => knowledgeModal.classList.add('open'));
    setTimeout(() => knowledgeModal.querySelector('input')?.focus(), 170);
  });
  app.querySelector('[data-cancel-knowledge]')?.addEventListener('click', closeKnowledgeModal);
  knowledgeModal?.addEventListener('click', event => {
    if (event.target === knowledgeModal) closeKnowledgeModal();
  });
  app.querySelector('[data-knowledge-form]')?.addEventListener('submit', event => {
    event.preventDefault();
    closeKnowledgeModal();
  });
}

document.addEventListener('click', () => {
  document.querySelectorAll('.stage-filter.open').forEach(filter => {
    filter.classList.remove('open');
    filter.querySelector('.stage-trigger')?.setAttribute('aria-expanded', 'false');
  });
});

render();
