﻿-- 知识资产驾驶舱 Mock 数据
-- 适用：GaussDB Kernel 505.2.1
-- 仅用于开发/测试环境，请勿在生产环境执行。
-- 脚本只清理 MOCK- 前缀数据，不影响非 Mock 数据。

SET search_path TO public;

START TRANSACTION;

-- ============================================================
-- 1. 清理本脚本上一次写入的 Mock 数据，保证可重复执行
-- ============================================================

DELETE FROM t_km_product_kb_relation
 WHERE id LIKE 'MOCK-%' OR offering_id LIKE 'MOCK-%';

DELETE FROM t_km_product_repo_rule_relation
 WHERE id LIKE 'MOCK-%' OR offering_id LIKE 'MOCK-%';

DELETE FROM t_km_product_operating_knowledge_relation
 WHERE id LIKE 'MOCK-%' OR offering_id LIKE 'MOCK-%';

DELETE FROM t_km_product_rule_relation
 WHERE id LIKE 'MOCK-%' OR offering_id LIKE 'MOCK-%';

DELETE FROM t_km_product_skill_relation
 WHERE id LIKE 'MOCK-%' OR offering_id LIKE 'MOCK-%';

DELETE FROM t_km_kb_infos WHERE kb_id LIKE 'MOCK-%';
DELETE FROM t_km_operating_knowledge_infos WHERE id LIKE 'MOCK-%';
DELETE FROM t_km_rule_infos WHERE id LIKE 'MOCK-%';
DELETE FROM t_km_skill_infos WHERE skill_id LIKE 'MOCK-%';
DELETE FROM t_repo_rule_infos WHERE repo_url LIKE 'https://mock.example.com/%';
DELETE FROM t_km_product_infos WHERE offering_id LIKE 'MOCK-%';

-- ============================================================
-- 2. 产品中心数据：1 个 PDU、2 个 solution、3 个产品
-- ============================================================

INSERT INTO t_km_product_infos
    (offering_id, product_name, pdu, solution)
VALUES
    ('MOCK-OFFERING-NCP', 'NCP', '分组核心产品', 'New Calling'),
    ('MOCK-OFFERING-NEW-CALLING', 'New Calling', '分组核心产品', 'New Calling'),
    ('MOCK-OFFERING-UEG', 'UEG', '分组核心产品', 'SPC');

-- ============================================================
-- 3. 产业知识原子数据与产品关联
-- ============================================================

INSERT INTO t_km_kb_infos
    (kb_id, kb_name, kb_url, knowledge_num)
VALUES
    ('MOCK-KB-NCP-001', 'NCP 产品知识集 1', 'https://mock.example.com/kb/ncp-001', 100),
    ('MOCK-KB-NCP-002', 'NCP 产品知识集 2', 'https://mock.example.com/kb/ncp-002', 55),
    ('MOCK-KB-NC-001', 'New Calling 产品知识集', 'https://mock.example.com/kb/new-calling-001', 356),
    ('MOCK-KB-UEG-001', 'UEG 产品知识集', 'https://mock.example.com/kb/ueg-001', 210);

INSERT INTO t_km_product_kb_relation
    (id, offering_id, kb_id)
VALUES
    ('MOCK-KB-REL-001', 'MOCK-OFFERING-NCP', 'MOCK-KB-NCP-001'),
    ('MOCK-KB-REL-002', 'MOCK-OFFERING-NCP', 'MOCK-KB-NCP-002'),
    ('MOCK-KB-REL-003', 'MOCK-OFFERING-NEW-CALLING', 'MOCK-KB-NC-001'),
    ('MOCK-KB-REL-004', 'MOCK-OFFERING-UEG', 'MOCK-KB-UEG-001');

-- ============================================================
-- 4. 作业系统原子数据与产品关联
-- ============================================================

INSERT INTO t_km_operating_knowledge_infos
    (id, operating_system, scenario)
VALUES
    ('MOCK-OS-COREALM-DEVELOP', 'Corealm', 'develop'),
    ('MOCK-OS-CODEHUB-DEVELOP', 'Codehub', 'develop'),
    ('MOCK-OS-CIDA-TEST', 'CIDA', 'test'),
    ('MOCK-OS-COREALM-DESIGN', 'Corealm', 'design');

INSERT INTO t_km_product_operating_knowledge_relation
    (id, offering_id, operating_knowledge_id)
VALUES
    ('MOCK-OS-REL-001', 'MOCK-OFFERING-NCP', 'MOCK-OS-COREALM-DEVELOP'),
    ('MOCK-OS-REL-002', 'MOCK-OFFERING-NCP', 'MOCK-OS-CODEHUB-DEVELOP'),
    ('MOCK-OS-REL-003', 'MOCK-OFFERING-NEW-CALLING', 'MOCK-OS-CIDA-TEST'),
    ('MOCK-OS-REL-004', 'MOCK-OFFERING-UEG', 'MOCK-OS-COREALM-DESIGN');

-- ============================================================
-- 5. 规范 Rule 原子数据与产品关联
-- 规范树和正文仍由现有 /knowledgeCenter/rule/* 接口提供；
-- 以下数据用于我们自己的规范数量统计。
-- ============================================================

INSERT INTO t_km_rule_infos
    (id, scenario)
VALUES
    ('MOCK-RULE-DESIGN-001', 'design'),
    ('MOCK-RULE-DEVELOP-001', 'develop'),
    ('MOCK-RULE-DEVELOP-002', 'develop'),
    ('MOCK-RULE-TEST-001', 'test'),
    ('MOCK-RULE-TEST-002', 'test');

INSERT INTO t_km_product_rule_relation
    (id, offering_id, rule_id)
VALUES
    ('MOCK-RULE-REL-001', 'MOCK-OFFERING-NCP', 'MOCK-RULE-DESIGN-001'),
    ('MOCK-RULE-REL-002', 'MOCK-OFFERING-NCP', 'MOCK-RULE-DEVELOP-001'),
    ('MOCK-RULE-REL-003', 'MOCK-OFFERING-NCP', 'MOCK-RULE-TEST-001'),
    ('MOCK-RULE-REL-004', 'MOCK-OFFERING-NEW-CALLING', 'MOCK-RULE-DEVELOP-002'),
    ('MOCK-RULE-REL-005', 'MOCK-OFFERING-UEG', 'MOCK-RULE-TEST-002');

-- ============================================================
-- 6. Skill 原子数据与产品关联
-- ============================================================

INSERT INTO t_km_skill_infos
    (skill_id, name, description, level1, level2, process, sub_process,
     department, owner, status, scenario)
VALUES
    ('MOCK-SKILL-001', 'pcf-requirement-design', '需求澄清，头脑风暴',
     '需求开发', 'MML开发', '设计', '需求设计',
     '分组核心/网产品部', '董飞 00865306', '开发中', 'design'),
    ('MOCK-SKILL-002', 'repository-rule-generate', '从代码仓生成 Rule',
     '代码开发', '代码知识', '开发', '编码实现',
     '分组核心/网产品部', '张三 00000001', '已完成', 'develop'),
    ('MOCK-SKILL-003', 'automated-test-design', '自动化测试方案设计',
     '测试开发', '自动化测试', '测试', '测试设计',
     '分组核心/网产品部', '李四 00000002', '未开始', 'test'),
    ('MOCK-SKILL-004', 'ueg-domain-analysis', 'UEG 领域分析经验',
     '需求开发', '领域分析', '设计', '需求分析',
     '分组核心/网产品部', '王五 00000003', '开发中', 'design');

INSERT INTO t_km_product_skill_relation
    (id, offering_id, skill_id)
VALUES
    ('MOCK-SKILL-REL-001', 'MOCK-OFFERING-NCP', 'MOCK-SKILL-001'),
    ('MOCK-SKILL-REL-002', 'MOCK-OFFERING-NCP', 'MOCK-SKILL-002'),
    ('MOCK-SKILL-REL-003', 'MOCK-OFFERING-NCP', 'MOCK-SKILL-003'),
    ('MOCK-SKILL-REL-004', 'MOCK-OFFERING-UEG', 'MOCK-SKILL-004');

-- ============================================================
-- 7. 代码仓 Rule 原子数据与产品关联
-- ============================================================

INSERT INTO t_repo_rule_infos
    (repo_url, branch, repo_name, rule_status, source_type, workspace_id,
     create_time, scenario, commit_id)
VALUES
    ('https://mock.example.com/git/ncp-core.git', 'main', 'ncp-core',
     'success', 'server_generate', 'MOCK-WS-NCP-001',
     TIMESTAMP '2026-08-20 10:00:00', 'develop', 'mock-commit-ncp-001'),
    ('https://mock.example.com/git/ncp-test.git', 'release', 'ncp-test',
     'failed', 'codewiki_generate', 'MOCK-WS-NCP-002',
     TIMESTAMP '2026-08-20 11:00:00', 'test', 'mock-commit-ncp-002'),
    ('https://mock.example.com/git/ncp-design.git', 'main', 'ncp-design',
     'skipped', 'uploaded_zip', 'MOCK-WS-NCP-003',
     TIMESTAMP '2026-08-20 12:00:00', 'design', 'mock-commit-ncp-003'),
    ('https://mock.example.com/git/new-calling.git', 'develop', 'new-calling',
     'success', 'server_generate', 'MOCK-WS-NC-001',
     TIMESTAMP '2026-08-20 13:00:00', 'develop', 'mock-commit-nc-001'),
    ('https://mock.example.com/git/ueg-core.git', 'main', 'ueg-core',
     'success', 'server_generate', 'MOCK-WS-UEG-001',
     TIMESTAMP '2026-08-20 14:00:00', 'develop', 'mock-commit-ueg-001'),
    ('https://mock.example.com/git/ueg-test.git', 'test', 'ueg-test',
     'permission_deny', 'codewiki_generate', 'MOCK-WS-UEG-002',
     TIMESTAMP '2026-08-20 15:00:00', 'test', 'mock-commit-ueg-002');

INSERT INTO t_km_product_repo_rule_relation
    (id, offering_id, repo_url, branch, create_time)
VALUES
    ('MOCK-REPO-REL-001', 'MOCK-OFFERING-NCP',
     'https://mock.example.com/git/ncp-core.git', 'main',
     TIMESTAMP '2026-08-20 10:00:00'),
    ('MOCK-REPO-REL-002', 'MOCK-OFFERING-NCP',
     'https://mock.example.com/git/ncp-test.git', 'release',
     TIMESTAMP '2026-08-20 11:00:00'),
    ('MOCK-REPO-REL-003', 'MOCK-OFFERING-NCP',
     'https://mock.example.com/git/ncp-design.git', 'main',
     TIMESTAMP '2026-08-20 12:00:00'),
    ('MOCK-REPO-REL-004', 'MOCK-OFFERING-NEW-CALLING',
     'https://mock.example.com/git/new-calling.git', 'develop',
     TIMESTAMP '2026-08-20 13:00:00'),
    ('MOCK-REPO-REL-005', 'MOCK-OFFERING-UEG',
     'https://mock.example.com/git/ueg-core.git', 'main',
     TIMESTAMP '2026-08-20 14:00:00'),
    ('MOCK-REPO-REL-006', 'MOCK-OFFERING-UEG',
     'https://mock.example.com/git/ueg-test.git', 'test',
     TIMESTAMP '2026-08-20 15:00:00');

COMMIT;

-- ============================================================
-- 8. 验证查询
-- ============================================================

SELECT *
FROM t_km_product_infos
WHERE offering_id LIKE 'MOCK-%'
ORDER BY offering_id;

SELECT
    product.product_name,
    rule.scenario,
    COUNT(*) AS rule_count
FROM t_km_product_rule_relation relation
JOIN t_km_product_infos product
  ON product.offering_id = relation.offering_id
JOIN t_km_rule_infos rule
  ON rule.id = relation.rule_id
WHERE relation.offering_id LIKE 'MOCK-%'
GROUP BY product.product_name, rule.scenario
ORDER BY product.product_name, rule.scenario;

SELECT
    product.product_name,
    COUNT(relation.id) AS repository_count
FROM t_km_product_infos product
LEFT JOIN t_km_product_repo_rule_relation relation
  ON relation.offering_id = product.offering_id
WHERE product.offering_id LIKE 'MOCK-%'
GROUP BY product.product_name
ORDER BY product.product_name;



