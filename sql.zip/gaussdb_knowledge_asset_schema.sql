-- 知识资产数据库建表脚本（最终版）
-- 目标数据库：GaussDB Kernel 505.2.1 build ff07bff6
-- 编译信息：2024-12-27 09:22:42, commit 10161, last mr 21504, release
-- 默认 Schema：public；如使用其他 Schema，请在执行前修改 search_path。
-- 设计约定：仅设置主键，不设置外键、唯一约束、检查约束；数据关联与一致性由应用维护。

SET search_path TO public;

START TRANSACTION;

-- 1. 产品信息表（中心表）
CREATE TABLE t_km_product_infos (
    offering_id  varchar(255),
    product_name varchar(255),
    pdu          varchar(255),
    solution     varchar(255),
    CONSTRAINT pk_t_km_product_infos PRIMARY KEY (offering_id)
);

COMMENT ON TABLE t_km_product_infos IS '产品信息中心表';
COMMENT ON COLUMN t_km_product_infos.offering_id IS '产品ID，主键，也是全部产品关系的关联字段';
COMMENT ON COLUMN t_km_product_infos.product_name IS '产品名称，与offering_id业务上一对一，由应用维护';
COMMENT ON COLUMN t_km_product_infos.pdu IS '所属PDU';
COMMENT ON COLUMN t_km_product_infos.solution IS '所属解决方案';

-- 2. 产业知识库信息表
CREATE TABLE t_km_kb_infos (
    kb_id         varchar(255),
    kb_name       varchar(255),
    kb_url        varchar(255),
    knowledge_num int8,
    CONSTRAINT pk_t_km_kb_infos PRIMARY KEY (kb_id)
);

COMMENT ON TABLE t_km_kb_infos IS '产业知识库信息表';
COMMENT ON COLUMN t_km_kb_infos.kb_id IS '知识库ID，主键';
COMMENT ON COLUMN t_km_kb_infos.kb_name IS '知识库名称';
COMMENT ON COLUMN t_km_kb_infos.kb_url IS '知识库访问地址';
COMMENT ON COLUMN t_km_kb_infos.knowledge_num IS '知识条目数量';

-- 3. 产品与产业知识库关系表
CREATE TABLE t_km_product_kb_relation (
    id          varchar(255),
    offering_id varchar(255),
    kb_id       varchar(255),
    CONSTRAINT pk_t_km_product_kb_relation PRIMARY KEY (id)
);

COMMENT ON TABLE t_km_product_kb_relation IS '产品与产业知识库关系表';
COMMENT ON COLUMN t_km_product_kb_relation.id IS '关系记录ID，主键';
COMMENT ON COLUMN t_km_product_kb_relation.offering_id IS '产品ID，逻辑关联t_km_product_infos.offering_id';
COMMENT ON COLUMN t_km_product_kb_relation.kb_id IS '知识库ID，逻辑关联t_km_kb_infos.kb_id';

-- 4. 代码仓规范信息表
CREATE TABLE t_repo_rule_infos (
    repo_url     varchar(1024),
    branch       varchar(255),
    repo_name    varchar(255),
    rule_status  varchar(50),
    source_type  varchar(32),
    workspace_id varchar(64),
    create_time  timestamp(0) without time zone,
    scenario     varchar(50),
    commit_id    varchar(255),
    CONSTRAINT pk_t_repo_rule_infos PRIMARY KEY (repo_url, branch, create_time)
);

COMMENT ON TABLE t_repo_rule_infos IS '代码仓规范生成信息表';
COMMENT ON COLUMN t_repo_rule_infos.repo_url IS '代码仓地址，复合主键字段';
COMMENT ON COLUMN t_repo_rule_infos.branch IS '代码分支，复合主键字段';
COMMENT ON COLUMN t_repo_rule_infos.repo_name IS '代码仓名称';
COMMENT ON COLUMN t_repo_rule_infos.rule_status IS '规范生成状态';
COMMENT ON COLUMN t_repo_rule_infos.source_type IS '数据来源类型';
COMMENT ON COLUMN t_repo_rule_infos.workspace_id IS '工作空间ID';
COMMENT ON COLUMN t_repo_rule_infos.create_time IS '创建时间，复合主键字段';
COMMENT ON COLUMN t_repo_rule_infos.scenario IS '所属环节，例如design、develop、test';
COMMENT ON COLUMN t_repo_rule_infos.commit_id IS '代码提交ID';

-- 5. 产品与代码仓规范关系表
CREATE TABLE t_km_product_repo_rule_relation (
    id          varchar(255),
    offering_id varchar(255),
    repo_url    varchar(1024),
    branch      varchar(255),
    create_time timestamp(0) without time zone,
    CONSTRAINT pk_t_km_product_repo_rule_relation PRIMARY KEY (id)
);

COMMENT ON TABLE t_km_product_repo_rule_relation IS '产品与代码仓规范关系表';
COMMENT ON COLUMN t_km_product_repo_rule_relation.id IS '关系记录ID，主键';
COMMENT ON COLUMN t_km_product_repo_rule_relation.offering_id IS '产品ID';
COMMENT ON COLUMN t_km_product_repo_rule_relation.repo_url IS '代码仓地址';
COMMENT ON COLUMN t_km_product_repo_rule_relation.branch IS '代码分支';
COMMENT ON COLUMN t_km_product_repo_rule_relation.create_time IS '代码仓规范记录创建时间';

-- 6. 作业系统知识信息表
CREATE TABLE t_km_operating_knowledge_infos (
    id               varchar(255),
    operating_system varchar(255),
    scenario         varchar(255),
    CONSTRAINT pk_t_km_operating_knowledge_infos PRIMARY KEY (id)
);

COMMENT ON TABLE t_km_operating_knowledge_infos IS '作业系统知识信息表';
COMMENT ON COLUMN t_km_operating_knowledge_infos.id IS '作业系统知识ID，主键';
COMMENT ON COLUMN t_km_operating_knowledge_infos.operating_system IS '作业系统名称';
COMMENT ON COLUMN t_km_operating_knowledge_infos.scenario IS '所属场景';

-- 7. 产品与作业系统知识关系表
CREATE TABLE t_km_product_operating_knowledge_relation (
    id                     varchar(255),
    offering_id            varchar(255),
    operating_knowledge_id varchar(255),
    CONSTRAINT pk_t_km_product_operating_knowledge_relation PRIMARY KEY (id)
);

COMMENT ON TABLE t_km_product_operating_knowledge_relation IS '产品与作业系统知识关系表';
COMMENT ON COLUMN t_km_product_operating_knowledge_relation.id IS '关系记录ID，主键';
COMMENT ON COLUMN t_km_product_operating_knowledge_relation.offering_id IS '产品ID';
COMMENT ON COLUMN t_km_product_operating_knowledge_relation.operating_knowledge_id IS '作业系统知识ID';

-- 8. 规范信息表
CREATE TABLE t_km_rule_infos (
    id       varchar(255),
    scenario varchar(255),
    CONSTRAINT pk_t_km_rule_infos PRIMARY KEY (id)
);

COMMENT ON TABLE t_km_rule_infos IS '规范信息表';
COMMENT ON COLUMN t_km_rule_infos.id IS '规范ID，主键';
COMMENT ON COLUMN t_km_rule_infos.scenario IS '规范所属场景';

-- 9. 产品与规范关系表
CREATE TABLE t_km_product_rule_relation (
    id          varchar(255),
    offering_id varchar(255),
    rule_id     varchar(255),
    CONSTRAINT pk_t_km_product_rule_relation PRIMARY KEY (id)
);

COMMENT ON TABLE t_km_product_rule_relation IS '产品与规范关系表';
COMMENT ON COLUMN t_km_product_rule_relation.id IS '关系记录ID，主键';
COMMENT ON COLUMN t_km_product_rule_relation.offering_id IS '产品ID';
COMMENT ON COLUMN t_km_product_rule_relation.rule_id IS '规范ID';

-- 10. Skill信息表
CREATE TABLE t_km_skill_infos (
    skill_id    varchar(255),
    name        varchar(255),
    description varchar(255),
    level1      varchar(255),
    level2      varchar(255),
    process     varchar(255),
    sub_process varchar(255),
    department  varchar(255),
    owner       varchar(255),
    status      varchar(255),
    scenario    varchar(255),
    CONSTRAINT pk_t_km_skill_infos PRIMARY KEY (skill_id)
);

COMMENT ON TABLE t_km_skill_infos IS 'Skill信息表';
COMMENT ON COLUMN t_km_skill_infos.skill_id IS 'Skill ID，主键';
COMMENT ON COLUMN t_km_skill_infos.name IS 'Skill名称';
COMMENT ON COLUMN t_km_skill_infos.description IS 'Skill描述';
COMMENT ON COLUMN t_km_skill_infos.level1 IS '一级分类';
COMMENT ON COLUMN t_km_skill_infos.level2 IS '二级分类';
COMMENT ON COLUMN t_km_skill_infos.process IS '流程';
COMMENT ON COLUMN t_km_skill_infos.sub_process IS '子流程';
COMMENT ON COLUMN t_km_skill_infos.department IS '所属部门';
COMMENT ON COLUMN t_km_skill_infos.owner IS '责任人';
COMMENT ON COLUMN t_km_skill_infos.status IS '状态';
COMMENT ON COLUMN t_km_skill_infos.scenario IS '所属场景';

-- 11. 产品与Skill关系表
CREATE TABLE t_km_product_skill_relation (
    id          varchar(255),
    offering_id varchar(255),
    skill_id    varchar(255),
    CONSTRAINT pk_t_km_product_skill_relation PRIMARY KEY (id)
);

COMMENT ON TABLE t_km_product_skill_relation IS '产品与Skill关系表';
COMMENT ON COLUMN t_km_product_skill_relation.id IS '关系记录ID，主键';
COMMENT ON COLUMN t_km_product_skill_relation.offering_id IS '产品ID';
COMMENT ON COLUMN t_km_product_skill_relation.skill_id IS 'Skill ID';

-- 查询索引（均为普通索引，不属于唯一约束）
CREATE INDEX idx_km_product_name ON t_km_product_infos (product_name);
CREATE INDEX idx_km_product_pdu_solution ON t_km_product_infos (pdu, solution);

CREATE INDEX idx_km_product_kb_offering ON t_km_product_kb_relation (offering_id);
CREATE INDEX idx_km_product_kb_kb ON t_km_product_kb_relation (kb_id);

CREATE INDEX idx_repo_rule_scenario_time ON t_repo_rule_infos (scenario, create_time);
CREATE INDEX idx_repo_rule_status ON t_repo_rule_infos (rule_status);
CREATE INDEX idx_km_product_repo_rule_offering ON t_km_product_repo_rule_relation (offering_id);
CREATE INDEX idx_km_product_repo_rule_repo ON t_km_product_repo_rule_relation (repo_url, branch, create_time);

CREATE INDEX idx_km_operating_scenario ON t_km_operating_knowledge_infos (scenario);
CREATE INDEX idx_km_product_operating_offering ON t_km_product_operating_knowledge_relation (offering_id);
CREATE INDEX idx_km_product_operating_asset ON t_km_product_operating_knowledge_relation (operating_knowledge_id);

CREATE INDEX idx_km_rule_scenario ON t_km_rule_infos (scenario);
CREATE INDEX idx_km_product_rule_offering ON t_km_product_rule_relation (offering_id);
CREATE INDEX idx_km_product_rule_rule ON t_km_product_rule_relation (rule_id);

CREATE INDEX idx_km_skill_scenario_status ON t_km_skill_infos (scenario, status);
CREATE INDEX idx_km_product_skill_offering ON t_km_product_skill_relation (offering_id);
CREATE INDEX idx_km_product_skill_skill ON t_km_product_skill_relation (skill_id);

COMMIT;
