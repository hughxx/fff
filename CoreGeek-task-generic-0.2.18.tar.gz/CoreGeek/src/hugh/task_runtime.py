"""Task-independent execution, source receipts, HTTP and pagination checks."""
from contextlib import redirect_stdout, redirect_stderr
import builtins
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
from types import ModuleType
import urllib.error
import urllib.parse
import urllib.request

URLOPEN = urllib.request.urlopen
PROCESS_RUN = subprocess.run


def list_paths(value, path=()):
    """Find array envelopes without guessing business record field names."""
    if isinstance(value, list):
        return [list(path)]
    if not isinstance(value, dict) or len(path) > 6:
        return []
    return [p for key, child in value.items() for p in list_paths(child, (*path, key))]


def response_shape(body, records_path=None):
    paths = list_paths(body)
    if records_path is None:
        if len(paths) != 1:
            return {"paths": paths}
        records_path = paths[0]
    rows = lookup(body, records_path)
    if not isinstance(rows, list):
        nested = list_paths(rows, tuple(records_path))
        if len(nested) != 1:
            raise ValueError("records_path must point to a list; candidates: " + repr(nested))
        records_path, rows = nested[0], lookup(body, nested[0])
    fields = {}

    def walk(value, path=()):
        if not isinstance(value, dict) or len(path) > 6:
            return
        for key, item in value.items():
            current = [*path, key]
            norm = re.sub(r"[_-]", "", key).lower()
            parent = str(path[-1]).lower() if path else ""
            kind = None
            for name, aliases in {
                "total": {"total", "totalcount", "totalrecords"},
                "offset": {"offset", "skip"}, "page": {"page", "pagenumber", "currentpage"},
                "size": {"limit", "size", "pagesize", "perpage"},
                "more": {"hasmore", "more"}, "next": {"next", "nextcursor", "nextpage"},
            }.items():
                if norm in aliases:
                    kind = name
            if norm == "count" and parent in ("paging", "pagination", "meta"):
                kind = "total"
            if kind and not isinstance(item, (dict, list)):
                fields.setdefault(kind, []).append((current, item))
            walk(item, tuple(current))
    walk(body)
    shape = {"records_path": records_path, "rows": rows}
    for key, candidates in fields.items():
        if len(candidates) == 1:
            shape[key + "_path"], shape[key] = candidates[0]
        elif candidates:
            shape["ambiguous"] = True
    return shape


def whole_response(shape):
    """Only accept an observed complete page, never the requested page size."""
    if "rows" not in shape or shape.get("ambiguous"):
        return False
    total, rows = shape.get("total"), shape["rows"]
    if type(total) is not int or total < 0 or len(rows) != total:
        return False
    if "more" in shape and type(shape["more"]) is not bool:
        return False
    if ("offset" in shape and shape["offset"] != 0) or ("page" in shape and shape["page"] not in (0, 1)):
        return False
    if shape.get("more") is True or shape.get("next") not in (None, ""):
        return False
    # Only the conventional explicit id field is checked here. Other identity
    # contracts, including legitimate duplicates, use collect(id_path=...).
    if rows and all(isinstance(r, dict) and "id" in r for r in rows):
        ids = [encoded(r["id"]) for r in rows]
        if any(r["id"] is None for r in rows) or len(set(ids)) != len(ids):
            return False
    return True


class RecordedResponse(io.BytesIO):
    def __init__(self, raw, url, code, headers):
        super().__init__(raw)
        self.url, self.code, self.status, self.headers = url, code, code, headers

    def getcode(self):
        return self.code

    def geturl(self):
        return self.url

    def info(self):
        return self.headers


class ToolModule(ModuleType):
    """Tolerate import probe / from probe import probe without another turn."""
    def __init__(self, name, function):
        super().__init__(name)
        self.function = function
        setattr(self, name, function)

    def __call__(self, *args, **kwargs):
        return self.function(*args, **kwargs)


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value):
    return hashlib.sha256(encoded(value).encode("utf-8")).hexdigest()


def clone(value):
    return json.loads(encoded(value))


def lookup(value, path):
    if not isinstance(path, list):
        raise ValueError("A JSON path must be a list of keys or array indices")
    for key in path:
        if isinstance(value, dict) and isinstance(key, str) and key in value:
            value = value[key]
        elif isinstance(value, list) and type(key) is int and 0 <= key < len(value):
            value = value[key]
        else:
            raise ValueError("JSON path not present: " + repr(path))
    return value


def bounded(value, limit=12000):
    text = encoded(value)
    return value if len(text.encode("utf-8")) <= limit else {
        "truncated": True, "preview": text[:limit // 4],
        "note": "Log preview only; complete responses and datasets remain in task state."}


class ContinueNextTurn(Exception):
    """A verified page checkpoint exists; replay only an explicitly resumable script."""


class LimitedOutput(io.StringIO):
    def write(self, text):
        remaining = max(0, 7000 - self.tell())
        super().write(text[:remaining])
        return len(text)


class Runtime:
    def __init__(self, state_path, config=None):
        self.path = Path(state_path)
        self.state = ({"config": clone(config), "last": None, "data": None, "sources": {},
                       "checks": {}, "successful_requests": [], "http_history": []}
                      if config is not None else json.loads(self.path.read_text(encoding="utf-8")))
        self.started, self.request_count = time.monotonic(), 0
        self.used, self.used_checks = set(), set()
        self.answer = None
        self.reported = False
        self.proof = None
        self.log_bytes = 0
        self.http_used = []
        self.collected_http = set()
        self.warnings = []

    def remaining_seconds(self):
        return max(0.0, 11 - (time.monotonic() - self.started))

    def save(self):
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(encoded(self.state), encoding="utf-8")
        temporary.replace(self.path)

    def emit(self, label, value):
        line = label + ":" + encoded(bounded(value, 1800))
        size = len(line.encode("utf-8"))
        if self.log_bytes + size < 15000:
            print(line)
            self.log_bytes += size

    def request_config(self, request=None):
        request = request or {}
        if not isinstance(request, dict) or set(request) - {"url", "path", "method", "params", "headers", "json_body", "body"}:
            raise ValueError("request supports url/path/method/params/headers/json_body/body")
        defaults = self.state["config"].get("request", {})
        # Reuse only proven headers on this exact endpoint. Never inherit the
        # old task's filters, payload, pagination positions or dataset.
        target_url = request.get("url") or urllib.parse.urljoin(
            defaults.get("url", self.state["config"].get("base_url", "")), request.get("path", ""))
        parsed_target = urllib.parse.urlsplit(target_url)
        target_url = urllib.parse.urlunsplit((parsed_target.scheme, parsed_target.netloc, parsed_target.path, "", ""))
        if not defaults:
            for previous in reversed(self.state["config"].get("proven_requests", [])):
                if previous.get("url") == target_url:
                    defaults = {"headers": previous.get("headers", {})}
                    break
        result = {**defaults, **request}
        if "path" in request and "url" not in request:
            result["url"] = urllib.parse.urljoin(defaults.get("url", self.state["config"].get("base_url", "")), request["path"])
        result.pop("path", None)
        result.setdefault("url", self.state["config"].get("base_url", ""))
        for field in ("params", "headers"):
            if not isinstance(request.get(field, {}), dict):
                raise ValueError(field + " must be an object")
            result[field] = {**defaults.get(field, {}), **request.get(field, {})}
            result[field] = {k: v for k, v in result[field].items() if v is not None}
        target = urllib.parse.urlsplit(result["url"])
        origin = urllib.parse.urlunsplit((target.scheme, target.netloc, "", "", ""))
        if target.scheme not in ("http", "https") or origin not in self.state["config"].get("services", []):
            raise ValueError("Use an HTTP service referenced in the current task materials")
        params = {**defaults.get("params", {}), **dict(urllib.parse.parse_qsl(target.query)), **request.get("params", {})}
        result["params"] = {k: v for k, v in params.items() if v is not None}
        result["url"] = urllib.parse.urlunsplit((target.scheme, target.netloc,
                          urllib.parse.quote(urllib.parse.unquote(target.path), safe="/"), "", ""))
        result["method"] = str(result.get("method", "GET")).upper()
        return result

    def fetch(self, path=None, params=None, headers=None, _resolved=None, **options):
        request = {**options}
        for key, value in (("path", path), ("params", params), ("headers", headers)):
            if value is not None:
                request[key] = value
        config = clone(_resolved) if _resolved is not None else self.request_config(request)
        # Persist the latest attempted request as well as separate successful
        # evidence. A 400 must not silently restore headers used before a 401.
        self.state["config"]["request"] = clone(config)
        query = urllib.parse.urlencode(config["params"], doseq=True)
        url = config["url"] + ("?" + query if query else "")
        observation = {"url": url, "request": clone(config)}
        try:
            budget = self.remaining_seconds()
            if budget <= 0 or self.request_count >= 24:
                raise TimeoutError("HTTP budget exhausted")
            self.request_count += 1
            auth = {k: str(v) for k, v in config["headers"].items()}
            body = config.get("body")
            if config.get("json_body") is not None:
                if body is not None:
                    raise ValueError("Choose body or json_body")
                body = encoded(config["json_body"])
                auth.setdefault("Content-Type", "application/json; charset=utf-8")
            if isinstance(body, str):
                body = body.encode("utf-8")
            request = urllib.request.Request(url, data=body, headers=auth, method=config["method"])
            try:
                response = URLOPEN(request, timeout=min(2.0, budget))
            except urllib.error.HTTPError as error:
                response = error
            with response:
                raw = response.read(262145)
                observation.update(status=response.code, headers=dict(response.headers), truncated=len(raw) > 262144)
            text = raw[:262144].decode("utf-8-sig", errors="replace")
            observation["text"] = text
            try:
                observation["json"] = json.loads(text)
            except ValueError:
                pass
            if "json" not in observation:
                observation["body"] = text
            if 200 <= observation["status"] < 300 and not observation["truncated"]:
                self.state["data"] = observation.get("json", observation.get("body"))
                successes = self.state["successful_requests"]
                if not successes or successes[-1] != config:
                    successes.append(clone(config))
                    del successes[:-4]
        except Exception as error:
            observation.update(status=None, error=type(error).__name__ + ": " + str(error))
        self.state["last"] = observation
        self.http_used.append(clone(observation))
        self.state["http_history"].append(clone(observation))
        del self.state["http_history"][:-4]
        self.save()
        self.emit("HUGH_HTTP", observation)
        # A compatibility alias on the returned value avoids tripling JSON in
        # every log and next-turn context.
        returned = clone(observation)
        returned.setdefault("body", returned.get("json", returned.get("text")))
        return returned

    def tracked_urlopen(self, request, data=None, timeout=None, **kwargs):
        """Standard urllib reads receive the same recording as probe."""
        req = request if isinstance(request, urllib.request.Request) else urllib.request.Request(request, data=data)
        if kwargs:
            raise ValueError("Use probe for custom HTTP transport options")
        headers = dict(req.header_items())
        payload = req.data if data is None else data
        if isinstance(payload, bytes):
            payload = payload.decode("utf-8")
        # A standard urllib request is a complete request, not a patch to the
        # previous query. Preserve its URL query and clear old omitted filters.
        params = {k: None for k in self.state["config"].get("request", {}).get("params", {})}
        params.update(dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(req.full_url).query)))
        response = self.fetch(url=req.full_url, params=params, method=req.get_method(), headers=headers, body=payload)
        if response.get("status") is None:
            raise urllib.error.URLError(response.get("error", "HTTP request failed"))
        raw = response["text"].encode("utf-8")
        stream = RecordedResponse(raw, response["url"], response["status"], response["headers"])
        if response["status"] >= 400:
            raise urllib.error.HTTPError(response["url"], response["status"], response["text"], response["headers"], stream)
        return stream

    @staticmethod
    def require_success(response, json_only=True):
        if (response.get("status") is None or not 200 <= response["status"] < 300
                or response.get("truncated") or (json_only and "json" not in response)):
            raise ValueError("Request failed or incomplete: " + encoded(bounded(response, 5000)))

    def fetch_json(self, **request):
        response = self.fetch(**request)
        self.require_success(response)
        return response["json"]

    def probe_many(self, candidates):
        if not isinstance(candidates, list) or len(candidates) > 12:
            raise ValueError("probe_many accepts up to 12 candidates")
        results, seen = [], set()
        for candidate in candidates:
            key = digest(candidate)
            if key in seen:
                continue
            seen.add(key)
            if self.remaining_seconds() <= 0 or self.request_count >= 24:
                break
            result = self.fetch(**candidate)
            results.append(result)
            if result.get("status") is not None and 200 <= result["status"] < 300 and not result.get("truncated"):
                break
        return results

    def read_source(self, name, *, request=None, file=None, format="json"):
        """A complete file or ONE response, not a claim that a paged API is complete."""
        self.source_name(name)
        if format not in ("json", "csv", "text"):
            raise ValueError("format must be json/csv/text")
        if (request is None) == (file is None):
            raise ValueError("read_source needs exactly one of request or file")
        if file is not None:
            path = Path(file)
            if not path.is_absolute():
                path = self.path.parent / path
            with path.open("rb") as stream:
                raw = stream.read(1048577)
            if len(raw) > 1048576:
                raise ValueError("Source exceeds 1 MiB; process it explicitly and run a verifier")
            text = raw.decode("utf-8-sig")
            data = json.loads(text) if format == "json" else list(csv.DictReader(io.StringIO(text))) if format == "csv" else text
            evidence = {"kind": "file", "path": str(path.resolve()), "bytes_sha256": hashlib.sha256(raw).hexdigest()}
        else:
            response = self.fetch(**request)
            self.require_success(response, json_only=format == "json")
            data = (response["json"] if format == "json" else list(csv.DictReader(io.StringIO(response["text"])))
                    if format == "csv" else response["text"])
            evidence = {"kind": "http_single", "request": response["request"], "scope": "one_response"}
        self.state["sources"][name] = {"complete": True, "data": data, "evidence": evidence}
        self.used.add(name)
        self.save()
        self.emit("HUGH_SOURCE", {"name": name, **evidence, "data_sha256": digest(data)})
        return clone(data)

    @staticmethod
    def source_name(name):
        if not isinstance(name, str) or not 0 < len(name) <= 100:
            raise ValueError("Source name must be 1-100 characters")

    def collect(self, name="data", *, request=None, records_path=None, pagination=None, id_path=None):
        """Collect a dataset according to the CURRENT documented/observed contract."""
        self.source_name(name)
        first = None
        if pagination is None or records_path is None:
            first = self.fetch(**(request or {}))
            self.require_success(first)
            shape = response_shape(first["json"], records_path)
            if "rows" not in shape:
                raise ValueError("Specify records_path; array candidates: " + repr(shape.get("paths")))
            records_path = shape["records_path"]
            if pagination is None:
                if shape.get("ambiguous"):
                    raise ValueError("Ambiguous paging metadata; specify pagination using the actual response")
                mode = "offset" if "offset" in shape else "page" if "page" in shape else "single"
                if mode != "single":
                    position = shape[mode]
                    start = 0 if mode == "offset" else 1
                    if type(position) is not int:
                        raise ValueError("Paging position must be an integer")
                    pagination = {"mode": mode, "param": shape[mode + "_path"][-1], "start": start,
                                  "position_path": shape[mode + "_path"]}
                    if "total" in shape:
                        pagination.update(end="total", total_path=shape["total_path"])
                    elif "more" in shape:
                        pagination.update(end="has_more", has_more_path=shape["more_path"])
                    else:
                        raise ValueError("Specify a documented pagination termination rule")
                    if "size" in shape:
                        pagination["size_path"] = shape["size_path"]
                    if "more" in shape:
                        pagination["has_more_path"] = shape["more_path"]
                    if "next" in shape:
                        pagination["next_path"] = shape["next_path"]
                    if position != start:
                        first = None  # Collect from the beginning, not an old offset.
                elif "total" in shape and not whole_response(shape):
                    raise ValueError("Response is incomplete; specify the actual paging request parameter")
                elif shape.get("more") is True or shape.get("next") not in (None, ""):
                    raise ValueError("More pages exist; specify cursor/request mapping")
                else:
                    pagination = {"mode": "single", "end": "single"}
                    if "total" in shape:
                        pagination["total_path"] = shape["total_path"]
                if id_path is None and shape["rows"] and all(isinstance(r, dict) and "id" in r for r in shape["rows"]):
                    id_path = ["id"]
            else:
                first = None  # An explicit contract may request a different starting page.
        pagination = clone(pagination or {"mode": "single", "end": "single"})
        allowed = {"mode", "end", "param", "start", "step", "size_param", "size", "position_path",
                   "size_path", "total_path", "next_path", "has_more_path", "allow_repeated_pages"}
        if set(pagination) - allowed:
            raise ValueError("Unknown pagination option")
        mode, end = pagination.get("mode"), pagination.get("end")
        if mode not in ("single", "offset", "page", "cursor"):
            raise ValueError("mode must be single/offset/page/cursor")
        if end not in ("single", "total", "empty", "short", "next", "has_more"):
            raise ValueError("Declare end: single/total/empty/short/next/has_more")
        if (mode == "single") != (end == "single"):
            raise ValueError("single mode requires single end")
        if mode != "single" and not isinstance(pagination.get("param"), str):
            raise ValueError("Declare the actual paging request parameter")
        for ending, field in (("total", "total_path"), ("short", "size_path"),
                              ("next", "next_path"), ("has_more", "has_more_path")):
            if end == ending and field not in pagination:
                raise ValueError(ending + " termination requires " + field)
        if mode == "cursor" and "next_path" not in pagination:
            raise ValueError("cursor mode requires next_path")
        start = pagination.get("start", 1 if mode == "page" else 0 if mode == "offset" else None)
        if mode in ("offset", "page") and (type(start) is not int or start < 0):
            raise ValueError("offset/page start must be a nonnegative integer")
        step = pagination.get("step", 1)
        if type(step) is not int or step <= 0:
            raise ValueError("page step must be positive")
        config = self.request_config(request)
        for key in ("param", "size_param"):
            if key in pagination:
                config["params"].pop(pagination[key], None)
        plan = {"request": config, "records_path": records_path if records_path is not None else [],
                "pagination": pagination, "id_path": id_path}
        signature = digest(plan)
        source = self.state["sources"].get(name)
        if not source or source.get("signature") != signature:
            source = {"signature": signature, "plan": plan, "data": [], "complete": False,
                      "next": start, "total": None, "size": pagination.get("size"),
                      "ids": [], "tokens": [], "page_hashes": [], "pages": [],
                      "evidence": {"kind": "dataset"}}
            self.state["sources"][name] = source
        self.used.add(name)
        while not source["complete"]:
            if self.remaining_seconds() < 0.2 or self.request_count >= 24:
                self.save()
                raise ContinueNextTurn("Dataset checkpoint saved: " + name)
            token = source["next"]
            params = dict(config["params"])
            if mode != "single" and token is not None:
                params[pagination["param"]] = token
            if pagination.get("size_param") and source["size"] is not None:
                params[pagination["size_param"]] = source["size"]
            response, first = (first, None) if first is not None else (self.fetch(_resolved={**config, "params": params}), None)
            self.require_success(response)
            self.collected_http.add(digest(response["request"]))
            body = response["json"]
            rows = lookup(body, plan["records_path"])
            if not isinstance(rows, list):
                raise ValueError("records_path points to its enclosing object; array candidates: " + repr(list_paths(body)))
            if "position_path" in pagination and encoded(lookup(body, pagination["position_path"])) != encoded(token):
                raise ValueError("Server page position did not match the requested position")
            total = lookup(body, pagination["total_path"]) if "total_path" in pagination else None
            if "total_path" in pagination:
                if type(total) is not int or total < 0:
                    raise ValueError("Server total must be a nonnegative integer")
                if source["total"] is not None and total != source["total"]:
                    raise ValueError("Server total changed during collection")
            actual_size = lookup(body, pagination["size_path"]) if "size_path" in pagination else None
            if actual_size is not None and (type(actual_size) is not int or actual_size <= 0 or len(rows) > actual_size):
                raise ValueError("Invalid actual page size")
            new_ids = []
            if id_path is not None:
                for row in rows:
                    identity = lookup(row, id_path)
                    if identity is None:
                        raise ValueError("Unique identifier is missing")
                    key = encoded(identity)
                    if key in source["ids"] or key in new_ids:
                        raise ValueError("Repeated unique ID; dataset is not complete")
                    new_ids.append(key)
            page_hash = digest(rows)
            if (rows and page_hash in source["page_hashes"] and "position_path" not in pagination
                    and not pagination.get("allow_repeated_pages", False)):
                raise ValueError("Repeated page without a verified position; inspect the API contract")
            count = len(source["data"]) + len(rows)
            if total is not None and count > total:
                raise ValueError("Collected count exceeds the server total")
            next_token = lookup(body, pagination["next_path"]) if "next_path" in pagination else None
            more = lookup(body, pagination["has_more_path"]) if "has_more_path" in pagination else None
            if "has_more_path" in pagination and type(more) is not bool:
                raise ValueError("has_more_path must contain an actual boolean")
            ended = (end == "single" or (end == "total" and count == total)
                     or (end == "empty" and not rows) or (end == "short" and len(rows) < actual_size)
                     or (end == "next" and next_token in (None, "")) or (end == "has_more" and more is False))
            if ended and total is not None and count != total:
                raise ValueError("Termination before all records were collected")
            if ended and more is True:
                raise ValueError("Termination contradicts has_more")
            if ended and "next_path" in pagination and next_token not in (None, ""):
                raise ValueError("Termination contradicts next cursor")
            if not ended and not rows and mode in ("offset", "page"):
                raise ValueError("Empty page before declared termination")
            if not ended:
                advance = (token + len(rows) if mode == "offset" else token + step if mode == "page" else next_token)
                if advance in (None, "") or encoded(advance) == encoded(token) or encoded(advance) in source["tokens"]:
                    raise ValueError("Pagination cursor/position did not advance")
            else:
                advance = None
            # Commit a whole validated page atomically; no partial duplicate data.
            source["data"].extend(clone(rows))
            source["ids"].extend(new_ids)
            source["tokens"].append(encoded(token))
            source["page_hashes"].append(page_hash)
            source["pages"].append({"position": token, "count": len(rows), "total": total, "actual_size": actual_size})
            source.update(next=advance, total=total, complete=ended)
            if actual_size is not None:
                source["size"] = actual_size
            self.save()
            self.emit("HUGH_COLLECTION", {"name": name, "page": source["pages"][-1], "count": count,
                                         "complete": ended, "id_path": id_path})
        return clone(source["data"])

    def prepare_program(self, argv, cwd):
        """Repair launch mechanics only, inside this task's workspace."""
        info = {}
        if not isinstance(argv, (list, tuple)) or not argv:
            return info
        path = Path(argv[0])
        if not path.is_absolute():
            path = Path(cwd) / path
        path = path.resolve()
        info.update(program=str(path), exists=path.is_file())
        if not path.is_file():
            info["path_lookup"] = shutil.which(str(argv[0]))
            return info
        with path.open("rb") as stream:
            prefix = stream.read(512)
        info.update(mode=oct(path.stat().st_mode & 0o777))
        if prefix.startswith(b"#!") or b"\0" not in prefix:
            info["first_line"] = prefix.split(b"\n")[0].decode("utf-8", errors="replace")
        if prefix.startswith(b"#!") and path.is_relative_to(self.path.parent.resolve()):
            if prefix.split(b"\n")[0].endswith(b"\r") and path.stat().st_size <= 1048576:
                raw = path.read_bytes()
                if b"\0" not in raw:
                    path.write_bytes(raw.replace(b"\r\n", b"\n"))
                    info["repair"] = "Normalized CRLF script line endings; verifier logic unchanged"
            if os.name != "nt" and not os.access(path, os.X_OK):
                path.chmod(path.stat().st_mode | 0o100)
                info["permission_repair"] = "Added owner execute permission"
        return info

    def record_process(self, result):
        ident = "process-" + str(len(self.state["checks"]) + 1)
        result["id"] = ident
        self.state["checks"][ident] = result
        self.used_checks.add(ident)
        self.save()
        self.emit("HUGH_PROCESS", result)
        return clone(result)

    def tracked_process(self, argv, **kwargs):
        """Record ordinary subprocess.run calls without requiring model IDs."""
        cwd = str(Path(kwargs.get("cwd") or os.getcwd()).resolve())
        info = {} if kwargs.get("shell") else self.prepare_program(argv, cwd)
        result = {"argv": [str(v) for v in argv] if isinstance(argv, (tuple, list)) else str(argv),
                  "cwd": cwd, "launch": info}
        kwargs["timeout"] = min(float(kwargs.get("timeout") or 8), self.remaining_seconds())
        force_capture = kwargs.get("capture_output") or (kwargs.get("stdout") is None and kwargs.get("stderr") is None)
        capture = force_capture or (kwargs.get("stdout") == subprocess.PIPE and
                                    kwargs.get("stderr") in (subprocess.PIPE, subprocess.STDOUT))
        if force_capture:
            kwargs.pop("capture_output", None)
            kwargs.update(stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            proc = PROCESS_RUN(argv, **kwargs)
            result.update(exit_code=proc.returncode)
            out, err = proc.stdout, proc.stderr
        except (OSError, subprocess.SubprocessError) as error:
            out, err = getattr(error, "stdout", None), getattr(error, "stderr", None)
            result.update(exit_code=getattr(error, "returncode", None), error=type(error).__name__ + ": " + str(error))
            proc = None
            failure = error
        text = "\n".join(v.decode("utf-8", errors="replace") if isinstance(v, bytes) else str(v)
                         for v in (out, err) if v)
        result.update(output=text[:16000], truncated=len(text.encode("utf-8")) > 16000 or not capture)
        self.record_process(result)
        if proc is None:
            raise failure
        return proc

    def run(self, argv, *, cwd=None, timeout=8, input=None):
        """Capture the actual process result; checker names/formats are task-defined."""
        if not isinstance(argv, list) or not argv or not all(isinstance(v, str) for v in argv):
            raise ValueError("run requires an argv list; use ['sh','-lc',...] when shell syntax is necessary")
        budget = min(float(timeout), self.remaining_seconds())
        if budget <= 0:
            raise TimeoutError("Command budget exhausted")
        cwd = str(Path(cwd).resolve()) if cwd else str(self.path.parent)
        result = {"argv": argv, "cwd": cwd, "launch": self.prepare_program(argv, cwd)}
        with tempfile.TemporaryFile() as output:
            try:
                proc = PROCESS_RUN(argv, cwd=cwd, stdout=output, stderr=subprocess.STDOUT,
                                      input=input.encode("utf-8") if isinstance(input, str) else input,
                                      timeout=budget, env={**os.environ, "PYTHONUTF8": "1"})
                result["exit_code"] = proc.returncode
            except subprocess.TimeoutExpired:
                result.update(exit_code=None, error="Process timed out")
            except OSError as error:
                result.update(exit_code=None, error=type(error).__name__ + ": " + str(error))
            output.seek(0)
            raw = output.read(16001)
        result.update(output=raw[:16000].decode("utf-8", errors="replace"), truncated=len(raw) > 16000)
        return self.record_process(result)

    def automatic_http_sources(self):
        groups, latest = {}, {}
        for response in self.http_used:
            latest[response["request"]["url"]] = response
            if digest(response["request"]) in self.collected_http:
                continue
            if response.get("status") is None or not 200 <= response["status"] < 300 or response.get("truncated"):
                continue
            body = response.get("json", response.get("text"))
            shape = response_shape(body)
            req = clone(response["request"])
            for kind in ("offset", "page", "size"):
                if kind + "_path" in shape:
                    req["params"].pop(shape[kind + "_path"][-1], None)
            group = groups.setdefault(digest(req), {"request": req, "responses": []})
            group["responses"].append((body, shape))
        for response in latest.values():
            self.require_success(response, json_only=False)
        receipts = []
        for group in groups.values():
            req, values = group["request"], group["responses"]
            # Explicit collect contracts already validate even unusual field names.
            covered = False
            for name in self.used:
                source = self.state["sources"][name]
                if not source.get("complete"):
                    continue
                plan = source.get("plan", {})
                actual = clone(plan.get("request", source.get("evidence", {}).get("request", {})))
                comparable = clone(req)
                if plan:
                    for key in ("param", "size_param"):
                        actual.get("params", {}).pop(plan["pagination"].get(key), None)
                        comparable.get("params", {}).pop(plan["pagination"].get(key), None)
                    # Response page-size metadata may be a default query option.
                    for _, shape in values:
                        for kind in ("offset", "page", "size"):
                            if kind + "_path" in shape:
                                actual.get("params", {}).pop(shape[kind + "_path"][-1], None)
                if actual == comparable and (plan or not list_paths(values[-1][0])):
                    covered = True
                    break
            if covered:
                continue
            body, shape = values[-1]
            receipt = {"name": "http:" + digest(req)[:12], "request": req, "complete": True}
            if not list_paths(body) and not any(k in shape for k in ("total", "more", "next")):
                receipt.update(kind="http_single", scope="one_response", data_sha256=digest(body))
            else:
                if "rows" not in shape or shape.get("ambiguous") or type(shape.get("total")) is not int:
                    raise ValueError("HTTP list completeness is unknown; use collect() or specify records_path/pagination")
                mode = "offset" if "offset" in shape else "page" if "page" in shape else "single"
                pages = {}
                for _, page in values:
                    if page.get("total") != shape["total"] or page.get("ambiguous") or "rows" not in page:
                        raise ValueError("HTTP page totals or schema changed")
                    position = page.get(mode, 0)
                    if type(position) is not int:
                        raise ValueError("Invalid HTTP page position")
                    pages[position] = page
                rows, position = [], 1 if mode == "page" else 0
                for index, page in sorted(pages.items()):
                    if index != position:
                        raise ValueError("HTTP pages have a gap; use collect() to fetch from the beginning")
                    rows.extend(page["rows"])
                    position += 1 if mode == "page" else len(page["rows"])
                complete = {**pages[max(pages)], "rows": rows}
                complete.pop("page", None)
                complete.pop("offset", None)
                if not whole_response(complete):
                    raise ValueError("HTTP dataset is incomplete or contains repeated IDs; use collect()")
                receipt.update(kind="dataset", count=len(rows), total=shape["total"], pages=len(pages),
                               data_sha256=digest(rows), contract={"mode": mode, "end": "total"})
            receipts.append(receipt)
        return receipts

    def report(self, answer, *, sources=None, checks=None):
        # Internal source labels and process IDs are optional. Actual evidence
        # is collected by the runtime; spelling a label cannot create evidence.
        names = list(self.used)
        checks_used = [v for k, v in self.state["checks"].items() if k in self.used_checks]
        if checks_used and (checks_used[-1].get("exit_code") != 0 or checks_used[-1].get("truncated")):
            raise ValueError("Last process failed or its output was incomplete: " + encoded(checks_used[-1]))
        selected = [v["id"] for v in checks_used if v.get("exit_code") == 0 and not v.get("truncated")]
        if isinstance(checks, list):
            for ident in checks:
                known = self.state["checks"].get(str(ident))
                if known and (str(ident) not in self.used_checks or known.get("exit_code") != 0 or known.get("truncated")):
                    raise ValueError("Requested verifier is stale or failed: " + str(ident))
        if sources or checks:
            unknown = [str(v) for v in (sources or []) if str(v) not in names]
            unknown += [str(v) for v in (checks or []) if str(v) not in selected]
            if unknown:
                self.warnings.append("Ignored unregistered labels; using actual current execution evidence: " + repr(unknown))
        checks = selected
        receipts = self.automatic_http_sources()
        for name in self.used:
            if not self.state["sources"][name].get("complete"):
                raise ValueError("An accessed dataset is incomplete: " + name)
        for name in names:
            source = self.state["sources"].get(name)
            if name not in self.used or not source or not source.get("complete"):
                raise ValueError("Source was not completely read by this execution: " + str(name))
            receipt = {"name": name, **source["evidence"], "complete": True, "data_sha256": digest(source["data"])}
            if source["evidence"]["kind"] == "dataset":
                receipt.update(count=len(source["data"]), total=source["total"], pages=len(source["pages"]),
                               contract=source["plan"]["pagination"], id_path=source["plan"]["id_path"])
            receipts.append(receipt)
        executions = []
        for ident in checks:
            result = self.state["checks"].get(ident)
            if ident not in self.used_checks or not result or result.get("exit_code") != 0 or result.get("truncated"):
                raise ValueError("Verifier did not actually succeed in this execution: " + str(ident))
            executions.append(clone(result))
        if not receipts and not executions:
            raise ValueError("No actual source or successful verifier; read_source/collect/run before report(answer)")
        if answer is None or len(encoded(answer).encode("utf-8")) > 24000:
            raise ValueError("Answer is null or exceeds the submission budget")
        self.answer, self.reported = clone(answer), True
        self.report_inputs = (clone(answer), list(names), list(checks))
        self.proof = {"method": "runtime_evidence_v2", "answer_sha256": digest(answer),
                      "sources": receipts, "checks": executions}

    def execute(self, packet):
        self.used, self.used_checks, self.http_used = set(), set(), []
        self.collected_http = set()
        self.reported, self.warnings = False, []
        if packet.get("resume"):
            if not self.state.get("resumable"):
                return {"status": "error", "error": "Previous script did not opt into resume"}
            source = self.state["script"]
        else:
            value = packet.get("python_candidates", packet.get("python"))
            candidates = value if isinstance(value, list) else [value]
            if not 1 <= len(candidates) <= 3 or not all(isinstance(code, str) and code for code in candidates):
                return {"status": "error", "error": "Return one to three Python programs for the current task"}
            if len(candidates) == 1:
                source = candidates[0]
            else:
                # One platform command tries bounded, material-grounded alternatives.
                # A verified report stops the volley; failures remain visible.
                source = (
                    "_candidate_errors=[]\n"
                    "for _candidate_number,_candidate_source in enumerate(" + repr(candidates) + ",1):\n"
                    " try:\n"
                    "  exec(compile(_candidate_source,'<task candidate %d>'%_candidate_number,'exec'),globals())\n"
                    " except Exception as _candidate_error:\n"
                    "  _candidate_errors.append([_candidate_number,type(_candidate_error).__name__,str(_candidate_error)])\n"
                    "  continue\n"
                    " if reported(): break\n"
                    "if not reported(): raise RuntimeError('candidate failures: '+repr(_candidate_errors))\n"
                )
            self.state.update(script=source, resumable=packet.get("resumable") is True)
        self.save()
        scope = {"__name__": "__task__", "probe": self.fetch, "fetch_json": self.fetch_json,
                 "probe_many": self.probe_many, "collect": self.collect, "read_source": self.read_source,
                 "run": self.run, "report": self.report, "lookup": lookup,
                 "remaining_seconds": self.remaining_seconds, "WORKDIR": str(self.path.parent),
                 "CONFIG": self.state["config"], "LAST_HTTP": clone(self.state.get("last")),
                 "HTTP_HISTORY": self.state["http_history"], "DATA": clone(self.state.get("data")),
                 "PREVIOUS_REQUESTS": clone(self.state["config"].get("proven_requests", [])),
                 "reported": lambda: self.reported}
        tool_modules = {name: ToolModule(name, scope[name]) for name in
                        ("probe", "fetch_json", "probe_many", "collect", "read_source", "run", "report")}
        def compatible_import(name, globals=None, locals=None, fromlist=(), level=0):
            if not level and name in tool_modules:
                return tool_modules[name]
            return builtins.__import__(name, globals, locals, fromlist, level)
        scope["__builtins__"] = {**vars(builtins), "__import__": compatible_import}
        stream, errors = LimitedOutput(), LimitedOutput()
        previous_cwd = os.getcwd()
        previous_urlopen, previous_run = urllib.request.urlopen, subprocess.run
        try:
            os.chdir(self.path.parent)
            urllib.request.urlopen, subprocess.run = self.tracked_urlopen, self.tracked_process
            with redirect_stdout(stream), redirect_stderr(errors):
                exec(compile(source, "<task python>", "exec"), scope)
            if scope.get("ANSWER") is not None or scope.get("COMPLETE") is True:
                raise ValueError("ANSWER/COMPLETE are not evidence; use report with verified sources/checks")
            if self.reported:
                answer, names, checks = self.report_inputs
                self.report(answer, sources=names, checks=checks)
            result = ({"status": "answer", "answer": self.answer, "proof": self.proof} if self.reported
                      else {"status": "observation", "note": "No report; inspect actual results and continue"})
        except ContinueNextTurn as error:
            result = {"status": "progress" if self.state["resumable"] else "observation", "note": str(error),
                      "resume_requires": "An idempotent script with resumable=true"}
        except BaseException as error:
            result = {"status": "error", "error": type(error).__name__ + ": " + str(error),
                      "traceback": traceback.format_exc()[-2500:]}
        finally:
            urllib.request.urlopen, subprocess.run = previous_urlopen, previous_run
            os.chdir(previous_cwd)
        self.save()
        result.update(output=stream.getvalue(), stderr=errors.getvalue(), warnings=self.warnings[-6:],
                      processes=[bounded(v, 4500) for k, v in self.state["checks"].items() if k in self.used_checks][-4:],
                      observation=bounded(self.state.get("last")),
                      config=self.state["config"], http_history=[bounded(o, 3000) for o in self.state["http_history"]],
                      collections={name: {"complete": value["complete"], "count": len(value["data"]),
                                         "pages": value["pages"][-4:], "total": value["total"]}
                                   for name, value in self.state["sources"].items() if "pages" in value},
                      profile={"successful_requests": self.state["successful_requests"],
                               "dataset_plans": [v["plan"] for v in self.state["sources"].values()
                                                 if v.get("complete") and "plan" in v][-3:]})
        return result


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    packet = json.loads(sys.argv[1])
    runtime = Runtime(Path(__file__).with_name(".hugh_task_state.json"))
    result = runtime.execute(packet)
    result["id"] = packet["id"]
    # Never loop indefinitely trying to shrink a nested object.
    for field in ("output", "observation", "http_history", "profile", "processes", "traceback", "stderr"):
        if len(encoded(result).encode("utf-8")) > 55000 and field in result:
            result[field] = bounded(result[field], 1500)
    if len(encoded(result).encode("utf-8")) > 55000:
        result = {"id": packet["id"], "status": "error", "error": "Result too large; reduce output or answer"}
    print("HUGH_TASK:" + encoded(result))


if __name__ == "__main__":
    main()
