(function () {
  "use strict";

  const API_BASE = window.KM_API_BASE || "";
  const app = document.querySelector("#app");
  const kbDialog = document.querySelector("#kb-dialog");
  const kbForm = document.querySelector("#kb-form");
  const kbFormError = document.querySelector("#kb-form-error");

  let activeOfferingId = "";

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function text(value, fallback = "—") {
    return value === null || value === undefined || value === ""
      ? fallback
      : escapeHtml(value);
  }

  async function request(path, options = {}) {
    const response = await fetch(`${API_BASE}${path}`, {
      headers: { "Content-Type": "application/json", ...(options.headers || {}) },
      ...options,
    });

    let payload = null;
    try { payload = await response.json(); } catch (_) { /* 空响应 */ }

    if (!response.ok) {
      throw new Error(payload?.message || `请求失败（HTTP ${response.status}）`);
    }
    return payload?.data ?? payload;
  }

  function parseRoute() {
    const raw = location.hash.slice(1) || "/";
    const [pathname, query = ""] = raw.split("?");
    const params = new URLSearchParams(query);
    const match = pathname.match(
      /^\/products\/([^/]+)\/(industry|operations\/repositories|operations\/systems|domain\/specs|domain\/skills)$/
    );

    if (!match) return { page: "dashboard", pathname: "/", scenario: params.get("scenario") || "" };
    return {
      page: "product",
      pathname,
      offeringId: decodeURIComponent(match[1]),
      view: match[2],
      scenario: params.get("scenario") || "",
    };
  }

  function withScenario(pathname, scenario) {
    return `#${pathname}${scenario ? `?scenario=${encodeURIComponent(scenario)}` : ""}`;
  }

  function scenarioSelect(current) {
    return `
      <label>
        环节
        <select id="scenario-filter">
          <option value="" ${current === "" ? "selected" : ""}>全部</option>
          <option value="develop" ${current === "develop" ? "selected" : ""}>开发</option>
          <option value="test" ${current === "test" ? "selected" : ""}>测试</option>
          <option value="design" ${current === "design" ? "selected" : ""}>设计</option>
        </select>
      </label>`;
  }

  function bindScenario(route) {
    document.querySelector("#scenario-filter")?.addEventListener("change", (event) => {
      location.hash = withScenario(route.pathname, event.target.value);
    });
  }

  function status(message, className = "") {
    app.innerHTML = `<p class="status ${className}">${escapeHtml(message)}</p>`;
  }

  function summaryItem(label, value) {
    return `<div class="summary-item"><span>${escapeHtml(label)}</span><strong>${text(value, "0")}</strong></div>`;
  }

  async function renderDashboard(route) {
    status("正在加载知识资产总览……");
    const query = route.scenario ? `?scenario=${encodeURIComponent(route.scenario)}` : "";
    const data = await request(`/api/dashboard/summary${query}`);
    const overall = data.overall || {};
    const products = data.products || [];
    const scenarios = data.scenarios || [];

    app.innerHTML = `
      <section>
        <div class="toolbar">
          <div><h2>知识资产总览</h2><p>查看全局与产品维度的知识资产。</p></div>
          ${scenarioSelect(route.scenario)}
        </div>
        <div class="summary-grid">
          ${summaryItem("产品知识库", overall.knowledgeBaseCount)}
          ${summaryItem("产业知识", overall.knowledgeCount)}
          ${summaryItem("代码仓资产", overall.repositoryCount)}
          ${summaryItem("作业系统对接", overall.operatingSystemCount)}
          ${summaryItem("规范", overall.specCount)}
          ${summaryItem("Skills", overall.skillCount)}
        </div>
      </section>

      <section>
        <h2>各环节知识建设现状</h2>
        ${scenarios.length ? `
          <div class="table-wrap"><table>
            <thead><tr><th>环节</th><th>代码仓</th><th>规范</th><th>Skill</th></tr></thead>
            <tbody>${scenarios.map((item) => `
              <tr><td>${text(item.scenarioName || item.scenario)}</td><td>${text(item.repositoryCount, "0")}</td><td>${text(item.specCount, "0")}</td><td>${text(item.skillCount, "0")}</td></tr>`).join("")}</tbody>
          </table></div>` : `<p class="status">暂无环节建设数据。</p>`}
      </section>

      <section>
        <h2>产品知识资产建设情况</h2>
        ${products.length ? `
          <div class="table-wrap"><table>
            <thead><tr><th>PDU</th><th>解决方案/开发部</th><th>产品</th><th>产业知识</th><th>代码仓</th><th>规范</th><th>Skill</th></tr></thead>
            <tbody>${products.map((product) => `
              <tr>
                <td>${text(product.pdu)}</td>
                <td>${text(product.solution)}</td>
                <td><a href="#/products/${encodeURIComponent(product.offeringId)}/industry">${text(product.productName)}</a></td>
                <td>${text(product.knowledgeCount, "0")}</td>
                <td>${text(product.repositoryCount, "0")}</td>
                <td>${text(product.specCount, "0")}</td>
                <td>${text(product.skillCount, "0")}</td>
              </tr>`).join("")}</tbody>
          </table></div>` : `<p class="status">暂无产品数据。</p>`}
      </section>`;

    bindScenario(route);
  }

  function productNavigation(route) {
    const id = encodeURIComponent(route.offeringId);
    const link = (view, label) => {
      const href = withScenario(`/products/${id}/${view}`, route.scenario);
      return `<a href="${href}" ${route.view === view ? 'aria-current="page"' : ""}>${label}</a>`;
    };
    return `
      <nav class="category-nav" aria-label="产品知识分类">
        ${link("industry", "产业知识")}
        ${link("operations/repositories", "代码仓资产")}
        ${link("operations/systems", "作业系统对接")}
        ${link("domain/specs", "规范")}
        ${link("domain/skills", "Skill")}
      </nav>`;
  }

  function productSummary(data) {
    return `
      <div class="summary-grid">
        ${summaryItem("产品知识库", data.knowledgeBaseCount)}
        ${summaryItem("产业知识", data.knowledgeCount)}
        ${summaryItem("代码仓资产", data.repositoryCount)}
        ${summaryItem("作业系统对接", data.operatingSystemCount)}
        ${summaryItem("规范", data.specCount)}
        ${summaryItem("Skills", data.skillCount)}
      </div>`;
  }

  function table(headers, rows) {
    if (!rows.length) return `<p class="status">暂无数据。</p>`;
    return `<div class="table-wrap"><table><thead><tr>${headers.map((h) => `<th>${h}</th>`).join("")}</tr></thead><tbody>${rows.join("")}</tbody></table></div>`;
  }

  async function renderProductContent(route) {
    const id = encodeURIComponent(route.offeringId);
    const scenarioQuery = route.scenario ? `?scenario=${encodeURIComponent(route.scenario)}` : "";

    if (route.view === "industry") {
      const items = await request(`/api/products/${id}/knowledge-bases`);
      return `
        <div class="toolbar"><h2>产品知识集</h2><button id="add-kb">新增关联知识集</button></div>
        ${table(["名称", "URL", "知识数量"], (items || []).map((item) => `
          <tr><td>${text(item.kbName)}</td><td>${text(item.kbUrl)}</td><td>${text(item.knowledgeNum, "0")}</td></tr>`))}`;
    }

    if (route.view === "operations/repositories") {
      const items = await request(`/api/products/${id}/repositories${scenarioQuery}`);
      return `<h2>关联代码仓</h2>${table(["名称", "URL", "分支", "Spec 状态", "来源", "环节"], (items || []).map((item) => `
        <tr><td>${text(item.repoName)}</td><td>${text(item.repoUrl)}</td><td>${text(item.branch)}</td><td>${text(item.specStatus)}</td><td>${text(item.sourceType)}</td><td>${text(item.scenario)}</td></tr>`))}`;
    }

    if (route.view === "operations/systems") {
      const items = await request(`/api/products/${id}/operating-systems${scenarioQuery}`);
      return `<h2>作业系统对接</h2>${table(["作业平台", "环节", "是否关联"], (items || []).map((item) => `
        <tr><td>${text(item.operatingSystem)}</td><td>${text(item.scenario)}</td><td>${item.inUse ? "是" : "否"}</td></tr>`))}`;
    }

    if (route.view === "domain/specs") {
      const items = await request(`/api/products/${id}/specs${scenarioQuery}`);
      return `<h2>产品规范</h2>${table(["规范 ID", "环节"], (items || []).map((item) => `
        <tr><td>${text(item.id)}</td><td>${text(item.scenario)}</td></tr>`))}<p>当前数据表不包含规范正文，前端不展示静态示例正文。</p>`;
    }

    const items = await request(`/api/products/${id}/skills${scenarioQuery}`);
    return `<h2>Skill 规划清单</h2>${table(
      ["经验名称", "说明", "一级场景", "二级场景", "活动", "子活动", "部门", "Owner", "状态", "环节"],
      (items || []).map((item) => `<tr><td>${text(item.name)}</td><td>${text(item.description)}</td><td>${text(item.level1)}</td><td>${text(item.level2)}</td><td>${text(item.process)}</td><td>${text(item.subProcess)}</td><td>${text(item.department)}</td><td>${text(item.owner)}</td><td>${text(item.status)}</td><td>${text(item.scenario)}</td></tr>`)
    )}`;
  }

  async function renderProduct(route) {
    status("正在加载产品知识资产……");
    activeOfferingId = route.offeringId;
    const query = route.scenario ? `?scenario=${encodeURIComponent(route.scenario)}` : "";
    const [summary, content] = await Promise.all([
      request(`/api/products/${encodeURIComponent(route.offeringId)}/assets${query}`),
      renderProductContent(route),
    ]);

    app.innerHTML = `
      <p><a href="#/">← 返回知识资产总览</a></p>
      <section>
        <div class="toolbar">
          <div><h2>${text(summary.productName)}知识资产驾驶舱</h2><p>${text(summary.pdu)} / ${text(summary.solution)} / ${text(summary.productName)}</p></div>
          ${route.view === "industry" ? "" : scenarioSelect(route.scenario)}
        </div>
        ${productSummary(summary)}
      </section>
      ${productNavigation(route)}
      <section id="product-content">${content}</section>`;

    bindScenario(route);
    document.querySelector("#add-kb")?.addEventListener("click", () => {
      kbForm.reset();
      kbFormError.textContent = "";
      kbDialog.showModal();
    });
  }

  async function renderRoute() {
    const route = parseRoute();
    try {
      if (route.page === "dashboard") await renderDashboard(route);
      else await renderProduct(route);
    } catch (error) {
      status(error.message || "页面加载失败。", "error");
    }
  }

  kbForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    kbFormError.textContent = "";
    const form = new FormData(kbForm);
    try {
      await request(`/api/products/${encodeURIComponent(activeOfferingId)}/knowledge-bases`, {
        method: "POST",
        body: JSON.stringify({ kbId: form.get("kbId"), kbUrl: form.get("kbUrl") }),
      });
      kbDialog.close();
      await renderRoute();
    } catch (error) {
      kbFormError.textContent = error.message || "关联失败。";
    }
  });

  document.querySelector("#kb-cancel").addEventListener("click", () => kbDialog.close());
  window.addEventListener("hashchange", renderRoute);
  renderRoute();
})();

