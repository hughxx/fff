#!/usr/bin/env python3
"""Competition entry point; works without installation or a specific cwd."""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path


def parse_port(value: str) -> int:
    try:
        port = int(value)
    except ValueError as error:
        raise ValueError("port must be an integer") from error
    if not 1 <= port <= 65535:
        raise ValueError("port must be between 1 and 65535")
    return port


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="CoreGeek competition agent")
    parser.add_argument("port", type=parse_port)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
    from agent.telemetry import configure_logging, exception_location, log_event

    runtime_logging = configure_logging()
    try:
        from agent.application import AgentApplication
        from agent.server import serve
        from agent.strategy import StrategyEngine
        serve(args.port, AgentApplication(StrategyEngine()))
    except Exception as error:
        log_event(logging.getLogger("agent.server"), "fatal", level=logging.ERROR, error=exception_location(error))
        raise SystemExit(1) from None
    finally:
        runtime_logging.close()


if __name__ == "__main__":
    main()
