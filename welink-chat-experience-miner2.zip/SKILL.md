---
name: welink-chat-experience-miner
description: 使用 WeLink CLI 获取群聊或私聊历史消息，将原始聊天按来源和日期归档到 raw_data，并基于用户 Prompt 跨日期提取、合并和更新本地经验文件。在用户明确同意并提供 CloudDrive 账号密码后支持解析聊天图片和附件。
---

# WeLink 聊天记录经验提取 Skill

## 第一篇：WeLink CLI 使用

### 一次性安装与登录

执行前检查：

```powershell
welink-cli --version
```

如果无返回，先准备：

1. 安装 Node.js（包含 npm/npx）。
2. WeLink PC 升级到 7.34.12 及以上，并保持运行。
3. 管理员 PowerShell 执行：

```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

按提示确认 `Y`。网络问题时，将以下域名加入 `NO_PROXY`：

- `open.inner.welink.huawei.com`
- `cmc.centralrepo.rnd.huawei.com`

安装或更新：

```powershell
npm install -g @welink/welink-cli --registry=https://cmc.centralrepo.rnd.huawei.com/artifactory/api/npm/product_npm/ --strict-ssl=false
```

权限问题使用管理员 PowerShell 安装；登录和查询使用普通用户 PowerShell。

### 登录

```powershell
welink-cli auth login
welink-cli auth status
```

登录扫码期间不得中断 `welink-cli` 进程和运行它的 shell。`auth status` 未成功时停止后续流程，不生成空的经验文件。

### IM 历史消息

最近会话：

```powershell
welink-cli im query-recent-conversation --count 20
```

群聊：

```powershell
welink-cli im query-history-message --group-id "1234567891011" --query-count 100
```

私聊：

```powershell
welink-cli im query-history-message --user-account "a0012345" --query-count 100
```

翻页规则：第一页不传 `--message-id`；后续使用上一页返回的 `minMsgId`，向更旧方向传 `--query-direction 0`，按 `msgId` 去重，直到没有数据或到达时间下界。`--query-direction 1` 表示向更新方向查询。

查询结果中的 `serverSendTime` 是毫秒时间戳，归档时统一转换为 `YYYY-MM-DD HH:MM:SS`。

其他 IM、会议和搜索命令见 `references/welink-cli.md`，但本 Skill 的经验提取只需要 IM 历史消息命令。

## 第二篇：经验提取

### 1. 原始聊天记录归档

工作目录固定采用以下结构：

```text
raw_data/
  <工号或群组ID>/
    2026-08-25.md
    2026-08-26.md
experience/
  <经验文件>.md
```

`raw_data` 是原始记录层：

- 工号或群组 ID 作为来源目录名；
- 按消息本地日期写入 Markdown；
- 每条消息保留 `msgId`、发送人、接收方、时间、`contentType` 和原始文本；
- 重复抓取必须按 `msgId` 去重；
- 不得覆盖已有日期文件中的历史消息；
- 图片、文件、卡片默认不下载；只有用户明确同意并提供 CloudDrive 账号密码时，才按 `/:um_begin{...}/:um_end` 标记下载到本地 `attachments/`，并改写为相对 Markdown 链接。下载失败保留原始标记并继续文本提取。

使用 `scripts/query_history.py` 可以自动翻页、过滤时间范围、按天归档：

```powershell
python scripts/query_history.py `
  --group-id 1234567891011 `
  --start "2026-08-01 00:00:00" `
  --end "2026-08-31 23:59:59" `
  --raw-root raw_data
```

私聊将 `--group-id` 换成 `--user-account`。只有确实需要单个 Markdown 时才使用 `--output`，否则默认按天归档。需要处理图片或附件时增加 `--download-attachments`；脚本会先征求同意，再交互式读取账号和密码。用户拒绝或不提供完整凭据时，不中断文本归档。

### 2. 跨日期读取与经验生成

提取前必须读取目标来源目录下相关时间范围的全部日期文件，按日期和消息时间合并成连续会话。日期文件只是存储边界，不是分析边界。

必须特别处理跨天问题：

- 前一天提出的问题，后一天给出的结论，要合并成一条经验；
- 先读取前后相邻日期，再判断是否属于同一事件；
- 超长记录按完整消息边界分块，禁止拆开单条消息；
- 每个后续分块要携带上一块的未完问题、临时结论和待验证项；
- 分块完成后统一去重、合并，禁止把每天机械地各总结一条。

### 3. Prompt 与本地经验文件

Prompt 是必需输入。优先使用用户提供的 Prompt；没有提供时使用以下默认 Prompt：

```text
从 WeLink 聊天记录中提取可复用的工程经验。忽略寒暄、闲聊和没有事实依据的内容，识别背景、问题、现象、分析过程、根因、解决方案、验证结果和注意事项。只依据聊天原文，不得编造。跨日期但属于同一问题的消息必须合并。输出一条结构化 Markdown 经验。
```

用户 Prompt 可以指定领域、过滤条件、经验粒度和输出格式，但不得要求模型脱离原文推测事实。

经验只保存到本地 `experience/`，不上传任何远端服务。每条经验一个 Markdown 文件，文件名使用稳定标题 slug；标题变化或内容更新时，优先根据已有经验的稳定 ID 更新原文件，而不是重复创建。

建议经验文件包含以下结构：

```markdown
---
id: stable-experience-id
title: 简洁经验标题
source: welink
source_files:
  - raw_data/1234567891011/2026-08-25.md
  - raw_data/1234567891011/2026-08-26.md
updated_at: 2026-08-28 10:30:00
---

# 简洁经验标题

## 背景

## 问题

## 分析与根因

## 解决方案

## 验证结果

## 注意事项
```

### 4. 合并、更新与跳过规则

处理新记录前先扫描 `experience/` 中已有文件：

- 新主题且与已有经验无实质关联：创建新文件；
- 同一问题、同一解决方案或同一长期主题：更新已有文件；
- 更新时保留仍有效的旧事实，补充新日期的证据、变化和验证结果；
- 不要把当天摘要直接追加成重复经验；
- 只有寒暄、重复内容或无法复用的聊天，不创建或更新经验；
- 生成经验后同步更新 `source_files` 和 `updated_at`；
- 最终只输出本地文件路径和处理摘要，不调用经验中心或其他云端写入接口。

本 Skill 的边界是：WeLink CLI 获取聊天记录 →（用户同意时）按 `/:um_begin` 下载附件 → `raw_data` 按天归档 → 跨天阅读 → 按 Prompt 生成经验 → 本地 `experience` 文件合并或更新。
