#!/usr/bin/env python3
"""Export WeLink history to Markdown without downloading or processing images."""
import argparse
import json
import subprocess
import sys
import re
import getpass
import hashlib
import html
import requests
from datetime import datetime
from pathlib import Path


def run_cli(args, timeout):
    try:
        result = subprocess.run(["welink-cli", *args], capture_output=True,
                                text=True, encoding="utf-8", errors="replace",
                                timeout=timeout)
    except FileNotFoundError as exc:
        raise RuntimeError("未找到 welink-cli，请先安装并登录 WeLink CLI") from exc
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError("welink-cli 查询超时") from exc
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or f"welink-cli 退出码 {result.returncode}")
    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"welink-cli 返回内容不是合法 JSON：{exc}") from exc
    if str(data.get("resultCode", "0")) != "0":
        raise RuntimeError(data.get("resultContext") or "WeLink 查询失败")
    return data.get("respData") or {}


def parse_time(value):
    if not value:
        return 0
    return int(datetime.strptime(value, "%Y-%m-%d %H:%M:%S").timestamp() * 1000)


def fetch(selector, source_id, start_ms, end_ms, count, timeout):
    cursor = ""
    seen = set()
    messages = {}
    while True:
        args = ["im", "query-history-message", selector, source_id,
                "--query-count", str(count)]
        if cursor:
            # WeLink CLI: direction=0 means messages earlier than message-id.
            args += ["--message-id", cursor, "--query-direction", "0"]
        body = run_cli(args, timeout)
        rows = body.get("chatInfo") or []
        if not rows:
            break
        times = []
        for row in rows:
            msg_id = str(row.get("msgId") or "")
            timestamp = int(row.get("serverSendTime") or 0)
            if timestamp:
                times.append(timestamp)
            if not msg_id or (start_ms and timestamp < start_ms) or (end_ms and timestamp > end_ms):
                continue
            messages[msg_id] = row
        if start_ms and times and min(times) < start_ms:
            break
        next_cursor = str(body.get("minMsgId") or "")
        if not next_cursor:
            next_cursor = min((str(x.get("msgId")) for x in rows if x.get("msgId") is not None),
                              default="", key=lambda x: int(x))
        if not next_cursor or next_cursor in seen or len(rows) < count:
            break
        seen.add(next_cursor)
        cursor = next_cursor
    return sorted(messages.values(), key=lambda x: (int(x.get("serverSendTime") or 0), str(x.get("msgId") or "")))


def render(rows, source_label):
    lines = [f"# WeLink 聊天记录：{source_label}", ""]
    for row in rows:
        timestamp = int(row.get("serverSendTime") or 0)
        when = datetime.fromtimestamp(timestamp / 1000).strftime("%Y-%m-%d %H:%M:%S") if timestamp else ""
        sender = str(row.get("sender") or "")
        receiver = str(row.get("receiver") or "")
        msg_id = str(row.get("msgId") or "")
        content = str(row.get("content") or "")
        lines += [f"### {sender}（{when}）", f"消息 ID：{msg_id}", f"接收方：{receiver}", "", content, ""]
    return "\n".join(lines).rstrip() + "\n"


_ATTACHMENT_RE = re.compile(r"(?:/?:um_begin|/um:begin)\{(.*?)\}(?:/?:um_end|/um:end)", re.S)


def download_attachment(download_url, extraction_code, account, password, timeout=300):
    token = requests.post(
        "https://clouddrive.huawei.com/api/v2/token",
        json={"appId": "espace", "domain": "huawei", "loginName": account, "password": password},
        headers={"Content-Type": "application/json", "x-device-sn": "welink-chat-experience-miner",
                 "x-device-type": "web", "x-device-os": "win10", "x-device-name": "welink", "x-client-version": "10"},
        verify=False, timeout=60)
    token.raise_for_status()
    authorization = f"/:um_begin{{{download_url}|File|123|attachment|0|;;{extraction_code}|isOriginalImg:0}}/:um_end"
    response = requests.post(
        "https://clouddrive.huawei.com/imchat/api/v3/links/imdownload",
        headers={"Authorization": token.json().get("token", ""), "Content-Type": "application/json"},
        json={"imAuthorization": authorization}, verify=False, timeout=timeout)
    response.raise_for_status()
    return response.content


def enrich_attachments(rows, attachment_dir, account, password):
    """Download /:um_begin links and replace them with relative local Markdown links."""
    attachment_dir = Path(attachment_dir)
    attachment_dir.mkdir(parents=True, exist_ok=True)
    for row in rows:
        content = str(row.get("content") or "")
        def replace(match):
            parts = match.group(1).split("|")
            if len(parts) < 6 or not account or not password:
                return match.group(0)
            filename = Path(parts[3] or "attachment.bin").name
            suffix = Path(filename).suffix.lower()
            digest = hashlib.sha256(match.group(0).encode("utf-8")).hexdigest()[:12]
            target_name = f"{digest}_{filename}"
            target = attachment_dir / target_name
            try:
                if not target.exists():
                    codes = parts[5].split(";")
                    target.write_bytes(download_attachment(parts[0], codes[2] if len(codes) > 2 else "", account, password))
                label = html.escape(filename, quote=False)
                return f"![{label}](attachments/{target_name})" if suffix in {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp"} else f"[{label}](attachments/{target_name})"
            except Exception as exc:
                print(json.dumps({"warning": "附件下载失败", "filename": filename, "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
                return match.group(0)
        row["content"] = _ATTACHMENT_RE.sub(replace, content)
    return rows


def archive_daily(rows, source_id, raw_root):
    """Write rows into raw_data/<source>/<YYYY-MM-DD>.md, deduplicating msgId."""
    destination_root = Path(raw_root) / source_id
    destination_root.mkdir(parents=True, exist_ok=True)
    grouped = {}
    for row in rows:
        stamp = int(row.get("serverSendTime") or 0)
        day = datetime.fromtimestamp(stamp / 1000).strftime("%Y-%m-%d") if stamp else "unknown-date"
        grouped.setdefault(day, []).append(row)
    written = []
    for day, day_rows in grouped.items():
        target = destination_root / f"{day}.md"
        old = target.read_text(encoding="utf-8") if target.exists() else ""
        existing = set(re.findall(r"消息 ID：([^\s]+)", old))
        fresh = [row for row in day_rows if str(row.get("msgId") or "") not in existing]
        if fresh:
            body = render(fresh, source_id)
            if old.strip():
                target.write_text(old.rstrip() + "\n\n" + body, encoding="utf-8")
            else:
                target.write_text(body, encoding="utf-8")
        elif not target.exists():
            target.write_text(render(day_rows, source_id), encoding="utf-8")
        written.append(str(target))
    return written


def main():
    parser = argparse.ArgumentParser(description="导出 WeLink 历史聊天记录 Markdown")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--group-id")
    group.add_argument("--user-account")
    parser.add_argument("--start", help="起始时间：YYYY-MM-DD HH:MM:SS")
    parser.add_argument("--end", help="结束时间：YYYY-MM-DD HH:MM:SS")
    output = parser.add_mutually_exclusive_group()
    output.add_argument("--output", help="Markdown 输出路径（单文件模式）")
    output.add_argument("--raw-root", default="raw_data", help="按天归档根目录，默认 raw_data")
    parser.add_argument("--query-count", type=int, default=100)
    parser.add_argument("--timeout", type=int, default=60)
    parser.add_argument("--download-attachments", action="store_true", help="经用户确认后下载聊天中的图片/附件")
    parser.add_argument("--cloud-account", help="CloudDrive 账号；不传则交互式询问")
    args = parser.parse_args()
    start_ms, end_ms = parse_time(args.start), parse_time(args.end)
    if start_ms and end_ms and start_ms > end_ms:
        parser.error("--start 不能晚于 --end")
    selector, source_id = (("--group-id", args.group_id) if args.group_id else ("--user-account", args.user_account))
    rows = fetch(selector, source_id, start_ms, end_ms, max(1, min(100, args.query_count)), args.timeout)
    account = password = None
    if args.download_attachments:
        print("聊天中包含需要登录 CloudDrive 才能下载的图片或附件。是否同意下载？[y/N]", file=sys.stderr)
        if input().strip().lower() == "y":
            account = args.cloud_account or input("CloudDrive 账号：").strip()
            password = getpass.getpass("CloudDrive 密码（仅本次运行使用，不写入文件）：")
            if not account or not password:
                print("未提供完整账号密码，无法解析图片/附件；将保留原始下载标记。", file=sys.stderr)
            else:
                base = Path(args.output).parent if args.output else Path(args.raw_root) / source_id
                enrich_attachments(rows, base / "attachments", account, password)
        else:
            print("用户未同意下载图片/附件，将保留原始下载标记并继续文本提取。", file=sys.stderr)
    if args.output:
        target = Path(args.output)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(render(rows, source_id), encoding="utf-8")
        output_paths = [str(target)]
    else:
        output_paths = archive_daily(rows, source_id, args.raw_root)
    print(json.dumps({"ok": True, "count": len(rows), "outputs": output_paths}, ensure_ascii=False))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(1)
