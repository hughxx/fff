# WeLink CLI 命令参考

## IM

| 命令 | 说明 | 参数 |
|---|---|---|
| `im send-to-user` | 给用户发送文本、图片或文件 | `--receiver`、`--text`，可选 `--image`、`--file` |
| `im send-to-group` | 给群发送文本、图片或文件 | `--group-id`、`--text`，可选 `--image`、`--file` |
| `im query-recent-conversation` | 查询最近会话 | 可选 `--count` |
| `im query-group-member` | 查询群成员 | `--group-id` |
| `im query-history-message` | 查询历史消息 | 群聊用 `--group-id`，私聊用 `--user-account`；`--query-count`；翻页用 `--message-id`、`--query-direction` |
| `im create-group` | 创建群 | `--name`、`--user-account`、`--notice`、`--type` |
| `im add-group-member` | 加群成员 | `--group-id`、`--user-account` |

历史消息翻页约定：首次不传 `--message-id`；继续向更旧方向查询时传上一页返回的 `minMsgId`，`--query-direction 0`。向更新方向查询使用 `1`。返回记录按 `msgId` 去重。

## 会议

可用命令：`meeting info`、`meeting topic`、`meeting topic-materials`、`meeting fuzzy-search`、`meeting create`、`meeting update`、`meeting cancel`、`meeting query-list`、`meeting topic-create`、`meeting topic-update`、`meeting topic-delete`。

常用必填参数：详情/议题使用 `--meeting-id`；议题材料再加 `--topic-id`；创建会议使用 `--subject`、`--start-time`、`--end-time`、`--meeting-user-list`；取消会议使用 `--meeting-id`。具体参数可执行 `welink-cli meeting <command> --help` 查看。

## 搜索

```powershell
welink-cli search person --text "张三" --page-size 20
welink-cli search group --text "项目组" --page-size 20 --type 2
```

`search person` 搜索联系人；`search group` 搜索群组，`--type` 为 0 群组、1 讨论群、2 全部。
