"""Standalone program sent to the task sandbox; never run on the agent host.

Only the observed declarative spec grammar has an automatic repair path.
Unrecognized requirements return full context for the platform LLM.
"""
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time


MARKER = "HUGH_TASK:"


def read_text(path, limit=8000):
    with path.open(encoding="utf-8-sig", errors="replace") as stream:
        value = stream.read(limit + 1)
    return value[:limit] + ("\n[FILE_TRUNCATED]" if len(value) > limit else "")


def find_tasks(description):
    # Chinese instructions often have no space before the ASCII file name.
    names = re.findall(r"[A-Za-z0-9_./\\:~-]+\.(?:md|txt|json)", description)
    direct = [Path(n).resolve() for n in names if Path(n).is_file()]
    if direct:
        return sorted(set(direct))
    wanted = {Path(n).name for n in names}
    started, visited = time.monotonic(), set()
    for root in ("/tmp/selfEvolutionTask", os.getcwd(), "/tmp", "/workspace", "/sandbox", "/app", "/home", "/opt"):
        if not os.path.isdir(root):
            continue
        found = []
        for base, dirs, files in os.walk(root):
            dirs[:] = [d for d in dirs if d not in (".git", "node_modules", "__pycache__", "site-packages", ".cache")]
            if len(Path(base).parts) - len(Path(root).parts) >= 7:
                dirs[:] = []
            if base in visited:
                dirs[:] = []
                continue
            visited.add(base)
            for name in files:
                if name in wanted or (not wanted and name.startswith("task_") and name.endswith(".md")):
                    found.append((Path(base) / name).resolve())
            if time.monotonic() - started > 2 or len(visited) > 6000:
                return sorted(set(found))
        if found:
            return sorted(set(found))
    return []


def inside(root, name):
    path = (root / name).resolve()
    if path == root or not path.is_relative_to(root):
        raise ValueError("Spec path escapes workspace: " + name)
    # The checker and specification are inputs, never repair targets.
    if path.name in ("check", "spec.md"):
        raise ValueError("Reserved spec target: " + name)
    return path


def repair_plan(workspace, spec):
    """Parse *all* requirements before changing any files; fail closed to LLM."""
    plan, section, config = [], "", None
    for raw in spec.splitlines():
        line = raw.strip()
        if not line or line.startswith("# "):
            continue
        if line.startswith("## "):
            title = line[3:].strip()
            if title in ("目录要求", "脚本要求"):
                section, config = title, None
            elif title.startswith("配置文件 "):
                section = "配置文件"
                config = inside(workspace, title[len("配置文件 "):].strip(" `"))
            else:
                raise ValueError("Unknown spec heading: " + title)
            continue
        if not line.startswith("- "):
            raise ValueError("Unknown spec requirement: " + line)
        line = line[2:].strip()
        if section == "目录要求":
            match = re.fullmatch(r"`?([^`\s]+)`?\s+必须存在[，,]\s*权限(?:为)?\s*`?([0-7]{3})`?[。.]?", line)
            if match:
                plan.append(("directory", inside(workspace, match[1]), int(match[2], 8)))
                continue
        elif section == "配置文件":
            match = re.fullmatch(r"第\s*(\d+)\s*行[：:]\s*`([^`\r\n]*)`[。.]?", line)
            if match and 1 <= int(match[1]) <= 10000:
                plan.append(("line", config, int(match[1]), match[2]))
                continue
        elif section == "脚本要求":
            match = re.fullmatch(r"`?([^`\s]+)`?\s+必须存在且可执行[（(]权限\s*`?([0-7]{3})`?[）)][。.]?", line)
            if match:
                plan.append(("script", inside(workspace, match[1]), int(match[2], 8)))
                continue
        raise ValueError("Unknown spec requirement: " + line)
    if not plan:
        raise ValueError("No supported requirements found")
    for op in plan:
        path = op[1]
        if path.exists() and ((op[0] == "directory") != path.is_dir()):
            raise ValueError("Conflicting file type: " + str(path))
        if op[0] == "line" and path.exists() and path.stat().st_size > 128000:
            raise ValueError("Config too large for automatic repair")
    return plan


def apply_plan(plan):
    configs = {}
    for op in plan:
        kind, path = op[:2]
        if kind == "directory":
            path.mkdir(parents=True, exist_ok=True)
            path.chmod(op[2])
        elif kind == "script":
            path.parent.mkdir(parents=True, exist_ok=True)
            if not path.exists():
                path.write_bytes(b"#!/bin/sh\n")
            path.chmod(op[2])
        else:
            if path not in configs:
                configs[path] = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
            lines = configs[path]
            while len(lines) < op[2]:
                lines.append("")
            lines[op[2] - 1] = op[3]
    for path, lines in configs.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        # Preserve physical line numbers when padding an initially short file.
        path.write_bytes(("\n".join(lines) + "\n").encode("utf-8"))


def run_checker(workspace):
    checker = workspace / "check"
    if checker.is_symlink() or not checker.is_file() or checker.stat().st_size > 128000:
        raise ValueError("Missing or unsupported workspace checker")
    data = checker.read_bytes()
    # Fix only launch formatting; preserve the actual verification logic.
    if data.startswith(b"#!") and b"\r\n" in data:
        checker.write_bytes(data.replace(b"\r\n", b"\n"))
    checker.chmod((checker.stat().st_mode & 0o777) | 0o111)
    with tempfile.TemporaryFile() as output:
        result = subprocess.run([str(checker)], cwd=workspace, stdout=output,
                                stderr=subprocess.STDOUT, timeout=8, check=False)
        output.seek(0)
        raw = output.read(12001)
    text = raw[:12000].decode("utf-8", errors="replace")
    truncated = len(raw) > 12000
    tokens = re.findall(r"(?m)^\s*TOKEN:\s*(\S+)\s*$", text)
    token = tokens[-1] if result.returncode == 0 and not truncated and tokens else None
    return result.returncode, text, token


def bootstrap(description):
    context = {"cwd": os.getcwd(), "kind": "unknown"}
    files = find_tasks(description)
    if len(files) != 1:
        context["discovery_error"] = "Expected one task file; found " + str([str(p) for p in files[:8]])
        return {"status": "context", "context": context}
    task = files[0]
    body = read_text(task)
    context.update(task_file=str(task), task_text=body,
                   siblings=sorted(p.name for p in task.parent.iterdir())[:50])
    docs = task.parent / "API_DOCS.md"
    if "API_DOCS.md" in body or "文化遗产" in body:
        context.update(kind="heritage" if "文化遗产" in body else "api",
                       api_docs_file=str(docs), api_docs=read_text(docs, 10000) if docs.is_file() else "API_DOCS.md not found")
        city = re.search(r'"city"\s*:\s*"([^"<>]+)"', body)
        if city:
            context["city"] = city[1]
        return {"status": "context", "context": context}
    if "spec.md" in body and "check" in body:
        context["kind"] = "engineering"
        candidates = set(re.findall(r"\bws_[A-Za-z0-9_-]+\b", body))
        candidates.update(re.findall(r"`([^`\s]+/)`", body))
        workspaces = {(task.parent / name).resolve() for name in candidates}
        workspaces = [p for p in workspaces if p.is_relative_to(task.parent) and (p / "spec.md").is_file()]
        if len(workspaces) != 1:
            context["repair_error"] = "Cannot identify a unique referenced workspace"
            return {"status": "context", "context": context}
        workspace = workspaces[0]
        spec = read_text(workspace / "spec.md")
        context.update(workspace=str(workspace), spec=spec)
        try:
            plan = repair_plan(workspace, spec)
            apply_plan(plan)
            code, output, token = run_checker(workspace)
            context.update(checker_exit=code, checker_output=output)
            if token:
                return {"status": "answer", "context": context, "answer": {"token": token}}
        except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
            context["repair_error"] = str(exc)
        # Include existing configuration once, so the LLM can fix + check at once.
        config_names = re.findall(r"(?m)^## 配置文件\s+`?([^`\s]+)`?", spec)
        context["config_files"] = {}
        for name in config_names[:4]:
            try:
                path = inside(workspace, name)
                if path.is_file():
                    context["config_files"][name] = read_text(path, 1500)
            except (OSError, ValueError):
                pass
    return {"status": "context", "context": context}


def main():
    request = json.loads(sys.argv[1])
    try:
        result = bootstrap(request["description"])
    except Exception as exc:
        result = {"status": "context", "context": {"bootstrap_error": str(exc)}}
    result["id"] = request["id"]
    payload = json.dumps(result, ensure_ascii=False, separators=(",", ":"))
    while len(payload.encode("utf-8")) > 56000:
        context = result.get("context", {})
        candidates = [(len(v), k) for k, v in context.items() if isinstance(v, str) and len(v) > 1000]
        if not candidates:
            context.pop("siblings", None)
            context.pop("config_files", None)
        else:
            _, key = max(candidates)
            context[key] = context[key][:len(context[key]) // 2] + "\n[CONTEXT_TRUNCATED]"
        payload = json.dumps(result, ensure_ascii=False, separators=(",", ":"))
    print(MARKER + payload)


if __name__ == "__main__":
    main()
