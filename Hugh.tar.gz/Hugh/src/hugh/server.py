"""Standard-library HTTP server with serialized, idempotent per-team state."""
from collections import OrderedDict
import argparse
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import logging
import threading
from time import perf_counter
from .engine import Engine

LOGGER = logging.getLogger("hugh")
EMPTY = {"roleCommandMap": {}, "prompt": "", "executeCmd": ""}


class Session:
    def __init__(self):
        self.lock = threading.Lock()
        self.engine = Engine()
        self.cache = OrderedDict()
        self.last_round = 0

    def decide(self, payload):
        number = int(payload["roundNo"])
        digest = hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        key = number, digest
        with self.lock:
            if key in self.cache:
                return self.cache[key]
            if number == 1 and self.last_round > 1:
                self.engine, self.cache, self.last_round = Engine(), OrderedDict(), 0
            if number < self.last_round:
                return dict(EMPTY)
            response = self.engine.decide(payload)
            self.last_round = number
            self.cache[key] = response
            while len(self.cache) > 8:
                self.cache.popitem(last=False)
            return response


class AgentServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address):
        super().__init__(address, Handler)
        self.sessions = {}
        self.session_lock = threading.Lock()

    def decision(self, payload):
        team = payload["teamOur"]
        key = str(team.get("teamId", "")), team.get("type", "")
        with self.session_lock:
            if key not in self.sessions:
                self.sessions[key] = Session()
            session = self.sessions[key]
        return session.decide(payload)


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_json({"status": "ok", "agent": "Hugh"})

    def do_POST(self):
        start = perf_counter()
        number = "?"
        try:
            self.connection.settimeout(4)
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 8 * 1024 * 1024:
                raise ValueError("invalid request length")
            payload = json.loads(self.rfile.read(length).decode("utf-8-sig"))
            if not isinstance(payload, dict):
                raise ValueError("request must be an object")
            number = payload.get("roundNo", "?")
            response = self.server.decision(payload)
        except Exception:
            LOGGER.exception("round=%s decision failed", number)
            response = dict(EMPTY)
        self.send_json(response)
        elapsed = (perf_counter() - start) * 1000
        if elapsed > 500 or (isinstance(number, int) and (number - 1) % 130 == 0):
            LOGGER.info("round=%s actions=%d ms=%.1f", number, len(response["roleCommandMap"]), elapsed)

    def send_json(self, value):
        body = json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (OSError, TimeoutError):
            pass

    def log_message(self, format, *args):
        pass


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("port", type=int)
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("port must be between 1 and 65535")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    LOGGER.info("Hugh listening on 0.0.0.0:%s", args.port)
    AgentServer(("0.0.0.0", args.port)).serve_forever()
