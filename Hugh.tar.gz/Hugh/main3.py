#!/usr/bin/env python3
"""Platform entry point: python3 main3.py PORT."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
from hugh.server import main

if __name__ == "__main__":
    main()
