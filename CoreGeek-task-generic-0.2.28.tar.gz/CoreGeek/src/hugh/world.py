"""Authoritative turn state, geometry, and one reusable distance field per actor."""
from collections import Counter
from dataclasses import dataclass
from heapq import heappop, heappush
from functools import lru_cache

ACTORS = {"worker", "pioneer"}
TOWERS = {"rocket", "gatling", "railgun"}
ORES = {"stone", "iron", "copper"}
RANGES = {"rocket": (10, 15, 100000), "gatling": (3, 5, 7), "railgun": (6, 8, 10)}
PRICES = {"WeaponUpgradeVoucher1": 100, "WeaponUpgradeVoucher2": 150,
          "WallUpgradeVoucher1": 20, "WallUpgradeVoucher2": 30,
          "StationUpgradeVoucher1": 100, "StationUpgradeVoucher2": 150,
          "WallFixer": 10, "Medicine": 10, "Bomb": 100, "DizzyWeapon": 100}


def pos(raw):
    return int(raw["x"]), int(raw["y"])


def point(cell):
    return {"x": cell[0], "y": cell[1]}


def distance(a, b):
    return max(abs(a[0] - b[0]), abs(a[1] - b[1]))


def neighbors(p):
    return [(p[0] + dx, p[1] + dy) for dx in (-1, 0, 1) for dy in (-1, 0, 1) if dx or dy]


@dataclass
class Unit:
    id: int
    kind: str
    pos: tuple
    hp: int
    level: int
    cooldown: int
    reach: int
    capacity: int
    bag: Counter
    target: str = ""
    abnormal: str = ""
    power: int = 0

    @classmethod
    def read(cls, r):
        kind = r["roleType"]
        level = max(1, min(3, int(r.get("level") or 1)))
        reach = int(r.get("attackRange") or 0)
        if reach <= 0 and kind in RANGES:
            reach = RANGES[kind][level - 1]
        raw_capacity = r.get("backPackCapability")
        default_capacity = 40 if kind == "pioneer" else 100 if kind == "worker" else 0
        capacity = default_capacity if raw_capacity is None else int(raw_capacity)
        return cls(int(r["id"]), kind, pos(r["pos"]), int(r.get("health", 0)), level,
                   int(r.get("cooldown") or 0), reach, capacity,
                   Counter(r.get("backpack") or []), r.get("targetTeam", ""),
                   r.get("abnormalState", ""), int(r.get("attackPower") or 0))

    @property
    def cells(self):
        x, y = self.pos
        return {(x, y), (x + 1, y), (x, y - 1), (x + 1, y - 1)} if self.kind == "station" else {self.pos}

    @property
    def free(self):
        return max(0, self.capacity - self.bag.total())

    @property
    def max_hp(self):
        if self.kind == "station":
            return 1500 * self.level
        if self.kind in TOWERS | {"wall"}:
            return 500 + 500 * self.level
        return 220 if self.kind == "worker" else 200


class World:
    def __init__(self, payload):
        self.raw = payload
        self.round = int(payload["roundNo"])
        self.tick = (self.round - 1) % 130
        self.day = (self.round - 1) // 130 + 1
        self.daylight = self.tick < 70
        info, team = payload["mapInfo"], payload["teamOur"]
        self.width, self.height = int(info["width"]), int(info["height"])
        self.side, self.gold = team.get("type") or "challenger", int(team.get("goldNum") or 0)
        self.zones = {pos(z["pos"]): z["neutralType"] for z in info.get("zones") or []}
        self.ours = [Unit.read(u) for u in team.get("roles") or [] if u.get("health", 0) > 0]
        self.enemies = [Unit.read(u) for u in (payload.get("teamEnemy") or {}).get("roles") or [] if u.get("health", 0) > 0]
        self.robots = [Unit.read(u) for u in (payload.get("robot") or {}).get("roles") or [] if u.get("health", 0) > 0]
        self.actors = sorted((u for u in self.ours if u.kind in ACTORS), key=lambda u: u.id)
        self.workers = [u for u in self.actors if u.kind == "worker"]
        self.pioneer = next((u for u in self.actors if u.kind == "pioneer"), None)
        self.base = next((u for u in self.ours if u.kind == "station"), None)
        self.towers = [u for u in self.ours if u.kind in TOWERS]
        self.walls = [u for u in self.ours if u.kind == "wall"]
        self.by_id = {u.id: u for u in self.ours}
        self.by_pos = {cell: u for u in self.ours + self.enemies for cell in u.cells}
        self.static = {p for p, name in self.zones.items() if name != "land"}
        for u in self.ours + self.enemies:
            if u.kind not in ACTORS:
                self.static.update(u.cells)
        self.tasks = team.get("playerTasks") or []
        self.vendor_prices = {p["name"]: int(p["price"]) for p in payload.get("vendorShopList") or []}
        self.shop_prices = dict(PRICES)
        self.shop_prices.update({p["name"]: int(p["price"]) for p in payload.get("weaponShopList") or []})
        self.danger = Counter()
        if not self.daylight:
            wall_cells = {u.pos for u in self.walls}
            for robot in self.robots:
                if robot.abnormal == "dizzy":
                    continue
                for dx in range(-3, 4):
                    for dy in range(-3, 4):
                        p = (robot.pos[0] + dx, robot.pos[1] + dy)
                        if self.inside(p) and not (set(ray(robot.pos, p)[1:-1]) & wall_cells):
                            self.danger[p] += 2 if robot.kind in ("smallRobot", "middleRobot") else 5

    def inside(self, p):
        return 0 <= p[0] < self.width and 0 <= p[1] < self.height

    def base_distance(self, p):
        return min(distance(p, c) for c in self.base.cells) if self.base else 100

    def ring(self, radius):
        if not self.base:
            return []
        x, y = self.base.pos
        return [(a, b) for a in range(x - radius, x + radius + 2)
                for b in range(y - radius - 1, y + radius + 1)
                if self.inside((a, b)) and self.base_distance((a, b)) == radius]

    def near(self, kind):
        return [p for p, name in self.zones.items() if name == kind]

    def stand_cells(self, target):
        cells = target.cells if isinstance(target, Unit) else {target}
        return {p for cell in cells for p in neighbors(cell) if self.inside(p) and p not in self.static}


@lru_cache(maxsize=8192)
def ray(a, b):
    """Integer raster used only for conservative threat estimates/fallback guns."""
    x, y = a
    dx, dy = abs(b[0] - x), abs(b[1] - y)
    sx, sy = (1 if x < b[0] else -1), (1 if y < b[1] else -1)
    err, cells = dx - dy, []
    while True:
        cells.append((x, y))
        if (x, y) == b:
            return tuple(cells)
        e = err * 2
        if e > -dy:
            err -= dy
            x += sx
        if e < dx:
            err += dx
            y += sy


class Route:
    def __init__(self, world, actor, blocked, first_penalty=None):
        self.cost = {actor.pos: 0}
        self.steps = {actor.pos: 0}
        self.first = {actor.pos: None}
        heap = [(0, actor.pos)]
        while heap:
            cost, here = heappop(heap)
            if cost != self.cost[here]:
                continue
            for p in neighbors(here):
                if not world.inside(p) or p in blocked:
                    continue
                new = cost + 1 + min(40, world.danger[p])
                if here == actor.pos and first_penalty:
                    new += first_penalty.get(p, 0)
                if new < self.cost.get(p, 1000000):
                    self.cost[p] = new
                    self.steps[p] = self.steps[here] + 1
                    self.first[p] = p if here == actor.pos else self.first[here]
                    heappush(heap, (new, p))

    def best(self, goals):
        return min((p for p in goals if p in self.cost), key=lambda p: (self.cost[p], p), default=None)
